import { AppShell } from '@/components/app-shell';
import ObligacionesPage from './ObligacionesPage';

export default function Page() {
  return (
    <AppShell>
      <ObligacionesPage />
    </AppShell>
  );
}
