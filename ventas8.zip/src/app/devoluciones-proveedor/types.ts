export interface DevolucionesProveedor { id:number; numero_devolucion:string; factura:string; proveedor:string; fecha_devolucion:string; motivo:string; total:number; responsable:string; estado:string; }
export type DevolucionesProveedorFormValues=Omit<DevolucionesProveedor,'id'>;
