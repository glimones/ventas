import { AppShell } from '@/components/app-shell';
import DevolucionesProveedorPage from './DevolucionesProveedorPage';

export default function Page() {
  return (
    <AppShell>
      <DevolucionesProveedorPage />
    </AppShell>
  );
}
