import { AppShell } from '@/components/app-shell';
import DespachosPage from './DespachosPage';

export default function Page() {
  return (
    <AppShell>
      <DespachosPage />
    </AppShell>
  );
}
