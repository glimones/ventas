export interface Despachos { id:number; codigo:string; pedido:string; cliente:string; bodega:string; transportista:string; guia_remision:string; fecha_despacho:string; fecha_entrega:string; estado:string; }
export type DespachosFormValues = Omit<Despachos,'id'>;
