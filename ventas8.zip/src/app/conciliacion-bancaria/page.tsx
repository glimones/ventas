import { AppShell } from '@/components/app-shell';
import ConciliacionBancariaPage from './ConciliacionBancariaPage';

export default function Page() {
  return (
    <AppShell>
      <ConciliacionBancariaPage />
    </AppShell>
  );
}
