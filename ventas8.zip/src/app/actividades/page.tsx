import { AppShell } from '@/components/app-shell';
import ActividadesPage from './ActividadesPage';

export default function Page() {
  return (
    <AppShell>
      <ActividadesPage />
    </AppShell>
  );
}
