import { AppShell } from '@/components/app-shell';
import CentrosCostosPage from './CentrosCostosPage';

export default function Page() {
  return (
    <AppShell>
      <CentrosCostosPage />
    </AppShell>
  );
}
