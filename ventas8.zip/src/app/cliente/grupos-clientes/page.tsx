import { AppShell } from '@/components/app-shell';
import GruposClientesPage from './GruposClientesPage';

export default function Page() {
  return (
    <AppShell>
      <GruposClientesPage />
    </AppShell>
  );
}
