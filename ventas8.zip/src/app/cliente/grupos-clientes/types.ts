export interface GruposClientes {
  id: number;
  codigo: string;
  nombre: string;
  criterio: string;
  descuento: number;
  limite_credito: number;
  clientes_asignados: number;
  estado: string;
}

export interface GruposClientesFormValues {
  codigo: string;
  nombre: string;
  criterio: string;
  descuento: number;
  limite_credito: number;
  clientes_asignados: number;
  estado: string;
}
