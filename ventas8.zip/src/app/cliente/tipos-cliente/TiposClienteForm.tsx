'use client';
import React from 'react';
import { TiposClienteFormValues } from './types';

interface Props {
  values: TiposClienteFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const TiposClienteForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre' className='form-label'>Nombre *</label>
          <input type='text' className='form-control' id='nombre' name='nombre' value={values.nombre || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-12'>
        <div className='mb-3'>
          <label htmlFor='segmento' className='form-label'>Segmento *</label>
          <select className='form-select' id='segmento' name='segmento' value={values.segmento || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='PERSONA NATURAL'>Persona natural</option>
            <option value='PERSONA JURIDICA'>Persona jurídica</option>
            <option value='INSTITUCIONAL'>Institucional</option>
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='limite_credito' className='form-label'>Límite de crédito</label>
          <input type='number' min='0' step='0.01' className='form-control' id='limite_credito' name='limite_credito' value={values.limite_credito || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='dias_credito' className='form-label'>Días de crédito</label>
          <input type='number' min='0' className='form-control' id='dias_credito' name='dias_credito' value={values.dias_credito || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='descuento_maximo' className='form-label'>Descuento máximo (%)</label>
          <input type='number' min='0' max='100' step='0.01' className='form-control' id='descuento_maximo' name='descuento_maximo' value={values.descuento_maximo || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default TiposClienteForm;
