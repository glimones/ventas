import { AppShell } from '@/components/app-shell';
import TiposClientePage from './TiposClientePage';

export default function Page() {
  return (
    <AppShell>
      <TiposClientePage />
    </AppShell>
  );
}
