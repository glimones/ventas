export interface TiposCliente {
  id: number;
  codigo: string;
  nombre: string;
  segmento: string;
  limite_credito: number;
  dias_credito: number;
  descuento_maximo: number;
  estado: string;
}

export interface TiposClienteFormValues {
  codigo: string;
  nombre: string;
  segmento: string;
  limite_credito: number;
  dias_credito: number;
  descuento_maximo: number;
  estado: string;
}
