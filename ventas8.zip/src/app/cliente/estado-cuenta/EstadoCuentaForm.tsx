'use client';
import React from 'react';
import { EstadoCuentaFormValues } from './types';

interface Props {
  values: EstadoCuentaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const EstadoCuentaForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='cliente' className='form-label'>Cliente *</label>
          <input type='text' className='form-control' id='cliente' name='cliente' value={values.cliente || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='tipo_documento' className='form-label'>Tipo de documento *</label>
          <select className='form-select' id='tipo_documento' name='tipo_documento' value={values.tipo_documento || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='FACTURA'>Factura</option>
            <option value='NOTA_CREDITO'>Nota de crédito</option>
            <option value='RECIBO'>Recibo</option>
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='fecha_emision' className='form-label'>Fecha de emisión *</label>
          <input type='date' className='form-control' id='fecha_emision' name='fecha_emision' value={values.fecha_emision || ''} onChange={handleInputChange} required />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='fecha_vencimiento' className='form-label'>Fecha de vencimiento *</label>
          <input type='date' className='form-control' id='fecha_vencimiento' name='fecha_vencimiento' value={values.fecha_vencimiento || ''} onChange={handleInputChange} required />
        </div>
      </div>
      <div className='col-md-4'>
        <div className='mb-3'>
          <label htmlFor='total' className='form-label'>Total</label>
          <input type='number' min='0' step='0.01' className='form-control' id='total' name='total' value={values.total || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-4'>
        <div className='mb-3'>
          <label htmlFor='saldo' className='form-label'>Saldo pendiente</label>
          <input type='number' min='0' step='0.01' className='form-control' id='saldo' name='saldo' value={values.saldo || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-4'>
        <div className='mb-3'>
          <label htmlFor='dias_mora' className='form-label'>Días de mora</label>
          <input type='number' min='0' className='form-control' id='dias_mora' name='dias_mora' value={values.dias_mora || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default EstadoCuentaForm;
