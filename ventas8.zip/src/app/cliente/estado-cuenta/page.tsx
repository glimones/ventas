import { AppShell } from '@/components/app-shell';
import EstadoCuentaPage from './EstadoCuentaPage';

export default function Page() {
  return (
    <AppShell>
      <EstadoCuentaPage />
    </AppShell>
  );
}
