export interface Sucursales {
  id: number;
  codigo: string;
  nombre: string;
  direccion: string;
  ciudad: string;
  responsable: string;
  telefono: string;
  email: string;
  estado: string;
}

export interface SucursalesFormValues {
  codigo: string;
  nombre: string;
  direccion: string;
  ciudad: string;
  responsable: string;
  telefono: string;
  email: string;
  estado: string;
}
