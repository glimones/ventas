import { AppShell } from '@/components/app-shell';
import SucursalesPage from './SucursalesPage';

export default function Page() {
  return (
    <AppShell>
      <SucursalesPage />
    </AppShell>
  );
}
