'use client';
import React, { useState } from 'react';
import { Sucursales, SucursalesFormValues } from './types';
import SucursalesModal from './SucursalesModal';
import './bootstrap-sucursales.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: SucursalesFormValues = {
  codigo: '',
  nombre: '',
  direccion: '',
  ciudad: '',
  responsable: '',
  telefono: '',
  email: '',
  estado: 'Activo',
};

const initialData: Sucursales[] = [
  { id: 1, codigo: 'UIO-001', nombre: 'Matriz Quito', direccion: 'Av. 10 de Agosto N34-120', ciudad: 'Quito', responsable: 'Carla Morales', telefono: '02 245 8000', email: 'quito@empresa.ec', estado: 'Activo' },
  { id: 2, codigo: 'GYE-001', nombre: 'Sucursal Guayaquil', direccion: 'Av. Carlos Julio Arosemena km 2', ciudad: 'Guayaquil', responsable: 'Diego Vera', telefono: '04 398 2000', email: 'guayaquil@empresa.ec', estado: 'Activo' },
];

export default function SucursalesPage() {
  const [data, setData] = useState<Sucursales[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<SucursalesFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (item: Sucursales) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      nombre: item.nombre || '',
      direccion: item.direccion || '',
      ciudad: item.ciudad || '',
      responsable: item.responsable || '',
      telefono: item.telefono || '',
      email: item.email || '',
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, ...form }
          : item
      ));
    } else {
      const nuevo: Sucursales = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        ...form,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre.toLowerCase().includes(filtro.toLowerCase()) ||
    item.direccion.toLowerCase().includes(filtro.toLowerCase()) ||
    item.ciudad.toLowerCase().includes(filtro.toLowerCase()) ||
    item.responsable.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Sucursales</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Dirección</th>
                <th>Ciudad</th>
                <th>Responsable</th>
                <th>Contacto</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={10} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.nombre}</td>
                  <td>{item.direccion}</td>
                  <td>{item.ciudad}</td>
                  <td>{item.responsable}</td>
                  <td>{item.telefono}<br /><small className='text-muted'>{item.email}</small></td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <SucursalesModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
