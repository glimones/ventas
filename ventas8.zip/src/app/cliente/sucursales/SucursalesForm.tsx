'use client';
import React from 'react';
import { SucursalesFormValues } from './types';

interface Props {
  values: SucursalesFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const SucursalesForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre' className='form-label'>Nombre *</label>
          <input type='text' className='form-control' id='nombre' name='nombre' value={values.nombre || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-12'>
        <div className='mb-3'>
          <label htmlFor='direccion' className='form-label'>Dirección *</label>
          <input type='text' className='form-control' id='direccion' name='direccion' value={values.direccion || ''} onChange={handleInputChange} required autoComplete='street-address' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='ciudad' className='form-label'>Ciudad *</label>
          <input type='text' className='form-control' id='ciudad' name='ciudad' value={values.ciudad || ''} onChange={handleInputChange} required autoComplete='address-level2' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='responsable' className='form-label'>Responsable *</label>
          <input type='text' className='form-control' id='responsable' name='responsable' value={values.responsable || ''} onChange={handleInputChange} required autoComplete='name' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='telefono' className='form-label'>Teléfono</label>
          <input type='tel' className='form-control' id='telefono' name='telefono' value={values.telefono || ''} onChange={handleInputChange} autoComplete='tel' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='email' className='form-label'>Correo electrónico</label>
          <input type='email' className='form-control' id='email' name='email' value={values.email || ''} onChange={handleInputChange} autoComplete='email' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default SucursalesForm;
