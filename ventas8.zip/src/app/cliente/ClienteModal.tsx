import React, { useEffect } from "react";
import { ClienteFormValues } from "./types";
import ClienteForm from "./ClienteForm";
import "./cliente.css";

interface Props {
  show: boolean;
  editando: boolean;
  values: ClienteFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  saving: boolean;
  submitError: string;
}

const ClienteModal: React.FC<Props> = ({
  show,
  editando,
  values,
  onChange,
  onClose,
  onSubmit,
  saving,
  submitError,
}) => {
  // Prevenir scroll y eventos de tecla en el fondo cuando el modal está abierto
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && show) {
        e.preventDefault();
        onClose();
      }
    };

    if (show) {
      document.body.classList.add('modal-open');
      document.body.style.overflow = 'hidden';
      document.body.style.paddingRight = '15px';
      document.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.classList.remove('modal-open');
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
      document.removeEventListener('keydown', handleKeyDown);
    }
    
    return () => {
      document.body.classList.remove('modal-open');
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [show, onClose]);

  if (!show) return null;
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onSubmit(e);
  };

  return (
      <div 
           className="modal-overlay"
        style={{ 
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1050,
        padding: '20px'
      }}
      >
       <div 
        className="modal-container"
        style={{
          background: 'white',
          borderRadius: '12px',
          width: '100%',
          maxWidth: '800px',
          maxHeight: '95vh',
          overflow: 'hidden',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
            <form onSubmit={handleSubmit}>
          <div className="modal-header text-white" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#343a40' }}>
            <h5 className="modal-title" style={{ margin: 0, fontSize: '1.25rem', fontWeight: 600 }}>
              {editando ? "Editar Cliente" : "Nuevo Cliente"}
            </h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={onClose}
                  aria-label="Cerrar"
              style={{ 
                background: 'none',
                border: 'none',
                color: 'white',
                fontSize: '1.5rem',
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer'
              }}
                >
              ×
            </button>
              </div>
          <div className="modal-body" style={{ 
            padding: '1.5rem', 
            flex: 1, 
            overflowY: 'auto', 
            backgroundColor: '#fafbfc',
            minHeight: '200px',
            maxHeight: 'calc(95vh - 180px)' 
          }}>
                <p className="text-muted mb-3">Los campos marcados con * son obligatorios</p>
                {submitError && <div className="alert alert-danger" role="alert">{submitError}</div>}
                <ClienteForm values={values} onChange={onChange} />
              </div>
               <div className="modal-footer" style={{ padding: '1rem 1.5rem', backgroundColor: 'white', borderTop: '1px solid #e9ecef', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={onClose}
                  disabled={saving}
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="btn btn-success"
                  disabled={saving}
                >
                  {saving ? "Guardando..." : "Guardar"}
                </button>
              </div>
            </form>
          </div>
        </div>
    
  );
};

export default ClienteModal;