import DomainCrud from '@/components/domain-crud';import{domainConfigs}from '@/components/domain-config';export default function AtsPage(){return <DomainCrud config={domainConfigs.ats}/>}
