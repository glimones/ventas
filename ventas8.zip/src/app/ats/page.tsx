import { AppShell } from '@/components/app-shell';
import AtsPage from './AtsPage';

export default function Page() {
  return (
    <AppShell>
      <AtsPage />
    </AppShell>
  );
}
