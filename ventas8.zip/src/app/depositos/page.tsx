import { AppShell } from '@/components/app-shell';
import DepositosPage from './DepositosPage';

export default function Page() {
  return (
    <AppShell>
      <DepositosPage />
    </AppShell>
  );
}
