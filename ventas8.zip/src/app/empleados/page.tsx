import { AppShell } from '@/components/app-shell';
import EmpleadosPage from './EmpleadosPage';

export default function Page() {
  return (
    <AppShell>
      <EmpleadosPage />
    </AppShell>
  );
}
