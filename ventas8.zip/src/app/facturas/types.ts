// Tipos de datos para facturas electrónicas Ecuador SRI

export interface DetalleFactura {
  id: number;
  codigo_principal: string;
  codigo_auxiliar?: string;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  descuento: number;
  precio_total_sin_impuesto: number;
  codigo_porcentaje_iva: string; // 0, 2, 3 (0%, 12%, 14%)
  tarifa_iva: number;
  valor_iva: number;
  precio_total_con_impuesto: number;
}

export interface InfoTributaria {
  ambiente: string; // 1 = Pruebas, 2 = Producción
  tipo_emision: string; // 1 = Emisión normal
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  clave_acceso: string;
  cod_doc: string; // 01 = Factura
  estab: string; // Establecimiento
  ptoEmi: string; // Punto de emisión
  secuencial: string;
  direccion_matriz: string;
}

export interface InfoFactura {
  fecha_emision: string; // DD/MM/YYYY
  direccion_establecimiento: string;
  contribuyente_especial?: string;
  obligado_contabilidad: string; // SI o NO
  tipo_identificacion_comprador: string; // 04 = RUC, 05 = Cédula, 06 = Pasaporte, 07 = Venta consumidor final, 08 = Identificación exterior
  guia_remision?: string;
  razon_social_comprador: string;
  identificacion_comprador: string;
  direccion_comprador?: string;
  total_sin_impuestos: number;
  total_descuento: number;
  propina: number;
  importe_total: number;
  moneda: string; // DOLAR
  forma_pago: string; // 01 = Sin utilización del sistema financiero
  valor_modificacion?: number;
}

export interface TotalConImpuesto {
  codigo: string; // 2 = IVA
  codigo_porcentaje: string; // 0, 2, 3
  descuento_adicional: number;
  base_imponible: number;
  tarifa: number;
  valor: number;
}

export interface Pago {
  forma_pago: string; // 01 = Sin utilización del sistema financiero, 15 = Compensación de deudas, 16 = Tarjeta de débito, 17 = Dinero electrónico, 18 = Tarjeta prepago, 19 = Tarjeta de crédito, 20 = Otros con utilización del sistema financiero, 21 = Endoso de títulos
  total: number;
  plazo?: number;
  unidad_tiempo?: string; // dias, meses, años
}

export type EstadoFactura =
  | 'PENDIENTE'
  | 'AUTORIZADA'
  | 'RECHAZADA'
  | 'DEVUELTA';

export interface HistorialEstadoFactura {
  estado: EstadoFactura;
  fecha: string;
  origen: 'VENTA_RAPIDA' | 'SIMULADOR_SRI' | 'SISTEMA';
  detalle: string;
}

export interface Factura {
  id: number;
  origen_venta_rapida?: string;
  destino_ingreso?: string;
  info_tributaria: InfoTributaria;
  info_factura: InfoFactura;
  detalles: DetalleFactura[];
  total_con_impuestos: TotalConImpuesto[];
  pagos: Pago[];
  estado_sri: EstadoFactura;
  historial_estados?: HistorialEstadoFactura[];
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  xml_generado?: string;
  observaciones_sri?: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
}

export interface FacturaFormValues {
  // Info Tributaria
  ambiente: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
  
  // Info Factura
  fecha_emision: string;
  direccion_establecimiento: string;
  contribuyente_especial: string;
  obligado_contabilidad: string;
  tipo_identificacion_comprador: string;
  guia_remision: string;
  razon_social_comprador: string;
  identificacion_comprador: string;
  direccion_comprador: string;
  propina: number;
  moneda: string;
  forma_pago: string;
  
  // Detalles se manejarán por separado en el componente
}

export interface DetalleFormValues {
  codigo_principal: string;
  codigo_auxiliar: string;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  descuento: number;
  codigo_porcentaje_iva: string;
}

export interface QuickSaleInvoiceDraft {
  saleNumber: string;
  paymentDestination: string;
  form: FacturaFormValues;
  detalles: DetalleFormValues[];
}

export const QUICK_SALE_INVOICE_DRAFT_KEY = "quick-sale-electronic-invoice-draft";
export const QUICK_SALE_INVOICE_DRAFT_NOTE =
  "Borrador local desde Venta rápida; pendiente de revisión y envío al SRI.";
export const FACTURAS_HISTORY_STORAGE_KEY = "facturas-history-v1";
export const IVA_RATE_BY_CODE: Record<string, number> = {
  "0": 0,
  "2": 0.12,
  "3": 0.14,
  "4": 0.15,
};

// Opciones para los selectores
export const TIPO_IDENTIFICACION_OPTIONS = [
  { value: '04', label: 'RUC' },
  { value: '05', label: 'Cédula' },
  { value: '06', label: 'Pasaporte' },
  { value: '07', label: 'Venta a consumidor final' },
  { value: '08', label: 'Identificación del exterior' },
];

export const CODIGO_IVA_OPTIONS = [
  { value: '0', label: '0% IVA' },
  { value: '2', label: '12% IVA' },
  { value: '3', label: '14% IVA' },
  { value: '4', label: '15% IVA' },
];

export const FORMA_PAGO_OPTIONS = [
  { value: '01', label: 'Sin utilización del sistema financiero' },
  { value: '15', label: 'Compensación de deudas' },
  { value: '16', label: 'Tarjeta de débito' },
  { value: '17', label: 'Dinero electrónico' },
  { value: '18', label: 'Tarjeta prepago' },
  { value: '19', label: 'Tarjeta de crédito' },
  { value: '20', label: 'Otros con utilización del sistema financiero' },
  { value: '21', label: 'Endoso de títulos' },
];

export const AMBIENTE_OPTIONS = [
  { value: '1', label: 'Pruebas' },
  { value: '2', label: 'Producción' },
];
