"use client";

import React, { useEffect } from "react";
import { X } from "lucide-react";
import {
  EstadoFactura,
  Factura,
  HistorialEstadoFactura,
  QUICK_SALE_INVOICE_DRAFT_NOTE,
} from "./types";

interface Props {
  factura: Factura;
  onClose: () => void;
  getFormaPagoDescripcion: (codigo: string) => string;
}

const estadoLabel: Record<EstadoFactura, string> = {
  PENDIENTE: "Pendiente",
  AUTORIZADA: "Autorizada",
  RECHAZADA: "Rechazada",
  DEVUELTA: "Devuelta",
};

const estadoClass: Record<EstadoFactura, string> = {
  PENDIENTE: "is-pending",
  AUTORIZADA: "is-authorized",
  RECHAZADA: "is-rejected",
  DEVUELTA: "is-returned",
};

const formatDate = (value: string) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "Fecha no disponible"
    : date.toLocaleString("es-EC");
};

const formatCurrency = (value: number) =>
  value.toLocaleString("es-EC", { style: "currency", currency: "USD" });

const FacturaSeguimientoModal: React.FC<Props> = ({
  factura,
  onClose,
  getFormaPagoDescripcion,
}) => {
  const isQuickSaleDraft =
    factura.observaciones_sri === QUICK_SALE_INVOICE_DRAFT_NOTE;
  const history: HistorialEstadoFactura[] =
    factura.historial_estados?.length
      ? factura.historial_estados
      : [
          {
            estado: factura.estado_sri,
            fecha: factura.fecha_autorizacion ?? factura.fecha_creacion,
            origen: isQuickSaleDraft ? "VENTA_RAPIDA" : "SIMULADOR_SRI",
            detalle:
              factura.observaciones_sri ??
              (isQuickSaleDraft
                ? "Borrador local pendiente de revisión; no se envió al SRI."
                : `Estado registrado por el simulador local: ${estadoLabel[factura.estado_sri]}.`),
          },
        ];

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };

    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose]);

  const documentNumber = [
    factura.info_tributaria.estab,
    factura.info_tributaria.ptoEmi,
    factura.info_tributaria.secuencial.padStart(9, "0"),
  ].join("-");

  return (
    <div
      className="factura-history-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        className="factura-history-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="factura-history-title"
      >
        <header className="factura-history-header">
          <div>
            <p className="factura-history-eyebrow">Historial del documento</p>
            <h2 id="factura-history-title">Seguimiento de factura</h2>
            <p className="factura-history-number">{documentNumber}</p>
          </div>
          <button
            type="button"
            className="factura-history-close"
            onClick={onClose}
            aria-label="Cerrar seguimiento"
          >
            <X size={20} />
          </button>
        </header>

        <div className="factura-history-body">
          <div className="factura-history-summary">
            <div>
              <span>Cliente</span>
              <strong>{factura.info_factura.razon_social_comprador}</strong>
              <small>{factura.info_factura.identificacion_comprador}</small>
            </div>
            <div>
              <span>Total</span>
              <strong>{formatCurrency(factura.info_factura.importe_total)}</strong>
              <small>{factura.info_factura.fecha_emision}</small>
            </div>
            <div>
              <span>Estado actual</span>
              <strong
                className={`factura-history-status ${estadoClass[factura.estado_sri]}`}
              >
                {isQuickSaleDraft
                  ? "Borrador local pendiente"
                  : estadoLabel[factura.estado_sri]}
              </strong>
              <small>{isQuickSaleDraft ? "Solo en este navegador" : "Entorno simulado"}</small>
            </div>
          </div>

          <section className="factura-history-section">
            <h3>Actividad</h3>
            <ol className="factura-history-timeline">
              {history.map((event, index) => (
                <li
                  className={`factura-history-event ${estadoClass[event.estado]} ${
                    index === history.length - 1 ? "is-current" : ""
                  }`}
                  key={`${event.fecha}-${index}`}
                >
                  <span className="factura-history-dot" aria-hidden="true" />
                  <div>
                    <div className="factura-history-event-heading">
                      <strong>
                        {event.origen === "VENTA_RAPIDA"
                          ? "Borrador local guardado"
                          : event.origen === "SIMULADOR_SRI"
                            ? `Respuesta del simulador: ${estadoLabel[event.estado]}`
                            : `Documento ${estadoLabel[event.estado].toLowerCase()}`}
                      </strong>
                      <time dateTime={event.fecha}>{formatDate(event.fecha)}</time>
                    </div>
                    <p>{event.detalle}</p>
                  </div>
                </li>
              ))}
              {isQuickSaleDraft && (
                <li className="factura-history-event is-upcoming">
                  <span className="factura-history-dot" aria-hidden="true" />
                  <div>
                    <div className="factura-history-event-heading">
                      <strong>Envío al SRI</strong>
                      <span>No realizado</span>
                    </div>
                    <p>
                      Este flujo de demostración no envía ni autoriza facturas
                      electrónicas.
                    </p>
                  </div>
                </li>
              )}
            </ol>
          </section>

          <section className="factura-history-section">
            <h3>Datos de la venta</h3>
            <dl className="factura-history-metadata">
              <div>
                <dt>Forma de pago</dt>
                <dd>{getFormaPagoDescripcion(factura.info_factura.forma_pago)}</dd>
              </div>
              {factura.origen_venta_rapida && (
                <div>
                  <dt>Referencia de Venta rápida</dt>
                  <dd>{factura.origen_venta_rapida}</dd>
                </div>
              )}
              {factura.destino_ingreso && (
                <div>
                  <dt>Destino del cobro</dt>
                  <dd>{factura.destino_ingreso}</dd>
                </div>
              )}
              {factura.observaciones_sri &&
                !isQuickSaleDraft &&
                factura.observaciones_sri !== QUICK_SALE_INVOICE_DRAFT_NOTE && (
                  <div>
                    <dt>Observaciones</dt>
                    <dd>{factura.observaciones_sri}</dd>
                  </div>
                )}
            </dl>
          </section>

          <section className="factura-history-section">
            <h3>Productos</h3>
            <div className="factura-history-items">
              {factura.detalles.map((detalle) => (
                <div className="factura-history-item" key={detalle.id}>
                  <div>
                    <strong>{detalle.descripcion}</strong>
                    <small>
                      {detalle.cantidad} × {formatCurrency(detalle.precio_unitario)}
                    </small>
                  </div>
                  <strong>{formatCurrency(detalle.precio_total_con_impuesto)}</strong>
                </div>
              ))}
            </div>
          </section>
        </div>

        <footer className="factura-history-footer">
          <p>
            El historial se conserva localmente en este navegador; no se ha
            guardado en el servidor.
          </p>
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cerrar
          </button>
        </footer>
      </section>
    </div>
  );
};

export default FacturaSeguimientoModal;
