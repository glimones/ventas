import { AppShell } from '@/components/app-shell';
import BancosPage from './BancosPage';

export default function Page() {
  return (
    <AppShell>
      <BancosPage />
    </AppShell>
  );
}
