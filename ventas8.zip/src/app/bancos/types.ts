export interface Bancos{id:number;codigo:string;nombre:string;numero_cuenta:string;tipo_cuenta:string;moneda:string;saldo:number;estado:string}export type BancosFormValues=Omit<Bancos,'id'>;
