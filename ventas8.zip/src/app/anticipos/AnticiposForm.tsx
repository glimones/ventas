"use client";
import React from "react";
import { AnticiposFormValues } from "./types";

interface Props {
  values: AnticiposFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const AnticiposForm: React.FC<Props> = ({ values, onChange }) => (
  <div className="row g-3">
    <div className="col-md-3">
      <label htmlFor="numero_anticipo" className="form-label">N� Anticipo *</label>
      <input type="text" className="form-control" id="numero_anticipo" name="numero_anticipo" value={values.numero_anticipo} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="fecha_anticipo" className="form-label">Fecha *</label>
      <input type="date" className="form-control" id="fecha_anticipo" name="fecha_anticipo" value={values.fecha_anticipo} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="tipo" className="form-label">Tipo *</label>
      <select className="form-select" id="tipo" name="tipo" value={values.tipo} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="PROVEEDOR">Proveedor</option>
        <option value="CLIENTE">Cliente</option>
        <option value="EMPLEADO">Empleado</option>
      </select>
    </div>
    <div className="col-md-3">
      <label htmlFor="monto" className="form-label">Monto *</label>
      <input type="number" step="0.01" className="form-control" id="monto" name="monto" value={values.monto} onChange={onChange} required />
    </div>
    <div className="col-md-6">
      <label htmlFor="proveedor" className="form-label">Nombre *</label>
      <input type="text" className="form-control" id="proveedor" name="proveedor" value={values.proveedor} onChange={onChange} required />
    </div>
    <div className="col-md-6">
      <label htmlFor="identificacion_proveedor" className="form-label">Identificaci�n *</label>
      <input type="text" className="form-control" id="identificacion_proveedor" name="identificacion_proveedor" value={values.identificacion_proveedor} onChange={onChange} required />
    </div>
    <div className="col-md-4">
      <label htmlFor="forma_pago" className="form-label">Forma de Pago</label>
      <select className="form-select" id="forma_pago" name="forma_pago" value={values.forma_pago} onChange={onChange}>
        <option value="">Seleccione...</option>
        <option value="TRANSFERENCIA">Transferencia</option>
        <option value="CHEQUE">Cheque</option>
        <option value="EFECTIVO">Efectivo</option>
        <option value="TARJETA">Tarjeta</option>
      </select>
    </div>
    <div className="col-md-4">
      <label htmlFor="referencia" className="form-label">Referencia</label>
      <input type="text" className="form-control" id="referencia" name="referencia" value={values.referencia} onChange={onChange} />
    </div>
    <div className="col-md-4">
      <label htmlFor="estado" className="form-label">Estado *</label>
      <select className="form-select" id="estado" name="estado" value={values.estado} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="PENDIENTE">Pendiente</option>
        <option value="APLICADO">Aplicado</option>
        <option value="ANULADO">Anulado</option>
      </select>
    </div>
    <div className="col-md-12">
      <label htmlFor="descripcion" className="form-label">Descripci�n</label>
      <textarea className="form-control" id="descripcion" name="descripcion" value={values.descripcion} onChange={onChange} rows={3} />
    </div>
  </div>
);

export default AnticiposForm;