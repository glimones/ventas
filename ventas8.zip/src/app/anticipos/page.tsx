import { AppShell } from '@/components/app-shell';
import AnticiposPage from './AnticiposPage';

export default function Page() {
  return (
    <AppShell>
      <AnticiposPage />
    </AppShell>
  );
}
