// Tipos de datos para Anticipos (pagos adelantados a proveedores/clientes)

export interface Anticipo {
  id: number;
  numero_anticipo: string;
  fecha_anticipo: string;
  proveedor: string;
  identificacion_proveedor: string;
  tipo: "PROVEEDOR" | "CLIENTE" | "EMPLEADO";
  monto: number;
  saldo_pendiente: number;
  forma_pago: string;
  referencia: string;
  descripcion: string;
  estado: "PENDIENTE" | "APLICADO" | "ANULADO";
  comprobante_pdf?: string;
  fecha_creacion: string;
}

export interface AnticiposFormValues {
  numero_anticipo: string;
  fecha_anticipo: string;
  proveedor: string;
  identificacion_proveedor: string;
  tipo: string;
  monto: number;
  forma_pago: string;
  referencia: string;
  descripcion: string;
  estado: string;
}