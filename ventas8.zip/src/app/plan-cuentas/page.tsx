import { AppShell } from '@/components/app-shell';
import PlanCuentasPage from './PlanCuentasPage';

export default function Page() {
  return (
    <AppShell>
      <PlanCuentasPage />
    </AppShell>
  );
}
