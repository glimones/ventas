import { AppShell } from '@/components/app-shell';
import CierrePeriodosPage from './CierrePeriodosPage';

export default function Page() {
  return (
    <AppShell>
      <CierrePeriodosPage />
    </AppShell>
  );
}
