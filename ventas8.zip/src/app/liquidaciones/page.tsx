import { AppShell } from '@/components/app-shell';
import LiquidacionesPage from './LiquidacionesPage';

export default function Page() {
  return (
    <AppShell>
      <LiquidacionesPage />
    </AppShell>
  );
}
