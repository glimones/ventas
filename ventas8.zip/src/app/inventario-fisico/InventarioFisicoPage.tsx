"use client";

import React, { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Barcode,
  CheckCircle2,
  ClipboardCheck,
  ClipboardList,
  PackageSearch,
  RefreshCw,
  Search,
} from "lucide-react";
import {
  EstadoInventarioFisico,
  InventarioFisico,
  InventarioFisicoCatalogos,
  InventarioFisicoDetalle,
} from "./types";
import "./bootstrap-inventario-fisico.css";

interface ConteoForm {
  bodega_id: string;
  categoria_id: string;
  ubicacion_id: string;
  fecha_conteo: string;
  responsable_nombre: string;
}

interface ApiResponse<T> {
  data?: T;
  error?: string;
}

const fechaLocal = () => {
  const date = new Date();
  date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
  return date.toISOString().slice(0, 10);
};

const formInicial = (): ConteoForm => ({
  bodega_id: "",
  categoria_id: "",
  ubicacion_id: "",
  fecha_conteo: fechaLocal(),
  responsable_nombre: "",
});

const formatearCantidad = (value: number) =>
  value.toLocaleString("es-EC", { maximumFractionDigits: 4 });

const formatearDinero = (value: number) =>
  value.toLocaleString("es-EC", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
  });

const obtenerEstadoLabel = (estado: EstadoInventarioFisico) => {
  switch (estado) {
    case "EN_CONTEO":
      return "En conteo ciego";
    case "EN_REVISION":
      return "Pendiente de aprobación";
    case "APLICADO":
      return "Ajustes aplicados";
    default:
      return estado;
  }
};

async function leerData<T>(response: Response): Promise<T> {
  const payload = (await response.json()) as ApiResponse<T>;
  if (!response.ok) {
    throw new Error(payload.error || "No se pudo completar la solicitud.");
  }
  if (payload.data === undefined) {
    throw new Error("La respuesta del servidor no contiene datos.");
  }
  return payload.data;
}

export default function InventarioFisicoPage() {
  const [inventarios, setInventarios] = useState<InventarioFisico[]>([]);
  const [catalogos, setCatalogos] =
    useState<InventarioFisicoCatalogos | null>(null);
  const [detalle, setDetalle] = useState<InventarioFisicoDetalle | null>(null);
  const [conteos, setConteos] = useState<Record<number, string>>({});
  const [form, setForm] = useState<ConteoForm>(formInicial);
  const [busqueda, setBusqueda] = useState("");
  const [responsableAprobacion, setResponsableAprobacion] = useState("");
  const [confirmarAjustes, setConfirmarAjustes] = useState(false);
  const [inventarioSeleccionadoId, setInventarioSeleccionadoId] = useState<
    number | null
  >(null);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [cargandoInventarios, setCargandoInventarios] = useState(true);
  const [cargandoCatalogos, setCargandoCatalogos] = useState(true);
  const [cargandoDetalle, setCargandoDetalle] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [aplicando, setAplicando] = useState(false);
  const [errorInventarios, setErrorInventarios] = useState<string | null>(null);
  const [errorCatalogos, setErrorCatalogos] = useState<string | null>(null);
  const [errorDetalle, setErrorDetalle] = useState<string | null>(null);
  const [errorAccion, setErrorAccion] = useState<string | null>(null);
  const [mensaje, setMensaje] = useState<string | null>(null);
  const [versionInventarios, setVersionInventarios] = useState(0);
  const [versionDetalle, setVersionDetalle] = useState(0);

  useEffect(() => {
    const controller = new AbortController();
    const cargarInventarios = async () => {
      setCargandoInventarios(true);
      setErrorInventarios(null);
      try {
        const response = await fetch("/api/inventario-fisico", {
          cache: "no-store",
          signal: controller.signal,
        });
        const data = await leerData<InventarioFisico[]>(response);
        if (!controller.signal.aborted) setInventarios(data);
      } catch (loadError) {
        if (controller.signal.aborted) return;
        setErrorInventarios(
          loadError instanceof Error
            ? loadError.message
            : "No se pudo cargar el historial de conteos.",
        );
      } finally {
        if (!controller.signal.aborted) setCargandoInventarios(false);
      }
    };
    void cargarInventarios();
    return () => controller.abort();
  }, [versionInventarios]);

  useEffect(() => {
    const controller = new AbortController();
    const cargarCatalogos = async () => {
      setCargandoCatalogos(true);
      setErrorCatalogos(null);
      try {
        const response = await fetch("/api/productos/catalogos", {
          cache: "no-store",
          signal: controller.signal,
        });
        const data =
          (await response.json()) as InventarioFisicoCatalogos & {
            error?: string;
          };
        if (!response.ok) {
          throw new Error(data.error || "No se pudieron cargar los catálogos.");
        }
        if (
          !Array.isArray(data.bodegas) ||
          !Array.isArray(data.categorias) ||
          !Array.isArray(data.ubicaciones)
        ) {
          throw new Error("La respuesta de catálogos no tiene un formato válido.");
        }
        if (!controller.signal.aborted) setCatalogos(data);
      } catch (loadError) {
        if (controller.signal.aborted) return;
        setErrorCatalogos(
          loadError instanceof Error
            ? loadError.message
            : "No se pudieron cargar las bodegas y filtros.",
        );
      } finally {
        if (!controller.signal.aborted) setCargandoCatalogos(false);
      }
    };
    void cargarCatalogos();
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (inventarioSeleccionadoId === null) {
      setDetalle(null);
      setConteos({});
      return;
    }

    const controller = new AbortController();
    const cargarDetalle = async () => {
      setCargandoDetalle(true);
      setErrorDetalle(null);
      setErrorAccion(null);
      try {
        const response = await fetch(
          `/api/inventario-fisico/${inventarioSeleccionadoId}`,
          { cache: "no-store", signal: controller.signal },
        );
        const data = await leerData<InventarioFisicoDetalle>(response);
        if (controller.signal.aborted) return;
        setDetalle(data);
        setConteos(
          Object.fromEntries(
            data.productos.map((producto) => [
              producto.producto_id,
              producto.cantidad_contada === null
                ? ""
                : String(producto.cantidad_contada),
            ]),
          ),
        );
        setResponsableAprobacion("");
        setConfirmarAjustes(false);
      } catch (loadError) {
        if (controller.signal.aborted) return;
        setErrorDetalle(
          loadError instanceof Error
            ? loadError.message
            : "No se pudo cargar el detalle del conteo.",
        );
      } finally {
        if (!controller.signal.aborted) setCargandoDetalle(false);
      }
    };
    void cargarDetalle();
    return () => controller.abort();
  }, [inventarioSeleccionadoId, versionDetalle]);

  const ubicacionesDeBodega = useMemo(
    () =>
      catalogos?.ubicaciones.filter(
        (ubicacion) => String(ubicacion.bodega_id) === form.bodega_id,
      ) ?? [],
    [catalogos, form.bodega_id],
  );

  const productosFiltrados = useMemo(() => {
    if (!detalle) return [];
    const query = busqueda.trim().toLocaleLowerCase();
    if (!query) return detalle.productos;
    return detalle.productos.filter((producto) =>
      [
        producto.codigo,
        producto.nombre,
        producto.categoria,
        producto.ubicacion,
      ]
        .join(" ")
        .toLocaleLowerCase()
        .includes(query),
    );
  }, [busqueda, detalle]);

  const conteoCompleto = useMemo(
    () =>
      Boolean(
        detalle?.productos.length &&
          detalle.productos.every((producto) => {
            const value = conteos[producto.producto_id];
            if (value === undefined || value.trim() === "") return false;
            const quantity = Number(value);
            const normalized = Math.round(quantity * 10_000) / 10_000;
            return (
              Number.isFinite(quantity) &&
              quantity >= 0 &&
              Math.abs(quantity - normalized) <= 0.0000001
            );
          }),
      ),
    [conteos, detalle],
  );

  const productosRevisados = useMemo(
    () =>
      detalle?.productos.filter(
        (producto) =>
          producto.cantidad_sistema !== undefined &&
          producto.cantidad_contada !== null,
      ) ?? [],
    [detalle],
  );

  const productosConDiferencia = useMemo(
    () =>
      productosRevisados.filter(
        (producto) =>
          Number(producto.cantidad_contada) !== producto.cantidad_sistema,
      ),
    [productosRevisados],
  );

  const valorDiferencias = useMemo(
    () =>
      productosRevisados.reduce((total, producto) => {
        const diferencia =
          Number(producto.cantidad_contada) - (producto.cantidad_sistema ?? 0);
        return total + Math.abs(diferencia) * (producto.costo_unitario ?? 0);
      }, 0),
    [productosRevisados],
  );

  const actualizarLista = useCallback(
    () => setVersionInventarios((version) => version + 1),
    [],
  );

  const actualizarDetalle = useCallback(
    () => setVersionDetalle((version) => version + 1),
    [],
  );

  const abrirInventario = (inventarioId: number) => {
    setBusqueda("");
    setErrorAccion(null);
    setMensaje(null);
    setInventarioSeleccionadoId(inventarioId);
  };

  const volverALista = () => {
    if (guardando || aplicando) return;
    setInventarioSeleccionadoId(null);
    setMostrarFormulario(false);
    setErrorAccion(null);
    setMensaje(null);
    actualizarLista();
  };

  const iniciarConteo = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setGuardando(true);
    setErrorAccion(null);
    setMensaje(null);
    try {
      const response = await fetch("/api/inventario-fisico", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bodega_id: Number(form.bodega_id),
          categoria_id: form.categoria_id ? Number(form.categoria_id) : null,
          ubicacion_id: form.ubicacion_id ? Number(form.ubicacion_id) : null,
          fecha_conteo: form.fecha_conteo,
          responsable_nombre: form.responsable_nombre,
        }),
      });
      const data = await leerData<{
        id: number;
        codigo: string;
        productos_total: number;
      }>(response);
      setForm(formInicial());
      setMostrarFormulario(false);
      actualizarLista();
      setMensaje(
        `Conteo ${data.codigo} iniciado para ${data.productos_total} productos.`,
      );
      setInventarioSeleccionadoId(data.id);
    } catch (createError) {
      setErrorAccion(
        createError instanceof Error
          ? createError.message
          : "No se pudo iniciar el conteo.",
      );
    } finally {
      setGuardando(false);
    }
  };

  const guardarConteos = async (enviarARevision: boolean) => {
    if (!detalle) return;
    setGuardando(true);
    setErrorAccion(null);
    setMensaje(null);
    try {
      const response = await fetch(
        `/api/inventario-fisico/${detalle.inventario.id}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            enviar_a_revision: enviarARevision,
            conteos: detalle.productos.map((producto) => {
              const value = conteos[producto.producto_id] ?? "";
              return {
                producto_id: producto.producto_id,
                cantidad_contada: value.trim() === "" ? null : Number(value),
              };
            }),
          }),
        },
      );
      await leerData<{ id: number; estado: string }>(response);
      setMensaje(
        enviarARevision
          ? "Conteo enviado a revisión. El stock del sistema ya está visible."
          : "Avance del conteo guardado.",
      );
      actualizarDetalle();
      actualizarLista();
    } catch (saveError) {
      setErrorAccion(
        saveError instanceof Error
          ? saveError.message
          : "No se pudo guardar el conteo.",
      );
    } finally {
      setGuardando(false);
    }
  };

  const aplicarAjustes = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!detalle) return;
    setAplicando(true);
    setErrorAccion(null);
    setMensaje(null);
    try {
      const response = await fetch(
        `/api/inventario-fisico/${detalle.inventario.id}/aplicar`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            aprobado_por_nombre: responsableAprobacion,
          }),
        },
      );
      const data = await leerData<{
        codigo: string;
        productos_ajustados: number;
      }>(response);
      setMensaje(
        `Conteo ${data.codigo} aplicado. Se ajustaron ${data.productos_ajustados} productos.`,
      );
      setConfirmarAjustes(false);
      actualizarDetalle();
      actualizarLista();
    } catch (applyError) {
      setErrorAccion(
        applyError instanceof Error
          ? applyError.message
          : "No se pudieron aplicar los ajustes.",
      );
    } finally {
      setAplicando(false);
    }
  };

  const catalogosListos = Boolean(catalogos && !errorCatalogos);

  return (
    <div className="bootstrap-container physical-count-page">
      <div className="content-wrapper">
        <header className="physical-count-page-header">
          <div>
            <h1>Inventario físico</h1>
            <p>
              Cuenta existencias por bodega, revisa diferencias y autoriza los
              ajustes con trazabilidad.
            </p>
          </div>
          {inventarioSeleccionadoId !== null && (
            <button
              type="button"
              className="btn btn-outline-secondary"
              onClick={volverALista}
              disabled={guardando || aplicando}
            >
              <ArrowLeft size={16} className="me-2" />
              Volver a conteos
            </button>
          )}
        </header>

        {mensaje && (
          <div className="alert alert-success" role="status">
            {mensaje}
          </div>
        )}
        {errorAccion && (
          <div className="alert alert-danger" role="alert">
            {errorAccion}
          </div>
        )}

        {inventarioSeleccionadoId === null && (
          <>
            <section className="physical-count-intro">
              <div className="physical-count-intro-icon" aria-hidden="true">
                <ClipboardCheck size={23} />
              </div>
              <div>
                <strong>Conteo ciego y controlado</strong>
                <p>
                  Durante el conteo no se muestra el stock esperado. Al enviarlo
                  a revisión verás las diferencias; ninguna existencia cambia
                  hasta autorizar los ajustes.
                </p>
              </div>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => {
                  setMostrarFormulario((visible) => !visible);
                  setErrorAccion(null);
                }}
                disabled={!catalogosListos || cargandoCatalogos || guardando}
              >
                <ClipboardList size={16} className="me-2" />
                {mostrarFormulario ? "Cancelar" : "Iniciar conteo"}
              </button>
            </section>

            {errorCatalogos && (
              <div className="alert alert-danger" role="alert">
                {errorCatalogos}
              </div>
            )}

            {mostrarFormulario && catalogos && (
              <section className="physical-count-create-panel">
                <div className="physical-count-section-heading">
                  <div>
                    <h2>Configurar conteo</h2>
                    <p>
                      El alcance se fija al iniciar y se guarda como una
                      fotografía del stock actual de esa bodega.
                    </p>
                  </div>
                </div>
                <form onSubmit={iniciarConteo}>
                  <div className="physical-count-form-grid">
                    <div>
                      <label className="form-label" htmlFor="count-warehouse">
                        Bodega *
                      </label>
                      <select
                        id="count-warehouse"
                        className="form-select"
                        value={form.bodega_id}
                        onChange={(event) =>
                          setForm((previous) => ({
                            ...previous,
                            bodega_id: event.target.value,
                            ubicacion_id: "",
                          }))
                        }
                        required
                      >
                        <option value="">Selecciona una bodega</option>
                        {catalogos.bodegas.map((bodega) => (
                          <option key={bodega.id} value={bodega.id}>
                            {bodega.nombre}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="form-label" htmlFor="count-category">
                        Categoría
                      </label>
                      <select
                        id="count-category"
                        className="form-select"
                        value={form.categoria_id}
                        onChange={(event) =>
                          setForm((previous) => ({
                            ...previous,
                            categoria_id: event.target.value,
                          }))
                        }
                      >
                        <option value="">Todas las categorías</option>
                        {catalogos.categorias.map((categoria) => (
                          <option key={categoria.id} value={categoria.id}>
                            {categoria.nombre}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="form-label" htmlFor="count-location">
                        Pasillo o ubicación
                      </label>
                      <select
                        id="count-location"
                        className="form-select"
                        value={form.ubicacion_id}
                        onChange={(event) =>
                          setForm((previous) => ({
                            ...previous,
                            ubicacion_id: event.target.value,
                          }))
                        }
                        disabled={!form.bodega_id}
                      >
                        <option value="">Todas las ubicaciones</option>
                        {ubicacionesDeBodega.map((ubicacion) => (
                          <option key={ubicacion.id} value={ubicacion.id}>
                            {[
                              ubicacion.codigo,
                              ubicacion.pasillo
                                ? `Pasillo ${ubicacion.pasillo}`
                                : "",
                              ubicacion.estanteria
                                ? `Estante ${ubicacion.estanteria}`
                                : "",
                              ubicacion.nivel ? `Nivel ${ubicacion.nivel}` : "",
                            ]
                              .filter(Boolean)
                              .join(" · ")}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="form-label" htmlFor="count-date">
                        Fecha del conteo *
                      </label>
                      <input
                        id="count-date"
                        className="form-control"
                        type="date"
                        value={form.fecha_conteo}
                        onChange={(event) =>
                          setForm((previous) => ({
                            ...previous,
                            fecha_conteo: event.target.value,
                          }))
                        }
                        required
                      />
                    </div>
                    <div>
                      <label className="form-label" htmlFor="count-owner">
                        Responsable del conteo *
                      </label>
                      <input
                        id="count-owner"
                        className="form-control"
                        value={form.responsable_nombre}
                        onChange={(event) =>
                          setForm((previous) => ({
                            ...previous,
                            responsable_nombre: event.target.value,
                          }))
                        }
                        maxLength={160}
                        autoComplete="name"
                        required
                      />
                    </div>
                  </div>
                  <p className="physical-count-manual-identity">
                    El nombre del responsable y de quien aprueba se registra
                    manualmente porque este sistema no tiene una sesión de
                    usuario vinculada a este módulo.
                  </p>
                  <div className="physical-count-form-actions">
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={() => setMostrarFormulario(false)}
                      disabled={guardando}
                    >
                      Cancelar
                    </button>
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={guardando || !form.bodega_id}
                    >
                      {guardando ? "Preparando conteo…" : "Crear conteo ciego"}
                    </button>
                  </div>
                </form>
              </section>
            )}

            <section className="physical-count-list-panel">
              <div className="physical-count-section-heading">
                <div>
                  <h2>Conteos registrados</h2>
                  <p>Continúa un conteo o consulta sus diferencias y ajustes.</p>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-outline-secondary"
                  onClick={actualizarLista}
                  disabled={cargandoInventarios}
                  aria-label="Actualizar conteos"
                >
                  <RefreshCw size={15} className="me-1" />
                  Actualizar
                </button>
              </div>

              {cargandoInventarios && (
                <div className="physical-count-empty" role="status">
                  Cargando conteos…
                </div>
              )}
              {errorInventarios && (
                <div className="alert alert-danger" role="alert">
                  {errorInventarios}
                </div>
              )}
              {!cargandoInventarios &&
                !errorInventarios &&
                inventarios.length === 0 && (
                  <div className="physical-count-empty">
                    <PackageSearch size={25} aria-hidden="true" />
                    <strong>Aún no hay conteos físicos</strong>
                    <span>
                      Inicia uno por bodega, categoría o ubicación para empezar.
                    </span>
                  </div>
                )}
              {!cargandoInventarios &&
                !errorInventarios &&
                inventarios.length > 0 && (
                  <div className="table-responsive">
                    <table className="table table-hover align-middle physical-count-table">
                      <thead>
                        <tr>
                          <th>Conteo</th>
                          <th>Bodega</th>
                          <th>Fecha</th>
                          <th>Responsable</th>
                          <th>Avance</th>
                          <th>Diferencias</th>
                          <th>Valor estimado</th>
                          <th>Estado</th>
                          <th></th>
                        </tr>
                      </thead>
                      <tbody>
                        {inventarios.map((inventario) => (
                          <tr key={inventario.id}>
                            <td>
                              <strong>{inventario.codigo}</strong>
                            </td>
                            <td>{inventario.bodega}</td>
                            <td>{inventario.fecha_conteo}</td>
                            <td>{inventario.responsable_nombre || "No indicado"}</td>
                            <td>
                              {inventario.productos_contados} /{" "}
                              {inventario.productos_total}
                            </td>
                            <td>{inventario.diferencias}</td>
                            <td>{formatearDinero(inventario.valor_diferencia)}</td>
                            <td>
                              <span
                                className={`physical-count-status ${inventario.estado.toLowerCase()}`}
                              >
                                {obtenerEstadoLabel(inventario.estado)}
                              </span>
                            </td>
                            <td>
                              <button
                                type="button"
                                className="btn btn-sm btn-outline-primary"
                                onClick={() => abrirInventario(inventario.id)}
                              >
                                {inventario.estado === "EN_CONTEO"
                                  ? "Continuar"
                                  : inventario.estado === "EN_REVISION"
                                    ? "Revisar"
                                    : "Ver detalle"}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
            </section>
          </>
        )}

        {inventarioSeleccionadoId !== null && (
          <section className="physical-count-detail-panel">
            {cargandoDetalle && (
              <div className="physical-count-empty" role="status">
                Cargando detalle del conteo…
              </div>
            )}
            {errorDetalle && (
              <div className="alert alert-danger" role="alert">
                {errorDetalle}
              </div>
            )}
            {!cargandoDetalle && !errorDetalle && detalle && (
              <>
                <header className="physical-count-detail-header">
                  <div>
                    <div className="physical-count-detail-title">
                      <h2>{detalle.inventario.codigo}</h2>
                      <span
                        className={`physical-count-status ${detalle.inventario.estado.toLowerCase()}`}
                      >
                        {obtenerEstadoLabel(detalle.inventario.estado)}
                      </span>
                    </div>
                    <p>
                      {detalle.inventario.bodega} ·{" "}
                      {detalle.inventario.fecha_conteo} · Responsable:{" "}
                      {detalle.inventario.responsable_nombre || "No indicado"}
                    </p>
                  </div>
                  {detalle.inventario.estado === "EN_CONTEO" && (
                    <span className="physical-count-blind-badge">
                      Stock esperado oculto
                    </span>
                  )}
                  {detalle.inventario.estado === "APLICADO" &&
                    detalle.inventario.aprobado_por_nombre && (
                      <span className="physical-count-approved-by">
                        Aprobado por {detalle.inventario.aprobado_por_nombre}
                      </span>
                    )}
                </header>

                {detalle.inventario.estado === "EN_CONTEO" && (
                  <form
                    onSubmit={(event) => {
                      event.preventDefault();
                      void guardarConteos(false);
                    }}
                    className="physical-count-entry-form"
                  >
                    <div className="physical-count-entry-summary">
                      <div>
                        <strong>Conteo ciego</strong>
                        <span>
                          No se muestra la cantidad del sistema. Busca o escanea
                          un código y registra la cantidad física.
                        </span>
                      </div>
                      <div>
                        <strong>
                          {
                            detalle.productos.filter(
                              (producto) =>
                                conteos[producto.producto_id]?.trim() !== "",
                            ).length
                          }{" "}
                          / {detalle.productos.length}
                        </strong>
                        <span>productos contados</span>
                      </div>
                    </div>

                    <label className="physical-count-search">
                      <Search size={17} aria-hidden="true" />
                      <input
                        type="search"
                        aria-label="Buscar o escanear producto"
                        placeholder="Buscar o escanear código, nombre, categoría o ubicación…"
                        value={busqueda}
                        onChange={(event) => setBusqueda(event.target.value)}
                      />
                      <Barcode size={17} aria-hidden="true" />
                    </label>

                    <div className="table-responsive">
                      <table className="table table-hover align-middle physical-count-table">
                        <thead>
                          <tr>
                            <th>Código</th>
                            <th>Producto</th>
                            <th>Categoría</th>
                            <th>Ubicación</th>
                            <th>Unidad</th>
                            <th>Cantidad física *</th>
                          </tr>
                        </thead>
                        <tbody>
                          {productosFiltrados.map((producto) => (
                            <tr key={producto.producto_id}>
                              <td>{producto.codigo}</td>
                              <td>
                                <strong>{producto.nombre}</strong>
                              </td>
                              <td>{producto.categoria || "Sin categoría"}</td>
                              <td>{producto.ubicacion}</td>
                              <td>{producto.unidad_medida}</td>
                              <td>
                                <input
                                  type="number"
                                  className="form-control physical-count-quantity-input"
                                  min="0"
                                  step="0.0001"
                                  inputMode="decimal"
                                  aria-label={`Cantidad contada de ${producto.nombre}`}
                                  value={conteos[producto.producto_id] ?? ""}
                                  onChange={(event) =>
                                    setConteos((previous) => ({
                                      ...previous,
                                      [producto.producto_id]: event.target.value,
                                    }))
                                  }
                                />
                              </td>
                            </tr>
                          ))}
                          {productosFiltrados.length === 0 && (
                            <tr>
                              <td colSpan={6} className="text-center">
                                No hay productos que coincidan con la búsqueda.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    <div className="physical-count-form-actions">
                      <button
                        type="submit"
                        className="btn btn-outline-primary"
                        disabled={guardando}
                      >
                        {guardando ? "Guardando…" : "Guardar avance"}
                      </button>
                      <button
                        type="button"
                        className="btn btn-primary"
                        disabled={guardando || !conteoCompleto}
                        onClick={() => void guardarConteos(true)}
                      >
                        Enviar a revisión
                      </button>
                    </div>
                  </form>
                )}

                {detalle.inventario.estado !== "EN_CONTEO" && (
                  <>
                    <div className="physical-count-review-summary">
                      <div>
                        <span>Productos revisados</span>
                        <strong>{productosRevisados.length}</strong>
                      </div>
                      <div>
                        <span>Con diferencias</span>
                        <strong>{productosConDiferencia.length}</strong>
                      </div>
                      <div>
                        <span>Valor estimado de diferencia</span>
                        <strong>{formatearDinero(valorDiferencias)}</strong>
                      </div>
                    </div>

                    {productosConDiferencia.length === 0 ? (
                      <div className="physical-count-no-differences">
                        <CheckCircle2 size={19} aria-hidden="true" />
                        No hay diferencias entre el conteo físico y el sistema.
                      </div>
                    ) : (
                      <div className="table-responsive">
                        <table className="table table-hover align-middle physical-count-table">
                          <thead>
                            <tr>
                              <th>Código</th>
                              <th>Producto</th>
                              <th>Stock del sistema</th>
                              <th>Conteo físico</th>
                              <th>Diferencia</th>
                              <th>Valor estimado</th>
                            </tr>
                          </thead>
                          <tbody>
                            {productosConDiferencia.map((producto) => {
                              const difference =
                                Number(producto.cantidad_contada) -
                                (producto.cantidad_sistema ?? 0);
                              return (
                                <tr key={producto.producto_id}>
                                  <td>{producto.codigo}</td>
                                  <td>{producto.nombre}</td>
                                  <td>
                                    {formatearCantidad(
                                      producto.cantidad_sistema ?? 0,
                                    )}{" "}
                                    {producto.unidad_medida}
                                  </td>
                                  <td>
                                    {formatearCantidad(
                                      producto.cantidad_contada ?? 0,
                                    )}{" "}
                                    {producto.unidad_medida}
                                  </td>
                                  <td>
                                    <span
                                      className={`physical-count-variance ${difference > 0 ? "surplus" : "shortage"}`}
                                    >
                                      {difference > 0 ? "Sobrante +" : "Faltante "}
                                      {formatearCantidad(difference)}
                                    </span>
                                  </td>
                                  <td>
                                    {formatearDinero(
                                      Math.abs(difference) *
                                        (producto.costo_unitario ?? 0),
                                    )}
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}

                    {detalle.inventario.estado === "EN_REVISION" && (
                      <form
                        className="physical-count-approval"
                        onSubmit={aplicarAjustes}
                      >
                        <div>
                          <h3>Autorizar ajustes de inventario</h3>
                          <p>
                            Al confirmar, las existencias de esta bodega se
                            actualizarán a las cantidades contadas. Los
                            movimientos quedarán registrados en el historial.
                          </p>
                        </div>
                        <label htmlFor="count-approved-by">
                          Nombre de quien autoriza *
                        </label>
                        <input
                          id="count-approved-by"
                          className="form-control"
                          value={responsableAprobacion}
                          onChange={(event) =>
                            setResponsableAprobacion(event.target.value)
                          }
                          maxLength={160}
                          autoComplete="name"
                          required
                        />
                        <label className="physical-count-approval-check">
                          <input
                            type="checkbox"
                            checked={confirmarAjustes}
                            onChange={(event) =>
                              setConfirmarAjustes(event.target.checked)
                            }
                          />
                          <span>
                            Confirmo que revisé las diferencias y autorizo
                            aplicar los ajustes.
                          </span>
                        </label>
                        <div className="physical-count-form-actions">
                          <button
                            type="submit"
                            className="btn btn-danger"
                            disabled={
                              aplicando ||
                              !confirmarAjustes ||
                              !responsableAprobacion.trim()
                            }
                          >
                            {aplicando
                              ? "Aplicando ajustes…"
                              : "Confirmar y aplicar ajustes"}
                          </button>
                        </div>
                      </form>
                    )}

                    {detalle.inventario.estado === "APLICADO" && (
                      <div className="physical-count-applied-note">
                        <CheckCircle2 size={18} aria-hidden="true" />
                        Ajustes aplicados el{" "}
                        {detalle.inventario.aplicado_en
                          ? new Date(
                              detalle.inventario.aplicado_en,
                            ).toLocaleString("es-EC")
                          : "fecha no disponible"}
                        {detalle.inventario.aprobado_por_nombre &&
                          ` por ${detalle.inventario.aprobado_por_nombre}`}
                        .
                      </div>
                    )}
                  </>
                )}
              </>
            )}
          </section>
        )}
      </div>
    </div>
  );
}
