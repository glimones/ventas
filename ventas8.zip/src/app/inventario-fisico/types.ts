export type EstadoInventarioFisico =
  | 'EN_CONTEO'
  | 'EN_REVISION'
  | 'APLICADO'
  | string;

export interface InventarioFisico {
  id: number;
  codigo: string;
  bodega_id: number;
  bodega: string;
  fecha_conteo: string;
  responsable_nombre: string;
  aprobado_por_nombre?: string | null;
  aplicado_en?: string | null;
  estado: EstadoInventarioFisico;
  productos_total: number;
  productos_contados: number;
  diferencias: number;
  valor_diferencia: number;
}

export interface ProductoConteoFisico {
  producto_id: number;
  codigo: string;
  nombre: string;
  categoria: string;
  ubicacion: string;
  unidad_medida: string;
  cantidad_contada: number | null;
  cantidad_sistema?: number;
  costo_unitario?: number;
}

export interface InventarioFisicoDetalle {
  inventario: InventarioFisico;
  productos: ProductoConteoFisico[];
}

export interface InventarioFisicoCatalogos {
  bodegas: Array<{ id: number; codigo: string; nombre: string }>;
  categorias: Array<{ id: number; codigo: string; nombre: string }>;
  ubicaciones: Array<{
    id: number;
    codigo: string;
    bodega_id: number;
    pasillo?: string | null;
    estanteria?: string | null;
    nivel?: string | null;
  }>;
}
