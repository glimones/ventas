import { AppShell } from '@/components/app-shell';
import InventarioFisicoPage from './InventarioFisicoPage';

export default function Page() {
  return (
    <AppShell>
      <InventarioFisicoPage />
    </AppShell>
  );
}
