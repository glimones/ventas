import { AppShell } from '@/components/app-shell';
import DashboardKpiPage from './DashboardKpiPage';

export default function Page() {
  return (
    <AppShell>
      <DashboardKpiPage />
    </AppShell>
  );
}
