import { AppShell } from '@/components/app-shell';
import ComprasPage from './ComprasPage';

export default function Page() {
  return (
    <AppShell>
      <ComprasPage />
    </AppShell>
  );
}
