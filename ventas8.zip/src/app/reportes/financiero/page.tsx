import { AppShell } from '@/components/app-shell';
import FinancieroPage from './FinancieroPage';

export default function Page() {
  return (
    <AppShell>
      <FinancieroPage />
    </AppShell>
  );
}
