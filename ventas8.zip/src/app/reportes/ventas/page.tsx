import { AppShell } from '@/components/app-shell';
import VentasPage from './VentasPage';

export default function Page() {
  return (
    <AppShell>
      <VentasPage />
    </AppShell>
  );
}
