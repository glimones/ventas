import { AppShell } from '@/components/app-shell';
import GerencialPage from './GerencialPage';

export default function Page() {
  return (
    <AppShell>
      <GerencialPage />
    </AppShell>
  );
}
