export interface Inventario {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}

export interface InventarioFormValues {
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}
