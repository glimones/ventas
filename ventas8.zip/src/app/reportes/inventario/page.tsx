import { AppShell } from '@/components/app-shell';
import InventarioPage from './InventarioPage';

export default function Page() {
  return (
    <AppShell>
      <InventarioPage />
    </AppShell>
  );
}
