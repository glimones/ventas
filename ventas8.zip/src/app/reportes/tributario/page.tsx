import { AppShell } from '@/components/app-shell';
import TributarioPage from './TributarioPage';

export default function Page() {
  return (
    <AppShell>
      <TributarioPage />
    </AppShell>
  );
}
