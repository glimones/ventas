import Loading from "@/components/loading";

export default function RouteLoading() {
  return (
    <div className="relative min-h-full">
      <Loading />
    </div>
  );
}
