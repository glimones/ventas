import { AppShell } from '@/components/app-shell';
import ProspectosPage from './ProspectosPage';

export default function Page() {
  return (
    <AppShell>
      <ProspectosPage />
    </AppShell>
  );
}
