import { AppShell } from '@/components/app-shell';
import KardexPage from './KardexPage';

export default function Page() {
  return (
    <AppShell>
      <KardexPage />
    </AppShell>
  );
}
