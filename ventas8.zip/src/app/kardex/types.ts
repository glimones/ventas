export interface Kardex {
  id: number;
  codigo: string;
  producto: string;
  bodega: string;
  tipo_movimiento: string;
  fecha: string;
  entrada: number;
  salida: number;
  saldo: number;
  documento: string;
  estado: string;
}

export interface KardexFormValues {
  codigo: string;
  producto: string;
  bodega: string;
  tipo_movimiento: string;
  fecha: string;
  entrada: number;
  salida: number;
  saldo: number;
  documento: string;
  estado: string;
}
