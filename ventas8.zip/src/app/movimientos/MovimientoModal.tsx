﻿'use client';

import React, { useEffect } from 'react';
import { MovimientoFormValues } from './types';
import MovimientoForm from './MovimientoForm';
import './movimientos.css';

interface Props {
  show: boolean;
  editando: boolean;
  values: MovimientoFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

const MovimientoModal: React.FC<Props> = ({ show, editando, values, onChange, onClose, onSubmit }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && show) {
        e.preventDefault();
        onClose();
      }
    };
    if (show) {
      document.body.classList.add('modal-open');
      document.body.style.overflow = 'hidden';
      document.body.style.paddingRight = '15px';
      document.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.classList.remove('modal-open');
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
      document.removeEventListener('keydown', handleKeyDown);
    }
    return () => {
      document.body.classList.remove('modal-open');
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [show, onClose]);

  if (!show) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onSubmit(e);
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <>
      <div className='modal fade show d-block' tabIndex={-1} role='dialog' aria-modal='true' style={{ zIndex: 1050 }}>
        <div className='modal-dialog modal-lg' role='document' style={{ zIndex: 1060 }}>
          <div className='modal-content'>
            <form onSubmit={handleSubmit}>
              <div className='modal-header bg-primary text-white'>
                <h5 className='modal-title'>{editando ? 'Editar Movimiento' : 'Nuevo Movimiento'}</h5>
                <button type='button' className='btn-close btn-close-white' onClick={onClose} aria-label='Cerrar' />
              </div>
              <div className='modal-body'>
                <p className='text-muted mb-3'>Los campos marcados con * son obligatorios</p>
                <MovimientoForm values={values} onChange={onChange} />
              </div>
              <div className='modal-footer'>
                <button type='button' className='btn btn-secondary' onClick={onClose}>Cancelar</button>
                <button type='submit' className='btn btn-success'>Guardar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className='modal-backdrop fade show' onClick={handleBackdropClick} style={{ zIndex: 1040 }}></div>
    </>
  );
};

export default MovimientoModal;
