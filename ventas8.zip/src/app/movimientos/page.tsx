﻿import { AppShell } from '@/components/app-shell';
import MovimientosPage from './MovimientoPage';

export default function Page() {
  return (
    <AppShell>
      <MovimientosPage />
    </AppShell>
  );
}
