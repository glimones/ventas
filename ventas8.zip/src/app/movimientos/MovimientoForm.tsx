﻿'use client';

import React from 'react';
import { MovimientoFormValues } from './types';

interface Props {
  values: MovimientoFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const tiposMovimiento = [
  { value: '', label: 'Seleccione tipo de movimiento' },
  { value: 'Entrada', label: 'Entrada' },
  { value: 'Salida', label: 'Salida' },
  { value: 'Transferencia', label: 'Transferencia' },
  { value: 'Ajuste', label: 'Ajuste' },
];

const productos = [
  { value: '', label: 'Seleccione producto' },
  { value: 'Laptop Pro X1', label: 'Laptop Pro X1' },
  { value: 'Monitor 27 4K', label: 'Monitor 27 4K' },
  { value: 'Teclado Mecánico RGB', label: 'Teclado Mecánico RGB' },
  { value: 'Mouse Inalámbrico', label: 'Mouse Inalámbrico' },
];

const bodegas = [
  { value: '', label: 'Seleccione bodega' },
  { value: 'BOD-001 - Bodega Principal', label: 'BOD-001 - Bodega Principal' },
  { value: 'BOD-002 - Bodega Materia Prima', label: 'BOD-002 - Bodega Materia Prima' },
  { value: 'BOD-003 - Bodega Producto Terminado', label: 'BOD-003 - Bodega Producto Terminado' },
];

const MovimientoForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='producto' className='form-label'>Producto *</label>
          <select className='form-select' id='producto' name='producto' value={values.producto || ''} onChange={handleInputChange} required>
            {productos.map((opt) => (<option key={opt.value} value={opt.value}>{opt.label}</option>))}
          </select>
        </div>
        <div className='mb-3'>
          <label htmlFor='tipo' className='form-label'>Tipo de Movimiento *</label>
          <select className='form-select' id='tipo' name='tipo' value={values.tipo || ''} onChange={handleInputChange} required>
            {tiposMovimiento.map((opt) => (<option key={opt.value} value={opt.value}>{opt.label}</option>))}
          </select>
        </div>
        <div className='mb-3'>
          <label htmlFor='cantidad' className='form-label'>Cantidad *</label>
          <input type='number' className='form-control' id='cantidad' name='cantidad' value={values.cantidad || ''} onChange={handleInputChange} required min='1' autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='bodega_origen' className='form-label'>Bodega Origen</label>
          <select className='form-select' id='bodega_origen' name='bodega_origen' value={values.bodega_origen || ''} onChange={handleInputChange}>
            {bodegas.map((opt) => (<option key={opt.value} value={opt.value}>{opt.label}</option>))}
          </select>
        </div>
        <div className='mb-3'>
          <label htmlFor='bodega_destino' className='form-label'>Bodega Destino</label>
          <select className='form-select' id='bodega_destino' name='bodega_destino' value={values.bodega_destino || ''} onChange={handleInputChange}>
            {bodegas.map((opt) => (<option key={opt.value} value={opt.value}>{opt.label}</option>))}
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='fecha' className='form-label'>Fecha *</label>
          <input type='date' className='form-control' id='fecha' name='fecha' value={values.fecha || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='motivo' className='form-label'>Motivo *</label>
          <textarea className='form-control' id='motivo' name='motivo' value={values.motivo || ''} onChange={handleInputChange} rows={2} required />
        </div>
        <div className='mb-3'>
          <label htmlFor='responsable' className='form-label'>Responsable *</label>
          <input type='text' className='form-control' id='responsable' name='responsable' value={values.responsable || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='documento_referencia' className='form-label'>Documento Referencia</label>
          <input type='text' className='form-control' id='documento_referencia' name='documento_referencia' value={values.documento_referencia || ''} onChange={handleInputChange} autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || 'Pendiente'} onChange={handleInputChange}>
            <option value='Pendiente'>Pendiente</option>
            <option value='Completado'>Completado</option>
            <option value='Anulado'>Anulado</option>
          </select>
        </div>
        <div className='mb-3'>
          <label htmlFor='notas' className='form-label'>Notas</label>
          <textarea className='form-control' id='notas' name='notas' value={values.notas || ''} onChange={handleInputChange} rows={2} autoComplete='off' />
        </div>
      </div>
    </div>
  );
};

export default MovimientoForm;
