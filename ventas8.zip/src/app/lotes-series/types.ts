export interface LotesSeries {
  id: number;
  codigo: string;
  producto: string;
  numero_lote: string;
  fecha_fabricacion: string;
  fecha_vencimiento: string;
  cantidad: number;
  bodega: string;
  estado: string;
}

export interface LotesSeriesFormValues {
  codigo: string;
  producto: string;
  numero_lote: string;
  fecha_fabricacion: string;
  fecha_vencimiento: string;
  cantidad: number;
  bodega: string;
  estado: string;
}
