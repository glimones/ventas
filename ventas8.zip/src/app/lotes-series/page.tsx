import { AppShell } from '@/components/app-shell';
import LotesSeriesPage from './LotesSeriesPage';

export default function Page() {
  return (
    <AppShell>
      <LotesSeriesPage />
    </AppShell>
  );
}
