'use client';
import React, { useState } from 'react';
import { LotesSeries, LotesSeriesFormValues } from './types';
import LotesSeriesModal from './LotesSeriesModal';
import './bootstrap-lotes-series.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: LotesSeriesFormValues = {
  codigo: '',
  producto: '',
  numero_lote: '',
  fecha_fabricacion: '',
  fecha_vencimiento: '',
  cantidad: 0,
  bodega: '',
  estado: 'Activo',
};

const initialData: LotesSeries[] = [
  { id: 1, codigo: 'LOT-001', producto: 'Laptop HP Pavilion', numero_lote: 'HP-2025-01', fecha_fabricacion: '2025-01-10', fecha_vencimiento: '2028-01-10', cantidad: 25, bodega: 'Matriz Quito', estado: 'Activo' },
];

export default function LotesSeriesPage() {
  const [data, setData] = useState<LotesSeries[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<LotesSeriesFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (item: LotesSeries) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      producto: item.producto || '', numero_lote: item.numero_lote || '', fecha_fabricacion: item.fecha_fabricacion || '', fecha_vencimiento: item.fecha_vencimiento || '', cantidad: item.cantidad || 0, bodega: item.bodega || '',
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.name === 'cantidad' ? Number(e.target.value) : e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, ...form }
          : item
      ));
    } else {
      const nuevo: LotesSeries = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        ...form,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.producto.toLowerCase().includes(filtro.toLowerCase()) || item.numero_lote.toLowerCase().includes(filtro.toLowerCase()) || item.bodega.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Lotes/Series</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Producto</th><th>Lote/serie</th><th>Vencimiento</th><th>Cantidad</th><th>Bodega</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.producto}</td><td>{item.numero_lote}</td><td>{item.fecha_vencimiento || 'Sin vencimiento'}</td><td>{item.cantidad}</td><td>{item.bodega}</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <LotesSeriesModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
