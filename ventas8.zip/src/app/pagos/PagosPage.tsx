import DomainCrud from '@/components/domain-crud';import{domainConfigs}from '@/components/domain-config';export default function PagosPage(){return <DomainCrud config={domainConfigs.pagos}/>}
