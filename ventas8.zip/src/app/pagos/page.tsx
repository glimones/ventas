import { AppShell } from '@/components/app-shell';
import PagosPage from './PagosPage';

export default function Page() {
  return (
    <AppShell>
      <PagosPage />
    </AppShell>
  );
}
