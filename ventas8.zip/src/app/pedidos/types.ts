export interface Pedidos { id:number; codigo:string; cliente:string; fecha_pedido:string; fecha_entrega:string; subtotal:number; descuento:number; impuesto:number; total:number; vendedor:string; estado:string; }
export type PedidosFormValues = Omit<Pedidos,'id'>;
