import { AppShell } from '@/components/app-shell';
import PedidosPage from './PedidosPage';

export default function Page() {
  return (
    <AppShell>
      <PedidosPage />
    </AppShell>
  );
}
