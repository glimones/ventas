'use client';

import React, { useState } from 'react';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';
import PedidosModal from './PedidosModal';
import { Pedidos, PedidosFormValues } from './types';
import './bootstrap-pedidos.css';

const blank: PedidosFormValues = {
  codigo: '',
  cliente: '',
  fecha_pedido: '',
  fecha_entrega: '',
  subtotal: 0,
  descuento: 0,
  impuesto: 0,
  total: 0,
  vendedor: '',
  estado: 'Pendiente',
};

const seed: Pedidos[] = [
  {
    id: 1,
    codigo: 'PED-001',
    cliente: 'Comercial XYZ S.A.',
    fecha_pedido: '2025-03-01',
    fecha_entrega: '2025-03-04',
    subtotal: 1000,
    descuento: 50,
    impuesto: 114,
    total: 1064,
    vendedor: 'Ana Torres',
    estado: 'Confirmado',
  },
];

export default function PedidosPage() {
  const [data, setData] = useState(seed);
  const [q, setQ] = useState('');
  const [estadoFiltro, setEstadoFiltro] = useState('TODOS');
  const [show, setShow] = useState(false);
  const [id, setId] = useState<number | null>(null);
  const [form, setForm] = useState(blank);

  const close = () => {
    setShow(false);
    setId(null);
    setForm(blank);
  };

  const edit = (pedido: Pedidos) => {
    setId(pedido.id);
    setForm({ ...pedido });
    setShow(true);
  };

  const change = (
    event: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => {
    setForm((previous) => ({
      ...previous,
      [event.target.name]: ['subtotal', 'descuento', 'impuesto', 'total'].includes(
        event.target.name,
      )
        ? Number(event.target.value)
        : event.target.value,
    }));
  };

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    setData((previous) =>
      id === null
        ? [...previous, { ...form, id: Date.now() }]
        : previous.map((pedido) =>
            pedido.id === id ? { ...pedido, ...form } : pedido,
          ),
    );
    close();
  };

  const estadosDisponibles = Array.from(new Set(data.map((pedido) => pedido.estado)));
  const rows = data.filter((pedido) => {
    const coincideTexto = `${pedido.codigo} ${pedido.cliente} ${pedido.vendedor}`
      .toLowerCase()
      .includes(q.toLowerCase());
    return (
      coincideTexto &&
      (estadoFiltro === 'TODOS' || pedido.estado === estadoFiltro)
    );
  });
  const totalVisible = rows.reduce((sum, pedido) => sum + pedido.total, 0);

  const remove = (pedido: Pedidos) => {
    if (
      window.confirm(
        `¿Eliminar el pedido ${pedido.codigo} de ${pedido.cliente}? Esta acción no se puede deshacer.`,
      )
    ) {
      setData((previous) =>
        previous.filter((item) => item.id !== pedido.id),
      );
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">Pedidos</h1>
        <div className="d-flex flex-wrap align-items-center gap-2 mb-2">
          <input
            className="form-control flex-grow-1"
            style={{ minWidth: '220px' }}
            placeholder="Buscar cliente, pedido o vendedor..."
            aria-label="Buscar pedidos"
            value={q}
            onChange={(event) => setQ(event.target.value)}
          />
          <select
            className="form-select"
            style={{ maxWidth: '240px' }}
            aria-label="Filtrar pedidos por estado"
            value={estadoFiltro}
            onChange={(event) => setEstadoFiltro(event.target.value)}
          >
            <option value="TODOS">Todos los estados</option>
            {estadosDisponibles.map((estado) => (
              <option key={estado} value={estado}>
                {estado}
              </option>
            ))}
          </select>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setShow(true)}
          >
            <CirclePlus size={16} className="me-2" />
            Añadir pedido
          </button>
        </div>
        <p className="small text-muted mb-3" aria-live="polite">
          Mostrando {rows.length} de {data.length} pedidos · Total de la vista:{' '}
          <strong>${totalVisible.toFixed(2)}</strong>
        </p>
        <div className="table-responsive">
          <table className="table table-striped">
            <thead>
              <tr>
                <th>Pedido</th>
                <th>Cliente</th>
                <th>Fecha</th>
                <th>Entrega</th>
                <th>Total</th>
                <th>Vendedor</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center text-muted py-4">
                    No hay pedidos que coincidan con los filtros.
                  </td>
                </tr>
              ) : (
                rows.map((pedido) => (
                  <tr key={pedido.id}>
                    <td>{pedido.codigo}</td>
                    <td>{pedido.cliente}</td>
                    <td>{pedido.fecha_pedido}</td>
                    <td>{pedido.fecha_entrega}</td>
                    <td>${pedido.total.toFixed(2)}</td>
                    <td>{pedido.vendedor}</td>
                    <td>
                      <span className="badge text-bg-light border text-dark">
                        {pedido.estado}
                      </span>
                    </td>
                    <td>
                      <button
                        type="button"
                        className="btn btn-warning btn-sm me-1"
                        onClick={() => edit(pedido)}
                        title={`Editar pedido ${pedido.codigo}`}
                        aria-label={`Editar pedido ${pedido.codigo}`}
                      >
                        <SquarePen size={15} />
                      </button>
                      <button
                        type="button"
                        className="btn btn-danger btn-sm"
                        onClick={() => remove(pedido)}
                        title={`Eliminar pedido ${pedido.codigo}`}
                        aria-label={`Eliminar pedido ${pedido.codigo}`}
                      >
                        <Trash2 size={15} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <PedidosModal
          show={show}
          editando={id !== null}
          values={form}
          onChange={change}
          onClose={close}
          onSubmit={submit}
        />
      </div>
    </div>
  );
}
