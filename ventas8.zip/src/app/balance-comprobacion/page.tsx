import { AppShell } from '@/components/app-shell';
import BalanceComprobacionPage from './BalanceComprobacionPage';

export default function Page() {
  return (
    <AppShell>
      <BalanceComprobacionPage />
    </AppShell>
  );
}
