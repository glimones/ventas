import { AppShell } from '@/components/app-shell';
import EstadoCuentaClientesPage from './EstadoCuentaClientesPage';

export default function Page() {
  return (
    <AppShell>
      <EstadoCuentaClientesPage />
    </AppShell>
  );
}
