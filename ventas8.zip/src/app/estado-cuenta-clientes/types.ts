export interface EstadoCuentaClientes { id:number; codigo:string; cliente:string; identificacion:string; fecha_corte:string; saldo_anterior:number; cargos:number; abonos:number; saldo_actual:number; dias_mora:number; estado:string; }
export type EstadoCuentaClientesFormValues = Omit<EstadoCuentaClientes,'id'>;
