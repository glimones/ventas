import { AppShell } from '@/components/app-shell';
import RetencionesTributacionPage from './RetencionesTributacionPage';

export default function Page() {
  return (
    <AppShell>
      <RetencionesTributacionPage />
    </AppShell>
  );
}
