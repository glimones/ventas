import { AppShell } from '@/components/app-shell';
import DiarioGeneralPage from './DiarioGeneralPage';

export default function Page() {
  return (
    <AppShell>
      <DiarioGeneralPage />
    </AppShell>
  );
}
