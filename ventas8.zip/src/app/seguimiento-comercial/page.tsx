import { AppShell } from '@/components/app-shell';
import SeguimientoComercialPage from './SeguimientoComercialPage';

export default function Page() {
  return (
    <AppShell>
      <SeguimientoComercialPage />
    </AppShell>
  );
}
