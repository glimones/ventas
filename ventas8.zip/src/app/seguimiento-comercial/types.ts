export interface SeguimientoComercial {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}

export interface SeguimientoComercialFormValues {
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}
