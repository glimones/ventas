import { AppShell } from '@/components/app-shell';
import RetencionesCxpPage from './RetencionesCxpPage';

export default function Page() {
  return (
    <AppShell>
      <RetencionesCxpPage />
    </AppShell>
  );
}
