import { AppShell } from '@/components/app-shell';
import ChequesPage from './ChequesPage';

export default function Page() {
  return (
    <AppShell>
      <ChequesPage />
    </AppShell>
  );
}
