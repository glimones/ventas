import { AppShell } from '@/components/app-shell';
import RevalorizacionesPage from './RevalorizacionesPage';

export default function Page() {
  return (
    <AppShell>
      <RevalorizacionesPage />
    </AppShell>
  );
}
