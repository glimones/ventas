import { AppShell } from "@/components/app-shell";
import HomeDashboard from "@/components/home-dashboard";

export default function Home() {
  return (
    <AppShell showFooter={false}>
      <HomeDashboard />
    </AppShell>
  );
}