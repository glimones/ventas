import { AppShell } from '@/components/app-shell';
import CarteraPage from './CarteraPage';

export default function Page() {
  return (
    <AppShell>
      <CarteraPage />
    </AppShell>
  );
}
