import DomainCrud from '@/components/domain-crud';import{domainConfigs}from '@/components/domain-config';export default function CarteraPage(){return <DomainCrud config={domainConfigs.cartera}/>}
