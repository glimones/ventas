import { AppShell } from '@/components/app-shell';
import EstadoCuentaCxpPage from './EstadoCuentaCxpPage';

export default function Page() {
  return (
    <AppShell>
      <EstadoCuentaCxpPage />
    </AppShell>
  );
}
