import type { OrdenCompra } from "./ordenes-compra/types";
import type { SolicitudCompra } from "./solicitudes-compra/types";

const SOLICITUDES_KEY = "compras:solicitudes:v1";
const ORDENES_KEY = "compras:ordenes:v1";

export const ORDENES_COMPRA_INITIAL: OrdenCompra[] = [
  { id: 1, numero_orden: "OC-2025-001", fecha_orden: "2025-01-05", fecha_entrega_requerida: "2025-02-01", estado: "RECIBIDA_TOTAL", tipo_orden: "ORDEN_DIRECTA", prioridad: "ALTA", proveedor: "Suministros XYZ", identificacion_proveedor: "1799876543001", subtotal: 4800, iva: 720, total: 5520, observaciones: "Materiales de construcción", fecha_creacion: "2025-01-05" },
  { id: 2, numero_orden: "OC-2025-002", fecha_orden: "2025-02-10", fecha_entrega_requerida: "2025-03-15", estado: "ENVIADA", tipo_orden: "DESDE_COTIZACION", prioridad: "NORMAL", proveedor: "Distribuidora ABC", identificacion_proveedor: "1790012345001", subtotal: 12500, iva: 1875, total: 14375, observaciones: "Equipos de oficina", fecha_creacion: "2025-02-10" },
  { id: 3, numero_orden: "OC-2025-003", fecha_orden: "2025-03-01", fecha_entrega_requerida: "2025-03-20", estado: "BORRADOR", tipo_orden: "ORDEN_URGENTE", prioridad: "URGENTE", proveedor: "Tecnología S.A.", identificacion_proveedor: "1795555555001", subtotal: 8100, iva: 1215, total: 9315, observaciones: "Servidores y networking", fecha_creacion: "2025-03-01" },
];

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isSolicitudCompra(value: unknown): value is SolicitudCompra {
  return (
    isRecord(value) &&
    typeof value.id === "number" &&
    Number.isInteger(value.id) &&
    typeof value.numero_solicitud === "string" &&
    typeof value.fecha_solicitud === "string" &&
    typeof value.solicitante === "string" &&
    typeof value.departamento === "string" &&
    typeof value.centro_costo === "string" &&
    typeof value.prioridad === "string" &&
    typeof value.estado === "string" &&
    typeof value.items_solicitados === "number" &&
    Number.isFinite(value.items_solicitados) &&
    typeof value.total_estimado === "number" &&
    Number.isFinite(value.total_estimado) &&
    typeof value.justificacion === "string" &&
    typeof value.fecha_creacion === "string"
  );
}

function isOrdenCompra(value: unknown): value is OrdenCompra {
  return (
    isRecord(value) &&
    typeof value.id === "number" &&
    Number.isInteger(value.id) &&
    typeof value.numero_orden === "string" &&
    typeof value.fecha_orden === "string" &&
    typeof value.fecha_entrega_requerida === "string" &&
    typeof value.estado === "string" &&
    typeof value.tipo_orden === "string" &&
    typeof value.prioridad === "string" &&
    typeof value.proveedor === "string" &&
    typeof value.identificacion_proveedor === "string" &&
    typeof value.subtotal === "number" &&
    Number.isFinite(value.subtotal) &&
    typeof value.iva === "number" &&
    Number.isFinite(value.iva) &&
    typeof value.total === "number" &&
    Number.isFinite(value.total) &&
    (value.observaciones === undefined || typeof value.observaciones === "string") &&
    (value.solicitud_compra_id === undefined ||
      (typeof value.solicitud_compra_id === "number" && Number.isInteger(value.solicitud_compra_id))) &&
    typeof value.fecha_creacion === "string"
  );
}

function readList<T>(
  key: string,
  fallback: T[],
  isItem: (value: unknown) => value is T,
  label: string,
): T[] {
  const stored = window.localStorage.getItem(key);
  if (stored === null) return fallback;

  const parsed: unknown = JSON.parse(stored);
  if (!Array.isArray(parsed) || !parsed.every(isItem)) {
    throw new Error(`Los datos guardados de ${label} tienen un formato inválido.`);
  }
  return parsed;
}

export function readSolicitudesCompra(fallback: SolicitudCompra[]): SolicitudCompra[] {
  return readList(SOLICITUDES_KEY, fallback, isSolicitudCompra, "solicitudes de compra");
}

export function saveSolicitudesCompra(solicitudes: SolicitudCompra[]): void {
  window.localStorage.setItem(SOLICITUDES_KEY, JSON.stringify(solicitudes));
}

export function readOrdenesCompra(fallback: OrdenCompra[]): OrdenCompra[] {
  return readList(ORDENES_KEY, fallback, isOrdenCompra, "órdenes de compra");
}

export function saveOrdenesCompra(ordenes: OrdenCompra[]): void {
  window.localStorage.setItem(ORDENES_KEY, JSON.stringify(ordenes));
}
