import { AppShell } from '@/components/app-shell';
import AperturaCierreCajaPage from './AperturaCierreCajaPage';

export default function Page() {
  return (
    <AppShell>
      <AperturaCierreCajaPage />
    </AppShell>
  );
}
