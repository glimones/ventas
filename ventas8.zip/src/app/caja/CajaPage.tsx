"use client";

import TreasuryCrudPage, { type TreasuryField } from "@/components/treasury-crud";

import CajaModal from "./CajaModal";
import "./bootstrap-caja.css";

const fields: TreasuryField[] = [
  { name: "codigo", label: "Código" },
  { name: "nombre", label: "Caja" },
  { name: "ubicacion", label: "Ubicación" },
  { name: "responsable", label: "Responsable" },
  { name: "saldo", label: "Saldo" },
];

const form = {
  codigo: "",
  nombre: "",
  ubicacion: "",
  responsable: "",
  saldo: 0,
  estado: "Activo",
};

const data = [
  {
    id: 1,
    codigo: "CAJ-001",
    nombre: "Caja principal",
    ubicacion: "Matriz Quito",
    responsable: "Ana Torres",
    saldo: 2450,
    estado: "Activo",
  },
];

export default function CajaPage() {
  return (
    <TreasuryCrudPage
      title="Cajas"
      searchPlaceholder="Buscar caja o responsable..."
      fields={fields}
      initialForm={form}
      initialData={data}
      Modal={CajaModal}
      css="bootstrap-caja.css"
    />
  );
}
