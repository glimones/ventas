import type { ChangeEvent } from "react";

import TreasuryForm from "@/components/treasury-form";
import type { TreasuryField } from "@/components/treasury-crud";
import type { CajaFormValues } from "./types";

interface CajaFormProps {
  values: CajaFormValues;
  onChange: (
    event: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  ) => void;
}

const fields: TreasuryField[] = [
  { name: "codigo", label: "Código" },
  { name: "nombre", label: "Nombre de caja" },
  { name: "ubicacion", label: "Ubicación" },
  { name: "responsable", label: "Responsable" },
  { name: "saldo", label: "Saldo", type: "number" },
];

export default function CajaForm({ values, onChange }: CajaFormProps) {
  return <TreasuryForm values={values} onChange={onChange} fields={fields} />;
}
