export interface Caja{id:number;codigo:string;nombre:string;ubicacion:string;responsable:string;saldo:number;estado:string}export type CajaFormValues=Omit<Caja,'id'>;
