import { AppShell } from '@/components/app-shell';
import CajaPage from './CajaPage';

export default function Page() {
  return (
    <AppShell>
      <CajaPage />
    </AppShell>
  );
}
