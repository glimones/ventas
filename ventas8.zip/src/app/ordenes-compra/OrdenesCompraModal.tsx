"use client";
import React, { useEffect } from "react";
import { OrdenesCompraFormValues } from "./types";
import OrdenesCompraForm from "./OrdenesCompraForm";

interface Props {
  show: boolean;
  editando: boolean;
  values: OrdenesCompraFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

const OrdenesCompraModal: React.FC<Props> = ({ show, editando, values, onChange, onClose, onSubmit }) => {
  useEffect(() => {
    if (show) { document.body.style.overflow = "hidden"; }
    else { document.body.style.overflow = ""; }
    return () => { document.body.style.overflow = ""; };
  }, [show]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { if (e.key === "Escape" && show) onClose(); };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [show, onClose]);

  if (!show) return null;

  return (
    <div className="purchase-modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="purchase-modal" role="dialog" aria-modal="true" aria-labelledby="purchase-modal-title">
        <form onSubmit={onSubmit}>
          <div className="purchase-modal-header">
            <h2 id="purchase-modal-title">{editando ? "Editar orden de compra" : "Nueva orden de compra"}</h2>
            <button type="button" className="purchase-modal-close" aria-label="Cerrar" onClick={onClose}>×</button>
          </div>
          <div className="purchase-modal-body">
            <OrdenesCompraForm values={values} onChange={onChange} />
          </div>
          <div className="purchase-modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
            <button type="submit" className="btn btn-success">{editando ? "Actualizar" : "Crear orden"}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default OrdenesCompraModal;