"use client";

import React, { useState, useCallback, useEffect } from "react";
import { CirclePlus, SquarePen, Trash2 } from "lucide-react";
import { OrdenCompra, OrdenesCompraFormValues } from "./types";
import OrdenesCompraModal from "./OrdenesCompraModal";
import { ORDENES_COMPRA_INITIAL, readOrdenesCompra, saveOrdenesCompra } from "../compras-store";
import "../compras-ui.css";

const INITIAL: OrdenesCompraFormValues = {
  numero_orden: "",
  fecha_orden: "",
  fecha_entrega_requerida: "",
  estado: "BORRADOR",
  tipo_orden: "",
  prioridad: "NORMAL",
  proveedor: "",
  identificacion_proveedor: "",
  subtotal: 0,
  iva: 0,
  total: 0,
  observaciones: "",
};

const ESTADOS = [
  "BORRADOR", "EMITIDA", "ENVIADA", "CONFIRMADA", "EN_PROCESO",
  "RECIBIDA_PARCIAL", "RECIBIDA_TOTAL", "FACTURADA", "PAGADA", "CANCELADA", "ANULADA",
];

const ESTADOS_POR_RECIBIR = new Set([
  "EMITIDA", "ENVIADA", "CONFIRMADA", "EN_PROCESO", "RECIBIDA_PARCIAL",
]);

function getReceivingContext(estado: string): string {
  const contextos: Record<string, string> = {
    BORRADOR: "Pendiente de emisión",
    EMITIDA: "Pendiente de envío",
    ENVIADA: "Esperando recepción",
    CONFIRMADA: "Esperando recepción",
    EN_PROCESO: "Recepción en proceso",
    RECIBIDA_PARCIAL: "Recepción parcial",
    RECIBIDA_TOTAL: "Recepción completa",
    FACTURADA: "Factura registrada",
    PAGADA: "Orden pagada",
    CANCELADA: "Orden cancelada",
    ANULADA: "Orden anulada",
  };
  return contextos[estado] ?? estado.replace(/_/g, " ");
}

export default function OrdenesCompraPage() {
  const [data, setData] = useState<OrdenCompra[]>(ORDENES_COMPRA_INITIAL);
  const [storageReady, setStorageReady] = useState(false);
  const [storageError, setStorageError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editando, setEditando] = useState(false);
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [form, setForm] = useState<OrdenesCompraFormValues>(INITIAL);
  const [filtro, setFiltro] = useState("");
  const [estadoFiltro, setEstadoFiltro] = useState("");
  const nextId = Math.max(0, ...data.map((orden) => orden.id)) + 1;

  useEffect(() => {
    try {
      setData(readOrdenesCompra(ORDENES_COMPRA_INITIAL));
      setStorageReady(true);
    } catch {
      setStorageError("No se pudieron cargar las órdenes guardadas. Revisa el almacenamiento del navegador.");
    }
  }, []);

  useEffect(() => {
    if (!storageReady) return;
    try {
      saveOrdenesCompra(data);
      setStorageError("");
    } catch {
      setStorageError("No se pudieron guardar los cambios de las órdenes en este navegador.");
    }
  }, [data, storageReady]);

  const filtered = data.filter(
    (o) =>
      (!filtro || o.proveedor.toLowerCase().includes(filtro.toLowerCase()) || o.numero_orden.toLowerCase().includes(filtro.toLowerCase())) &&
      (!estadoFiltro || (estadoFiltro === "POR_RECIBIR" ? ESTADOS_POR_RECIBIR.has(o.estado) : o.estado === estadoFiltro))
  );
  const ordenesRecibir = data.filter((orden) => ESTADOS_POR_RECIBIR.has(orden.estado)).length;
  const ordenesRecibidas = data.filter((orden) => orden.estado === "RECIBIDA_TOTAL").length;

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setForm((prev) => ({ ...prev, [name]: type === "number" ? parseFloat(value) || 0 : value }));
  }, []);

  const openNew = () => {
    setEditando(false);
    setCurrentId(null);
    setForm({ ...INITIAL, numero_orden: `OC-${new Date().getFullYear()}-${String(nextId).padStart(3, "0")}` });
    setModalOpen(true);
  };

  const openEdit = (o: OrdenCompra) => {
    setEditando(true);
    setCurrentId(o.id);
    setForm({
      numero_orden: o.numero_orden,
      fecha_orden: o.fecha_orden,
      fecha_entrega_requerida: o.fecha_entrega_requerida,
      estado: o.estado,
      tipo_orden: o.tipo_orden,
      prioridad: o.prioridad,
      proveedor: o.proveedor,
      identificacion_proveedor: o.identificacion_proveedor,
      subtotal: o.subtotal,
      iva: o.iva,
      total: o.total,
      observaciones: o.observaciones || "",
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editando && currentId !== null) {
      setData((prev) =>
        prev.map((o) =>
          o.id === currentId
            ? { ...o, ...form, estado: form.estado, tipo_orden: form.tipo_orden, prioridad: form.prioridad }
            : o
        )
      );
    } else {
      const nuevo: OrdenCompra = {
        id: nextId,
        ...form,
        estado: form.estado,
        tipo_orden: form.tipo_orden,
        prioridad: form.prioridad,
        observaciones: form.observaciones,
        fecha_creacion: new Date().toISOString().split("T")[0],
      };
      setData((prev) => [...prev, nuevo]);
    }
    setModalOpen(false);
  };

  const handleDelete = (id: number) => {
    if (window.confirm("�Eliminar esta orden de compra?")) {
      setData((prev) => prev.filter((o) => o.id !== id));
    }
  };

  return (
    <div className="bootstrap-container purchase-page purchase-page--orders">
      <div className="content-wrapper">
      <header className="purchase-page-header">
        <div>
          <p className="purchase-eyebrow">GESTIÓN DE COMPRAS</p>
          <h1>Órdenes de compra</h1>
          <p>Consulta el estado, la recepción y las fechas de entrega de tus órdenes.</p>
        </div>
        <button className="btn btn-primary purchase-create-button" onClick={openNew} disabled={!storageReady}>
          <CirclePlus size={18} /> Nueva orden
        </button>
      </header>
      {storageError && <div className="alert alert-danger" role="alert">{storageError}</div>}

      <section className="purchase-summary-grid" aria-label="Resumen de órdenes de compra">
        <article className="purchase-summary-card"><span>Órdenes registradas</span><strong>{storageReady ? data.length : "—"}</strong></article>
        <article className="purchase-summary-card purchase-summary-card--warning"><span>Pendientes de recepción</span><strong>{storageReady ? ordenesRecibir : "—"}</strong></article>
        <article className="purchase-summary-card purchase-summary-card--success"><span>Recepción completa</span><strong>{storageReady ? ordenesRecibidas : "—"}</strong></article>
      </section>

      <div className="purchase-toolbar">
        <div className="purchase-filter-controls">
          <input type="search" className="form-control purchase-search" aria-label="Buscar órdenes de compra" placeholder="Buscar proveedor o número de orden..." value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <select className="form-select purchase-status-filter" aria-label="Filtrar órdenes por estado" value={estadoFiltro} onChange={(e) => setEstadoFiltro(e.target.value)}>
            <option value="">Todos los estados</option>
            <option value="POR_RECIBIR">Por recibir</option>
            {ESTADOS.map((estado) => <option key={estado} value={estado}>{estado.replace(/_/g, " ")}</option>)}
          </select>
        </div>
        <span className="purchase-result-count" role="status">Mostrando {filtered.length} de {data.length} órdenes</span>
      </div>

      <div className="table-responsive purchase-table-wrap">
        <table className="table table-hover align-middle purchase-table">
          <thead>
            <tr>
              <th>N# Orden</th>
              <th>Fecha</th>
              <th>Entrega</th>
              <th>Proveedor</th>
              <th>Prioridad</th>
              <th>Total</th>
              <th>Estado / recepción</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {!storageReady ? (
              <tr><td colSpan={8} className="text-center text-muted py-4">Cargando órdenes...</td></tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center text-muted py-4">Sin Órdenes de compra registradas</td>
              </tr>
            ) : (
              filtered.map((o) => (
                <tr key={o.id}>
                  <td><strong>{o.numero_orden}</strong></td>
                  <td>{o.fecha_orden}</td>
                  <td>{o.fecha_entrega_requerida}</td>
                  <td>{o.proveedor}</td>
                  <td>
                    <span className={`purchase-badge purchase-badge--${getPriorityTone(o.prioridad)}`}>
                      {o.prioridad}
                    </span>
                  </td>
                  <td className="fw-bold">${o.total.toFixed(2)}</td>
                  <td>
                    <span className={`purchase-badge purchase-badge--${getStatusTone(o.estado)}`}>
                      {o.estado.replace(/_/g, " ")}
                    </span>
                    <div className="purchase-status-context">{getReceivingContext(o.estado)}</div>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      <button className="btn btn-sm btn-outline-primary" title="Editar" onClick={() => openEdit(o)}><SquarePen size={16} /></button>
                      <button className="btn btn-sm btn-outline-danger" title="Eliminar" onClick={() => handleDelete(o.id)}><Trash2 size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <OrdenesCompraModal show={modalOpen} editando={editando} values={form} onChange={handleChange} onClose={() => setModalOpen(false)} onSubmit={handleSubmit} />
      </div>
    </div>
  );
}

function getStatusTone(estado: string): string {
  if (["CANCELADA", "ANULADA"].includes(estado)) return "danger";
  if (["RECIBIDA_TOTAL", "FACTURADA", "PAGADA"].includes(estado)) return "success";
  if (["RECIBIDA_PARCIAL", "EN_PROCESO"].includes(estado)) return "warning";
  if (["EMITIDA", "ENVIADA", "CONFIRMADA"].includes(estado)) return "info";
  return "neutral";
}

function getPriorityTone(prioridad: string): string {
  if (prioridad === "URGENTE") return "danger";
  if (prioridad === "ALTA") return "warning";
  if (prioridad === "BAJA") return "success";
  return "info";
}