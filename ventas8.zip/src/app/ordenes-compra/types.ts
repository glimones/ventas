// Tipos de datos para �rdenes de Compra (versi�n simplificada para CRUD)

export interface OrdenCompra {
  id: number;
  numero_orden: string;
  fecha_orden: string;
  fecha_entrega_requerida: string;
  estado: string;
  tipo_orden: string;
  prioridad: string;
  proveedor: string;
  identificacion_proveedor: string;
  subtotal: number;
  iva: number;
  total: number;
  observaciones?: string;
  solicitud_compra_id?: number;
  fecha_creacion: string;
}

export interface OrdenesCompraFormValues {
  numero_orden: string;
  fecha_orden: string;
  fecha_entrega_requerida: string;
  estado: string;
  tipo_orden: string;
  prioridad: string;
  proveedor: string;
  identificacion_proveedor: string;
  subtotal: number;
  iva: number;
  total: number;
  observaciones: string;
}