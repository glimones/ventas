"use client";
import React from "react";
import { OrdenesCompraFormValues } from "./types";

interface Props {
  values: OrdenesCompraFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const OrdenesCompraForm: React.FC<Props> = ({ values, onChange }) => (
  <div className="row g-3">
    <div className="col-md-3">
      <label htmlFor="numero_orden" className="form-label">N# Orden *</label>
      <input type="text" className="form-control" id="numero_orden" name="numero_orden" value={values.numero_orden} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="fecha_orden" className="form-label">Fecha *</label>
      <input type="date" className="form-control" id="fecha_orden" name="fecha_orden" value={values.fecha_orden} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="fecha_entrega_requerida" className="form-label">Entrega Requerida *</label>
      <input type="date" className="form-control" id="fecha_entrega_requerida" name="fecha_entrega_requerida" value={values.fecha_entrega_requerida} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="prioridad" className="form-label">Prioridad *</label>
      <select className="form-select" id="prioridad" name="prioridad" value={values.prioridad} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="BAJA">Baja</option>
        <option value="NORMAL">Normal</option>
        <option value="ALTA">Alta</option>
        <option value="URGENTE">Urgente</option>
      </select>
    </div>
    <div className="col-md-6">
      <label htmlFor="proveedor" className="form-label">Proveedor *</label>
      <input type="text" className="form-control" id="proveedor" name="proveedor" value={values.proveedor} onChange={onChange} required />
    </div>
    <div className="col-md-6">
      <label htmlFor="identificacion_proveedor" className="form-label">Identificación *</label>
      <input type="text" className="form-control" id="identificacion_proveedor" name="identificacion_proveedor" value={values.identificacion_proveedor} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="tipo_orden" className="form-label">Tipo *</label>
      <select className="form-select" id="tipo_orden" name="tipo_orden" value={values.tipo_orden} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="DESDE_COTIZACION">Desde cotización</option>
        <option value="ORDEN_DIRECTA">Orden directa</option>
        <option value="ORDEN_URGENTE">Orden urgente</option>
        <option value="CONTRATO_MARCO">Contrato marco</option>
      </select>
    </div>
    <div className="col-md-3">
      <label htmlFor="estado" className="form-label">Estado *</label>
      <select className="form-select" id="estado" name="estado" value={values.estado} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="BORRADOR">Borrador</option>
        <option value="EMITIDA">Emitida</option>
        <option value="ENVIADA">Enviada al proveedor</option>
        <option value="CONFIRMADA">Confirmada</option>
        <option value="EN_PROCESO">En proceso</option>
        <option value="RECIBIDA_PARCIAL">Recibida parcial</option>
        <option value="RECIBIDA_TOTAL">Recibida total</option>
        <option value="FACTURADA">Facturada</option>
        <option value="PAGADA">Pagada</option>
        <option value="CANCELADA">Cancelada</option>
        <option value="ANULADA">Anulada</option>
      </select>
    </div>
    <div className="col-md-2">
      <label htmlFor="subtotal" className="form-label">Subtotal</label>
      <input type="number" step="0.01" className="form-control" id="subtotal" name="subtotal" value={values.subtotal} onChange={onChange} />
    </div>
    <div className="col-md-2">
      <label htmlFor="iva" className="form-label">IVA</label>
      <input type="number" step="0.01" className="form-control" id="iva" name="iva" value={values.iva} onChange={onChange} />
    </div>
    <div className="col-md-2">
      <label htmlFor="total" className="form-label">Total</label>
      <input type="number" step="0.01" className="form-control" id="total" name="total" value={values.total} onChange={onChange} />
    </div>
    <div className="col-md-12">
      <label htmlFor="observaciones" className="form-label">Observaciones</label>
      <textarea className="form-control" id="observaciones" name="observaciones" value={values.observaciones} onChange={onChange} rows={3} />
    </div>
  </div>
);

export default OrdenesCompraForm;