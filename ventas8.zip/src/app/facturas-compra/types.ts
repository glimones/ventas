export interface FacturasCompra { id:number; numero_factura:string; proveedor:string; identificacion_proveedor:string; fecha_emision:string; fecha_vencimiento:string; subtotal:number; iva:number; total:number; forma_pago:string; estado:string; }
export type FacturasCompraFormValues=Omit<FacturasCompra,'id'>;
