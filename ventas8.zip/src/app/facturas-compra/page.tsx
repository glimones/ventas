import { AppShell } from '@/components/app-shell';
import FacturasCompraPage from './FacturasCompraPage';

export default function Page() {
  return (
    <AppShell>
      <FacturasCompraPage />
    </AppShell>
  );
}
