'use client';

import React, { useState } from 'react';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';
import FacturasCompraModal from './FacturasCompraModal';
import { FacturasCompra, FacturasCompraFormValues } from './types';
import './bootstrap-facturas-compra.css';

const blank: FacturasCompraFormValues = {
  numero_factura: '',
  proveedor: '',
  identificacion_proveedor: '',
  fecha_emision: '',
  fecha_vencimiento: '',
  subtotal: 0,
  iva: 0,
  total: 0,
  forma_pago: 'Crédito 30 días',
  estado: 'Registrada',
};

const seed: FacturasCompra[] = [
  {
    id: 1,
    numero_factura: '001-001-000458',
    proveedor: 'Suministros XYZ',
    identificacion_proveedor: '1799876543001',
    fecha_emision: '2025-03-02',
    fecha_vencimiento: '2025-04-01',
    subtotal: 4800,
    iva: 720,
    total: 5520,
    forma_pago: 'Crédito 30 días',
    estado: 'Registrada',
  },
];

const ESTADOS_FACTURA = ['Registrada', 'Vencida', 'Pagada', 'Anulada'];

function getInvoiceStatusClass(estado: string): string {
  const classes: Record<string, string> = {
    Registrada: 'purchase-workflow-status--pending',
    Vencida: 'purchase-workflow-status--overdue',
    Pagada: 'purchase-workflow-status--complete',
    Anulada: 'purchase-workflow-status--cancelled',
  };
  return classes[estado] ?? 'purchase-workflow-status--neutral';
}

export default function FacturasCompraPage() {
  const [data, setData] = useState(seed);
  const [q, setQ] = useState('');
  const [estadoFiltro, setEstadoFiltro] = useState('');
  const [show, setShow] = useState(false);
  const [id, setId] = useState<number | null>(null);
  const [form, setForm] = useState(blank);

  const close = () => {
    setShow(false);
    setId(null);
    setForm(blank);
  };

  const edit = (invoice: FacturasCompra) => {
    setId(invoice.id);
    setForm({ ...invoice });
    setShow(true);
  };

  const change = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm((previous) => ({
      ...previous,
      [e.target.name]: ['subtotal', 'iva', 'total'].includes(e.target.name)
        ? Number(e.target.value)
        : e.target.value,
    }));
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setData((previous) =>
      id === null
        ? [...previous, { ...form, id: Date.now() }]
        : previous.map((invoice) => (invoice.id === id ? { ...invoice, ...form } : invoice)),
    );
    close();
  };

  const rows = data.filter(
    (invoice) =>
      `${invoice.numero_factura} ${invoice.proveedor} ${invoice.identificacion_proveedor}`
        .toLowerCase()
        .includes(q.toLowerCase()) &&
      (!estadoFiltro || invoice.estado === estadoFiltro),
  );

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">Facturas de Compra</h1>
        <div className="d-flex justify-content-between mb-3 gap-2 flex-wrap">
          <div className="d-flex gap-2 flex-wrap">
            <input
              className="form-control"
              style={{ width: 'min(100%, 360px)' }}
              placeholder="Buscar factura o proveedor..."
              aria-label="Buscar factura o proveedor"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <select
              className="form-select"
              style={{ width: 'min(100%, 220px)' }}
              aria-label="Filtrar facturas por estado"
              value={estadoFiltro}
              onChange={(e) => setEstadoFiltro(e.target.value)}
            >
              <option value="">Todos los estados</option>
              {ESTADOS_FACTURA.map((estado) => <option key={estado}>{estado}</option>)}
            </select>
          </div>
          <button className="btn btn-primary" onClick={() => setShow(true)}>
            <CirclePlus size={16} className="me-2" />
            Registrar factura
          </button>
        </div>
        <div className="table-responsive">
          <table className="table table-striped align-middle">
            <thead>
              <tr>
                <th>Factura</th>
                <th>Proveedor</th>
                <th>Emisión</th>
                <th>Vencimiento</th>
                <th>Subtotal</th>
                <th>Total</th>
                <th>Forma de pago</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr><td colSpan={9} className="text-center text-muted py-4">No hay facturas que coincidan con los filtros.</td></tr>
              ) : rows.map((invoice) => (
                <tr key={invoice.id}>
                  <td><strong>{invoice.numero_factura}</strong></td>
                  <td>{invoice.proveedor}</td>
                  <td>{invoice.fecha_emision}</td>
                  <td>{invoice.fecha_vencimiento}</td>
                  <td>${invoice.subtotal.toFixed(2)}</td>
                  <td className="fw-bold">${invoice.total.toFixed(2)}</td>
                  <td>{invoice.forma_pago}</td>
                  <td>
                    <span className={`purchase-workflow-status ${getInvoiceStatusClass(invoice.estado)}`}>
                      {invoice.estado}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      <button className="btn btn-warning btn-sm" aria-label={`Editar factura ${invoice.numero_factura}`} onClick={() => edit(invoice)}>
                        <SquarePen size={15} />
                      </button>
                      <button className="btn btn-danger btn-sm" aria-label={`Eliminar factura ${invoice.numero_factura}`} onClick={() => setData((previous) => previous.filter((item) => item.id !== invoice.id))}>
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-muted small mt-2">Mostrando {rows.length} de {data.length} facturas</p>
        <FacturasCompraModal show={show} editando={id !== null} values={form} onChange={change} onClose={close} onSubmit={submit} />
      </div>
    </div>
  );
}
