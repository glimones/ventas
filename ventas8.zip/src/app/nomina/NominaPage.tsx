import DomainCrud from '@/components/domain-crud';import{domainConfigs}from '@/components/domain-config';export default function NominaPage(){return <DomainCrud config={domainConfigs.nomina}/>}
