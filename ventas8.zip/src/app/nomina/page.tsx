import { AppShell } from '@/components/app-shell';
import NominaPage from './NominaPage';

export default function Page() {
  return (
    <AppShell>
      <NominaPage />
    </AppShell>
  );
}
