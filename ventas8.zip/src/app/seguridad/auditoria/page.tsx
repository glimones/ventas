import { AppShell } from '@/components/app-shell';
import AuditoriaPage from './AuditoriaPage';

export default function Page() {
  return (
    <AppShell>
      <AuditoriaPage />
    </AppShell>
  );
}
