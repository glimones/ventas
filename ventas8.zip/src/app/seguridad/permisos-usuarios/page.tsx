import DomainCrud from "@/components/domain-crud";
import { domainConfigs } from "@/components/domain-config";
import { AppShell } from "@/components/app-shell";

export default function PermisosUsuariosPage() {
  return (
    <AppShell>
      <DomainCrud config={domainConfigs['seguridad/permisos-usuarios']} />
    </AppShell>
  );
}