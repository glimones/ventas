import { AppShell } from '@/components/app-shell';
import DomainCrud from "@/components/domain-crud";
import { domainConfigs } from "@/components/domain-config";

export default function RolesPage() {
  return (
    <AppShell>
      <DomainCrud config={domainConfigs['seguridad/roles']} />
    </AppShell>
  );
}