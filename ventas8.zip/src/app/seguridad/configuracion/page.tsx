import { AppShell } from '@/components/app-shell';
import ConfiguracionPage from './ConfiguracionPage';

export default function Page() {
  return (
    <AppShell>
      <ConfiguracionPage />
    </AppShell>
  );
}
