import Link from "next/link";
import { AppShell } from "@/components/app-shell";
import { ShieldCheck, Users, KeyRound, LayoutGrid } from "lucide-react";
import "./seguridad.css";

const cards = [
  {
    title: "Usuarios",
    description: "Gestiona cuentas, accesos, 2FA y estado.",
    href: "/seguridad/usuarios",
    icon: Users,
  },
  {
    title: "Roles",
    description: "Define perfiles y alcance funcional.",
    href: "/seguridad/roles",
    icon: KeyRound,
  },
  {
    title: "Permisos de usuarios",
    description: "Controla acciones por módulo y vigencia.",
    href: "/seguridad/permisos-usuarios",
    icon: LayoutGrid,
  },
];

export default function SeguridadHome() {
  return (
    <AppShell>
      <div className="bootstrap-container security-home">
        <div className="content-wrapper">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <div>
              <h1 className="mb-2">Módulo de Seguridad</h1>
              <p className="text-muted mb-0">Administración de usuarios, roles y permisos del sistema</p>
            </div>
            <span className="badge bg-dark d-inline-flex align-items-center gap-2 p-2">
              <ShieldCheck size={18} />
              Sistema activo
            </span>
          </div>

          <div className="row g-3">
            {cards.map((card) => {
              const Icon = card.icon;
              return (
                <div key={card.href} className="col-md-4">
                  <Link href={card.href} className="security-option d-block h-100 p-4">
                    <div className="security-option-icon mb-3">
                      <Icon size={20} />
                    </div>
                    <h5 className="mb-2">{card.title}</h5>
                    <p className="text-muted mb-0">{card.description}</p>
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </AppShell>
  );
}