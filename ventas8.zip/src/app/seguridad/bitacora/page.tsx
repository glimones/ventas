import { AppShell } from '@/components/app-shell';
import BitacoraPage from './BitacoraPage';

export default function Page() {
  return (
    <AppShell>
      <BitacoraPage />
    </AppShell>
  );
}
