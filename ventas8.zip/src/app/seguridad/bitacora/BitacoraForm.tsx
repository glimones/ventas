'use client';
import React from 'react';
import { BitacoraFormValues } from './types';

interface Props {
  values: BitacoraFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const BitacoraForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className="row g-3">
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="codigo" className="form-label">Código *</label>
          <input type="text" className="form-control" id="codigo" name="codigo" value={values.codigo || ''} onChange={handleInputChange} required autoComplete="off" />
        </div>
      </div>
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label">Nombre *</label>
          <input type="text" className="form-control" id="nombre" name="nombre" value={values.nombre || ''} onChange={handleInputChange} required autoComplete="off" />
        </div>
      </div>
      <div className="col-md-12">
        <div className="mb-3">
          <label htmlFor="descripcion" className="form-label">Descripción</label>
          <textarea className="form-control" id="descripcion" name="descripcion" value={values.descripcion || ''} onChange={handleInputChange} rows={3} autoComplete="off" />
        </div>
      </div>
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="fecha" className="form-label">Fecha</label>
          <input type="date" className="form-control" id="fecha" name="fecha" value={values.fecha || ''} onChange={handleInputChange} autoComplete="off" />
        </div>
      </div>
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="estado" className="form-label">Estado *</label>
          <select className="form-select" id="estado" name="estado" value={values.estado || ''} onChange={handleInputChange} required>
            <option value="">Seleccione...</option>
            <option value="Activo">Activo</option>
            <option value="Inactivo">Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default BitacoraForm;
