export interface Proveedores {
  id: number;
  codigo: string;
  razon_social: string;
  nombre_comercial: string;
  tipo_identificacion: string;
  identificacion: string;
  categoria: string;
  email: string;
  telefono: string;
  ciudad: string;
  dias_credito: number;
  estado: string;
}

export interface ProveedoresFormValues {
  codigo: string;
  razon_social: string;
  nombre_comercial: string;
  tipo_identificacion: string;
  identificacion: string;
  categoria: string;
  email: string;
  telefono: string;
  ciudad: string;
  dias_credito: number;
  estado: string;
}
