import { AppShell } from '@/components/app-shell';
import ClasificacionPage from './ClasificacionPage';

export default function Page() {
  return (
    <AppShell>
      <ClasificacionPage />
    </AppShell>
  );
}
