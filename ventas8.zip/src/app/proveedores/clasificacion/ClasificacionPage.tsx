'use client';
import React, { useState } from 'react';
import { Clasificacion, ClasificacionFormValues } from './types';
import ClasificacionModal from './ClasificacionModal';
import './bootstrap-clasificacion.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: ClasificacionFormValues = {
  codigo: '',
  nombre: '',
  nivel_riesgo: '',
  categoria_compra: '',
  criticidad: '',
  dias_credito: 0,
  proveedores_asignados: 0,
  estado: 'Activo',
};

const initialData: Clasificacion[] = [
  { id: 1, codigo: 'EST', nombre: 'Proveedores estratégicos', nivel_riesgo: 'BAJO', categoria_compra: 'Tecnología y suministros críticos', criticidad: 'ESTRATEGICO', dias_credito: 30, proveedores_asignados: 6, estado: 'Activo' },
  { id: 2, codigo: 'REG', nombre: 'Proveedores regulares', nivel_riesgo: 'MEDIO', categoria_compra: 'Servicios generales', criticidad: 'IMPORTANTE', dias_credito: 15, proveedores_asignados: 14, estado: 'Activo' },
];

export default function ClasificacionPage() {
  const [data, setData] = useState<Clasificacion[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ClasificacionFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (item: Clasificacion) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      nombre: item.nombre || '',
      nivel_riesgo: item.nivel_riesgo || '',
      categoria_compra: item.categoria_compra || '',
      criticidad: item.criticidad || '',
      dias_credito: item.dias_credito || 0,
      proveedores_asignados: item.proveedores_asignados || 0,
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const numericFields = ['dias_credito', 'proveedores_asignados'];
    setForm(prev => ({ ...prev, [e.target.name]: numericFields.includes(e.target.name) ? Number(e.target.value) : e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, ...form }
          : item
      ));
    } else {
      const nuevo: Clasificacion = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        ...form,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nivel_riesgo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.categoria_compra.toLowerCase().includes(filtro.toLowerCase()) ||
    item.criticidad.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Clasificación</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Riesgo</th>
                <th>Categoría de compra</th>
                <th>Criticidad</th>
                <th>Crédito</th>
                <th>Proveedores</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={11} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.nombre}</td>
                  <td>{item.nivel_riesgo}</td>
                  <td>{item.categoria_compra}</td>
                  <td>{item.criticidad}</td>
                  <td>{item.dias_credito} días</td>
                  <td>{item.proveedores_asignados}</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <ClasificacionModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
