export interface Clasificacion {
  id: number;
  codigo: string;
  nombre: string;
  nivel_riesgo: string;
  categoria_compra: string;
  criticidad: string;
  dias_credito: number;
  proveedores_asignados: number;
  estado: string;
}

export interface ClasificacionFormValues {
  codigo: string;
  nombre: string;
  nivel_riesgo: string;
  categoria_compra: string;
  criticidad: string;
  dias_credito: number;
  proveedores_asignados: number;
  estado: string;
}
