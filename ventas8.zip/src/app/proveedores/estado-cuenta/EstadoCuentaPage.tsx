'use client';
import React, { useState } from 'react';
import { EstadoCuenta, EstadoCuentaFormValues } from './types';
import EstadoCuentaModal from './EstadoCuentaModal';
import './bootstrap-estado-cuenta.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: EstadoCuentaFormValues = {
  codigo: '',
  proveedor: '',
  tipo_documento: '',
  fecha_emision: '',
  fecha_vencimiento: '',
  total: 0,
  saldo: 0,
  dias_mora: 0,
  estado: 'Activo',
};

const initialData: EstadoCuenta[] = [
  { id: 1, codigo: 'FAC-00871', proveedor: 'Suministros Andinos S.A.', tipo_documento: 'FACTURA', fecha_emision: '2025-09-01', fecha_vencimiento: '2025-10-01', total: 1850, saldo: 1850, dias_mora: 0, estado: 'Pendiente' },
  { id: 2, codigo: 'FAC-00822', proveedor: 'Tecnología Empresarial Cía. Ltda.', tipo_documento: 'FACTURA', fecha_emision: '2025-08-05', fecha_vencimiento: '2025-09-04', total: 4920, saldo: 1320, dias_mora: 26, estado: 'Vencido' },
];

export default function EstadoCuentaPage() {
  const [data, setData] = useState<EstadoCuenta[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<EstadoCuentaFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (item: EstadoCuenta) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      proveedor: item.proveedor || '',
      tipo_documento: item.tipo_documento || '',
      fecha_emision: item.fecha_emision || '',
      fecha_vencimiento: item.fecha_vencimiento || '',
      total: item.total || 0,
      saldo: item.saldo || 0,
      dias_mora: item.dias_mora || 0,
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const numericFields = ['total', 'saldo', 'dias_mora'];
    setForm(prev => ({ ...prev, [e.target.name]: numericFields.includes(e.target.name) ? Number(e.target.value) : e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, ...form }
          : item
      ));
    } else {
      const nuevo: EstadoCuenta = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        ...form,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.proveedor.toLowerCase().includes(filtro.toLowerCase()) ||
    item.tipo_documento.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Estados de Cuenta</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Proveedor</th>
                <th>Documento</th>
                <th>Emisión</th>
                <th>Vencimiento</th>
                <th>Total</th>
                <th>Saldo</th>
                <th>Mora</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={11} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.proveedor}</td>
                  <td>{item.tipo_documento}<br /><small className='text-muted'>{item.codigo}</small></td>
                  <td>{item.fecha_emision}</td>
                  <td>{item.fecha_vencimiento}</td>
                  <td>${item.total.toFixed(2)}</td>
                  <td className='fw-bold'>${item.saldo.toFixed(2)}</td>
                  <td>{item.dias_mora > 0 ? `${item.dias_mora} días` : 'Al día'}</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <EstadoCuentaModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
