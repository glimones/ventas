import { AppShell } from '@/components/app-shell';
import DecimosPage from './DecimosPage';

export default function Page() {
  return (
    <AppShell>
      <DecimosPage />
    </AppShell>
  );
}
