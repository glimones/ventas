import DomainCrud from '@/components/domain-crud';import{domainConfigs}from '@/components/domain-config';export default function DecimosPage(){return <DomainCrud config={domainConfigs.decimos}/>}
