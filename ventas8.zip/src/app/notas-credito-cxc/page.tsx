import { AppShell } from '@/components/app-shell';
import NotasCreditoCxcPage from './NotasCreditoCxcPage';

export default function Page() {
  return (
    <AppShell>
      <NotasCreditoCxcPage />
    </AppShell>
  );
}
