import { AppShell } from '@/components/app-shell';
import DepreciacionesPage from './DepreciacionesPage';

export default function Page() {
  return (
    <AppShell>
      <DepreciacionesPage />
    </AppShell>
  );
}
