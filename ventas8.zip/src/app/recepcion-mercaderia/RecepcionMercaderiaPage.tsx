'use client';

import React, { useState } from 'react';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';
import RecepcionMercaderiaModal from './RecepcionMercaderiaModal';
import { RecepcionMercaderia, RecepcionMercaderiaFormValues } from './types';
import './bootstrap-recepcion-mercaderia.css';

const blank: RecepcionMercaderiaFormValues = {
  codigo: '',
  orden_compra: '',
  proveedor: '',
  bodega: '',
  guia_remision: '',
  fecha_recepcion: '',
  recibido_por: '',
  cantidad_items: 0,
  estado: 'Pendiente',
};

const seed: RecepcionMercaderia[] = [
  {
    id: 1,
    codigo: 'REC-001',
    orden_compra: 'OC-2025-001',
    proveedor: 'Suministros XYZ',
    bodega: 'Matriz Quito',
    guia_remision: 'GR-001-000456',
    fecha_recepcion: '2025-03-02',
    recibido_por: 'Carlos Ruiz',
    cantidad_items: 24,
    estado: 'Completa',
  },
];

const ESTADOS_RECEPCION = ['Pendiente', 'Parcial', 'Completa', 'Rechazada'];

function getReceiptStatusClass(estado: string): string {
  const classes: Record<string, string> = {
    Pendiente: 'purchase-workflow-status--pending',
    Parcial: 'purchase-workflow-status--partial',
    Completa: 'purchase-workflow-status--complete',
    Rechazada: 'purchase-workflow-status--cancelled',
  };
  return classes[estado] ?? 'purchase-workflow-status--neutral';
}

export default function RecepcionMercaderiaPage() {
  const [data, setData] = useState(seed);
  const [q, setQ] = useState('');
  const [estadoFiltro, setEstadoFiltro] = useState('');
  const [show, setShow] = useState(false);
  const [id, setId] = useState<number | null>(null);
  const [form, setForm] = useState(blank);

  const close = () => {
    setShow(false);
    setId(null);
    setForm(blank);
  };

  const edit = (receipt: RecepcionMercaderia) => {
    setId(receipt.id);
    setForm({ ...receipt });
    setShow(true);
  };

  const change = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm((previous) => ({
      ...previous,
      [e.target.name]: e.target.name === 'cantidad_items' ? Number(e.target.value) : e.target.value,
    }));
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setData((previous) =>
      id === null
        ? [...previous, { ...form, id: Date.now() }]
        : previous.map((receipt) => (receipt.id === id ? { ...receipt, ...form } : receipt)),
    );
    close();
  };

  const rows = data.filter(
    (receipt) =>
      `${receipt.codigo} ${receipt.orden_compra} ${receipt.proveedor} ${receipt.bodega} ${receipt.guia_remision}`
        .toLowerCase()
        .includes(q.toLowerCase()) &&
      (!estadoFiltro || receipt.estado === estadoFiltro),
  );

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">Recepción de Mercadería</h1>
        <div className="d-flex justify-content-between mb-3 gap-2 flex-wrap">
          <div className="d-flex gap-2 flex-wrap">
            <input
              className="form-control"
              style={{ width: 'min(100%, 360px)' }}
              placeholder="Buscar orden, proveedor o guía..."
              aria-label="Buscar orden, proveedor o guía"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
            <select
              className="form-select"
              style={{ width: 'min(100%, 220px)' }}
              aria-label="Filtrar recepciones por estado"
              value={estadoFiltro}
              onChange={(e) => setEstadoFiltro(e.target.value)}
            >
              <option value="">Todos los estados</option>
              {ESTADOS_RECEPCION.map((estado) => <option key={estado}>{estado}</option>)}
            </select>
          </div>
          <button className="btn btn-primary" onClick={() => setShow(true)}>
            <CirclePlus size={16} className="me-2" />
            Registrar recepción
          </button>
        </div>
        <div className="table-responsive">
          <table className="table table-striped align-middle">
            <thead>
              <tr>
                <th>Recepción</th>
                <th>Orden</th>
                <th>Proveedor</th>
                <th>Bodega</th>
                <th>Guía</th>
                <th>Fecha</th>
                <th>Ítems registrados</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr><td colSpan={9} className="text-center text-muted py-4">No hay recepciones que coincidan con los filtros.</td></tr>
              ) : rows.map((receipt) => (
                <tr key={receipt.id}>
                  <td><strong>{receipt.codigo}</strong></td>
                  <td>{receipt.orden_compra}</td>
                  <td>{receipt.proveedor}</td>
                  <td>{receipt.bodega}</td>
                  <td>{receipt.guia_remision}</td>
                  <td>{receipt.fecha_recepcion}</td>
                  <td>{receipt.cantidad_items}</td>
                  <td>
                    <span className={`purchase-workflow-status ${getReceiptStatusClass(receipt.estado)}`}>
                      {receipt.estado}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      <button className="btn btn-warning btn-sm" aria-label={`Editar recepción ${receipt.codigo}`} onClick={() => edit(receipt)}>
                        <SquarePen size={15} />
                      </button>
                      <button className="btn btn-danger btn-sm" aria-label={`Eliminar recepción ${receipt.codigo}`} onClick={() => setData((previous) => previous.filter((item) => item.id !== receipt.id))}>
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-muted small mt-2">Mostrando {rows.length} de {data.length} recepciones</p>
        <RecepcionMercaderiaModal show={show} editando={id !== null} values={form} onChange={change} onClose={close} onSubmit={submit} />
      </div>
    </div>
  );
}
