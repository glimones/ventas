export interface RecepcionMercaderia { id:number; codigo:string; orden_compra:string; proveedor:string; bodega:string; guia_remision:string; fecha_recepcion:string; recibido_por:string; cantidad_items:number; estado:string; }
export type RecepcionMercaderiaFormValues=Omit<RecepcionMercaderia,'id'>;
