import { AppShell } from '@/components/app-shell';
import RecepcionMercaderiaPage from './RecepcionMercaderiaPage';

export default function Page() {
  return (
    <AppShell>
      <RecepcionMercaderiaPage />
    </AppShell>
  );
}
