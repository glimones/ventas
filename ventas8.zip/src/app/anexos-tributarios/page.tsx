import { AppShell } from '@/components/app-shell';
import AnexosTributariosPage from './AnexosTributariosPage';

export default function Page() {
  return (
    <AppShell>
      <AnexosTributariosPage />
    </AppShell>
  );
}
