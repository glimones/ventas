import { AppShell } from '@/components/app-shell';
import AsientosContablesPage from './AsientosContablesPage';

export default function Page() {
  return (
    <AppShell>
      <AsientosContablesPage />
    </AppShell>
  );
}
