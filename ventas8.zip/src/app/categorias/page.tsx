import { AppShell } from "@/components/app-shell";
import CategoriasPage from "./CategoriasPage";

export default function Page() {
  return (
    <AppShell>
      <CategoriasPage />
    </AppShell>
  );
}