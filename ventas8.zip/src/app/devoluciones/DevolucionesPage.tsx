"use client";
import React, { useState } from "react";
import { Devolucion, DevolucionesFormValues } from "./types";
import DevolucionesModal from "./DevolucionesModal";
import "./bootstrap-devoluciones.css";
import { CirclePlus, SquarePen, Trash2, Eye } from "lucide-react";

const initialForm: DevolucionesFormValues = {
  numero_devolucion: "",
  fecha_devolucion: new Date().toISOString().split("T")[0],
  factura_id: null,
  numero_factura: "",
  cliente: "",
  identificacion_cliente: "",
  motivo: "",
  estado: "PENDIENTE",
  imagen_factura: "",
};

const initialData: Devolucion[] = [
  {
    id: 1,
    numero_devolucion: "DEV-001",
    fecha_devolucion: "2025-09-15",
    factura_id: 101,
    numero_factura: "001-001-000000101",
    cliente: "COMERCIAL XYZ S.A.",
    identificacion_cliente: "1790012345001",
    motivo: "Producto defectuoso en la entrega",
    detalles: [],
    subtotal: 250.00,
    iva: 30.00,
    total: 280.00,
    estado: "APROBADA",
    fecha_creacion: "2025-09-15",
  },
  {
    id: 2,
    numero_devolucion: "DEV-002",
    fecha_devolucion: "2025-09-20",
    factura_id: 102,
    numero_factura: "001-001-000000102",
    cliente: "DISTRIBUIDORA ABC LTDA.",
    identificacion_cliente: "1790098765001",
    motivo: "Error en cantidades facturadas vs entregadas",
    detalles: [],
    subtotal: 500.00,
    iva: 60.00,
    total: 560.00,
    estado: "PENDIENTE",
    fecha_creacion: "2025-09-20",
  },
];

export default function DevolucionesPage() {
  const [data, setData] = useState<Devolucion[]>(initialData);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<DevolucionesFormValues>(initialForm);
  const [imagenAmpliada, setImagenAmpliada] = useState<string | null>(null);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    const ultimoNum = Math.max(...data.map(d => parseInt(d.numero_devolucion.replace(/[^0-9]/g, "")) || 0), 0);
    setForm(prev => ({ ...prev, numero_devolucion: `DEV-${String(ultimoNum + 1).padStart(3, "0")}` }));
    setShowModal(true);
  };

  const abrirModalEditar = (item: Devolucion) => {
    setEditandoId(item.id);
    setForm({
      numero_devolucion: item.numero_devolucion,
      fecha_devolucion: item.fecha_devolucion,
      factura_id: item.factura_id,
      numero_factura: item.numero_factura,
      cliente: item.cliente,
      identificacion_cliente: item.identificacion_cliente,
      motivo: item.motivo,
      estado: item.estado,
      imagen_factura: item.imagen_factura || "",
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: name === "factura_id" ? (value ? parseInt(value) : null) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, numero_devolucion: form.numero_devolucion, fecha_devolucion: form.fecha_devolucion, factura_id: form.factura_id || 0, numero_factura: form.numero_factura, cliente: form.cliente, identificacion_cliente: form.identificacion_cliente, motivo: form.motivo, estado: form.estado as Devolucion["estado"], imagen_factura: form.imagen_factura }
          : item
      ));
    } else {
      const nuevo: Devolucion = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        numero_devolucion: form.numero_devolucion,
        fecha_devolucion: form.fecha_devolucion,
        factura_id: form.factura_id || 0,
        numero_factura: form.numero_factura,
        cliente: form.cliente,
        identificacion_cliente: form.identificacion_cliente,
        motivo: form.motivo,
        detalles: [],
        subtotal: 0,
        iva: 0,
        total: 0,
        estado: form.estado as Devolucion["estado"],
        imagen_factura: form.imagen_factura,
        fecha_creacion: new Date().toISOString().split("T")[0],
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm("¿Está seguro de eliminar esta devolución?")) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.numero_devolucion.toLowerCase().includes(filtro.toLowerCase()) ||
    item.numero_factura.toLowerCase().includes(filtro.toLowerCase()) ||
    item.cliente.toLowerCase().includes(filtro.toLowerCase()) ||
    item.motivo.toLowerCase().includes(filtro.toLowerCase())
  );

  const estadoBadge = (estado: string) => {
    const map: Record<string, string> = {
      PENDIENTE: "warning",
      APROBADA: "success",
      RECHAZADA: "danger",
      COMPLETADA: "primary",
    };
    return map[estado] || "secondary";
  };

  const formatMoney = (val: number) => `$${val.toFixed(2)}`;

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">Devoluciones</h1>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <input type="text" className="form-control w-50" placeholder="Buscar por N# Devolución, Factura, Cliente..." value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <button className="btn btn-danger d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Devolución</span>
          </button>
        </div>
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-light">
              <tr>
                <th>N# Devolución</th>
                <th>Fecha</th>
                <th>N# Factura</th>
                <th>Cliente</th>
                <th>Identificación</th>
                <th>Motivo</th>
                <th>Total</th>
                <th>Estado</th>
                <th>Factura</th>
                <th style={{ width: "180px" }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={10} className="text-center text-muted py-4">No se encontraron devoluciones</td></tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td><strong>{item.numero_devolucion}</strong></td>
                  <td>{item.fecha_devolucion}</td>
                  <td>{item.numero_factura}</td>
                  <td>{item.cliente}</td>
                  <td>{item.identificacion_cliente}</td>
                  <td><small>{item.motivo.length > 40 ? item.motivo.substring(0, 40) + "..." : item.motivo}</small></td>
                  <td>{formatMoney(item.total)}</td>
                  <td><span className={`badge bg-${estadoBadge(item.estado)}`}>{item.estado}</span></td>
                  <td>
                    {item.imagen_factura ? (
                      <button className="btn btn-outline-info btn-sm" onClick={() => setImagenAmpliada(item.imagen_factura || null)} title="Ver factura">
                        <Eye size={14} />
                      </button>
                    ) : (
                      <span className="text-muted">-</span>
                    )}
                  </td>
                  <td>
                    <button className="btn btn-warning btn-sm me-1" onClick={() => abrirModalEditar(item)} title="Editar"><SquarePen size={16} /></button>
                    <button className="btn btn-danger btn-sm" onClick={() => eliminar(item.id)} title="Eliminar"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Imagen Ampliada */}
      {imagenAmpliada && (
        <div className="modal-overlay" onClick={() => setImagenAmpliada(null)} style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.8)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 2000, padding: "40px" }}>
          <div style={{ position: "relative", maxWidth: "90vw", maxHeight: "90vh" }}>
            <button onClick={() => setImagenAmpliada(null)} style={{ position: "absolute", top: "-30px", right: "0", background: "white", border: "none", borderRadius: "50%", width: "30px", height: "30px", fontSize: "18px", cursor: "pointer" }}>-s</button>
            <img src={imagenAmpliada} alt="Factura" style={{ maxWidth: "90vw", maxHeight: "85vh", objectFit: "contain", borderRadius: "8px" }} />
          </div>
        </div>
      )}

      <DevolucionesModal show={showModal} editando={editandoId !== null} values={form} onChange={handleChange} onClose={cerrarModal} onSubmit={handleSubmit} />
    </div>
  );
}