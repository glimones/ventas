import { AppShell } from '@/components/app-shell';
import DevolucionesPage from './DevolucionesPage';

export default function Page() {
  return (
    <AppShell>
      <DevolucionesPage />
    </AppShell>
  );
}
