"use client";
import React from "react";
import { DevolucionesFormValues } from "./types";

interface Props {
  values: DevolucionesFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onImagenChange?: (file: File | null) => void;
  imagenPreview?: string | null;
}

const DevolucionesForm: React.FC<Props> = ({ values, onChange, onImagenChange, imagenPreview }) => {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    if (onImagenChange) onImagenChange(file);
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const result = ev.target?.result as string;
        onChange({ target: { name: "imagen_factura", value: result } } as any);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="row g-3">
      {/* Datos de la Factura Relacionada */}
      <div className="col-12"><h6 className="text-primary border-bottom pb-2">Factura Relacionada</h6></div>
      <div className="col-md-3">
        <label htmlFor="numero_factura" className="form-label">N# Factura *</label>
        <input type="text" className="form-control" id="numero_factura" name="numero_factura" value={values.numero_factura} onChange={onChange} required placeholder="001-001-000000001" />
      </div>
      <div className="col-md-3">
        <label htmlFor="factura_id" className="form-label">ID Factura</label>
        <input type="number" className="form-control" id="factura_id" name="factura_id" value={values.factura_id ?? ""} onChange={onChange} placeholder="ID de factura original" />
      </div>
      <div className="col-md-6">
        <label htmlFor="cliente" className="form-label">Cliente *</label>
        <input type="text" className="form-control" id="cliente" name="cliente" value={values.cliente} onChange={onChange} required />
      </div>
      <div className="col-md-6">
        <label htmlFor="identificacion_cliente" className="form-label">Identificación Cliente *</label>
        <input type="text" className="form-control" id="identificacion_cliente" name="identificacion_cliente" value={values.identificacion_cliente} onChange={onChange} required placeholder="RUC o C�dula" />
      </div>

      {/* Datos de la Devoluci�n */}
      <div className="col-12 mt-3"><h6 className="text-primary border-bottom pb-2">Datos de la Devolución</h6></div>
      <div className="col-md-3">
        <label htmlFor="numero_devolucion" className="form-label">N# Devolución *</label>
        <input type="text" className="form-control" id="numero_devolucion" name="numero_devolucion" value={values.numero_devolucion} onChange={onChange} required placeholder="DEV-001" />
      </div>
      <div className="col-md-3">
        <label htmlFor="fecha_devolucion" className="form-label">Fecha Devolución *</label>
        <input type="date" className="form-control" id="fecha_devolucion" name="fecha_devolucion" value={values.fecha_devolucion} onChange={onChange} required />
      </div>
      <div className="col-md-6">
        <label htmlFor="estado" className="form-label">Estado *</label>
        <select className="form-select" id="estado" name="estado" value={values.estado} onChange={onChange} required>
          <option value="">Seleccione...</option>
          <option value="PENDIENTE">Pendiente</option>
          <option value="APROBADA">Aprobada</option>
          <option value="RECHAZADA">Rechazada</option>
          <option value="COMPLETADA">Completada</option>
        </select>
      </div>
      <div className="col-md-12">
        <label htmlFor="motivo" className="form-label">Motivo de Devolución *</label>
        <textarea className="form-control" id="motivo" name="motivo" value={values.motivo} onChange={onChange} rows={3} required placeholder="Describa el motivo de la devoluci�n..." />
      </div>

      {/* Imagen de la Factura */}
      <div className="col-12 mt-3"><h6 className="text-primary border-bottom pb-2">Imagen de Factura</h6></div>
      <div className="col-md-12">
        <input type="file" className="form-control" accept="image/*,.pdf" onChange={handleFileChange} />
        {imagenPreview && (
          <div className="mt-3 p-2 border rounded">
            <img src={imagenPreview} alt="Vista previa factura" style={{ maxWidth: "100%", maxHeight: "400px", objectFit: "contain" }} />
          </div>
        )}
        {!imagenPreview && values.imagen_factura && (
          <div className="mt-3 p-2 border rounded">
            <img src={values.imagen_factura} alt="Factura" style={{ maxWidth: "100%", maxHeight: "400px", objectFit: "contain" }} />
          </div>
        )}
        {!imagenPreview && !values.imagen_factura && (
          <small className="text-muted">Adjunte una imagen o PDF de la factura relacionada (opcional)</small>
        )}
      </div>
    </div>
  );
};

export default DevolucionesForm;