// Tipos de datos para Devoluciones
// Una devoluci�n est� vinculada a una factura y contiene los productos devueltos

export interface DetalleDevolucion {
  id: number;
  codigo_producto: string;
  descripcion: string;
  cantidad_devuelta: number;
  precio_unitario: number;
  subtotal: number;
  motivo: string;
}

export interface Devolucion {
  id: number;
  numero_devolucion: string;
  fecha_devolucion: string;
  factura_id: number;
  numero_factura: string;
  cliente: string;
  identificacion_cliente: string;
  motivo: string;
  detalles: DetalleDevolucion[];
  subtotal: number;
  iva: number;
  total: number;
  estado: "PENDIENTE" | "APROBADA" | "RECHAZADA" | "COMPLETADA";
  imagen_factura?: string;
  fecha_creacion: string;
}

export interface DevolucionesFormValues {
  numero_devolucion: string;
  fecha_devolucion: string;
  factura_id: number | null;
  numero_factura: string;
  cliente: string;
  identificacion_cliente: string;
  motivo: string;
  estado: string;
  imagen_factura?: string;
}