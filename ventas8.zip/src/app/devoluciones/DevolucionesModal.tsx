"use client";
import React, { useEffect, useState } from "react";
import { DevolucionesFormValues } from "./types";
import DevolucionesForm from "./DevolucionesForm";

interface Props {
  show: boolean;
  editando: boolean;
  values: DevolucionesFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

const DevolucionesModal: React.FC<Props> = ({ show, editando, values, onChange, onClose, onSubmit }) => {
  const [imagenPreview, setImagenPreview] = useState<string | null>(null);

  useEffect(() => {
    if (show) { document.body.style.overflow = "hidden"; }
    else { document.body.style.overflow = ""; }
    return () => { document.body.style.overflow = ""; };
  }, [show]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => { if (e.key === "Escape" && show) onClose(); };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [show, onClose]);

  // Limpiar preview al abrir/cerrar
  useEffect(() => { if (!show) setImagenPreview(null); }, [show]);

  if (!show) return null;

  const handleBackdropClick = (e: React.MouseEvent) => { if (e.target === e.currentTarget) onClose(); };

  const handleImagenChange = (file: File | null) => {
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setImagenPreview(ev.target?.result as string);
      reader.readAsDataURL(file);
    } else {
      setImagenPreview(null);
    }
  };

  return (
    <div className="modal-overlay" onClick={handleBackdropClick} style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1050, padding: "20px" }}>
      <div className="modal-container" style={{ background: "white", borderRadius: "12px", width: "100%", maxWidth: "900px", maxHeight: "95vh", overflow: "hidden", boxShadow: "0 20px 60px rgba(0,0,0,0.3)", display: "flex", flexDirection: "column" }}>
        <form onSubmit={onSubmit}>
          <div className="modal-header text-white" style={{ padding: "1.5rem", display: "flex", alignItems: "center", justifyContent: "space-between", background: "#dc3545" }}>
            <h5 className="modal-title">
              <i className="fas fa-undo-alt me-2"></i>
              {editando ? "Editar Devolución" : "Nueva Devolución"}
            </h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose} aria-label="Cerrar" style={{ filter: "brightness(0) invert(1)" }} />
          </div>
          <div className="modal-body" style={{ padding: "1.5rem", overflowY: "auto", maxHeight: "calc(85vh - 140px)" }}>
            <DevolucionesForm values={values} onChange={onChange} onImagenChange={handleImagenChange} imagenPreview={imagenPreview} />
          </div>
          <div className="modal-footer" style={{ padding: "1rem 1.5rem", display: "flex", justifyContent: "flex-end", gap: "0.5rem", borderTop: "1px solid #dee2e6", background: "#f8f9fa" }}>
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
            <button type="submit" className="btn btn-danger">{editando ? "Actualizar" : "Registrar Devolución"}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DevolucionesModal;