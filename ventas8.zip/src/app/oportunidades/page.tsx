import { AppShell } from '@/components/app-shell';
import OportunidadesPage from './OportunidadesPage';

export default function Page() {
  return (
    <AppShell>
      <OportunidadesPage />
    </AppShell>
  );
}
