import { AppShell } from '@/components/app-shell';
import GestionCobranzaPage from './GestionCobranzaPage';

export default function Page() {
  return (
    <AppShell>
      <GestionCobranzaPage />
    </AppShell>
  );
}
