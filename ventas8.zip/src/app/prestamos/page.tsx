import { AppShell } from '@/components/app-shell';
import PrestamosPage from './PrestamosPage';

export default function Page() {
  return (
    <AppShell>
      <PrestamosPage />
    </AppShell>
  );
}
