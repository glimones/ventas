import { AppShell } from '@/components/app-shell';
import FormasPagoPage from './FormasPagoPage';

export default function Page() {
  return (
    <AppShell>
      <FormasPagoPage />
    </AppShell>
  );
}
