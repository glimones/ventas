import { AppShell } from '@/components/app-shell';
import NumeracionesPage from './NumeracionesPage';

export default function Page() {
  return (
    <AppShell>
      <NumeracionesPage />
    </AppShell>
  );
}
