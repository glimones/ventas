import { AppShell } from '@/components/app-shell';
import ConfiguracionGeneralPage from './ConfiguracionGeneralPage';

export default function Page() {
  return (
    <AppShell>
      <ConfiguracionGeneralPage />
    </AppShell>
  );
}
