import { AppShell } from '@/components/app-shell';
import PuntosEmisionPage from './PuntosEmisionPage';

export default function Page() {
  return (
    <AppShell>
      <PuntosEmisionPage />
    </AppShell>
  );
}
