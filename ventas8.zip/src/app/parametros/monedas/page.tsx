import { AppShell } from '@/components/app-shell';
import MonedasPage from './MonedasPage';

export default function Page() {
  return (
    <AppShell>
      <MonedasPage />
    </AppShell>
  );
}
