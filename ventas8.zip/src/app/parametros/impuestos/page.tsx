import { AppShell } from '@/components/app-shell';
import ImpuestosPage from './ImpuestosPage';

export default function Page() {
  return (
    <AppShell>
      <ImpuestosPage />
    </AppShell>
  );
}
