import { AppShell } from '@/components/app-shell';
import BajasActivosPage from './BajasActivosPage';

export default function Page() {
  return (
    <AppShell>
      <BajasActivosPage />
    </AppShell>
  );
}
