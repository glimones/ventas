import { AppShell } from '@/components/app-shell';
import CuentasPorPagarPage from './CuentasPorPagarPage';

export default function Page() {
  return (
    <AppShell>
      <CuentasPorPagarPage />
    </AppShell>
  );
}
