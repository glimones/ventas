export interface CuentasPorPagar { id:number; numero_obligacion:string; factura:string; proveedor:string; fecha_emision:string; fecha_vencimiento:string; total:number; pagado:number; saldo:number; dias_mora:number; estado:string; }
export type CuentasPorPagarFormValues=Omit<CuentasPorPagar,'id'>;
