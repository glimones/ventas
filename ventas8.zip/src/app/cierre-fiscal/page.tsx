import { AppShell } from '@/components/app-shell';
import CierreFiscalPage from './CierreFiscalPage';

export default function Page() {
  return (
    <AppShell>
      <CierreFiscalPage />
    </AppShell>
  );
}
