"use client";

import React, { useEffect } from "react";
import { History, RotateCcw, X } from "lucide-react";
import { Producto } from "./types";
import { useProductoMovimientos } from "./use-producto-movimientos";
import "./producto.css";

interface Props {
  producto: Producto;
  ubicacion: string;
  onClose: () => void;
}

const tipoMovimientoLabel = (tipo: string) => {
  switch (tipo) {
    case "ENTRADA":
      return "Entrada";
    case "SALIDA":
      return "Salida";
    case "TRANSFERENCIA":
      return "Transferencia";
    case "AJUSTE":
      return "Ajuste";
    default:
      return tipo;
  }
};

const formatFecha = (value: string) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "Fecha no disponible"
    : date.toLocaleString("es-EC");
};

const ProductoHistorialModal: React.FC<Props> = ({
  producto,
  ubicacion,
  onClose,
}) => {
  const { data, isLoading, error, refetch } = useProductoMovimientos(
    producto.id,
  );

  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };

    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose]);

  return (
    <div
      className="producto-history-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        className="producto-history-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="producto-history-title"
      >
        <header className="producto-history-header">
          <div className="producto-history-heading">
            <span className="producto-history-icon" aria-hidden="true">
              <History size={21} />
            </span>
            <div>
              <p>Inventario · movimientos recientes</p>
              <h2 id="producto-history-title">{producto.nombre}</h2>
              <small>
                Código {producto.codigo} · {ubicacion}
              </small>
            </div>
          </div>
          <button
            type="button"
            className="producto-history-close"
            onClick={onClose}
            aria-label="Cerrar historial"
          >
            <X size={20} />
          </button>
        </header>

        <div className="producto-history-summary">
          <div>
            <span>Stock actual</span>
            <strong>
              {producto.stock_actual} {producto.unidad_medida}
            </strong>
          </div>
          <div>
            <span>Stock mínimo</span>
            <strong>
              {producto.controla_stock === false
                ? "No controla stock"
                : `${producto.stock_minimo} ${producto.unidad_medida}`}
            </strong>
          </div>
          <div>
            <span>Movimientos cargados</span>
            <strong>{isLoading ? "…" : data.length}</strong>
          </div>
        </div>

        <div className="producto-history-content">
          {error && (
            <div className="alert alert-danger" role="alert">
              <span>{error}</span>
              <button
                type="button"
                className="btn btn-outline-danger btn-sm"
                onClick={refetch}
                disabled={isLoading}
              >
                <RotateCcw size={14} className="me-1" />
                Reintentar
              </button>
            </div>
          )}

          {isLoading && (
            <div className="producto-history-loading" role="status">
              <span className="spinner-border spinner-border-sm" aria-hidden="true" />
              Cargando movimientos…
            </div>
          )}

          {!isLoading && !error && data.length === 0 && (
            <div className="producto-history-empty">
              <History size={28} aria-hidden="true" />
              <strong>Sin movimientos registrados</strong>
              <span>
                Cuando se registre una entrada, salida o ajuste aparecerá aquí.
              </span>
            </div>
          )}

          {data.length > 0 && (
            <div className="table-responsive producto-history-table">
              <table className="table table-hover align-middle">
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Movimiento</th>
                    <th>Bodega</th>
                    <th className="text-end">Cantidad</th>
                    <th>Motivo / referencia</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((movimiento) => (
                    <tr key={movimiento.id}>
                      <td>{formatFecha(movimiento.fecha)}</td>
                      <td>
                        <span
                          className={`badge movimiento-${movimiento.tipo.toLowerCase()}`}
                        >
                          {tipoMovimientoLabel(movimiento.tipo)}
                        </span>
                      </td>
                      <td>{movimiento.bodega_nombre || "Bodega sin nombre"}</td>
                      <td className="text-end">
                        {movimiento.cantidad.toLocaleString("es-EC")}
                      </td>
                      <td>
                        <div className="producto-history-reason">
                          <span>{movimiento.motivo || "Sin motivo indicado"}</span>
                          {movimiento.documento_referencia && (
                            <small>{movimiento.documento_referencia}</small>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <footer className="producto-history-footer">
          <span>Se muestran hasta los 50 movimientos más recientes.</span>
          <button type="button" className="btn btn-secondary" onClick={onClose}>
            Cerrar
          </button>
        </footer>
      </section>
    </div>
  );
};

export default ProductoHistorialModal;
