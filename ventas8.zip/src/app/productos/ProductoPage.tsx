"use client";

import React, { useState, useCallback, useEffect, useMemo } from "react";
import {
  Producto,
  ProductoFormValues,
  MovimientoInventario,
  ProductoCatalogs,
  TransferenciaSugerida,
} from "./types";
import ProductoModal from "./ProductoModal";
import MovimientoModal from "./MovimientoModal";
import ProductoHistorialModal from "./ProductoHistorialModal";
import TransferenciaSugeridaModal from "./TransferenciaSugeridaModal";
import { useTransferenciasSugeridas } from "./use-transferencias-sugeridas";
import "./bootstrap-producto.css";
import "./inventario-inteligente.css";
import {
  AlertTriangle,
  ArrowUpDown,
  ArrowRightLeft,
  CirclePlus,
  History,
  MapPin,
  Package,
  SquarePen,
  Trash2,
} from "lucide-react";

type FiltroStock =
  | "TODOS"
  | "AGOTADOS"
  | "BAJO"
  | "REPOSICION"
  | "NORMAL"
  | "EXCESO";

type EstadoStock = "AGOTADO" | "BAJO" | "NORMAL" | "EXCESO" | "NO_CONTROLADO";

const getEtiquetaStock = (estado: EstadoStock) => {
  switch (estado) {
    case "AGOTADO":
      return "Agotado";
    case "BAJO":
      return "Bajo mínimo";
    case "EXCESO":
      return "Sobre máximo";
    case "NO_CONTROLADO":
      return "No controlado";
    default:
      return "Saludable";
  }
};

const getEstadoStock = (producto: Producto): EstadoStock => {
  if (producto.controla_stock === false) return "NO_CONTROLADO";
  if (producto.stock_actual <= 0) return "AGOTADO";
  if (producto.stock_minimo > 0 && producto.stock_actual <= producto.stock_minimo) {
    return "BAJO";
  }
  if (
    producto.stock_maximo > 0 &&
    producto.stock_actual > producto.stock_maximo
  ) {
    return "EXCESO";
  }
  return "NORMAL";
};

const getCantidadSugerida = (producto: Producto): number | null => {
  if (producto.controla_stock === false) return null;
  const nivelMinimo = Math.max(0, producto.stock_minimo);
  const nivelObjetivo =
    producto.stock_maximo > nivelMinimo
      ? producto.stock_maximo
      : nivelMinimo > 0
        ? nivelMinimo * 2
        : null;
  return nivelObjetivo === null
    ? null
    : Math.max(0, nivelObjetivo - producto.stock_actual);
};

const formatStock = (value: number) =>
  value.toLocaleString("es-EC", { maximumFractionDigits: 4 });

const initialForm: ProductoFormValues = {
  codigo: "",
  nombre: "",
  descripcion: "",
  categoria: "",
  categoria_id: "",
  precio_compra: 0,
  precio_venta: 0,
  costo: 0,
  stock_actual: 0,
  stock_minimo: 0,
  stock_maximo: 0,
  unidad_medida: "",
  unidad_medida_id: "",
  marca_id: "",
  proveedor_id: "",
  ubicacion_id: "",
  bodega_id: "",
  imagen_url: "",
  estado: "Activo",
};

export default function ProductosPage() {
  const [productos, setProductos] = useState<Producto[]>([]);
  const {
    data: transferenciasSugeridas,
    isLoading: cargandoTransferencias,
    error: errorTransferencias,
    refetch: recargarTransferencias,
  } = useTransferenciasSugeridas();
  const [filtro, setFiltro] = useState<string>("");
  const [filtroStock, setFiltroStock] = useState<FiltroStock>("TODOS");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [showMovimientoModal, setShowMovimientoModal] = useState<boolean>(false);
  const [selectedProducto, setSelectedProducto] = useState<Producto | null>(null);
  const [productoHistorial, setProductoHistorial] = useState<Producto | null>(null);
  const [transferenciaSeleccionada, setTransferenciaSeleccionada] =
    useState<TransferenciaSugerida | null>(null);
  const [guardandoTransferencia, setGuardandoTransferencia] = useState(false);
  const [errorTransferencia, setErrorTransferencia] = useState<string | null>(null);
  const [mensajeTransferencia, setMensajeTransferencia] = useState<string | null>(
    null,
  );
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ProductoFormValues>(initialForm);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [guardando, setGuardando] = useState(false);
  const [catalogos, setCatalogos] = useState<ProductoCatalogs>({
    categorias: [], marcas: [], unidades: [], bodegas: [], ubicaciones: [], proveedores: [],
  });
  const [cargandoCatalogos, setCargandoCatalogos] = useState(true);

  const cargarProductos = useCallback(async () => {
    setCargando(true);
    try {
      const response = await fetch("/api/productos", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudieron cargar los productos.");
      setProductos(result.data as Producto[]);
      setError("");
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Error al cargar productos.");
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => { void cargarProductos(); }, [cargarProductos]);

  const cargarCatalogos = useCallback(async () => {
    setCargandoCatalogos(true);
    try {
      const response = await fetch("/api/productos/catalogos", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudieron cargar los catálogos.");
      setCatalogos(result as ProductoCatalogs);
    } catch (catalogError) {
      setError(catalogError instanceof Error ? catalogError.message : "Error al cargar catálogos.");
    } finally { setCargandoCatalogos(false); }
  }, []);

  useEffect(() => { void cargarCatalogos(); }, [cargarCatalogos]);

  const limpiarForm = useCallback(() => {
    setForm(initialForm);
    setEditandoId(null);
  }, []);

  const abrirModalNuevo = useCallback(() => {
    limpiarForm();
    setError("");
    setShowModal(true);
  }, [limpiarForm]);
  
  const abrirModalEditar = useCallback((producto: Producto) => {
    // Crear un nuevo objeto para evitar referencias
    setForm({
      codigo: producto.codigo || "",
      nombre: producto.nombre || "",
      descripcion: producto.descripcion || "",
      categoria: producto.categoria || "",
      categoria_id: String(producto.categoria_id || ""),
      precio_compra: producto.precio_compra || 0,
      precio_venta: producto.precio_venta || 0,
      costo: producto.costo || 0,
      stock_actual: producto.stock_actual || 0,
      stock_minimo: producto.stock_minimo || 0,
      stock_maximo: producto.stock_maximo || 0,
      unidad_medida: producto.unidad_medida || "",
      unidad_medida_id: String(producto.unidad_medida_id || ""),
      marca_id: producto.marca_id ? String(producto.marca_id) : "",
      proveedor_id: producto.proveedor_id ? String(producto.proveedor_id) : "",
      ubicacion_id: producto.ubicacion_id ? String(producto.ubicacion_id) : "",
      bodega_id: "",
      imagen_url: producto.imagen_url || "",
      estado: producto.estado || "Activo",
    });
    setEditandoId(producto.id);
    setError("");
    setShowModal(true);
  }, []);
  
  const abrirModalMovimiento = useCallback((producto: Producto) => {
    setSelectedProducto(producto);
    setTimeout(() => {
      setShowMovimientoModal(true);
      console.log("Modal de movimiento abierto para producto:", producto.id);
    }, 0);
  }, []);

  const cerrarHistorial = useCallback(() => {
    setProductoHistorial(null);
  }, []);

  const cerrarModal = useCallback(() => {
    console.log("Cerrando modal");
    setShowModal(false);
    // Limpiar el formulario después de que el modal se haya cerrado
    setTimeout(limpiarForm, 300);
  }, [limpiarForm]);
  
  const cerrarModalMovimiento = useCallback(() => {
    console.log("Cerrando modal de movimiento");
    setShowMovimientoModal(false);
    setTimeout(() => setSelectedProducto(null), 300);
  }, []);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    console.log(`Campo ${name} cambiado a:`, value);
    
    setForm(prev => ({
      ...prev,
      [name]: value,
    }));
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setError("");
    const payload = {
      codigo: form.codigo,
      nombre: form.nombre,
      descripcion: form.descripcion,
      categoria_id: form.categoria_id,
      marca_id: form.marca_id,
      unidad_medida_id: form.unidad_medida_id,
      ubicacion_id: form.ubicacion_id,
      proveedor_id: form.proveedor_id,
      bodega_id: form.bodega_id,
      stock_actual: form.stock_actual,
      precio_compra: form.precio_compra,
      precio_venta: form.precio_venta,
      costo: form.costo,
      stock_minimo: form.stock_minimo,
      stock_maximo: form.stock_maximo,
      imagen_url: form.imagen_url,
      estado: form.estado,
    };
    if (editandoId) {
      delete (payload as Partial<ProductoFormValues>).stock_actual;
    }
    try {
      const response = await fetch(editandoId ? `/api/productos/${editandoId}` : "/api/productos", {
        method: editandoId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo guardar el producto.");
      await cargarProductos();
      cerrarModal();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Error al guardar el producto.");
    } finally { setGuardando(false); }
  }, [form, editandoId, cerrarModal, cargarProductos]);
  
  const handleMovimientoSubmit = useCallback(async (movimiento: Partial<MovimientoInventario>) => {
    if (!selectedProducto) return;
    setGuardando(true);
    setError("");
    try {
      const response = await fetch(`/api/productos/${selectedProducto.id}/movimientos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(movimiento),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo registrar el movimiento.");
      await cargarProductos();
      cerrarModalMovimiento();
    } catch (movementError) {
      setError(movementError instanceof Error ? movementError.message : "Error al registrar el movimiento.");
    } finally { setGuardando(false); }
  }, [selectedProducto, cerrarModalMovimiento, cargarProductos]);

  const confirmarTransferencia = useCallback(async () => {
    if (!transferenciaSeleccionada) return;
    setGuardandoTransferencia(true);
    setErrorTransferencia(null);
    setMensajeTransferencia(null);
    try {
      const response = await fetch(
        `/api/productos/${transferenciaSeleccionada.producto_id}/transferencias`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            bodega_origen_id: transferenciaSeleccionada.bodega_origen_id,
            bodega_destino_id: transferenciaSeleccionada.bodega_destino_id,
            cantidad: transferenciaSeleccionada.cantidad_sugerida,
          }),
        },
      );
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "No se pudo registrar la transferencia.");
      }
      await cargarProductos();
      recargarTransferencias();
      setMensajeTransferencia(
        `Transferencia ${result.data.codigo} registrada correctamente.`,
      );
      setTransferenciaSeleccionada(null);
    } catch (transferError) {
      setErrorTransferencia(
        transferError instanceof Error
          ? transferError.message
          : "Error al registrar la transferencia.",
      );
    } finally {
      setGuardandoTransferencia(false);
    }
  }, [cargarProductos, recargarTransferencias, transferenciaSeleccionada]);

  const eliminarProducto = useCallback(async (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar este producto?")) {
      try {
        const response = await fetch(`/api/productos/${id}`, { method: "DELETE" });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "No se pudo desactivar el producto.");
        await cargarProductos();
      } catch (deleteError) {
        setError(deleteError instanceof Error ? deleteError.message : "Error al desactivar el producto.");
      }
    }
  }, [cargarProductos]);

  const obtenerUbicacion = useCallback(
    (producto: Producto) => {
      const ubicacion = catalogos.ubicaciones.find(
        (opcion) => opcion.id === producto.ubicacion_id,
      );
      if (!ubicacion) return producto.ubicacion || "Sin ubicación asignada";
      const bodega = catalogos.bodegas.find(
        (opcion) => opcion.id === ubicacion.bodega_id,
      );
      return [
        bodega?.nombre,
        ubicacion.codigo,
        ubicacion.pasillo ? `Pasillo ${ubicacion.pasillo}` : "",
        ubicacion.estanteria ? `Estante ${ubicacion.estanteria}` : "",
        ubicacion.nivel ? `Nivel ${ubicacion.nivel}` : "",
      ]
        .filter(Boolean)
        .join(" · ");
    },
    [catalogos.bodegas, catalogos.ubicaciones],
  );

  const obtenerProveedor = useCallback(
    (producto: Producto) =>
      catalogos.proveedores.find(
        (proveedor) => proveedor.id === producto.proveedor_id,
      )?.nombre ?? "Sin proveedor asignado",
    [catalogos.proveedores],
  );

  const productosActivos = useMemo(
    () => productos.filter((producto) => producto.estado === "Activo"),
    [productos],
  );
  const productosControlados = useMemo(
    () =>
      productosActivos.filter((producto) => producto.controla_stock !== false),
    [productosActivos],
  );
  const productosAgotados = productosControlados.filter(
    (producto) => getEstadoStock(producto) === "AGOTADO",
  );
  const productosBajoMinimo = productosControlados.filter(
    (producto) => getEstadoStock(producto) === "BAJO",
  );
  const productosSobreMaximo = productosControlados.filter(
    (producto) => getEstadoStock(producto) === "EXCESO",
  );

  const productosParaReposicion = useMemo(
    () =>
      productosControlados
        .filter((producto) => {
          const estadoStock = getEstadoStock(producto);
          return estadoStock === "AGOTADO" || estadoStock === "BAJO";
        })
        .sort((a, b) => {
          const prioridad = (producto: Producto) =>
            producto.stock_actual <= 0
              ? -1
              : producto.stock_minimo > 0
                ? producto.stock_actual / producto.stock_minimo
                : 0;
          return prioridad(a) - prioridad(b);
        }),
    [productosControlados],
  );
  const sugerenciasReposicion = productosParaReposicion.slice(0, 5);

  const productosFiltrados = useMemo(() => {
    const textoFiltro = filtro.trim().toLowerCase();
    return productos.filter((producto) => {
      const estadoStock = getEstadoStock(producto);
      const textoProducto = [
        ...Object.values(producto).map(String),
        obtenerUbicacion(producto),
        obtenerProveedor(producto),
      ]
        .join(" ")
        .toLowerCase();
      const coincideTexto = textoProducto.includes(textoFiltro);
      const coincideStock =
        filtroStock === "TODOS" ||
        (filtroStock === "AGOTADOS" && estadoStock === "AGOTADO") ||
        (filtroStock === "BAJO" && estadoStock === "BAJO") ||
        (filtroStock === "REPOSICION" &&
          (estadoStock === "AGOTADO" || estadoStock === "BAJO")) ||
        (filtroStock === "NORMAL" && estadoStock === "NORMAL") ||
        (filtroStock === "EXCESO" && estadoStock === "EXCESO");

      return coincideTexto && coincideStock;
    });
  }, [filtro, filtroStock, obtenerProveedor, obtenerUbicacion, productos]);

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-0">Stock de Productos</h1>
        
        <div className="d-flex justify-content-between align-items-center mb-4">          
          <p className="text-muted mb-0">Registro de productos y movimientos</p>
          <div className="ms-auto">
            <button 
              className="btn btn-primary d-flex align-items-center" 
              onClick={abrirModalNuevo}
              type="button"
              disabled={cargandoCatalogos || guardando}
            >
              <CirclePlus className="me-2" size={16} />
              <span>Añadir Producto</span>
            </button>
          </div>
        </div>
        {error && <div className="alert alert-danger" role="alert">{error}</div>}

        <section className="inventory-intelligence" aria-labelledby="inventory-intelligence-title">
          <div className="inventory-intelligence-heading">
            <div>
              <h2 id="inventory-intelligence-title">Estado del inventario</h2>
              <p>Alertas y reposición sugerida según los límites configurados por producto.</p>
            </div>
            <span className="inventory-readonly-note">
              Las sugerencias no registran compras ni movimientos automáticamente.
            </span>
          </div>
          <div className="inventory-summary-grid">
            <button
              type="button"
              className={`inventory-summary-card ${filtroStock === "TODOS" ? "is-selected" : ""}`}
              onClick={() => setFiltroStock("TODOS")}
              disabled={cargando}
              aria-pressed={filtroStock === "TODOS"}
            >
              <span><Package size={17} /> Productos activos</span>
              <strong>{cargando ? "—" : productosActivos.length}</strong>
            </button>
            <button
              type="button"
              className={`inventory-summary-card is-danger ${filtroStock === "AGOTADOS" ? "is-selected" : ""}`}
              onClick={() => setFiltroStock("AGOTADOS")}
              disabled={cargando}
              aria-pressed={filtroStock === "AGOTADOS"}
            >
              <span><AlertTriangle size={17} /> Agotados</span>
              <strong>{cargando ? "—" : productosAgotados.length}</strong>
            </button>
            <button
              type="button"
              className={`inventory-summary-card is-warning ${filtroStock === "BAJO" ? "is-selected" : ""}`}
              onClick={() => setFiltroStock("BAJO")}
              disabled={cargando}
              aria-pressed={filtroStock === "BAJO"}
            >
              <span><AlertTriangle size={17} /> Bajo mínimo</span>
              <strong>{cargando ? "—" : productosBajoMinimo.length}</strong>
            </button>
            <button
              type="button"
              className={`inventory-summary-card is-reorder ${filtroStock === "REPOSICION" ? "is-selected" : ""}`}
              onClick={() => setFiltroStock("REPOSICION")}
              disabled={cargando}
              aria-pressed={filtroStock === "REPOSICION"}
            >
              <span><ArrowUpDown size={17} /> Reposición sugerida</span>
              <strong>{cargando ? "—" : productosParaReposicion.length}</strong>
            </button>
            <button
              type="button"
              className={`inventory-summary-card is-excess ${filtroStock === "EXCESO" ? "is-selected" : ""}`}
              onClick={() => setFiltroStock("EXCESO")}
              disabled={cargando}
              aria-pressed={filtroStock === "EXCESO"}
            >
              <span><Package size={17} /> Sobre máximo</span>
              <strong>{cargando ? "—" : productosSobreMaximo.length}</strong>
            </button>
          </div>
        </section>

        {!cargando && sugerenciasReposicion.length > 0 && (
          <section className="inventory-reorder-panel" aria-labelledby="inventory-reorder-title">
            <div className="inventory-reorder-heading">
              <div>
                <h2 id="inventory-reorder-title">Sugerencias de reposición</h2>
                <p>Prioriza agotados y productos más cercanos a quedarse sin stock.</p>
              </div>
              <span>Máximo 5 prioridades</span>
            </div>
            <div className="inventory-reorder-grid">
              {sugerenciasReposicion.map((producto) => {
                const sugerencia = getCantidadSugerida(producto);
                const ubicacion = obtenerUbicacion(producto);
                return (
                  <article className="inventory-reorder-item" key={producto.id}>
                    <div className="inventory-reorder-item-heading">
                      <div>
                        <strong>{producto.nombre}</strong>
                        <small>{producto.codigo} · {producto.categoria}</small>
                      </div>
                      <span className={`inventory-status-pill ${getEstadoStock(producto).toLowerCase()}`}>
                        {getEtiquetaStock(getEstadoStock(producto))}
                      </span>
                    </div>
                    <div className="inventory-reorder-amount">
                      <span>
                        Stock {formatStock(producto.stock_actual)} / mínimo {formatStock(producto.stock_minimo)} {producto.unidad_medida}
                      </span>
                      <strong>
                        {sugerencia === null
                          ? "Configura mínimo y máximo"
                          : `Reponer ${formatStock(sugerencia)} ${producto.unidad_medida}`}
                      </strong>
                    </div>
                    <div className="inventory-reorder-meta">
                      <span><MapPin size={14} /> {ubicacion}</span>
                      <span>Proveedor: {obtenerProveedor(producto)}</span>
                    </div>
                    <button
                      type="button"
                      className="btn btn-sm btn-outline-primary"
                      onClick={() => {
                        setFiltroStock("TODOS");
                        setFiltro(producto.codigo);
                        document.getElementById("lista-productos")?.scrollIntoView({
                          behavior: "smooth",
                          block: "start",
                        });
                      }}
                    >
                      Ver producto
                    </button>
                  </article>
                );
              })}
            </div>
          </section>
        )}

        <section
          className="inventory-transfer-panel"
          aria-labelledby="inventory-transfer-title"
        >
          <div className="inventory-transfer-heading">
            <div>
              <h2 id="inventory-transfer-title">
                <ArrowRightLeft size={18} aria-hidden="true" />
                Transferencias sugeridas entre bodegas
              </h2>
              <p>
                Redistribuye existencias antes de realizar una nueva compra.
                Confirmar una sugerencia actualiza ambas bodegas y deja
                trazabilidad del movimiento.
              </p>
            </div>
            {!cargandoTransferencias && !errorTransferencias && (
              <span>
                {transferenciasSugeridas.length}{" "}
                {transferenciasSugeridas.length === 1
                  ? "sugerencia"
                  : "sugerencias"}
              </span>
            )}
          </div>

          <p className="inventory-transfer-policy">
            Se sugieren cantidades que conservan el mínimo en la bodega de
            origen y mantienen el stock total de la empresa por encima del
            mínimo configurado. No se mueve inventario sin confirmación.
          </p>

          {mensajeTransferencia && (
            <div className="inventory-transfer-success" role="status">
              {mensajeTransferencia}
            </div>
          )}

          {cargandoTransferencias && (
            <div className="inventory-transfer-state" role="status">
              Buscando excedentes disponibles en las bodegas…
            </div>
          )}

          {errorTransferencias && (
            <div className="inventory-transfer-error" role="alert">
              <span>{errorTransferencias}</span>
              <button
                type="button"
                className="btn btn-sm btn-outline-primary"
                onClick={recargarTransferencias}
              >
                Reintentar
              </button>
            </div>
          )}

          {!cargandoTransferencias &&
            !errorTransferencias &&
            transferenciasSugeridas.length === 0 && (
              <div className="inventory-transfer-state">
                No hay transferencias internas posibles con los niveles de
                stock actuales. Si el stock total no alcanza el mínimo, revisa
                las sugerencias de reposición.
              </div>
            )}

          {!cargandoTransferencias &&
            !errorTransferencias &&
            transferenciasSugeridas.length > 0 && (
              <div className="inventory-transfer-grid">
                {transferenciasSugeridas.slice(0, 5).map((transferencia) => (
                  <article
                    className="inventory-transfer-card"
                    key={`${transferencia.producto_id}-${transferencia.bodega_origen_id}-${transferencia.bodega_destino_id}`}
                  >
                    <div className="inventory-transfer-card-heading">
                      <div>
                        <strong>{transferencia.producto_nombre}</strong>
                        <small>
                          {transferencia.producto_codigo} · Stock total{" "}
                          {formatStock(transferencia.stock_total)}{" "}
                          {transferencia.unidad_medida}
                        </small>
                      </div>
                    </div>
                    <div className="inventory-transfer-route">
                      <div>
                        <span>Desde · {transferencia.bodega_origen_nombre}</span>
                        <strong>
                          {formatStock(transferencia.stock_origen)} →{" "}
                          {formatStock(transferencia.stock_origen_despues)}
                        </strong>
                      </div>
                      <ArrowRightLeft size={18} aria-hidden="true" />
                      <div>
                        <span>Hacia · {transferencia.bodega_destino_nombre}</span>
                        <strong>
                          {formatStock(transferencia.stock_destino)} →{" "}
                          {formatStock(transferencia.stock_destino_despues)}
                        </strong>
                      </div>
                    </div>
                    <div className="inventory-transfer-card-footer">
                      <span>
                        Transferir {formatStock(transferencia.cantidad_sugerida)}{" "}
                        {transferencia.unidad_medida}
                      </span>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => {
                          setErrorTransferencia(null);
                          setMensajeTransferencia(null);
                          setTransferenciaSeleccionada(transferencia);
                        }}
                        disabled={guardandoTransferencia}
                      >
                        Revisar transferencia
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            )}
          {!cargandoTransferencias &&
            !errorTransferencias &&
            transferenciasSugeridas.length > 5 && (
            <p className="inventory-transfer-more">
              Mostrando 5 de {transferenciasSugeridas.length} sugerencias.
            </p>
            )}
        </section>

        <div className="inventory-product-toolbar" id="lista-productos">
          <div className="input-group">
            <span className="input-group-text" aria-hidden="true">
              <i className="bi bi-search"></i>
            </span>
            <input
              type="search"
              className="form-control"
              placeholder="Buscar por código, nombre, categoría, proveedor o ubicación..."
              aria-label="Buscar productos"
              value={filtro}
              onChange={(event) => setFiltro(event.target.value)}
            />
          </div>
          <select
            className="form-select inventory-stock-filter"
            aria-label="Filtrar por estado de stock"
            value={filtroStock}
            onChange={(event) => {
              const value = event.target.value;
              if (
                value === "TODOS" ||
                value === "AGOTADOS" ||
                value === "BAJO" ||
                value === "REPOSICION" ||
                value === "NORMAL" ||
                value === "EXCESO"
              ) {
                setFiltroStock(value);
              }
            }}
          >
            <option value="TODOS">Todos los niveles de stock</option>
            <option value="AGOTADOS">Agotados</option>
            <option value="BAJO">Bajo mínimo</option>
            <option value="REPOSICION">Requieren reposición</option>
            <option value="NORMAL">Stock saludable</option>
            <option value="EXCESO">Sobre máximo</option>
          </select>
        </div>
        
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Categoría</th>
                <th>Marca</th>
                <th>Precio Compra</th>
                <th>Precio Venta</th>
                <th>Costo</th>
                <th>Stock</th>
                <th>U.M.</th>
                <th>Ubicación</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && <tr><td colSpan={12} className="text-center">Cargando productos...</td></tr>}
              {!cargando && productosFiltrados.length === 0 && (
                <tr>
                  <td colSpan={12} className="text-center">
                    <div className="alert alert-info mb-0">
                      {error ? "No se pudieron cargar los productos" : "No se encontraron productos"}
                    </div>
                  </td>
                </tr>
              )}
              {productosFiltrados.map((producto) => (
                <tr key={producto.id}>
                  <td>{producto.codigo}</td>
                  <td>
                    <div className="d-flex align-items-center">
                      {producto.imagen_url && !producto.imagen_url.toLowerCase().endsWith("placeholder.png") ? (
                        <img
                          src={producto.imagen_url.startsWith("http") || producto.imagen_url.startsWith("/")
                            ? producto.imagen_url
                            : `/img/${producto.imagen_url}`}
                          alt={producto.nombre}
                          className="me-2"
                          style={{ width: '30px', height: '30px', objectFit: 'cover' }}
                          onError={(event) => { event.currentTarget.style.display = "none"; }}
                        />
                      ) : <Package className="me-2" size={24} aria-hidden="true" />}
                      <div>{producto.nombre}</div>
                    </div>
                  </td>
                  <td>{producto.categoria}</td>
                  <td>{producto.marca}</td>
                  <td>${producto.precio_compra.toFixed(2)}</td>
                  <td>${producto.precio_venta.toFixed(2)}</td>
                  <td>${producto.costo?.toFixed(2) ?? "0.00"}</td>
                  <td>
                    <div className="inventory-stock-cell">
                      <strong>{formatStock(producto.stock_actual)}</strong>
                      {producto.controla_stock === false ? (
                        <span className="inventory-status-pill no_controlado">No controlado</span>
                      ) : (
                        <>
                          <small>
                            Mín. {formatStock(producto.stock_minimo)} · Máx. {formatStock(producto.stock_maximo)}
                          </small>
                          <span className={`inventory-status-pill ${getEstadoStock(producto).toLowerCase()}`}>
                            {getEtiquetaStock(getEstadoStock(producto))}
                          </span>
                        </>
                      )}
                    </div>
                  </td>
                  <td>{producto.unidad_medida}</td>
                  <td className="inventory-location-cell" title={obtenerUbicacion(producto)}>
                    <MapPin size={14} aria-hidden="true" />
                    <span>{obtenerUbicacion(producto)}</span>
                  </td>
                  <td>
                    <span
                      className={`badge bg-${
                        producto.estado === "Activo"
                          ? "success"
                          : producto.estado === "Inactivo"
                          ? "secondary"
                          : "danger"
                      }`}
                    >
                      {producto.estado}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group btn-group-sm opciones-btn-group">
                      <button
                        className="btn btn-outline-primary"
                        onClick={() => setProductoHistorial(producto)}
                        title="Ver historial de movimientos"
                        aria-label={`Ver historial de movimientos de ${producto.nombre}`}
                        type="button"
                        disabled={guardando}
                      >
                        <History size={16} />
                      </button>
                      <button
                        className="btn btn-primary"
                        onClick={() => abrirModalMovimiento(producto)}
                        title="Registrar movimiento"
                        type="button"
                        disabled={guardando}
                      >
                        <ArrowUpDown size={16} />
                      </button>
                      <button
                        className="btn btn-warning"
                        onClick={() => abrirModalEditar(producto)}
                        title="Editar producto"
                        type="button"
                        disabled={guardando}
                      >
                        <SquarePen size={16} />
                      </button>
                      <button
                        className="btn btn-danger"
                        onClick={() => eliminarProducto(producto.id)}
                        title="Eliminar producto"
                        type="button"
                        disabled={guardando}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <ProductoModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          catalogs={catalogos}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          saving={guardando}
          submitError={error}
        />
        
        <MovimientoModal
          show={showMovimientoModal}
          producto={selectedProducto}
          bodegas={catalogos.bodegas}
          onClose={cerrarModalMovimiento}
          onSubmit={handleMovimientoSubmit}
          error={error}
          saving={guardando}
        />
        {productoHistorial && (
          <ProductoHistorialModal
            producto={productoHistorial}
            ubicacion={obtenerUbicacion(productoHistorial)}
            onClose={cerrarHistorial}
          />
        )}
        {transferenciaSeleccionada && (
          <TransferenciaSugeridaModal
            transferencia={transferenciaSeleccionada}
            onClose={() => {
              if (!guardandoTransferencia) {
                setTransferenciaSeleccionada(null);
                setErrorTransferencia(null);
              }
            }}
            onConfirm={confirmarTransferencia}
            saving={guardandoTransferencia}
            error={errorTransferencia}
          />
        )}
      </div>
    </div>
  );
}