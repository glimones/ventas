"use client";

import React, { useEffect } from "react";
import { ArrowRightLeft, X } from "lucide-react";
import { TransferenciaSugerida } from "./types";

interface Props {
  transferencia: TransferenciaSugerida;
  onClose: () => void;
  onConfirm: () => void;
  saving: boolean;
  error: string | null;
}

const formatStock = (value: number) =>
  value.toLocaleString("es-EC", { maximumFractionDigits: 4 });

const TransferenciaSugeridaModal: React.FC<Props> = ({
  transferencia,
  onClose,
  onConfirm,
  saving,
  error,
}) => {
  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !saving) onClose();
    };
    document.body.style.overflow = "hidden";
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [onClose, saving]);

  return (
    <div
      className="inventory-transfer-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget && !saving) onClose();
      }}
    >
      <section
        className="inventory-transfer-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="inventory-transfer-modal-title"
      >
        <header className="inventory-transfer-modal-header">
          <div className="inventory-transfer-modal-icon" aria-hidden="true">
            <ArrowRightLeft size={20} />
          </div>
          <div>
            <p>Confirmación de movimiento</p>
            <h2 id="inventory-transfer-modal-title">Transferir inventario</h2>
          </div>
          <button
            type="button"
            className="inventory-transfer-modal-close"
            onClick={onClose}
            aria-label="Cerrar"
            disabled={saving}
          >
            <X size={20} />
          </button>
        </header>

        <div className="inventory-transfer-modal-body">
          <div className="inventory-transfer-product">
            <strong>{transferencia.producto_nombre}</strong>
            <span>
              Código {transferencia.producto_codigo} · Mínimo configurado{" "}
              {formatStock(transferencia.stock_minimo)} {transferencia.unidad_medida}
            </span>
          </div>

          <div className="inventory-transfer-route">
            <div>
              <span>Bodega de origen</span>
              <strong>{transferencia.bodega_origen_nombre}</strong>
              <small>
                {formatStock(transferencia.stock_origen)} →{" "}
                {formatStock(transferencia.stock_origen_despues)}{" "}
                {transferencia.unidad_medida}
              </small>
            </div>
            <ArrowRightLeft size={20} aria-hidden="true" />
            <div>
              <span>Bodega de destino</span>
              <strong>{transferencia.bodega_destino_nombre}</strong>
              <small>
                {formatStock(transferencia.stock_destino)} →{" "}
                {formatStock(transferencia.stock_destino_despues)}{" "}
                {transferencia.unidad_medida}
              </small>
            </div>
          </div>

          <div className="inventory-transfer-quantity">
            <span>Cantidad sugerida</span>
            <strong>
              {formatStock(transferencia.cantidad_sugerida)}{" "}
              {transferencia.unidad_medida}
            </strong>
          </div>

          <p className="inventory-transfer-confirmation-note">
            Al confirmar, el sistema actualizará ambas bodegas en una sola
            operación y guardará el movimiento en el historial. Esta acción no
            se puede deshacer desde esta pantalla.
          </p>

          {error && (
            <div className="alert alert-danger mb-0" role="alert">
              {error}
            </div>
          )}
        </div>

        <footer className="inventory-transfer-modal-footer">
          <button
            type="button"
            className="btn btn-outline-secondary"
            onClick={onClose}
            disabled={saving}
          >
            Cancelar
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={onConfirm}
            disabled={saving}
          >
            {saving ? "Registrando..." : "Confirmar transferencia"}
          </button>
        </footer>
      </section>
    </div>
  );
};

export default TransferenciaSugeridaModal;
