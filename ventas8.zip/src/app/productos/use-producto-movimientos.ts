"use client";

import { useCallback, useEffect, useState } from "react";
import { ProductoMovimientoHistorial } from "./types";

interface MovimientoState {
  data: ProductoMovimientoHistorial[];
  isLoading: boolean;
  error: string | null;
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const isMovimientoHistorial = (
  value: unknown,
): value is ProductoMovimientoHistorial =>
  isRecord(value) &&
  typeof value.id === "string" &&
  Number.isFinite(value.producto_id) &&
  (value.tipo === "ENTRADA" ||
    value.tipo === "SALIDA" ||
    value.tipo === "TRANSFERENCIA" ||
    value.tipo === "AJUSTE") &&
  Number.isFinite(value.bodega_id) &&
  typeof value.bodega_nombre === "string" &&
  Number.isFinite(value.cantidad) &&
  typeof value.fecha === "string" &&
  typeof value.motivo === "string" &&
  (value.documento_referencia === null ||
    typeof value.documento_referencia === "string");

export function useProductoMovimientos(productoId: number | null) {
  const [state, setState] = useState<MovimientoState>({
    data: [],
    isLoading: productoId !== null,
    error: null,
  });
  const [refreshVersion, setRefreshVersion] = useState(0);
  const refetch = useCallback(
    () => setRefreshVersion((version) => version + 1),
    [],
  );

  useEffect(() => {
    if (productoId === null) {
      setState({ data: [], isLoading: false, error: null });
      return;
    }

    const controller = new AbortController();
    let isMounted = true;

    const cargarMovimientos = async () => {
      setState((previous) => ({
        ...previous,
        isLoading: true,
        error: null,
      }));

      try {
        const response = await fetch(
          `/api/productos/${productoId}/movimientos`,
          { cache: "no-store", signal: controller.signal },
        );
        const payload: unknown = await response.json();
        if (!response.ok) {
          const message =
            isRecord(payload) && typeof payload.error === "string"
              ? payload.error
              : "No se pudo cargar el historial de movimientos.";
          throw new Error(message);
        }
        if (
          !isRecord(payload) ||
          !Array.isArray(payload.data) ||
          !payload.data.every(isMovimientoHistorial)
        ) {
          throw new Error("La respuesta del historial tiene un formato no válido.");
        }

        if (isMounted) {
          setState({ data: payload.data, isLoading: false, error: null });
        }
      } catch (loadError) {
        if (controller.signal.aborted || !isMounted) return;
        setState((previous) => ({
          ...previous,
          isLoading: false,
          error:
            loadError instanceof Error
              ? loadError.message
              : "Error al cargar los movimientos.",
        }));
      } finally {
        if (isMounted && !controller.signal.aborted) {
          setState((previous) => ({ ...previous, isLoading: false }));
        }
      }
    };

    void cargarMovimientos();
    return () => {
      isMounted = false;
      controller.abort();
    };
  }, [productoId, refreshVersion]);

  return { ...state, refetch };
}
