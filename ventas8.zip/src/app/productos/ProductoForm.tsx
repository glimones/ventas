import React from "react";
import { ProductoCatalogs, ProductoFormValues } from "./types";

interface Props {
  values: ProductoFormValues;
  catalogs: ProductoCatalogs;
  editando: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const ProductoForm: React.FC<Props> = ({ values, catalogs, editando, onChange }) => {
  // Manejador de eventos para asegurar que los cambios se registren
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  // Manejador especial para campos numéricos
  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const numericValue = value === '' ? 0 : parseFloat(value);
    
    // Crear un evento sintético para mantener la coherencia con la interfaz
    const syntheticEvent = {
      ...e,
      target: {
        ...e.target,
        name,
        value: numericValue,
      },
    } as unknown as React.ChangeEvent<HTMLInputElement>;
    
    handleInputChange(syntheticEvent);
  };

  return (
    <div className="row g-3">
      {/* Primera columna */}
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="codigo" className="form-label">
            Código *
          </label>
          <input
            type="text"
            className="form-control"
            id="codigo"
            name="codigo"
            value={values.codigo || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label">
            Nombre *
          </label>
          <input
            type="text"
            className="form-control"
            id="nombre"
            name="nombre"
            value={values.nombre || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="descripcion" className="form-label">
            Descripción
          </label>
          <textarea
            className="form-control"
            id="descripcion"
            name="descripcion"
            value={values.descripcion || ""}
            onChange={handleInputChange}
            rows={3}
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="categoria" className="form-label">
            Categoría *
          </label>
          <select
            className="form-select"
            id="categoria"
            name="categoria_id"
            value={values.categoria_id || ""}
            onChange={handleInputChange}
            required
          >
            <option value="">Seleccione una categoría</option>
            {catalogs.categorias.map((option) => (
              <option key={option.id} value={option.id}>
                {option.nombre}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="marca" className="form-label">
            Marca
          </label>
          <select
            className="form-select"
            id="marca"
            name="marca_id"
            value={values.marca_id || ""}
            onChange={handleInputChange}
          >
            <option value="">Seleccione una marca</option>
            {catalogs.marcas.map((marca) => (
              <option key={marca.id} value={marca.id}>
                {marca.nombre}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label htmlFor="proveedor_id" className="form-label">Proveedor</label>
          <select className="form-select" id="proveedor_id" name="proveedor_id" value={values.proveedor_id || ""} onChange={handleInputChange}>
            <option value="">Sin proveedor asignado</option>
            {catalogs.proveedores.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.nombre}</option>)}
          </select>
        </div>
      </div>
      
      {/* Segunda columna */}
      <div className="col-md-6">
        <div className="row">
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="precio_compra" className="form-label">
                Precio de compra *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-control"
                id="precio_compra"
                name="precio_compra"
                value={values.precio_compra || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="precio_venta" className="form-label">
                Precio de venta *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-control"
                id="precio_venta"
                name="precio_venta"
                value={values.precio_venta || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="costo" className="form-label">
                Costo
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-control"
                id="costo"
                name="costo"
                value={values.costo || ""}
                onChange={handleNumberChange}
              />
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="stock_actual" className="form-label">{editando ? "Stock actual (solo lectura)" : "Stock inicial"}</label>
              <input
                type="number"
                step="1"
                min="0"
                className="form-control"
                id="stock_actual"
                name="stock_actual"
                value={values.stock_actual || ""}
                onChange={handleNumberChange}
                readOnly={editando}
              />
            </div>
          </div>
          {!editando && <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="bodega_id" className="form-label">Bodega para stock inicial</label>
              <select className="form-select" id="bodega_id" name="bodega_id" value={values.bodega_id || ""} onChange={handleInputChange}>
                <option value="">Seleccione bodega si ingresa stock</option>
                {catalogs.bodegas.map((warehouse) => <option key={warehouse.id} value={warehouse.id}>{warehouse.nombre}</option>)}
              </select>
            </div>
          </div>}
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="stock_minimo" className="form-label">
                Stock mínimo *
              </label>
              <input
                type="number"
                step="1"
                min="0"
                className="form-control"
                id="stock_minimo"
                name="stock_minimo"
                value={values.stock_minimo || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="stock_maximo" className="form-label">
                Stock máximo
              </label>
              <input
                type="number"
                step="1"
                min="0"
                className="form-control"
                id="stock_maximo"
                name="stock_maximo"
                value={values.stock_maximo || ""}
                onChange={handleNumberChange}
              />
            </div>
          </div>
        </div>
        
        <div className="mb-3">
          <label htmlFor="unidad_medida" className="form-label">
            Unidad de medida *
          </label>
          <select
            className="form-select"
            id="unidad_medida"
            name="unidad_medida_id"
            value={values.unidad_medida_id || ""}
            onChange={handleInputChange}
            required
          >
            <option value="">Seleccione unidad</option>
            {catalogs.unidades.map((unit) => (
              <option key={unit.id} value={unit.id}>
                {unit.nombre} ({unit.abreviatura})
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="ubicacion_id" className="form-label">Ubicación en almacén</label>
          <select className="form-select" id="ubicacion_id" name="ubicacion_id" value={values.ubicacion_id || ""} onChange={handleInputChange}>
            <option value="">Sin ubicación</option>
            {catalogs.ubicaciones.map((location) => <option key={location.id} value={location.id}>{location.codigo} · {location.pasillo || ""}-{location.estanteria || ""}-{location.nivel || ""}</option>)}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="estado" className="form-label">
            Estado
          </label>
          <select
            className="form-select"
            id="estado"
            name="estado"
            value={values.estado || "Activo"}
            onChange={handleInputChange}
          >
            <option value="Activo">Activo</option>
            <option value="Inactivo">Inactivo</option>
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="imagen_url" className="form-label">URL de la imagen</label>
          <input
            type="url"
            className="form-control"
            id="imagen_url"
            name="imagen_url"
            value={values.imagen_url || ""}
            onChange={handleInputChange}
          />
        </div>
      </div>
    </div>
  );
};

export default ProductoForm;