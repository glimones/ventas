"use client";

import { useCallback, useEffect, useState } from "react";
import { TransferenciaSugerida } from "./types";

interface TransferenciasState {
  data: TransferenciaSugerida[];
  isLoading: boolean;
  error: string | null;
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const isTransferenciaSugerida = (
  value: unknown,
): value is TransferenciaSugerida =>
  isRecord(value) &&
  Number.isSafeInteger(value.producto_id) &&
  typeof value.producto_codigo === "string" &&
  typeof value.producto_nombre === "string" &&
  typeof value.unidad_medida === "string" &&
  Number.isSafeInteger(value.bodega_origen_id) &&
  typeof value.bodega_origen_nombre === "string" &&
  Number.isFinite(value.stock_origen) &&
  Number.isFinite(value.stock_origen_despues) &&
  Number.isSafeInteger(value.bodega_destino_id) &&
  typeof value.bodega_destino_nombre === "string" &&
  Number.isFinite(value.stock_destino) &&
  Number.isFinite(value.stock_destino_despues) &&
  Number.isFinite(value.stock_minimo) &&
  Number.isFinite(value.stock_total) &&
  Number.isFinite(value.cantidad_sugerida) &&
  Number(value.cantidad_sugerida) > 0;

export function useTransferenciasSugeridas() {
  const [state, setState] = useState<TransferenciasState>({
    data: [],
    isLoading: true,
    error: null,
  });
  const [refreshVersion, setRefreshVersion] = useState(0);
  const refetch = useCallback(
    () => setRefreshVersion((version) => version + 1),
    [],
  );

  useEffect(() => {
    const controller = new AbortController();
    let isMounted = true;

    const cargarSugerencias = async () => {
      setState((previous) => ({
        ...previous,
        isLoading: true,
        error: null,
      }));
      try {
        const response = await fetch("/api/productos/transferencias-sugeridas", {
          cache: "no-store",
          signal: controller.signal,
        });
        const payload: unknown = await response.json();
        if (!response.ok) {
          const message =
            isRecord(payload) && typeof payload.error === "string"
              ? payload.error
              : "No se pudieron cargar las sugerencias de transferencia.";
          throw new Error(message);
        }
        if (
          !isRecord(payload) ||
          !Array.isArray(payload.data) ||
          !payload.data.every(isTransferenciaSugerida)
        ) {
          throw new Error(
            "La respuesta de sugerencias de transferencia tiene un formato no válido.",
          );
        }
        if (isMounted) {
          setState({ data: payload.data, isLoading: false, error: null });
        }
      } catch (loadError) {
        if (controller.signal.aborted || !isMounted) return;
        setState((previous) => ({
          ...previous,
          isLoading: false,
          error:
            loadError instanceof Error
              ? loadError.message
              : "Error al cargar las sugerencias de transferencia.",
        }));
      } finally {
        if (isMounted && !controller.signal.aborted) {
          setState((previous) => ({ ...previous, isLoading: false }));
        }
      }
    };

    void cargarSugerencias();
    return () => {
      isMounted = false;
      controller.abort();
    };
  }, [refreshVersion]);

  return { ...state, refetch };
}
