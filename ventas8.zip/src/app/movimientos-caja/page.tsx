import { AppShell } from '@/components/app-shell';
import MovimientosCajaPage from './MovimientosCajaPage';

export default function Page() {
  return (
    <AppShell>
      <MovimientosCajaPage />
    </AppShell>
  );
}
