import DomainCrud from '@/components/domain-crud';import{domainConfigs}from '@/components/domain-config';export default function IvaPage(){return <DomainCrud config={domainConfigs.iva}/>}
