import { AppShell } from '@/components/app-shell';
import IvaPage from './IvaPage';

export default function Page() {
  return (
    <AppShell>
      <IvaPage />
    </AppShell>
  );
}
