import DomainCrud from '@/components/domain-crud';import{domainConfigs}from '@/components/domain-config';export default function AbonosPage(){return <DomainCrud config={domainConfigs.abonos}/>}
