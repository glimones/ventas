"use client";
import React from "react";
import { AbonosFormValues } from "./types";

interface Props {
  values: AbonosFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const AbonosForm: React.FC<Props> = ({ values, onChange }) => (
  <div className="row g-3">
    <h6 className="text-muted">Factura Relacionada</h6>
    <div className="col-md-3">
      <label htmlFor="factura_id" className="form-label">Factura ID</label>
      <input type="text" className="form-control" id="factura_id" name="factura_id" value={values.factura_id} onChange={onChange} />
    </div>
    <div className="col-md-3">
      <label htmlFor="numero_factura" className="form-label">N� Factura *</label>
      <input type="text" className="form-control" id="numero_factura" name="numero_factura" value={values.numero_factura} onChange={onChange} required />
    </div>
    <div className="col-md-6">
      <label htmlFor="cliente" className="form-label">Cliente *</label>
      <input type="text" className="form-control" id="cliente" name="cliente" value={values.cliente} onChange={onChange} required />
    </div>
    <div className="col-md-4">
      <label htmlFor="identificacion_cliente" className="form-label">Identificaci�n</label>
      <input type="text" className="form-control" id="identificacion_cliente" name="identificacion_cliente" value={values.identificacion_cliente} onChange={onChange} />
    </div>
    <div className="col-md-4">
      <label htmlFor="monto_total_factura" className="form-label">Monto Factura</label>
      <input type="number" step="0.01" className="form-control" id="monto_total_factura" name="monto_total_factura" value={values.monto_total_factura} onChange={onChange} />
    </div>
    <div className="col-md-4">
      <label htmlFor="saldo_pendiente" className="form-label">Saldo Pendiente</label>
      <input type="number" step="0.01" className="form-control" id="saldo_pendiente" value={values.monto_total_factura - values.monto_abonado} readOnly disabled />
    </div>
    <hr />
    <h6 className="text-muted">Datos del Abono</h6>
    <div className="col-md-3">
      <label htmlFor="numero_abono" className="form-label">N� Abono *</label>
      <input type="text" className="form-control" id="numero_abono" name="numero_abono" value={values.numero_abono} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="fecha_abono" className="form-label">Fecha *</label>
      <input type="date" className="form-control" id="fecha_abono" name="fecha_abono" value={values.fecha_abono} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="monto_abonado" className="form-label">Monto Abonado *</label>
      <input type="number" step="0.01" className="form-control" id="monto_abonado" name="monto_abonado" value={values.monto_abonado} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="estado" className="form-label">Estado *</label>
      <select className="form-select" id="estado" name="estado" value={values.estado} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="PENDIENTE">Pendiente</option>
        <option value="APLICADO">Aplicado</option>
        <option value="ANULADO">Anulado</option>
      </select>
    </div>
    <div className="col-md-4">
      <label htmlFor="forma_pago" className="form-label">Forma de Pago</label>
      <select className="form-select" id="forma_pago" name="forma_pago" value={values.forma_pago} onChange={onChange}>
        <option value="">Seleccione...</option>
        <option value="TRANSFERENCIA">Transferencia</option>
        <option value="CHEQUE">Cheque</option>
        <option value="EFECTIVO">Efectivo</option>
        <option value="TARJETA">Tarjeta</option>
      </select>
    </div>
    <div className="col-md-4">
      <label htmlFor="referencia" className="form-label">Referencia</label>
      <input type="text" className="form-control" id="referencia" name="referencia" value={values.referencia} onChange={onChange} />
    </div>
    <div className="col-md-12">
      <label htmlFor="observacion" className="form-label">Observaci�n</label>
      <textarea className="form-control" id="observacion" name="observacion" value={values.observacion} onChange={onChange} rows={3} />
    </div>
  </div>
);

export default AbonosForm;