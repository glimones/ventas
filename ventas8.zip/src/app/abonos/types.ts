// Tipos de datos para Abonos (pagos parciales a facturas)

export interface Abono {
  id: number;
  numero_abono: string;
  fecha_abono: string;
  factura_id: string;
  numero_factura: string;
  cliente: string;
  identificacion_cliente: string;
  monto_total_factura: number;
  monto_abonado: number;
  saldo_pendiente: number;
  forma_pago: string;
  referencia: string;
  observacion: string;
  estado: "APLICADO" | "PENDIENTE" | "ANULADO";
  comprobante_pdf?: string;
  fecha_creacion: string;
}

export interface AbonosFormValues {
  numero_abono: string;
  fecha_abono: string;
  factura_id: string;
  numero_factura: string;
  cliente: string;
  identificacion_cliente: string;
  monto_total_factura: number;
  monto_abonado: number;
  forma_pago: string;
  referencia: string;
  observacion: string;
  estado: string;
}