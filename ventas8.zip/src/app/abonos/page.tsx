import { AppShell } from '@/components/app-shell';
import AbonosPage from './AbonosPage';

export default function Page() {
  return (
    <AppShell>
      <AbonosPage />
    </AppShell>
  );
}
