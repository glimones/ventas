export interface Marcas {
  id: number;
  codigo: string;
  nombre: string;
  fabricante: string;
  pais_origen: string;
  sitio_web: string;
  estado: string;
}

export interface MarcasFormValues {
  codigo: string;
  nombre: string;
  fabricante: string;
  pais_origen: string;
  sitio_web: string;
  estado: string;
}
