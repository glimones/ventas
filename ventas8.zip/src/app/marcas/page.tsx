import { AppShell } from '@/components/app-shell';
import MarcasPage from './MarcasPage';

export default function Page() {
  return (
    <AppShell>
      <MarcasPage />
    </AppShell>
  );
}
