import DomainCrud from "@/components/domain-crud";
import { domainConfigs } from "@/components/domain-config";

export default function MarcasPage() {
  return <DomainCrud config={domainConfigs.marcas} />;
}
