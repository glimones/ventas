'use client';
import React from 'react';
import { MarcasFormValues } from './types';

interface Props {
  values: MarcasFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const MarcasForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre' className='form-label'>Nombre *</label>
          <input type='text' className='form-control' id='nombre' name='nombre' value={values.nombre || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-12'>
        <div className='mb-3'>
          <label htmlFor='fabricante' className='form-label'>Fabricante *</label>
          <input type='text' className='form-control' id='fabricante' name='fabricante' value={values.fabricante || ''} onChange={handleInputChange} required autoComplete='organization' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='pais_origen' className='form-label'>País de origen</label>
          <input type='text' className='form-control' id='pais_origen' name='pais_origen' value={values.pais_origen || ''} onChange={handleInputChange} autoComplete='country-name' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='sitio_web' className='form-label'>Sitio web</label>
          <input type='url' className='form-control' id='sitio_web' name='sitio_web' value={values.sitio_web || ''} onChange={handleInputChange} autoComplete='url' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default MarcasForm;
