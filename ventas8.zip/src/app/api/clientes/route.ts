import { NextResponse } from "next/server";
import {
  actualizarCliente,
  crearCliente,
  desactivarCliente,
  listarClientes,
} from "@/services/clientes.service";
import { DatabaseConfigurationError } from "@/lib/db";
import type { ClienteFormValues } from "@/app/cliente/types";

export const runtime = "nodejs";

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }

  console.error("Error en API de clientes:", error);
  return NextResponse.json(
    { error: "No se pudo completar la operación de clientes." },
    { status: 500 },
  );
}

function normalizeForm(input: unknown): ClienteFormValues | null {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const data = input as Record<string, unknown>;
  const required = [
    "nombre",
    "apellido",
    "tipo_documento",
    "documento",
    "direccion",
    "ciudad",
    "email",
    "telefono",
  ] as const;

  if (required.some((field) => typeof data[field] !== "string" || !data[field].trim())) {
    return null;
  }

  const value = (field: string) =>
    typeof data[field] === "string" ? data[field].trim() : "";

  return {
    nombre: value("nombre"),
    apellido: value("apellido"),
    empresa: value("empresa") || undefined,
    tipo_documento: value("tipo_documento"),
    documento: value("documento"),
    direccion: value("direccion"),
    ciudad: value("ciudad"),
    provincia: value("provincia") || undefined,
    pais: value("pais") || "Ecuador",
    codigo_postal: value("codigo_postal") || undefined,
    email: value("email"),
    telefono: value("telefono"),
    celular: value("celular") || undefined,
    notas: value("notas") || undefined,
    estado: value("estado") === "Inactivo" ? "Inactivo" : "Activo",
  };
}

export async function GET() {
  try {
    return NextResponse.json(await listarClientes());
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: Request) {
  try {
    const form = normalizeForm(await request.json());
    if (!form) {
      return NextResponse.json(
        { error: "Completa todos los campos obligatorios del cliente." },
        { status: 400 },
      );
    }

    return NextResponse.json({ id: await crearCliente(form) }, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

export async function PUT(request: Request) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return NextResponse.json({ error: "Los datos del cliente no son válidos." }, { status: 400 });
    }

    const data = body as Record<string, unknown>;
    const form = normalizeForm(data);
    const id = Number(data.id);
    if (!form || !Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "Los datos del cliente no son válidos." }, { status: 400 });
    }

    if (!(await actualizarCliente(id, form))) {
      return NextResponse.json({ error: "Cliente no encontrado." }, { status: 404 });
    }

    return NextResponse.json({ id });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: Request) {
  try {
    const body: unknown = await request.json();
    const id =
      body && typeof body === "object" && !Array.isArray(body)
        ? Number((body as Record<string, unknown>).id)
        : Number.NaN;
    if (!Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "El ID del cliente no es válido." }, { status: 400 });
    }

    if (!(await desactivarCliente(id))) {
      return NextResponse.json({ error: "Cliente no encontrado." }, { status: 404 });
    }

    return NextResponse.json({ id, estado: "Inactivo" });
  } catch (error) {
    return handleError(error);
  }
}