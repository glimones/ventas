import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  crearInventarioFisico,
  InventarioFisicoValidationError,
  listarInventariosFisicos,
} from "@/services/inventario-fisico.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return NextResponse.json({ data: await listarInventariosFisicos() });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await crearInventarioFisico(await request.json());
    return NextResponse.json({ data }, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }
  if (error instanceof InventarioFisicoValidationError) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  if (error instanceof SyntaxError) {
    return NextResponse.json(
      { error: "El cuerpo de la solicitud no es JSON válido." },
      { status: 400 },
    );
  }
  const code = (error as { code?: string })?.code;
  if (code === "23503" || code === "23502" || code === "22P02") {
    return NextResponse.json(
      { error: "El conteo no cumple las relaciones o reglas de la base." },
      { status: 400 },
    );
  }
  console.error("Error en API de inventario físico:", error);
  return NextResponse.json(
    { error: "No se pudo completar la operación de inventario físico." },
    { status: 500 },
  );
}
