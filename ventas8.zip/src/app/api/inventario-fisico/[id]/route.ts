import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  guardarConteoFisico,
  InventarioFisicoConflictError,
  InventarioFisicoValidationError,
  obtenerInventarioFisico,
} from "@/services/inventario-fisico.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function GET(_request: NextRequest, context: Context) {
  const inventarioId = Number((await context.params).id);
  if (!Number.isSafeInteger(inventarioId) || inventarioId <= 0) {
    return NextResponse.json(
      { error: "El ID del conteo físico no es válido." },
      { status: 400 },
    );
  }
  try {
    const data = await obtenerInventarioFisico(inventarioId);
    if (!data) {
      return NextResponse.json(
        { error: "El conteo físico no existe." },
        { status: 404 },
      );
    }
    return NextResponse.json({ data });
  } catch (error) {
    return handleError(error);
  }
}

export async function PUT(request: NextRequest, context: Context) {
  const inventarioId = Number((await context.params).id);
  if (!Number.isSafeInteger(inventarioId) || inventarioId <= 0) {
    return NextResponse.json(
      { error: "El ID del conteo físico no es válido." },
      { status: 400 },
    );
  }
  try {
    const data = await guardarConteoFisico(
      inventarioId,
      await request.json(),
    );
    return NextResponse.json({ data });
  } catch (error) {
    return handleError(error);
  }
}

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }
  if (error instanceof InventarioFisicoConflictError) {
    return NextResponse.json({ error: error.message }, { status: 409 });
  }
  if (error instanceof InventarioFisicoValidationError) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  if (error instanceof SyntaxError) {
    return NextResponse.json(
      { error: "El cuerpo de la solicitud no es JSON válido." },
      { status: 400 },
    );
  }
  console.error("Error al consultar o guardar conteo físico:", error);
  return NextResponse.json(
    { error: "No se pudo completar la operación del conteo físico." },
    { status: 500 },
  );
}
