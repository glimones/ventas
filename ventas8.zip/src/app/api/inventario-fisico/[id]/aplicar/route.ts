import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  aplicarConteoFisico,
  InventarioFisicoConflictError,
  InventarioFisicoValidationError,
} from "@/services/inventario-fisico.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function POST(request: NextRequest, context: Context) {
  const inventarioId = Number((await context.params).id);
  if (!Number.isSafeInteger(inventarioId) || inventarioId <= 0) {
    return NextResponse.json(
      { error: "El ID del conteo físico no es válido." },
      { status: 400 },
    );
  }
  try {
    const data = await aplicarConteoFisico(
      inventarioId,
      await request.json(),
    );
    return NextResponse.json({ data });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) {
      return NextResponse.json({ error: error.message }, { status: 503 });
    }
    if (error instanceof InventarioFisicoConflictError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    if (error instanceof InventarioFisicoValidationError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { error: "El cuerpo de la solicitud no es JSON válido." },
        { status: 400 },
      );
    }
    console.error("Error al aplicar ajustes de conteo físico:", error);
    return NextResponse.json(
      { error: "No se pudieron aplicar los ajustes del conteo físico." },
      { status: 500 },
    );
  }
}
