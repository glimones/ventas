import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  CompraValidationError,
  eliminarSolicitudCompra,
  guardarSolicitudCompra,
  listarSolicitudesCompra,
} from "@/services/compras-workflow.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ path: string[] }> };

async function getPath(context: RouteContext) {
  const { path } = await context.params;
  return path ?? [];
}

async function readObject(request: NextRequest) {
  try {
    const body: unknown = await request.json();
    return body !== null && typeof body === "object" && !Array.isArray(body)
      ? body
      : null;
  } catch {
    return null;
  }
}

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }
  if (error instanceof CompraValidationError) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  const code = (error as { code?: string })?.code;
  if (code === "23505") {
    return NextResponse.json({ error: "Ya existe una solicitud con ese número." }, { status: 409 });
  }
  if (code === "23503" || code === "23502" || code === "22P02") {
    return NextResponse.json({ error: "Los datos no cumplen las reglas de la base de datos." }, { status: 400 });
  }
  console.error("Error en el flujo de compras:", error);
  return NextResponse.json({ error: "No se pudo completar la operación de compras." }, { status: 500 });
}

export async function GET(_request: NextRequest, context: RouteContext) {
  try {
    if ((await getPath(context)).join("/") !== "solicitudes") {
      return NextResponse.json({ error: "Recurso de compras no válido." }, { status: 404 });
    }
    return NextResponse.json({ data: await listarSolicitudesCompra(), adapter: "postgresql" });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest, context: RouteContext) {
  try {
    if ((await getPath(context)).join("/") !== "solicitudes") {
      return NextResponse.json({ error: "Recurso de compras no válido." }, { status: 404 });
    }
    const body = await readObject(request);
    if (!body) return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
    const data = await guardarSolicitudCompra(body);
    return NextResponse.json({ data, adapter: "postgresql" }, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

export async function PUT(request: NextRequest, context: RouteContext) {
  try {
    const path = await getPath(context);
    const id = Number(path[1]);
    if (path[0] !== "solicitudes" || path.length !== 2 || !Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "Solicitud o identificador inválido." }, { status: 400 });
    }
    const body = await readObject(request);
    if (!body) return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
    const data = await guardarSolicitudCompra(body, id);
    return data
      ? NextResponse.json({ data, adapter: "postgresql" })
      : NextResponse.json({ error: "Solicitud no encontrada." }, { status: 404 });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(_request: NextRequest, context: RouteContext) {
  try {
    const path = await getPath(context);
    const id = Number(path[1]);
    if (path[0] !== "solicitudes" || path.length !== 2 || !Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "Solicitud o identificador inválido." }, { status: 400 });
    }
    const deleted = await eliminarSolicitudCompra(id);
    return deleted
      ? NextResponse.json({ data: { id }, adapter: "postgresql" })
      : NextResponse.json({ error: "Solo se pueden eliminar solicitudes en borrador." }, { status: 409 });
  } catch (error) {
    return handleError(error);
  }
}
