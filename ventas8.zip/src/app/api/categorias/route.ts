import { NextRequest, NextResponse } from "next/server";
import {
  actualizarCategoria,
  CategoriaValidationError,
  crearCategoria,
  desactivarCategoria,
  listarCategorias,
} from "@/services/categorias.service";
import { DatabaseConfigurationError } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }
  if (error instanceof CategoriaValidationError) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  const code = (error as { code?: string })?.code;
  if (code === "23505") {
    return NextResponse.json({ error: "Ya existe una categoría con ese código." }, { status: 409 });
  }
  console.error("Error en API de categorías:", error);
  return NextResponse.json({ error: "No se pudo completar la operación de categorías." }, { status: 500 });
}

export async function GET(request: NextRequest) {
  try {
    const data = await listarCategorias(request.nextUrl.searchParams.get("q") ?? "");
    return NextResponse.json({ data, adapter: "postgresql" });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    const id = await crearCategoria(await request.json());
    return NextResponse.json({ id }, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return NextResponse.json({ error: "Los datos de la categoría no son válidos." }, { status: 400 });
    }
    const data = body as Record<string, unknown>;
    const id = Number(data.id);
    if (!Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "El ID de la categoría no es válido." }, { status: 400 });
    }
    if (!(await actualizarCategoria(id, data))) {
      return NextResponse.json({ error: "Categoría no encontrada." }, { status: 404 });
    }
    return NextResponse.json({ id });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const body: unknown = await request.json();
    const id = body && typeof body === "object" && !Array.isArray(body)
      ? Number((body as Record<string, unknown>).id)
      : Number.NaN;
    if (!Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "El ID de la categoría no es válido." }, { status: 400 });
    }
    if (!(await desactivarCategoria(id))) {
      return NextResponse.json({ error: "Categoría no encontrada." }, { status: 404 });
    }
    return NextResponse.json({ id, estado: "Inactivo" });
  } catch (error) {
    return handleError(error);
  }
}
