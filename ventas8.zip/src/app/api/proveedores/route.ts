import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  actualizarProveedor,
  crearProveedor,
  desactivarProveedor,
  listarProveedores,
  ProveedorValidationError,
} from "@/services/proveedores.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }
  if (error instanceof ProveedorValidationError) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  const code = (error as { code?: string })?.code;
  if (code === "23505") {
    return NextResponse.json({ error: "Ya existe un proveedor con ese código o identificación." }, { status: 409 });
  }
  if (code === "23503" || code === "23502" || code === "22P02") {
    return NextResponse.json({ error: "Los datos no cumplen las reglas de la base de datos." }, { status: 400 });
  }
  console.error("Error en API de proveedores:", error);
  return NextResponse.json({ error: "No se pudo completar la operación de proveedores." }, { status: 500 });
}

export async function GET(request: NextRequest) {
  try {
    const data = await listarProveedores(request.nextUrl.searchParams.get("q") ?? "");
    return NextResponse.json({ data, adapter: "postgresql", capabilities: { create: true, update: true, delete: true } });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    return NextResponse.json({ id: await crearProveedor(await request.json()) }, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return NextResponse.json({ error: "Los datos del proveedor no son válidos." }, { status: 400 });
    }
    const data = body as Record<string, unknown>;
    const id = Number(data.id);
    if (!Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "El ID del proveedor no es válido." }, { status: 400 });
    }
    if (!(await actualizarProveedor(id, data))) {
      return NextResponse.json({ error: "Proveedor no encontrado." }, { status: 404 });
    }
    return NextResponse.json({ id });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const body: unknown = await request.json();
    const id = body && typeof body === "object" && !Array.isArray(body)
      ? Number((body as Record<string, unknown>).id)
      : Number.NaN;
    if (!Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "El ID del proveedor no es válido." }, { status: 400 });
    }
    if (!(await desactivarProveedor(id))) {
      return NextResponse.json({ error: "Proveedor no encontrado." }, { status: 404 });
    }
    return NextResponse.json({ id, estado: "Inactivo" });
  } catch (error) {
    return handleError(error);
  }
}
