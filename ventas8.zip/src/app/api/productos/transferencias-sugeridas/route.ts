import { NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import { listarTransferenciasSugeridas } from "@/services/productos.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const data = await listarTransferenciasSugeridas();
    return NextResponse.json({ data });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) {
      return NextResponse.json({ error: error.message }, { status: 503 });
    }
    console.error("Error al consultar sugerencias de transferencia:", error);
    return NextResponse.json(
      { error: "No se pudieron consultar las sugerencias de transferencia." },
      { status: 500 },
    );
  }
}
