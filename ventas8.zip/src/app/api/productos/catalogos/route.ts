import { NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import { listarCatalogosProducto } from "@/services/productos.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return NextResponse.json(await listarCatalogosProducto());
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) {
      return NextResponse.json({ error: error.message }, { status: 503 });
    }
    console.error("Error en catálogos de productos:", error);
    return NextResponse.json({ error: "No se pudieron cargar los catálogos de productos." }, { status: 500 });
  }
}