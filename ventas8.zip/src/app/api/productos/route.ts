import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import { crearProducto, listarProductos, ProductoValidationError } from "@/services/productos.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const data = await listarProductos(request.nextUrl.searchParams.get("q") ?? "");
    return NextResponse.json({
      data,
      adapter: "postgresql",
      capabilities: { create: true, update: true, delete: true, inventoryMovements: true },
    });
  } catch (error) {
    return handleError(error);
  }
}

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }
  if (error instanceof ProductoValidationError) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }
  const code = (error as { code?: string })?.code;
  if (code === "23505") return NextResponse.json({ error: "Ya existe un producto con ese código." }, { status: 409 });
  if (code === "23503" || code === "23502" || code === "22P02") {
    return NextResponse.json({ error: "Los datos no cumplen las relaciones o reglas de la base." }, { status: 400 });
  }
  console.error("Error en API de productos:", error);
  return NextResponse.json({ error: "No se pudo completar la operación de productos." }, { status: 500 });
}

export async function POST(request: NextRequest) {
  try {
    return NextResponse.json({ id: await crearProducto(await request.json()) }, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}
