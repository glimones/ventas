import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  listarMovimientosProducto,
  ProductoValidationError,
  registrarMovimientoProducto,
} from "@/services/productos.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function GET(_request: NextRequest, context: Context) {
  const id = Number((await context.params).id);
  if (!Number.isSafeInteger(id) || id <= 0) {
    return NextResponse.json({ error: "El ID del producto no es válido." }, { status: 400 });
  }

  try {
    const data = await listarMovimientosProducto(id);
    return NextResponse.json({ data });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) {
      return NextResponse.json({ error: error.message }, { status: 503 });
    }
    console.error("Error al consultar movimientos de inventario:", error);
    return NextResponse.json(
      { error: "No se pudo consultar el historial de movimientos." },
      { status: 500 },
    );
  }
}

export async function POST(request: NextRequest, context: Context) {
  try {
    const id = Number((await context.params).id);
    if (!Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "El ID del producto no es válido." }, { status: 400 });
    }
    return NextResponse.json(await registrarMovimientoProducto(id, await request.json()), { status: 201 });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) return NextResponse.json({ error: error.message }, { status: 503 });
    if (error instanceof ProductoValidationError) {
      const status = error.message.includes("excede el stock") ? 409 : 400;
      return NextResponse.json({ error: error.message }, { status });
    }
    const code = (error as { code?: string })?.code;
    if (code === "23503" || code === "23502" || code === "22P02") {
      return NextResponse.json({ error: "El movimiento no cumple las relaciones o reglas de la base." }, { status: 400 });
    }
    console.error("Error en movimiento de inventario:", error);
    return NextResponse.json({ error: "No se pudo registrar el movimiento." }, { status: 500 });
  }
}