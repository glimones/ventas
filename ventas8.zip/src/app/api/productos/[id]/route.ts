import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  actualizarProducto,
  desactivarProducto,
  ProductoValidationError,
} from "@/services/productos.service";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) return NextResponse.json({ error: error.message }, { status: 503 });
  if (error instanceof ProductoValidationError) return NextResponse.json({ error: error.message }, { status: 400 });
  const code = (error as { code?: string })?.code;
  if (code === "23505") return NextResponse.json({ error: "Ya existe un producto con ese código." }, { status: 409 });
  if (code === "23503" || code === "23502" || code === "22P02") return NextResponse.json({ error: "Los datos no cumplen las relaciones o reglas de la base." }, { status: 400 });
  console.error("Error en API de producto:", error);
  return NextResponse.json({ error: "No se pudo completar la operación de producto." }, { status: 500 });
}

async function getId(context: Context) {
  const id = Number((await context.params).id);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

export async function PUT(request: NextRequest, context: Context) {
  try {
    const id = await getId(context);
    if (!id) return NextResponse.json({ error: "El ID del producto no es válido." }, { status: 400 });
    if (!(await actualizarProducto(id, await request.json()))) {
      return NextResponse.json({ error: "Producto no encontrado." }, { status: 404 });
    }
    return NextResponse.json({ id });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest, context: Context) {
  return PUT(request, context);
}

export async function DELETE(_request: NextRequest, context: Context) {
  try {
    const id = await getId(context);
    if (!id) return NextResponse.json({ error: "El ID del producto no es válido." }, { status: 400 });
    if (!(await desactivarProducto(id))) {
      return NextResponse.json({ error: "Producto no encontrado." }, { status: 404 });
    }
    return NextResponse.json({ id, estado: "Inactivo" });
  } catch (error) {
    return handleError(error);
  }
}