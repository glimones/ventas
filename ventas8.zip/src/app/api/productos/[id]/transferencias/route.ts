import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  ProductoConflictError,
  ProductoValidationError,
  registrarTransferenciaSugerida,
} from "@/services/productos.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function POST(request: NextRequest, context: Context) {
  try {
    const productoId = Number((await context.params).id);
    if (!Number.isSafeInteger(productoId) || productoId <= 0) {
      return NextResponse.json(
        { error: "El ID del producto no es válido." },
        { status: 400 },
      );
    }
    const data = await registrarTransferenciaSugerida(
      productoId,
      await request.json(),
    );
    return NextResponse.json({ data }, { status: 201 });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) {
      return NextResponse.json({ error: error.message }, { status: 503 });
    }
    if (error instanceof ProductoConflictError) {
      return NextResponse.json({ error: error.message }, { status: 409 });
    }
    if (error instanceof ProductoValidationError) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    const code = (error as { code?: string })?.code;
    if (code === "23503" || code === "23502" || code === "22P02") {
      return NextResponse.json(
        { error: "La transferencia no cumple las reglas de la base." },
        { status: 400 },
      );
    }
    console.error("Error al registrar transferencia de inventario:", error);
    return NextResponse.json(
      { error: "No se pudo registrar la transferencia." },
      { status: 500 },
    );
  }
}
