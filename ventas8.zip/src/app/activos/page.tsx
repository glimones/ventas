import { AppShell } from '@/components/app-shell';
import ActivosPage from './ActivosPage';

export default function Page() {
  return (
    <AppShell>
      <ActivosPage />
    </AppShell>
  );
}
