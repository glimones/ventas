import DomainCrud from '@/components/domain-crud';import{domainConfigs}from '@/components/domain-config';export default function ActivosPage(){return <DomainCrud config={domainConfigs.activos}/>}
