import { AppShell } from '@/components/app-shell';
import ConfiguracionContablePage from './ConfiguracionContablePage';

export default function Page() {
  return (
    <AppShell>
      <ConfiguracionContablePage />
    </AppShell>
  );
}
