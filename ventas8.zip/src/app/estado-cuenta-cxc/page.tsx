import { AppShell } from '@/components/app-shell';
import EstadoCuentaCxcPage from './EstadoCuentaCxcPage';

export default function Page() {
  return (
    <AppShell>
      <EstadoCuentaCxcPage />
    </AppShell>
  );
}
