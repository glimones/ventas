import { AppShell } from '@/components/app-shell';
import AnticiposCxpPage from './AnticiposCxpPage';

export default function Page() {
  return (
    <AppShell>
      <AnticiposCxpPage />
    </AppShell>
  );
}
