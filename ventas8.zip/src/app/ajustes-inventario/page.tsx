import { AppShell } from '@/components/app-shell';
import AjustesInventarioPage from './AjustesInventarioPage';

export default function Page() {
  return (
    <AppShell>
      <AjustesInventarioPage />
    </AppShell>
  );
}
