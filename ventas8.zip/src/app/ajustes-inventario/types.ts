export interface AjustesInventario {
  id: number;
  codigo: string;
  producto: string;
  bodega: string;
  tipo_ajuste: string;
  cantidad: number;
  motivo: string;
  responsable: string;
  fecha: string;
  estado: string;
}

export interface AjustesInventarioFormValues {
  codigo: string;
  producto: string;
  bodega: string;
  tipo_ajuste: string;
  cantidad: number;
  motivo: string;
  responsable: string;
  fecha: string;
  estado: string;
}
