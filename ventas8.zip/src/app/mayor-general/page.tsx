import { AppShell } from '@/components/app-shell';
import MayorGeneralPage from './MayorGeneralPage';

export default function Page() {
  return (
    <AppShell>
      <MayorGeneralPage />
    </AppShell>
  );
}
