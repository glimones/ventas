﻿export interface Bodega {
  id: number;
  nombre: string;
  codigo: string;
  ubicacion: string;
  responsable: string;
  capacidad: number;
  tipo: string;
  ciudad: string;
  telefono: string;
  estado: string;
  notas?: string;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface BodegaFormValues {
  nombre: string;
  codigo: string;
  ubicacion: string;
  responsable: string;
  capacidad: string;
  tipo: string;
  ciudad: string;
  telefono: string;
  estado: string;
  notas?: string;
}
