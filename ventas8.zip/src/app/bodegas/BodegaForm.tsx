﻿import React from 'react';
import { BodegaFormValues } from './types';

interface Props {
  values: BodegaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const tiposBodega = [
  { value: '', label: 'Seleccione tipo de bodega' },
  { value: 'General', label: 'General' },
  { value: 'Materia Prima', label: 'Materia Prima' },
  { value: 'Producto Terminado', label: 'Producto Terminado' },
  { value: 'Refrigerada', label: 'Refrigerada' },
  { value: 'Tránsito', label: 'Tránsito' },
];

const BodegaForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre' className='form-label'>Nombre *</label>
          <input type='text' className='form-control' id='nombre' name='nombre' value={values.nombre || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='ubicacion' className='form-label'>Ubicación *</label>
          <textarea className='form-control' id='ubicacion' name='ubicacion' value={values.ubicacion || ''} onChange={handleInputChange} rows={2} required />
        </div>
        <div className='mb-3'>
          <label htmlFor='responsable' className='form-label'>Responsable *</label>
          <input type='text' className='form-control' id='responsable' name='responsable' value={values.responsable || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='capacidad' className='form-label'>Capacidad (m³ / unidades) *</label>
          <input type='number' className='form-control' id='capacidad' name='capacidad' value={values.capacidad || ''} onChange={handleInputChange} required min='0' autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='tipo' className='form-label'>Tipo de Bodega *</label>
          <select className='form-select' id='tipo' name='tipo' value={values.tipo || ''} onChange={handleInputChange} required>
            {tiposBodega.map((option) => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>
        </div>
        <div className='mb-3'>
          <label htmlFor='ciudad' className='form-label'>Ciudad *</label>
          <input type='text' className='form-control' id='ciudad' name='ciudad' value={values.ciudad || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='telefono' className='form-label'>Teléfono *</label>
          <input type='text' className='form-control' id='telefono' name='telefono' value={values.telefono || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || 'Activo'} onChange={handleInputChange}>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
        <div className='mb-3'>
          <label htmlFor='notas' className='form-label'>Notas</label>
          <textarea className='form-control' id='notas' name='notas' value={values.notas || ''} onChange={handleInputChange} rows={2} autoComplete='off' />
        </div>
      </div>
    </div>
  );
};

export default BodegaForm;
