﻿'use client';

import React, { useState, useCallback, useEffect } from 'react';
import { Bodega, BodegaFormValues } from './types';
import BodegaModal from './BodegaModal';
import RegistroResumen, { type FiltroEstadoRegistro } from '@/components/registro-resumen';
import './bootstrap-bodegas.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: BodegaFormValues = {
  nombre: '',
  codigo: '',
  ubicacion: '',
  responsable: '',
  capacidad: '',
  tipo: '',
  ciudad: '',
  telefono: '',
  estado: 'Activo',
  notas: '',
};

export default function BodegasPage() {
  const [bodegas, setBodegas] = useState<Bodega[]>([]);
  const [filtro, setFiltro] = useState<string>('');
  const [filtroEstado, setFiltroEstado] = useState<FiltroEstadoRegistro>('TODOS');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<BodegaFormValues>(initialForm);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');

  const cargarBodegas = useCallback(async () => {
    setCargando(true);
    try {
      const response = await fetch('/api/bodegas', { cache: 'no-store' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudieron cargar las bodegas.');
      setBodegas(result.data as Bodega[]);
      setError('');
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Error al cargar bodegas.');
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => { void cargarBodegas(); }, [cargarBodegas]);

  const limpiarForm = useCallback(() => {
    setForm(initialForm);
    setEditandoId(null);
  }, []);

  const abrirModalNueva = useCallback(() => {
    limpiarForm();
    setTimeout(() => setShowModal(true), 0);
  }, [limpiarForm]);

  const abrirModalEditar = useCallback((bodega: Bodega) => {
    setForm({
      nombre: bodega.nombre || '',
      codigo: bodega.codigo || '',
      ubicacion: bodega.ubicacion || '',
      responsable: bodega.responsable || '',
      capacidad: String(bodega.capacidad || ''),
      tipo: bodega.tipo || '',
      ciudad: bodega.ciudad || '',
      telefono: bodega.telefono || '',
      estado: bodega.estado || 'Activo',
      notas: bodega.notas || '',
    });
    setEditandoId(bodega.id);
    setTimeout(() => setShowModal(true), 0);
  }, []);

  const cerrarModal = useCallback(() => {
    setShowModal(false);
    setTimeout(limpiarForm, 300);
  }, [limpiarForm]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(editandoId ? `/api/bodegas/${editandoId}` : '/api/bodegas', {
        method: editandoId ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, capacidad: form.capacidad === '' ? null : Number(form.capacidad) }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo guardar la bodega.');
      await cargarBodegas();
      cerrarModal();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Error al guardar la bodega.');
    }
  }, [form, editandoId, cerrarModal, cargarBodegas]);

  const eliminarBodega = useCallback(async (id: number) => {
    if (window.confirm('¿Seguro que deseas eliminar esta bodega?')) {
      try {
        const response = await fetch(`/api/bodegas/${id}`, { method: 'DELETE' });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'No se pudo desactivar la bodega.');
        await cargarBodegas();
      } catch (deleteError) {
        setError(deleteError instanceof Error ? deleteError.message : 'Error al desactivar la bodega.');
      }
    }
  }, [cargarBodegas]);

  const bodegasActivas = bodegas.filter((bodega) =>
    (bodega.estado || '').toLocaleLowerCase().startsWith('activ'),
  ).length;
  const bodegasInactivas = bodegas.filter((bodega) =>
    (bodega.estado || '').toLocaleLowerCase().startsWith('inactiv'),
  ).length;
  const bodegasFiltradas = bodegas.filter((bodega) => {
    const coincideBusqueda = Object.values(bodega)
      .join(' ')
      .toLocaleLowerCase()
      .includes(filtro.toLocaleLowerCase());
    const estado = (bodega.estado || '').toLocaleLowerCase();
    const coincideEstado =
      filtroEstado === 'TODOS' ||
      (filtroEstado === 'ACTIVOS' && estado.startsWith('activ')) ||
      (filtroEstado === 'INACTIVOS' && estado.startsWith('inactiv'));
    return coincideBusqueda && coincideEstado;
  });

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Bodegas</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input type='text' className='form-control w-50' placeholder='Buscar bodega...' value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva} type='button'>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir Bodega</span>
          </button>
        </div>
        <RegistroResumen
          total={bodegas.length}
          activos={bodegasActivas}
          inactivos={bodegasInactivas}
          filtro={filtroEstado}
          cargando={cargando}
          onChange={setFiltroEstado}
        />
        {!cargando && (
          <p className='entity-result-count' role='status'>
            Mostrando {bodegasFiltradas.length} de {bodegas.length} bodegas
          </p>
        )}
        {error && <div className='alert alert-danger' role='alert'>{error}</div>}
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>Nombre</th>
                <th>Código</th>
                <th>Ubicación</th>
                <th>Responsable</th>
                <th>Tipo</th>
                <th>Capacidad</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && <tr><td colSpan={8} className='text-center'>Cargando bodegas...</td></tr>}
              {!cargando && bodegasFiltradas.length === 0 && (
                <tr><td colSpan={8} className='text-center'>{error ? 'No se pudieron cargar las bodegas' : 'No se encontraron bodegas'}</td></tr>
              )}
              {bodegasFiltradas.map((bodega) => (
                <tr key={bodega.id}>
                  <td>{bodega.nombre}</td>
                  <td>{bodega.codigo}</td>
                  <td>{bodega.ubicacion}</td>
                  <td>{bodega.responsable}</td>
                  <td>{bodega.tipo}</td>
                  <td>{bodega.capacidad}</td>
                  <td><span className={`badge bg-${bodega.estado === 'Activo' ? 'success' : 'secondary'}`}>{bodega.estado}</span></td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(bodega)} type='button'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminarBodega(bodega.id)} type='button'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <BodegaModal show={showModal} editando={!!editandoId} values={form} onChange={handleChange} onClose={cerrarModal} onSubmit={handleSubmit} />
      </div>
    </div>
  );
}
