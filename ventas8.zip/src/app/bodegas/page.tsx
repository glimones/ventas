﻿import { AppShell } from '@/components/app-shell';
import BodegasPage from './BodegaPage';

export default function Page() {
  return (
    <AppShell>
      <BodegasPage />
    </AppShell>
  );
}
