export type GiroNegocio = "alimentos" | "comercio" | "servicios";

export interface Empresa {
  id: number;
  nombre_comercial: string;
  nombre_legal: string;
  ruc: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  email: string;
  telefono?: string;
  logo_url?: string;
  moneda: string;
  estado: string;
  slug: string;
  giro_negocio: GiroNegocio;
  descripcion_web: string;
  color_primario: string;
  color_secundario: string;
  tienda_online: boolean;
  cuenta_clientes_habilitada: boolean;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface EmpresaFormValues {
  nombre_comercial: string;
  nombre_legal: string;
  ruc: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  email: string;
  telefono: string;
  logo_url?: string;
  moneda: string;
  estado: string;
  slug: string;
  giro_negocio: GiroNegocio;
  descripcion_web: string;
  color_primario: string;
  color_secundario: string;
  tienda_online: boolean;
  cuenta_clientes_habilitada: boolean;
}
  