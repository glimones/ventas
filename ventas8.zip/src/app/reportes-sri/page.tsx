import { AppShell } from '@/components/app-shell';
import ReportesSriPage from './ReportesSriPage';

export default function Page() {
  return (
    <AppShell>
      <ReportesSriPage />
    </AppShell>
  );
}
