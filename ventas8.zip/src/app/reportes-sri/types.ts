export interface ReportesSri {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}

export interface ReportesSriFormValues {
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}
