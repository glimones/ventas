import Link from "next/link";
import { LogOut, ShieldCheck } from "lucide-react";

import { AppSidebarMenu } from "@/components/sidebar-menu";

export function AppShell({
  children,
  showFooter = true,
}: {
  children: React.ReactNode;
  showFooter?: boolean;
}) {
  return (
    <div className="app-shell flex h-screen flex-col bg-neutral-100">
      <header className="z-20 flex h-[72px] w-full shrink-0 items-center justify-between gap-3 border-b border-white/10 bg-black px-6 py-2 text-white shadow-[0_10px_30px_rgba(0,0,0,0.18)]">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-white/8 backdrop-blur-sm">
            <ShieldCheck className="h-4.5 w-4.5 text-white" />
          </div>
          <div>
            <p className="m-0 text-[11px] font-semibold leading-4 uppercase tracking-[0.32em] text-white/60">
              Empresa
            </p>
            <p className="m-0 text-lg font-semibold leading-5 text-white">Sistema de Ventas</p>
            <p className="m-0 mt-0.5 text-xs leading-4 text-white/55">Gestión comercial y operativa</p>
          </div>
        </div>
        <Link
          href="/"
          aria-label="Cerrar sesión"
          title="Cerrar sesión"
          className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-white/8 text-white transition-colors hover:bg-white hover:text-black"
        >
          <LogOut className="h-4.5 w-4.5" />
        </Link>
      </header>

      <div className="flex min-h-0 flex-1 overflow-hidden bg-neutral-100">
        <div className="flex min-h-0 flex-1 overflow-hidden">
          <div className="app-shell-sidebar">
            <AppSidebarMenu />
          </div>
          <div className="app-shell-main flex min-w-0 flex-1 flex-col overflow-y-auto bg-neutral-100">
            <main className="flex-1">{children}</main>
          </div>
        </div>
      </div>

      {showFooter ? (
        <footer className="z-20 w-full bg-black px-6 py-2 text-center text-xs text-white">
          Motorizado por GLM
        </footer>
      ) : null}
    </div>
  );
}