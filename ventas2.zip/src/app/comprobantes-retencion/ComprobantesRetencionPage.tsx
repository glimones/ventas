"use client";

import React, { useState } from "react";
import { ComprobanteRetencion, ComprobanteRetencionFormValues, InfoComprobanteRetencion, DetalleImpuesto } from "./types";
import { SRIUniversalService } from "../../services/sri-universal.service";
import "./comprobantes-retencion.css";
import { CirclePlus, SquarePen, Trash2, Eye, Download } from 'lucide-react';

const initialForm: ComprobanteRetencionFormValues = {
  ambiente: "1",
  razon_social: "EMPRESA DEMO S.A.",
  nombre_comercial: "Demo",
  ruc: "1234567890001",
  estab: "001",
  ptoEmi: "001",
  secuencial: "1",
  direccion_matriz: "Av. Principal 123, Ciudad Demo",
  fecha_emision: new Date().toISOString().split('T')[0],
  direccion_establecimiento: "Av. Principal 123, Ciudad Demo",
  contribuyente_especial: "",
  obligado_contabilidad: "SI",
  tipo_identificacion_sujeto_retenido: "",
  razon_social_sujeto_retenido: "",
  identificacion_sujeto_retenido: "",
  periodo_fiscal: new Date().getMonth() < 9 ? `0${new Date().getMonth() + 1}/${new Date().getFullYear()}` : `${new Date().getMonth() + 1}/${new Date().getFullYear()}`,
  cod_doc_sustento: "",
  num_doc_sustento: "",
  fecha_emision_doc_sustento: "",
  codigo_impuesto: "",
  codigo_retencion: "",
  base_imponible: 0,
  porcentaje_retener: 0,
  valor_retenido: 0,
};

const initialComprobantes: ComprobanteRetencion[] = [
  {
    id: 1,
    info_tributaria: {
      ambiente: "1",
      tipo_emision: "1",
      razon_social: "EMPRESA DEMO S.A.",
      nombre_comercial: "Demo",
      ruc: "1234567890001",
      clave_acceso: "2309202407123456789000110010010000000011234567894",
      cod_doc: "07",
      estab: "001",
      ptoEmi: "001",
      secuencial: "000000001",
      direccion_matriz: "Av. Principal 123, Ciudad Demo"
    },
    info_comprobante_retencion: {
      fecha_emision: "23/09/2024",
      direccion_establecimiento: "Av. Principal 123, Ciudad Demo",
      contribuyente_especial: "",
      obligado_contabilidad: "SI",
      tipo_identificacion_sujeto_retenido: "05",
      razon_social_sujeto_retenido: "PROVEEDOR DEMO",
      identificacion_sujeto_retenido: "1234567890",
      periodo_fiscal: "09/2024"
    },
    impuestos: [
      {
        codigo: "1",
        codigo_retencion: "303",
        base_imponible: 1000.00,
        porcentaje_retener: 10,
        valor_retenido: 100.00,
        cod_doc_sustento: "01",
        num_doc_sustento: "001-001-000000001",
        fecha_emision_doc_sustento: "20/09/2024"
      }
    ],
    estado_sri: 'AUTORIZADA',
    numero_autorizacion: "2309202412345678901234567890123456",
    fecha_autorizacion: "2024-09-23T10:30:00.000Z",
    fecha_creacion: "2024-09-23T10:00:00.000Z",
    fecha_actualizacion: "2024-09-23T10:30:00.000Z"
  }
];

export default function ComprobantesRetencionPage() {
  const [comprobantes, setComprobantes] = useState<ComprobanteRetencion[]>(initialComprobantes);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ComprobanteRetencionFormValues>(initialForm);
  const [enviandoSRI, setEnviandoSRI] = useState<boolean>(false);

  const sriService = SRIUniversalService.getInstance();

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNuevo = () => {
    limpiarForm();
    const ultimoSecuencial = Math.max(...comprobantes.map(c => parseInt(c.info_tributaria.secuencial) || 0), 0);
    setForm(prev => ({
      ...prev,
      secuencial: (ultimoSecuencial + 1).toString()
    }));
    setShowModal(true);
  };

  const abrirModalEditar = (comprobante: ComprobanteRetencion) => {
    const primerImpuesto = comprobante.impuestos[0] || {};
    setForm({
      ambiente: comprobante.info_tributaria.ambiente,
      razon_social: comprobante.info_tributaria.razon_social,
      nombre_comercial: comprobante.info_tributaria.nombre_comercial,
      ruc: comprobante.info_tributaria.ruc,
      estab: comprobante.info_tributaria.estab,
      ptoEmi: comprobante.info_tributaria.ptoEmi,
      secuencial: comprobante.info_tributaria.secuencial,
      direccion_matriz: comprobante.info_tributaria.direccion_matriz,
      fecha_emision: comprobante.info_comprobante_retencion.fecha_emision.split('/').reverse().join('-'),
      direccion_establecimiento: comprobante.info_comprobante_retencion.direccion_establecimiento,
      contribuyente_especial: comprobante.info_comprobante_retencion.contribuyente_especial || "",
      obligado_contabilidad: comprobante.info_comprobante_retencion.obligado_contabilidad,
      tipo_identificacion_sujeto_retenido: comprobante.info_comprobante_retencion.tipo_identificacion_sujeto_retenido,
      razon_social_sujeto_retenido: comprobante.info_comprobante_retencion.razon_social_sujeto_retenido,
      identificacion_sujeto_retenido: comprobante.info_comprobante_retencion.identificacion_sujeto_retenido,
      periodo_fiscal: comprobante.info_comprobante_retencion.periodo_fiscal,
      cod_doc_sustento: primerImpuesto.cod_doc_sustento || "",
      num_doc_sustento: primerImpuesto.num_doc_sustento || "",
      fecha_emision_doc_sustento: primerImpuesto.fecha_emision_doc_sustento ? primerImpuesto.fecha_emision_doc_sustento.split('/').reverse().join('-') : "",
      codigo_impuesto: primerImpuesto.codigo || "",
      codigo_retencion: primerImpuesto.codigo_retencion || "",
      base_imponible: primerImpuesto.base_imponible || 0,
      porcentaje_retener: primerImpuesto.porcentaje_retener || 0,
      valor_retenido: primerImpuesto.valor_retenido || 0,
    });
    
    setEditandoId(comprobante.id);
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => {
      const newForm = {
        ...prev,
        [name]: value,
      };

      // Calcular valor retenido automÃ¡ticamente
      if (name === 'base_imponible' || name === 'porcentaje_retener') {
        const base = name === 'base_imponible' ? parseFloat(value) || 0 : prev.base_imponible;
        const porcentaje = name === 'porcentaje_retener' ? parseFloat(value) || 0 : prev.porcentaje_retener;
        newForm.valor_retenido = (base * porcentaje) / 100;
      }

      return newForm;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setEnviandoSRI(true);
    
    try {
      const infoComprobante: InfoComprobanteRetencion = {
        fecha_emision: form.fecha_emision.split('-').reverse().join('/'),
        direccion_establecimiento: form.direccion_establecimiento,
        contribuyente_especial: form.contribuyente_especial,
        obligado_contabilidad: form.obligado_contabilidad,
        tipo_identificacion_sujeto_retenido: form.tipo_identificacion_sujeto_retenido,
        razon_social_sujeto_retenido: form.razon_social_sujeto_retenido,
        identificacion_sujeto_retenido: form.identificacion_sujeto_retenido,
        periodo_fiscal: form.periodo_fiscal,
      };

      const detalleImpuesto: DetalleImpuesto = {
        codigo: form.codigo_impuesto,
        codigo_retencion: form.codigo_retencion,
        base_imponible: form.base_imponible,
        porcentaje_retener: form.porcentaje_retener,
        valor_retenido: form.valor_retenido,
        cod_doc_sustento: form.cod_doc_sustento,
        num_doc_sustento: form.num_doc_sustento,
        fecha_emision_doc_sustento: form.fecha_emision_doc_sustento.split('-').reverse().join('/'),
      };

      const nuevoComprobante: ComprobanteRetencion = {
        id: editandoId || Date.now(),
        info_tributaria: {
          ambiente: form.ambiente,
          tipo_emision: "1",
          razon_social: form.razon_social,
          nombre_comercial: form.nombre_comercial,
          ruc: form.ruc,
          clave_acceso: "",
          cod_doc: "07",
          estab: form.estab,
          ptoEmi: form.ptoEmi,
          secuencial: form.secuencial,
          direccion_matriz: form.direccion_matriz,
        },
        info_comprobante_retencion: infoComprobante,
        impuestos: [detalleImpuesto],
        estado_sri: 'PENDIENTE',
        fecha_creacion: new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString()
      };

      const comprobanteParaSRI = {
        id: nuevoComprobante.id,
        tipo_comprobante: '07' as const,
        info_tributaria: nuevoComprobante.info_tributaria,
        estado_sri: nuevoComprobante.estado_sri,
        fecha_creacion: nuevoComprobante.fecha_creacion,
        fecha_actualizacion: nuevoComprobante.fecha_actualizacion
      };

      const datosEspecificos = `
  <infoCompRetencion>
    <fechaEmision>${infoComprobante.fecha_emision}</fechaEmision>
    <dirEstablecimiento><![CDATA[${infoComprobante.direccion_establecimiento}]]></dirEstablecimiento>
    <obligadoContabilidad>${infoComprobante.obligado_contabilidad}</obligadoContabilidad>
    <tipoIdentificacionSujetoRetenido>${infoComprobante.tipo_identificacion_sujeto_retenido}</tipoIdentificacionSujetoRetenido>
    <razonSocialSujetoRetenido><![CDATA[${infoComprobante.razon_social_sujeto_retenido}]]></razonSocialSujetoRetenido>
    <identificacionSujetoRetenido>${infoComprobante.identificacion_sujeto_retenido}</identificacionSujetoRetenido>
    <periodoFiscal>${infoComprobante.periodo_fiscal}</periodoFiscal>
  </infoCompRetencion>
  <impuestos>
    <impuesto>
      <codigo>${detalleImpuesto.codigo}</codigo>
      <codigoRetencion>${detalleImpuesto.codigo_retencion}</codigoRetencion>
      <baseImponible>${detalleImpuesto.base_imponible.toFixed(2)}</baseImponible>
      <porcentajeRetener>${detalleImpuesto.porcentaje_retener}</porcentajeRetener>
      <valorRetenido>${detalleImpuesto.valor_retenido.toFixed(2)}</valorRetenido>
      <codDocSustento>${detalleImpuesto.cod_doc_sustento}</codDocSustento>
      <numDocSustento>${detalleImpuesto.num_doc_sustento}</numDocSustento>
      <fechaEmisionDocSustento>${detalleImpuesto.fecha_emision_doc_sustento}</fechaEmisionDocSustento>
    </impuesto>
  </impuestos>`;

      console.log('ðŸš€ Enviando comprobante de retenciÃ³n al SRI...', nuevoComprobante);
      const respuestaSRI = await sriService.enviarComprobanteSRI(comprobanteParaSRI, datosEspecificos, infoComprobante.fecha_emision);

      nuevoComprobante.estado_sri = respuestaSRI.estado;
      if (respuestaSRI.success) {
        nuevoComprobante.numero_autorizacion = respuestaSRI.numero_autorizacion;
        nuevoComprobante.fecha_autorizacion = respuestaSRI.fecha_autorizacion;
        nuevoComprobante.xml_generado = respuestaSRI.xml_autorizado;
      }
      nuevoComprobante.observaciones_sri = respuestaSRI.observaciones;

      if (editandoId) {
        setComprobantes((prev) =>
          prev.map((comp) =>
            comp.id === editandoId ? nuevoComprobante : comp
          )
        );
      } else {
        setComprobantes((prev) => [...prev, nuevoComprobante]);
      }

      if (respuestaSRI.success) {
        alert(`âœ… Comprobante de RetenciÃ³n ${respuestaSRI.estado.toLowerCase()} exitosamente.\nNÃºmero de autorizaciÃ³n: ${respuestaSRI.numero_autorizacion}`);
        cerrarModal();
      } else {
        alert(`âŒ Error del SRI: ${respuestaSRI.mensaje_error}\n\nObservaciones: ${respuestaSRI.observaciones}`);
      }

    } catch (error) {
      console.error('Error procesando comprobante de retenciÃ³n:', error);
      alert('Error inesperado al procesar el comprobante de retenciÃ³n');
    } finally {
      setEnviandoSRI(false);
    }
  };

  const eliminarComprobante = (id: number) => {
    if (window.confirm("Â¿Seguro que deseas eliminar este comprobante de retenciÃ³n?")) {
      setComprobantes((prev) => prev.filter((comp) => comp.id !== id));
    }
  };

  const comprobantesFiltrados = comprobantes.filter((comp) =>
    Object.values(comp.info_comprobante_retencion)
      .concat(Object.values(comp.info_tributaria))
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'AUTORIZADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'DEVUELTA': return 'bg-warning text-dark';
      case 'PENDIENTE': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Comprobantes de RetenciÃ³n ElectrÃ³nicos</h1>
            <p className="text-muted mb-0">GestiÃ³n de retenciones SRI Ecuador</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-info">Ambiente: Pruebas</span>
            <span className="badge bg-primary text-white">{comprobantes.length} comprobantes</span>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar por proveedor, RUC, secuencial..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-primary d-flex align-items-center" onClick={abrirModalNuevo}>
            <CirclePlus className="me-2" size={16} />
            <span>Nuevo Comprobante de RetenciÃ³n</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Secuencial</th>
                <th>Fecha</th>
                <th>Proveedor</th>
                <th>Documento Sustento</th>
                <th>Impuesto</th>
                <th>Valor Retenido</th>
                <th>Estado SRI</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {comprobantesFiltrados.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-4">
                    <div className="text-muted">
                      No se encontraron comprobantes de retenciÃ³n
                    </div>
                  </td>
                </tr>
              )}
              {comprobantesFiltrados.map((comp) => (
                <tr key={comp.id}>
                  <td>
                    <strong>{comp.info_tributaria.estab}-{comp.info_tributaria.ptoEmi}-{comp.info_tributaria.secuencial.padStart(9, '0')}</strong>
                  </td>
                  <td>{comp.info_comprobante_retencion.fecha_emision}</td>
                  <td>{comp.info_comprobante_retencion.razon_social_sujeto_retenido}</td>
                  <td>
                    <small className="text-muted">
                      {comp.impuestos[0]?.num_doc_sustento || 'N/A'}
                    </small>
                  </td>
                  <td>
                    <small>
                      {(() => {
                        const codigo = comp.impuestos[0]?.codigo;
                        let tipo = 'ICE';
                        if (codigo === '1') tipo = 'Renta';
                        else if (codigo === '2') tipo = 'IVA';
                        return `${tipo} - ${comp.impuestos[0]?.porcentaje_retener}%`;
                      })()}
                    </small>
                  </td>
                  <td className="text-end">
                    <strong>${comp.impuestos[0]?.valor_retenido?.toFixed(2) || '0.00'}</strong>
                  </td>
                  <td>
                    <span className={`badge ${getEstadoBadgeClass(comp.estado_sri)}`}>
                      {comp.estado_sri}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => abrirModalEditar(comp)}
                        title="Ver detalles"
                      >
                        <Eye size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(comp)}
                        title="Editar"
                        disabled={comp.estado_sri === 'AUTORIZADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      {comp.xml_generado && (
                        <button
                          className="btn btn-outline-success btn-sm"
                          title="Descargar XML"
                          onClick={() => {
                            const blob = new Blob([comp.xml_generado!], { type: 'application/xml' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `comprobante_retencion_${comp.info_tributaria.secuencial}.xml`;
                            a.click();
                          }}
                        >
                          <Download size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarComprobante(comp.id)}
                        title="Eliminar"
                        disabled={comp.estado_sri === 'AUTORIZADA'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>

      {/* Modal simplificado para comprobantes de retención */}
      {showModal && (
        <>
          <div className="modal-backdrop fade show"></div>
          <div className="modal fade show d-block" style={{ zIndex: 1050 }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <form onSubmit={handleSubmit}>
                <div className="modal-header bg-primary text-white">
                  <h5 className="modal-title">
                    {editandoId ? "Editar Comprobante de Retención" : "Nuevo Comprobante de Retención"}
                  </h5>
                  <button
                    type="button"
                    className="btn-close btn-close-white"
                    onClick={cerrarModal}
                    disabled={enviandoSRI}
                  />
                </div>
                
                <div className="modal-body" style={{ maxHeight: '70vh', overflowY: 'auto' }}>
                  <div className="row g-3">
                    {/* Datos del proveedor */}
                    <div className="col-12">
                      <h6 className="text-primary border-bottom pb-2">Datos del Proveedor</h6>
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="razon_social_sujeto_retenido" className="form-label">Proveedor *</label>
                      <input
                        type="text"
                        className="form-control"
                        id="razon_social_sujeto_retenido"
                        name="razon_social_sujeto_retenido"
                        value={form.razon_social_sujeto_retenido}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="identificacion_sujeto_retenido" className="form-label">RUC/CÃ©dula *</label>
                      <input
                        type="text"
                        className="form-control"
                        id="identificacion_sujeto_retenido"
                        name="identificacion_sujeto_retenido"
                        value={form.identificacion_sujeto_retenido}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    
                    {/* Documento sustento */}
                    <div className="col-12">
                      <h6 className="text-primary border-bottom pb-2 mt-3">Documento de Sustento</h6>
                    </div>
                    <div className="col-md-4">
                      <label htmlFor="cod_doc_sustento" className="form-label">Tipo Documento *</label>
                      <select
                        className="form-select"
                        id="cod_doc_sustento"
                        name="cod_doc_sustento"
                        value={form.cod_doc_sustento}
                        onChange={handleChange}
                        required
                      >
                        <option value="">Seleccione...</option>
                        <option value="01">Factura</option>
                        <option value="03">LiquidaciÃ³n de compra</option>
                        <option value="04">Nota de Crédito</option>
                        <option value="05">Nota de Débito</option>
                      </select>
                    </div>
                    <div className="col-md-4">
                      <label htmlFor="num_doc_sustento" className="form-label">NÃºmero Documento *</label>
                      <input
                        type="text"
                        className="form-control"
                        id="num_doc_sustento"
                        name="num_doc_sustento"
                        value={form.num_doc_sustento}
                        onChange={handleChange}
                        placeholder="001-001-000000001"
                        required
                      />
                    </div>
                    <div className="col-md-4">
                      <label htmlFor="fecha_emision_doc_sustento" className="form-label">Fecha Documento *</label>
                      <input
                        type="date"
                        className="form-control"
                        id="fecha_emision_doc_sustento"
                        name="fecha_emision_doc_sustento"
                        value={form.fecha_emision_doc_sustento}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    
                    {/* Impuesto */}
                    <div className="col-12">
                      <h6 className="text-primary border-bottom pb-2 mt-3">Impuesto a Retener</h6>
                    </div>
                    <div className="col-md-3">
                      <label htmlFor="codigo_impuesto" className="form-label">CÃ³digo Impuesto *</label>
                      <select
                        className="form-select"
                        id="codigo_impuesto"
                        name="codigo_impuesto"
                        value={form.codigo_impuesto}
                        onChange={handleChange}
                        required
                      >
                        <option value="">Seleccione...</option>
                        <option value="1">Renta</option>
                        <option value="2">IVA</option>
                        <option value="3">ISD</option>
                      </select>
                    </div>
                    <div className="col-md-3">
                      <label htmlFor="porcentaje_retener" className="form-label">% Retener *</label>
                      <input
                        type="number"
                        className="form-control"
                        id="porcentaje_retener"
                        name="porcentaje_retener"
                        value={form.porcentaje_retener}
                        onChange={handleChange}
                        min="0"
                        max="100"
                        step="0.01"
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="base_imponible" className="form-label">Base Imponible *</label>
                      <input
                        type="number"
                        className="form-control"
                        id="base_imponible"
                        name="base_imponible"
                        value={form.base_imponible}
                        onChange={handleChange}
                        min="0"
                        step="0.01"
                        required
                      />
                    </div>
                  </div>
                </div>
                
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={cerrarModal}
                    disabled={enviandoSRI}
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={enviandoSRI}
                  >
                    {enviandoSRI ? 'Enviando...' : 'Crear y Enviar al SRI'}
                  </button>
                </div>
              </form>
            </div>
          </div>
          </div>
        </>
      )}
    </div>
  );
}
