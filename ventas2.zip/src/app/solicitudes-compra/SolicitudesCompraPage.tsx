"use client";

import React, { useState } from "react";
import { SolicitudCompra, SolicitudCompraFormValues, InfoProveedor, DetalleCompra } from "./types";
import "./solicitudes-compra.css";
import { CirclePlus, SquarePen, Trash2, Eye, Package, Plus, Minus, Building, FileText, Calendar } from 'lucide-react';

const initialForm: SolicitudCompraFormValues = {
  fecha_solicitud: new Date().toISOString().split('T')[0],
  fecha_entrega_requerida: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // +15 días
  prioridad: "NORMAL",
  tipo_solicitud: "PRODUCTOS",
  centro_costo: "ADM",
  forma_pago_preferida: "CREDITO_30",
  tipo_entrega: "ENTREGA_EMPRESA",
  lugar_entrega: "",
  tipo_identificacion: "",
  identificacion: "",
  razon_social: "",
  nombre_comercial: "",
  direccion: "",
  telefono: "",
  email: "",
  contacto_principal: "",
  telefono_contacto: "",
  email_contacto: "",
  codigo_producto: "",
  descripcion: "",
  especificaciones_tecnicas: "",
  unidad_medida: "UND",
  cantidad_solicitada: 1,
  precio_referencial: 0,
  descuento_porcentaje: 0,
  fecha_entrega_requerida_item: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  observaciones_producto: "",
  justificacion_compra: "",
  observaciones_generales: "",
  solicitado_por: "admin",
  departamento_solicitante: "Administración",
};

const initialSolicitudes: SolicitudCompra[] = [
  {
    id: 1,
    numero_solicitud: "SC-2024-001",
    fecha_solicitud: "20/09/2024",
    fecha_entrega_requerida: "05/10/2024",
    estado: "COTIZADA",
    prioridad: "ALTA",
    tipo_solicitud: "PRODUCTOS",
    centro_costo: "SIS",
    forma_pago_preferida: "CREDITO_30",
    tipo_entrega: "ENTREGA_EMPRESA",
    lugar_entrega: "Oficina principal - Sistemas",
    info_proveedor: {
      tipo_identificacion: "04",
      identificacion: "1234567890001",
      razon_social: "PROVEEDORA TECH S.A.",
      nombre_comercial: "TechStore",
      direccion: "Av. Tecnología 123, Quito",
      telefono: "02-2345678",
      email: "ventas@techstore.com",
      contacto_principal: "María González",
      telefono_contacto: "0987654321",
      email_contacto: "maria.gonzalez@techstore.com"
    },
    detalles: [
      {
        id: "1",
        codigo_producto: "SRV001",
        descripcion: "Servidores Dell PowerEdge R740",
        especificaciones_tecnicas: "Intel Xeon, 32GB RAM, 1TB SSD, Garantía 3 años",
        unidad_medida: "UND",
        cantidad_solicitada: 2,
        precio_referencial: 3500.00,
        precio_cotizado: 3200.00,
        descuento_porcentaje: 5,
        subtotal_referencial: 6650.00,
        subtotal_cotizado: 6080.00,
        fecha_entrega_requerida: "05/10/2024",
        observaciones: "Requiere instalación incluida",
        estado_item: "COTIZADO"
      },
      {
        id: "2",
        codigo_producto: "LIC001", 
        descripcion: "Licencias Windows Server 2022",
        especificaciones_tecnicas: "Standard Edition - Usuario CAL",
        unidad_medida: "LIC",
        cantidad_solicitada: 50,
        precio_referencial: 45.00,
        precio_cotizado: 42.00,
        descuento_porcentaje: 0,
        subtotal_referencial: 2250.00,
        subtotal_cotizado: 2100.00,
        observaciones: "Licencias perpetuas",
        estado_item: "COTIZADO"
      }
    ],
    subtotal_referencial: 8900.00,
    descuento_total: 350.00,
    iva: 982.80,
    total_referencial: 9532.80,
    subtotal_cotizado: 8180.00,
    total_cotizado: 9161.60,
    justificacion_compra: "Upgrade infraestructura de servidores para soporte de nuevos sistemas",
    observaciones_generales: "Prioridad alta por vencimiento de garantías actuales",
    solicitado_por: "admin",
    departamento_solicitante: "Sistemas",
    fecha_creacion: "2024-09-20T08:00:00.000Z",
    fecha_actualizacion: "2024-09-21T14:30:00.000Z",
    aprobado_por: "jefe_sistemas",
    fecha_aprobacion: "2024-09-21T16:00:00.000Z"
  },
  {
    id: 2,
    numero_solicitud: "SC-2024-002",
    fecha_solicitud: "21/09/2024",
    fecha_entrega_requerida: "28/09/2024",
    estado: "EN_NEGOCIACION",
    prioridad: "NORMAL",
    tipo_solicitud: "SERVICIOS",
    centro_costo: "MAN",
    forma_pago_preferida: "CREDITO_15",
    tipo_entrega: "OBRA_PROYECTO",
    lugar_entrega: "Planta industrial - Sector B",
    info_proveedor: {
      tipo_identificacion: "04",
      identificacion: "9876543210001",
      razon_social: "MANTENIMIENTO INDUSTRIAL S.A.",
      direccion: "Zona Industrial Norte, Quito",
      telefono: "02-3456789",
      email: "servicios@manind.com",
      contacto_principal: "Carlos Ruiz",
      telefono_contacto: "0998765432",
      email_contacto: "carlos.ruiz@manind.com"
    },
    detalles: [
      {
        id: "1",
        descripcion: "Mantenimiento preventivo equipos industriales",
        especificaciones_tecnicas: "Revisión completa, cambio de filtros, lubricación, ajustes",
        unidad_medida: "SERV",
        cantidad_solicitada: 1,
        precio_referencial: 2500.00,
        descuento_porcentaje: 0,
        subtotal_referencial: 2500.00,
        fecha_entrega_requerida: "28/09/2024",
        observaciones: "Incluye repuestos menores",
        estado_item: "PENDIENTE"
      }
    ],
    subtotal_referencial: 2500.00,
    descuento_total: 0.00,
    iva: 300.00,
    total_referencial: 2800.00,
    justificacion_compra: "Mantenimiento preventivo programado para evitar paradas no planificadas",
    solicitado_por: "admin",
    departamento_solicitante: "Mantenimiento", 
    fecha_creacion: "2024-09-21T10:00:00.000Z",
    fecha_actualizacion: "2024-09-21T15:00:00.000Z"
  }
];

export default function SolicitudesCompraPage() {
  const [solicitudes, setSolicitudes] = useState<SolicitudCompra[]>(initialSolicitudes);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<SolicitudCompraFormValues>(initialForm);
  const [detallesTemp, setDetallesTemp] = useState<DetalleCompra[]>([]);
  const [procesando, setProcesando] = useState<boolean>(false);

  const limpiarForm = () => {
    setForm(initialForm);
    setDetallesTemp([]);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (solicitud: SolicitudCompra) => {
    setForm({
      fecha_solicitud: solicitud.fecha_solicitud.split('/').reverse().join('-'),
      fecha_entrega_requerida: solicitud.fecha_entrega_requerida.split('/').reverse().join('-'),
      prioridad: solicitud.prioridad,
      tipo_solicitud: solicitud.tipo_solicitud,
      centro_costo: solicitud.centro_costo,
      forma_pago_preferida: solicitud.forma_pago_preferida,
      tipo_entrega: solicitud.tipo_entrega,
      lugar_entrega: solicitud.lugar_entrega || "",
      tipo_identificacion: solicitud.info_proveedor.tipo_identificacion,
      identificacion: solicitud.info_proveedor.identificacion,
      razon_social: solicitud.info_proveedor.razon_social,
      nombre_comercial: solicitud.info_proveedor.nombre_comercial || "",
      direccion: solicitud.info_proveedor.direccion,
      telefono: solicitud.info_proveedor.telefono || "",
      email: solicitud.info_proveedor.email || "",
      contacto_principal: solicitud.info_proveedor.contacto_principal || "",
      telefono_contacto: solicitud.info_proveedor.telefono_contacto || "",
      email_contacto: solicitud.info_proveedor.email_contacto || "",
      codigo_producto: "",
      descripcion: "",
      especificaciones_tecnicas: "",
      unidad_medida: "UND",
      cantidad_solicitada: 1,
      precio_referencial: 0,
      descuento_porcentaje: 0,
      fecha_entrega_requerida_item: solicitud.fecha_entrega_requerida.split('/').reverse().join('-'),
      observaciones_producto: "",
      justificacion_compra: solicitud.justificacion_compra,
      observaciones_generales: solicitud.observaciones_generales || "",
      solicitado_por: solicitud.solicitado_por,
      departamento_solicitante: solicitud.departamento_solicitante,
    });
    
    setDetallesTemp([...solicitud.detalles]);
    setEditandoId(solicitud.id);
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const agregarDetalle = () => {
    if (!form.descripcion || form.cantidad_solicitada <= 0) {
      alert("Por favor complete la descripción y cantidad");
      return;
    }

    const subtotal = (form.cantidad_solicitada * form.precio_referencial) * (1 - form.descuento_porcentaje / 100);
    
    const nuevoDetalle: DetalleCompra = {
      id: Date.now().toString(),
      codigo_producto: form.codigo_producto,
      descripcion: form.descripcion,
      especificaciones_tecnicas: form.especificaciones_tecnicas,
      unidad_medida: form.unidad_medida,
      cantidad_solicitada: form.cantidad_solicitada,
      precio_referencial: form.precio_referencial,
      descuento_porcentaje: form.descuento_porcentaje,
      subtotal_referencial: subtotal,
      fecha_entrega_requerida: form.fecha_entrega_requerida_item,
      observaciones: form.observaciones_producto,
      estado_item: "PENDIENTE",
    };

    setDetallesTemp(prev => [...prev, nuevoDetalle]);
    
    // Limpiar campos del producto
    setForm(prev => ({
      ...prev,
      codigo_producto: "",
      descripcion: "",
      especificaciones_tecnicas: "",
      cantidad_solicitada: 1,
      precio_referencial: 0,
      descuento_porcentaje: 0,
      observaciones_producto: "",
    }));
  };

  const eliminarDetalle = (id: string) => {
    setDetallesTemp(prev => prev.filter(detalle => detalle.id !== id));
  };

  const calcularTotales = () => {
    const subtotal = detallesTemp.reduce((sum, detalle) => sum + detalle.subtotal_referencial, 0);
    const descuentoTotal = detallesTemp.reduce((sum, detalle) => 
      sum + (detalle.cantidad_solicitada * (detalle.precio_referencial || 0) * detalle.descuento_porcentaje / 100), 0);
    const iva = subtotal * 0.12; // 12% IVA
    const total = subtotal + iva;
    
    return { subtotal, descuentoTotal, iva, total };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (detallesTemp.length === 0) {
      alert("Debe agregar al menos un producto o servicio");
      return;
    }

    if (!form.justificacion_compra.trim()) {
      alert("La justificación de compra es obligatoria");
      return;
    }

    setProcesando(true);
    
    try {
      const totales = calcularTotales();
      
      const infoProveedor: InfoProveedor = {
        tipo_identificacion: form.tipo_identificacion as "04" | "05" | "06" | "07" | "08",
        identificacion: form.identificacion,
        razon_social: form.razon_social,
        nombre_comercial: form.nombre_comercial,
        direccion: form.direccion,
        telefono: form.telefono,
        email: form.email,
        contacto_principal: form.contacto_principal,
        telefono_contacto: form.telefono_contacto,
        email_contacto: form.email_contacto,
      };

      const nuevaSolicitud: SolicitudCompra = {
        id: editandoId || Date.now(),
        numero_solicitud: editandoId ? 
          solicitudes.find(s => s.id === editandoId)?.numero_solicitud || "" :
          `SC-${new Date().getFullYear()}-${String(solicitudes.length + 1).padStart(3, '0')}`,
        fecha_solicitud: form.fecha_solicitud.split('-').reverse().join('/'),
        fecha_entrega_requerida: form.fecha_entrega_requerida.split('-').reverse().join('/'),
        estado: editandoId ? 
          solicitudes.find(s => s.id === editandoId)?.estado || 'BORRADOR' : 
          'BORRADOR',
        prioridad: form.prioridad as "BAJA" | "NORMAL" | "ALTA" | "URGENTE",
        tipo_solicitud: form.tipo_solicitud as "PRODUCTOS" | "SERVICIOS" | "MIXTA",
        centro_costo: form.centro_costo as "ADM" | "VEN" | "PRO" | "LOG" | "SIS" | "MAN",
        forma_pago_preferida: form.forma_pago_preferida as "CONTADO" | "CREDITO_15" | "CREDITO_30" | "CREDITO_45" | "CREDITO_60" | "CREDITO_90",
        tipo_entrega: form.tipo_entrega as "RETIRO_PROVEEDOR" | "ENTREGA_EMPRESA" | "OBRA_PROYECTO",
        lugar_entrega: form.lugar_entrega,
        info_proveedor: infoProveedor,
        detalles: detallesTemp,
        subtotal_referencial: totales.subtotal,
        descuento_total: totales.descuentoTotal,
        iva: totales.iva,
        total_referencial: totales.total,
        justificacion_compra: form.justificacion_compra,
        observaciones_generales: form.observaciones_generales,
        solicitado_por: form.solicitado_por,
        departamento_solicitante: form.departamento_solicitante,
        fecha_creacion: editandoId ? 
          solicitudes.find(s => s.id === editandoId)?.fecha_creacion || new Date().toISOString() :
          new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString(),
      };

      console.log('💾 Guardando solicitud de compra...', nuevaSolicitud);

      if (editandoId) {
        setSolicitudes((prev) =>
          prev.map((sol) =>
            sol.id === editandoId ? nuevaSolicitud : sol
          )
        );
        alert(`✅ Solicitud ${nuevaSolicitud.numero_solicitud} actualizada exitosamente.`);
      } else {
        setSolicitudes((prev) => [...prev, nuevaSolicitud]);
        alert(`✅ Solicitud ${nuevaSolicitud.numero_solicitud} creada exitosamente.`);
      }

      cerrarModal();

    } catch (error) {
      console.error('Error procesando solicitud de compra:', error);
      alert('Error inesperado al procesar la solicitud de compra');
    } finally {
      setProcesando(false);
    }
  };

  const eliminarSolicitud = (id: number) => {
    const solicitud = solicitudes.find(s => s.id === id);
    if (solicitud && solicitud.estado !== 'BORRADOR') {
      alert("Solo se pueden eliminar solicitudes en estado BORRADOR");
      return;
    }
    
    if (window.confirm("¿Seguro que deseas eliminar esta solicitud de compra?")) {
      setSolicitudes((prev) => prev.filter((sol) => sol.id !== id));
    }
  };

  const cambiarEstado = (id: number, nuevoEstado: string) => {
    setSolicitudes(prev => 
      prev.map(sol => 
        sol.id === id 
          ? { ...sol, estado: nuevoEstado as "BORRADOR" | "ENVIADA" | "EN_NEGOCIACION" | "COTIZADA" | "APROBADA" | "RECHAZADA" | "ORDEN_GENERADA" | "CANCELADA", fecha_actualizacion: new Date().toISOString() }
          : sol
      )
    );
  };

  const solicitudesFiltradas = solicitudes.filter((sol) =>
    Object.values(sol.info_proveedor)
      .concat([sol.numero_solicitud, sol.estado, sol.prioridad, sol.centro_costo])
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'BORRADOR': return 'bg-secondary';
      case 'ENVIADA': return 'bg-primary';
      case 'EN_NEGOCIACION': return 'bg-warning text-dark';
      case 'COTIZADA': return 'bg-info';
      case 'APROBADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'ORDEN_GENERADA': return 'bg-dark';
      case 'CANCELADA': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  const getPrioridadBadgeClass = (prioridad: string) => {
    switch (prioridad) {
      case 'BAJA': return 'bg-secondary';
      case 'NORMAL': return 'bg-primary';
      case 'ALTA': return 'bg-warning text-dark';
      case 'URGENTE': return 'bg-danger';
      default: return 'bg-secondary';
    }
  };

  const totalesCalculados = calcularTotales();

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Solicitudes de Compra</h1>
            <p className="text-muted mb-0">Gestión de solicitudes de compra a proveedores</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-info">Sistema: Activo</span>
            <span className="badge bg-primary text-white">{solicitudes.length} solicitudes</span>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar por proveedor, número, estado, centro de costo..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-primary d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Solicitud de Compra</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Número</th>
                <th>Fecha</th>
                <th>Proveedor</th>
                <th>Centro Costo</th>
                <th>Ítems</th>
                <th>Total Ref.</th>
                <th>Estado</th>
                <th>Prioridad</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {solicitudesFiltradas.length === 0 && (
                <tr>
                  <td colSpan={9} className="text-center py-4">
                    <div className="text-muted">
                      No se encontraron solicitudes de compra
                    </div>
                  </td>
                </tr>
              )}
              {solicitudesFiltradas.map((sol) => (
                <tr key={sol.id}>
                  <td>
                    <strong>{sol.numero_solicitud}</strong>
                    <br />
                    <small className="text-muted">
                      <Calendar size={12} className="me-1" />
                      Entrega: {sol.fecha_entrega_requerida}
                    </small>
                  </td>
                  <td>{sol.fecha_solicitud}</td>
                  <td>
                    <div>
                      <strong>{sol.info_proveedor.razon_social}</strong>
                      {sol.info_proveedor.nombre_comercial && (
                        <div className="small text-muted">{sol.info_proveedor.nombre_comercial}</div>
                      )}
                    </div>
                  </td>
                  <td>
                    <span className="badge bg-light text-dark">{sol.centro_costo}</span>
                  </td>
                  <td>
                    <small className="text-muted">
                      <Package size={14} className="me-1" />
                      {sol.detalles.length} ítem{sol.detalles.length !== 1 ? 's' : ''}
                    </small>
                  </td>
                  <td className="text-end">
                    <strong>${sol.total_referencial.toFixed(2)}</strong>
                    {sol.total_cotizado && (
                      <div className="small text-success">
                        Cotizado: ${sol.total_cotizado.toFixed(2)}
                      </div>
                    )}
                  </td>
                  <td>
                    <div className="dropdown">
                      <span 
                        className={`badge ${getEstadoBadgeClass(sol.estado)} dropdown-toggle`}
                        data-bs-toggle="dropdown"
                        style={{ cursor: 'pointer' }}
                      >
                        {sol.estado.replace('_', ' ')}
                      </span>
                      <ul className="dropdown-menu">
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(sol.id, 'BORRADOR')}>Borrador</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(sol.id, 'ENVIADA')}>Enviada</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(sol.id, 'EN_NEGOCIACION')}>En Negociación</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(sol.id, 'COTIZADA')}>Cotizada</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(sol.id, 'APROBADA')}>Aprobada</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(sol.id, 'RECHAZADA')}>Rechazada</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(sol.id, 'ORDEN_GENERADA')}>Orden Generada</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(sol.id, 'CANCELADA')}>Cancelada</button></li>
                      </ul>
                    </div>
                  </td>
                  <td>
                    <span className={`badge ${getPrioridadBadgeClass(sol.prioridad)}`}>
                      {sol.prioridad}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => abrirModalEditar(sol)}
                        title="Ver detalles"
                      >
                        <Eye size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(sol)}
                        title="Editar"
                        disabled={sol.estado === 'APROBADA' || sol.estado === 'ORDEN_GENERADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarSolicitud(sol.id)}
                        title="Eliminar"
                        disabled={sol.estado !== 'BORRADOR'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal para solicitudes de compra */}
      {showModal && (
        <>
          <div className="modal fade show d-block" style={{ zIndex: 1050 }}>
            <div className="modal-dialog modal-xl">
              <div className="modal-content">
                <form onSubmit={handleSubmit}>
                  <div className="modal-header bg-success text-white">
                    <h5 className="modal-title">
                      <Building className="me-2" size={20} />
                      {editandoId ? "Editar Solicitud de Compra" : "Nueva Solicitud de Compra"}
                    </h5>
                    <button
                      type="button"
                      className="btn-close btn-close-white"
                      onClick={cerrarModal}
                      disabled={procesando}
                    />
                  </div>
                  
                  <div className="modal-body" style={{ maxHeight: '80vh', overflowY: 'auto' }}>
                    <div className="row g-3">
                      {/* Información general */}
                      <div className="col-12">
                        <h6 className="text-success border-bottom pb-2">
                          <FileText className="me-2" size={16} />
                          Información General
                        </h6>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="fecha_solicitud" className="form-label">Fecha Solicitud *</label>
                        <input
                          type="date"
                          className="form-control"
                          id="fecha_solicitud"
                          name="fecha_solicitud"
                          value={form.fecha_solicitud}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="fecha_entrega_requerida" className="form-label">Fecha Entrega Requerida *</label>
                        <input
                          type="date"
                          className="form-control"
                          id="fecha_entrega_requerida"
                          name="fecha_entrega_requerida"
                          value={form.fecha_entrega_requerida}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="prioridad" className="form-label">Prioridad *</label>
                        <select
                          className="form-select"
                          id="prioridad"
                          name="prioridad"
                          value={form.prioridad}
                          onChange={handleChange}
                          required
                        >
                          <option value="BAJA">Baja</option>
                          <option value="NORMAL">Normal</option>
                          <option value="ALTA">Alta</option>
                          <option value="URGENTE">Urgente</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="tipo_solicitud" className="form-label">Tipo *</label>
                        <select
                          className="form-select"
                          id="tipo_solicitud"
                          name="tipo_solicitud"
                          value={form.tipo_solicitud}
                          onChange={handleChange}
                          required
                        >
                          <option value="PRODUCTOS">Solo Productos</option>
                          <option value="SERVICIOS">Solo Servicios</option>
                          <option value="MIXTA">Productos y Servicios</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="centro_costo" className="form-label">Centro de Costo *</label>
                        <select
                          className="form-select"
                          id="centro_costo"
                          name="centro_costo"
                          value={form.centro_costo}
                          onChange={handleChange}
                          required
                        >
                          <option value="ADM">Administración</option>
                          <option value="VEN">Ventas</option>
                          <option value="PRO">Producción</option>
                          <option value="LOG">Logística</option>
                          <option value="SIS">Sistemas</option>
                          <option value="MAN">Mantenimiento</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="forma_pago_preferida" className="form-label">Forma de Pago</label>
                        <select
                          className="form-select"
                          id="forma_pago_preferida"
                          name="forma_pago_preferida"
                          value={form.forma_pago_preferida}
                          onChange={handleChange}
                        >
                          <option value="CONTADO">Contado</option>
                          <option value="CREDITO_15">Crédito 15 días</option>
                          <option value="CREDITO_30">Crédito 30 días</option>
                          <option value="CREDITO_45">Crédito 45 días</option>
                          <option value="CREDITO_60">Crédito 60 días</option>
                          <option value="CREDITO_90">Crédito 90 días</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="tipo_entrega" className="form-label">Tipo de Entrega</label>
                        <select
                          className="form-select"
                          id="tipo_entrega"
                          name="tipo_entrega"
                          value={form.tipo_entrega}
                          onChange={handleChange}
                        >
                          <option value="RETIRO_PROVEEDOR">Retiro en proveedor</option>
                          <option value="ENTREGA_EMPRESA">Entrega en empresa</option>
                          <option value="OBRA_PROYECTO">Entrega en obra/proyecto</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="lugar_entrega" className="form-label">Lugar de Entrega</label>
                        <input
                          type="text"
                          className="form-control"
                          id="lugar_entrega"
                          name="lugar_entrega"
                          value={form.lugar_entrega}
                          onChange={handleChange}
                          placeholder="Especificar ubicación"
                        />
                      </div>

                      {/* Información del proveedor */}
                      <div className="col-12">
                        <h6 className="text-success border-bottom pb-2 mt-3">
                          <Building className="me-2" size={16} />
                          Información del Proveedor
                        </h6>
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="razon_social" className="form-label">Proveedor/Razón Social *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="razon_social"
                          name="razon_social"
                          value={form.razon_social}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="identificacion" className="form-label">RUC/Cédula *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="identificacion"
                          name="identificacion"
                          value={form.identificacion}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="nombre_comercial" className="form-label">Nombre Comercial</label>
                        <input
                          type="text"
                          className="form-control"
                          id="nombre_comercial"
                          name="nombre_comercial"
                          value={form.nombre_comercial}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="email" className="form-label">Email</label>
                        <input
                          type="email"
                          className="form-control"
                          id="email"
                          name="email"
                          value={form.email}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-8">
                        <label htmlFor="direccion" className="form-label">Dirección *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="direccion"
                          name="direccion"
                          value={form.direccion}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-4">
                        <label htmlFor="telefono" className="form-label">Teléfono</label>
                        <input
                          type="text"
                          className="form-control"
                          id="telefono"
                          name="telefono"
                          value={form.telefono}
                          onChange={handleChange}
                        />
                      </div>

                      {/* Contacto del proveedor */}
                      <div className="col-md-4">
                        <label htmlFor="contacto_principal" className="form-label">Contacto Principal</label>
                        <input
                          type="text"
                          className="form-control"
                          id="contacto_principal"
                          name="contacto_principal"
                          value={form.contacto_principal}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-4">
                        <label htmlFor="telefono_contacto" className="form-label">Teléfono Contacto</label>
                        <input
                          type="text"
                          className="form-control"
                          id="telefono_contacto"
                          name="telefono_contacto"
                          value={form.telefono_contacto}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-4">
                        <label htmlFor="email_contacto" className="form-label">Email Contacto</label>
                        <input
                          type="email"
                          className="form-control"
                          id="email_contacto"
                          name="email_contacto"
                          value={form.email_contacto}
                          onChange={handleChange}
                        />
                      </div>

                      {/* Agregar productos/servicios */}
                      <div className="col-12">
                        <h6 className="text-success border-bottom pb-2 mt-3">
                          <Package className="me-2" size={16} />
                          Agregar Producto/Servicio
                        </h6>
                      </div>
                      <div className="col-md-2">
                        <label htmlFor="codigo_producto" className="form-label">Código</label>
                        <input
                          type="text"
                          className="form-control"
                          id="codigo_producto"
                          name="codigo_producto"
                          value={form.codigo_producto}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="descripcion" className="form-label">Descripción *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="descripcion"
                          name="descripcion"
                          value={form.descripcion}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="especificaciones_tecnicas" className="form-label">Especificaciones</label>
                        <input
                          type="text"
                          className="form-control"
                          id="especificaciones_tecnicas"
                          name="especificaciones_tecnicas"
                          value={form.especificaciones_tecnicas}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-1">
                        <label htmlFor="unidad_medida" className="form-label">Unidad</label>
                        <select
                          className="form-select"
                          id="unidad_medida"
                          name="unidad_medida"
                          value={form.unidad_medida}
                          onChange={handleChange}
                        >
                          <option value="UND">UND</option>
                          <option value="KG">KG</option>
                          <option value="LT">LT</option>
                          <option value="MT">MT</option>
                          <option value="M2">M²</option>
                          <option value="M3">M³</option>
                          <option value="SERV">SERV</option>
                          <option value="LIC">LIC</option>
                        </select>
                      </div>
                      <div className="col-md-1">
                        <label htmlFor="cantidad_solicitada" className="form-label">Cant.</label>
                        <input
                          type="number"
                          className="form-control"
                          id="cantidad_solicitada"
                          name="cantidad_solicitada"
                          value={form.cantidad_solicitada}
                          onChange={handleChange}
                          min="1"
                        />
                      </div>
                      <div className="col-md-1">
                        <label htmlFor="precio_referencial" className="form-label">Precio</label>
                        <input
                          type="number"
                          className="form-control"
                          id="precio_referencial"
                          name="precio_referencial"
                          value={form.precio_referencial}
                          onChange={handleChange}
                          min="0"
                          step="0.01"
                        />
                      </div>
                      <div className="col-md-1">
                        <label htmlFor="agregar_producto_compra" className="form-label">Agregar</label>
                        <button
                          type="button"
                          className="btn btn-success w-100"
                          onClick={agregarDetalle}
                          id="agregar_producto_compra"
                        >
                          <Plus size={16} />
                        </button>
                      </div>

                      {/* Lista de productos agregados */}
                      {detallesTemp.length > 0 && (
                        <>
                          <div className="col-12">
                            <h6 className="text-success border-bottom pb-2 mt-3">Productos/Servicios Agregados</h6>
                          </div>
                          <div className="col-12">
                            <div className="table-responsive">
                              <table className="table table-sm">
                                <thead className="table-light">
                                  <tr>
                                    <th>Código</th>
                                    <th>Descripción</th>
                                    <th>Especificaciones</th>
                                    <th>Unidad</th>
                                    <th>Cantidad</th>
                                    <th>Precio Ref.</th>
                                    <th>Subtotal</th>
                                    <th>Acción</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {detallesTemp.map((detalle) => (
                                    <tr key={detalle.id}>
                                      <td>{detalle.codigo_producto}</td>
                                      <td>{detalle.descripcion}</td>
                                      <td className="small">{detalle.especificaciones_tecnicas}</td>
                                      <td>{detalle.unidad_medida}</td>
                                      <td>{detalle.cantidad_solicitada}</td>
                                      <td>${(detalle.precio_referencial || 0).toFixed(2)}</td>
                                      <td>${detalle.subtotal_referencial.toFixed(2)}</td>
                                      <td>
                                        <button
                                          type="button"
                                          className="btn btn-outline-danger btn-sm"
                                          onClick={() => eliminarDetalle(detalle.id)}
                                        >
                                          <Minus size={14} />
                                        </button>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                                <tfoot className="table-light">
                                  <tr>
                                    <td colSpan={6} className="text-end fw-bold">Total Referencial:</td>
                                    <td className="fw-bold">${totalesCalculados.total.toFixed(2)}</td>
                                    <td></td>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>
                          </div>
                        </>
                      )}

                      {/* Justificación y observaciones */}
                      <div className="col-12">
                        <h6 className="text-success border-bottom pb-2 mt-3">Información Adicional</h6>
                      </div>
                      <div className="col-12">
                        <label htmlFor="justificacion_compra" className="form-label">Justificación de la Compra *</label>
                        <textarea
                          className="form-control"
                          id="justificacion_compra"
                          name="justificacion_compra"
                          rows={3}
                          value={form.justificacion_compra}
                          onChange={handleChange}
                          required
                          placeholder="Explique la necesidad y justificación para esta compra..."
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="solicitado_por" className="form-label">Solicitado por</label>
                        <input
                          type="text"
                          className="form-control"
                          id="solicitado_por"
                          name="solicitado_por"
                          value={form.solicitado_por}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="departamento_solicitante" className="form-label">Departamento</label>
                        <input
                          type="text"
                          className="form-control"
                          id="departamento_solicitante"
                          name="departamento_solicitante"
                          value={form.departamento_solicitante}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-12">
                        <label htmlFor="observaciones_generales" className="form-label">Observaciones Generales</label>
                        <textarea
                          className="form-control"
                          id="observaciones_generales"
                          name="observaciones_generales"
                          rows={2}
                          value={form.observaciones_generales}
                          onChange={handleChange}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={cerrarModal}
                      disabled={procesando}
                    >
                      Cancelar
                    </button>
                    <button 
                      type="submit" 
                      className="btn btn-success"
                      disabled={procesando}
                    >
                      {(() => {
                        if (procesando) return 'Guardando...';
                        if (editandoId) return 'Actualizar Solicitud';
                        return 'Crear Solicitud';
                      })()}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div className="modal-backdrop fade show"></div>
        </>
        )}
    </div>
  );
}
