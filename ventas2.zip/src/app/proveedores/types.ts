export interface Proveedor {
  id: number;
  razonSocial: string;
  ruc: string;
  contacto: string;
  email: string;
  telefono: string;
  ciudad: string;
  direccion: string;
  estado: "Activo" | "Inactivo";
}

export type ProveedorFormValues = Omit<Proveedor, "id">;
