"use client";

import { FormEvent, useState } from "react";
import { CirclePlus, SquarePen, Trash2 } from "lucide-react";

import type { Proveedor, ProveedorFormValues } from "./types";
import "../documentos-electronicos-base.css";

const initialForm: ProveedorFormValues = {
  razonSocial: "",
  ruc: "",
  contacto: "",
  email: "",
  telefono: "",
  ciudad: "",
  direccion: "",
  estado: "Activo",
};

const initialProveedores: Proveedor[] = [
  {
    id: 1,
    razonSocial: "Distribuidora Andina S.A.",
    ruc: "1790012345001",
    contacto: "María Torres",
    email: "ventas@distribuidoraandina.ec",
    telefono: "02 245 6789",
    ciudad: "Quito",
    direccion: "Av. Amazonas N34-120",
    estado: "Activo",
  },
  {
    id: 2,
    razonSocial: "Suministros del Pacífico Cía. Ltda.",
    ruc: "0991234567001",
    contacto: "Carlos Vera",
    email: "pedidos@suministrospacifico.ec",
    telefono: "04 256 7890",
    ciudad: "Guayaquil",
    direccion: "Av. Juan Tanca Marengo km 3",
    estado: "Activo",
  },
];

export default function ProveedoresPage() {
  const [proveedores, setProveedores] = useState(initialProveedores);
  const [filtro, setFiltro] = useState("");
  const [modalAbierto, setModalAbierto] = useState(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ProveedorFormValues>(initialForm);

  const proveedoresFiltrados = proveedores.filter((proveedor) =>
    Object.values(proveedor).join(" ").toLowerCase().includes(filtro.toLowerCase()),
  );

  const abrirNuevo = () => {
    setEditandoId(null);
    setForm(initialForm);
    setModalAbierto(true);
  };

  const abrirEdicion = (proveedor: Proveedor) => {
    const { id, ...values } = proveedor;
    setEditandoId(id);
    setForm(values);
    setModalAbierto(true);
  };

  const cerrarModal = () => {
    setModalAbierto(false);
    setEditandoId(null);
    setForm(initialForm);
  };

  const actualizarCampo = <K extends keyof ProveedorFormValues>(
    campo: K,
    valor: ProveedorFormValues[K],
  ) => setForm((actual) => ({ ...actual, [campo]: valor }));

  const guardarProveedor = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (editandoId !== null) {
      setProveedores((actuales) =>
        actuales.map((proveedor) =>
          proveedor.id === editandoId ? { id: editandoId, ...form } : proveedor,
        ),
      );
    } else {
      setProveedores((actuales) => [...actuales, { id: Date.now(), ...form }]);
    }

    cerrarModal();
  };

  const eliminarProveedor = (proveedor: Proveedor) => {
    if (window.confirm(`¿Eliminar al proveedor ${proveedor.razonSocial}?`)) {
      setProveedores((actuales) => actuales.filter(({ id }) => id !== proveedor.id));
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">Proveedores</h1>
        <p className="text-muted mb-0">Administración de proveedores y datos de contacto</p>
        <br />

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            value={filtro}
            onChange={(event) => setFiltro(event.target.value)}
            placeholder="Buscar proveedor..."
          />
          <button type="button" onClick={abrirNuevo} className="btn btn-primary d-flex align-items-center">
            <CirclePlus className="me-2" size={16} />
            <span>Añadir Proveedor</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Razón Social</th>
                <th>RUC</th>
                <th>Contacto</th>
                <th>Ciudad</th>
                <th>Teléfono</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {proveedoresFiltrados.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center">No se encontraron proveedores</td>
                </tr>
              )}
              {proveedoresFiltrados.map((proveedor) => (
                <tr key={proveedor.id}>
                  <td>
                    <strong>{proveedor.razonSocial}</strong>
                    <br />
                    <small className="text-muted">{proveedor.email}</small>
                  </td>
                  <td>{proveedor.ruc}</td>
                  <td>{proveedor.contacto}</td>
                  <td>{proveedor.ciudad}</td>
                  <td>{proveedor.telefono}</td>
                  <td>
                    <span className={`badge ${proveedor.estado === "Activo" ? "bg-success" : "bg-secondary"}`}>
                      {proveedor.estado}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex align-items-center">
                      <button type="button" onClick={() => abrirEdicion(proveedor)} className="btn btn-warning d-flex align-items-center me-1">
                        <SquarePen className="me-2" size={16} />
                        <span>Editar</span>
                      </button>
                      <button type="button" onClick={() => eliminarProveedor(proveedor)} className="btn btn-danger d-flex align-items-center">
                        <Trash2 className="me-2" size={16} />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modalAbierto && (
        <div className="modal-overlay" onClick={(event) => event.target === event.currentTarget && cerrarModal()}>
          <div className="modal-container" style={{ maxWidth: "800px" }} role="dialog" aria-modal="true" aria-labelledby="proveedor-modal-title">
            <form onSubmit={guardarProveedor}>
              <div className="modal-header bg-dark text-white">
                <h5 id="proveedor-modal-title" className="modal-title">
                  {editandoId === null ? "Nuevo Proveedor" : "Editar Proveedor"}
                </h5>
                <button type="button" className="btn-close btn-close-white" onClick={cerrarModal} aria-label="Cerrar" />
              </div>

              <div className="modal-body" style={{ maxHeight: "70vh", overflowY: "auto" }}>
                <p className="text-muted mb-3">Los campos marcados con * son obligatorios</p>
                <div className="row g-3">
                  <div className="col-12">
                    <label htmlFor="razonSocial" className="form-label">Razón Social *</label>
                    <input id="razonSocial" required value={form.razonSocial} onChange={(event) => actualizarCampo("razonSocial", event.target.value)} className="form-control" />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="ruc" className="form-label">RUC *</label>
                    <input id="ruc" required inputMode="numeric" maxLength={13} value={form.ruc} onChange={(event) => actualizarCampo("ruc", event.target.value)} className="form-control" />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="contacto" className="form-label">Persona de Contacto *</label>
                    <input id="contacto" required value={form.contacto} onChange={(event) => actualizarCampo("contacto", event.target.value)} className="form-control" />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="email" className="form-label">Correo Electrónico *</label>
                    <input id="email" required type="email" value={form.email} onChange={(event) => actualizarCampo("email", event.target.value)} className="form-control" />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="telefono" className="form-label">Teléfono *</label>
                    <input id="telefono" required value={form.telefono} onChange={(event) => actualizarCampo("telefono", event.target.value)} className="form-control" />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="ciudad" className="form-label">Ciudad *</label>
                    <input id="ciudad" required value={form.ciudad} onChange={(event) => actualizarCampo("ciudad", event.target.value)} className="form-control" />
                  </div>
                  <div className="col-md-6">
                    <label htmlFor="estado" className="form-label">Estado</label>
                    <select id="estado" value={form.estado} onChange={(event) => actualizarCampo("estado", event.target.value as ProveedorFormValues["estado"])} className="form-select">
                      <option value="Activo">Activo</option>
                      <option value="Inactivo">Inactivo</option>
                    </select>
                  </div>
                  <div className="col-12">
                    <label htmlFor="direccion" className="form-label">Dirección *</label>
                    <textarea id="direccion" required rows={3} value={form.direccion} onChange={(event) => actualizarCampo("direccion", event.target.value)} className="form-control" />
                  </div>
                </div>
              </div>

              <div className="modal-footer">
                <button type="button" onClick={cerrarModal} className="btn btn-secondary">Cancelar</button>
                <button type="submit" className="btn btn-success">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
