import { AppShell } from "@/components/app-shell";

import ProveedoresPage from "./ProveedoresPage";

export default function Page() {
  return (
    <AppShell>
      <ProveedoresPage />
    </AppShell>
  );
}
