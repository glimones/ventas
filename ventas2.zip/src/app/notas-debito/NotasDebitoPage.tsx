"use client";

import React, { useState } from "react";
import { NotaDebito, NotaDebitoFormValues, InfoNotaDebito } from "./types";
import { SRIUniversalService } from "../../services/sri-universal.service";
import "./notas-debito.css";
import { CirclePlus, SquarePen, Trash2, Eye, Download } from 'lucide-react';

const initialForm: NotaDebitoFormValues = {
  ambiente: "1",
  razon_social: "EMPRESA DEMO S.A.",
  nombre_comercial: "Demo",
  ruc: "1234567890001",
  estab: "001",
  ptoEmi: "001",
  secuencial: "1",
  direccion_matriz: "Av. Principal 123, Ciudad Demo",
  fecha_emision: new Date().toISOString().split('T')[0],
  direccion_establecimiento: "Av. Principal 123, Ciudad Demo",
  tipo_identificacion_sujeto_retenido: "",
  razon_social_sujeto_retenido: "",
  identificacion_sujeto_retenido: "",
  contribuyente_especial: "",
  obligado_contabilidad: "SI",
  rise: "",
  cod_doc_modificado: "",
  num_doc_modificado: "",
  fecha_emision_doc_modificado: "",
  valor_modificacion: 0,
  moneda: "DOLAR",
  motivo: "",
};

const initialNotasDebito: NotaDebito[] = [
  {
    id: 1,
    info_tributaria: {
      ambiente: "1",
      tipo_emision: "1",
      razon_social: "EMPRESA DEMO S.A.",
      nombre_comercial: "Demo",
      ruc: "1234567890001",
      clave_acceso: "2309202405123456789000110010010000000011234567895",
      cod_doc: "05",
      estab: "001",
      ptoEmi: "001",
      secuencial: "000000001",
      direccion_matriz: "Av. Principal 123, Ciudad Demo"
    },
    info_nota_debito: {
      fecha_emision: "23/09/2024",
      direccion_establecimiento: "Av. Principal 123, Ciudad Demo",
      tipo_identificacion_sujeto_retenido: "05",
      razon_social_sujeto_retenido: "CLIENTE DEMO",
      identificacion_sujeto_retenido: "1234567890",
      contribuyente_especial: "",
      obligado_contabilidad: "SI",
      rise: "",
      cod_doc_modificado: "01",
      num_doc_modificado: "001-001-000000001",
      fecha_emision_doc_modificado: "20/09/2024",
      total_sin_impuestos: 25.00,
      valor_total: 28.00,
      valor_modificacion: 28.00,
      moneda: "DOLAR",
      motivo: "Intereses por mora"
    },
    estado_sri: 'AUTORIZADA',
    numero_autorizacion: "2309202412345678901234567890123456",
    fecha_autorizacion: "2024-09-23T10:30:00.000Z",
    fecha_creacion: "2024-09-23T10:00:00.000Z",
    fecha_actualizacion: "2024-09-23T10:30:00.000Z"
  }
];

export default function NotasDebitoPage() {
  const [notasDebito, setNotasDebito] = useState<NotaDebito[]>(initialNotasDebito);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<NotaDebitoFormValues>(initialForm);
  const [enviandoSRI, setEnviandoSRI] = useState<boolean>(false);

  const sriService = SRIUniversalService.getInstance();

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    const ultimoSecuencial = Math.max(...notasDebito.map(nd => parseInt(nd.info_tributaria.secuencial) || 0), 0);
    setForm(prev => ({
      ...prev,
      secuencial: (ultimoSecuencial + 1).toString()
    }));
    setShowModal(true);
  };

  const abrirModalEditar = (notaDebito: NotaDebito) => {
    setForm({
      ambiente: notaDebito.info_tributaria.ambiente,
      razon_social: notaDebito.info_tributaria.razon_social,
      nombre_comercial: notaDebito.info_tributaria.nombre_comercial,
      ruc: notaDebito.info_tributaria.ruc,
      estab: notaDebito.info_tributaria.estab,
      ptoEmi: notaDebito.info_tributaria.ptoEmi,
      secuencial: notaDebito.info_tributaria.secuencial,
      direccion_matriz: notaDebito.info_tributaria.direccion_matriz,
      fecha_emision: notaDebito.info_nota_debito.fecha_emision.split('/').reverse().join('-'),
      direccion_establecimiento: notaDebito.info_nota_debito.direccion_establecimiento,
      tipo_identificacion_sujeto_retenido: notaDebito.info_nota_debito.tipo_identificacion_sujeto_retenido,
      razon_social_sujeto_retenido: notaDebito.info_nota_debito.razon_social_sujeto_retenido,
      identificacion_sujeto_retenido: notaDebito.info_nota_debito.identificacion_sujeto_retenido,
      contribuyente_especial: notaDebito.info_nota_debito.contribuyente_especial || "",
      obligado_contabilidad: notaDebito.info_nota_debito.obligado_contabilidad,
      rise: notaDebito.info_nota_debito.rise || "",
      cod_doc_modificado: notaDebito.info_nota_debito.cod_doc_modificado,
      num_doc_modificado: notaDebito.info_nota_debito.num_doc_modificado,
      fecha_emision_doc_modificado: notaDebito.info_nota_debito.fecha_emision_doc_modificado.split('/').reverse().join('-'),
      valor_modificacion: notaDebito.info_nota_debito.valor_modificacion,
      moneda: notaDebito.info_nota_debito.moneda,
      motivo: notaDebito.info_nota_debito.motivo,
    });
    
    setEditandoId(notaDebito.id);
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setEnviandoSRI(true);
    
    try {
      const infoNotaDebito: InfoNotaDebito = {
        fecha_emision: form.fecha_emision.split('-').reverse().join('/'),
        direccion_establecimiento: form.direccion_establecimiento,
        tipo_identificacion_sujeto_retenido: form.tipo_identificacion_sujeto_retenido,
        razon_social_sujeto_retenido: form.razon_social_sujeto_retenido,
        identificacion_sujeto_retenido: form.identificacion_sujeto_retenido,
        contribuyente_especial: form.contribuyente_especial,
        obligado_contabilidad: form.obligado_contabilidad,
        rise: form.rise,
        cod_doc_modificado: form.cod_doc_modificado,
        num_doc_modificado: form.num_doc_modificado,
        fecha_emision_doc_modificado: form.fecha_emision_doc_modificado.split('-').reverse().join('/'),
        total_sin_impuestos: form.valor_modificacion / 1.12, // Asumiendo 12% IVA
        valor_total: form.valor_modificacion,
        valor_modificacion: form.valor_modificacion,
        moneda: form.moneda,
        motivo: form.motivo,
      };

      const nuevaNotaDebito: NotaDebito = {
        id: editandoId || Date.now(),
        info_tributaria: {
          ambiente: form.ambiente,
          tipo_emision: "1",
          razon_social: form.razon_social,
          nombre_comercial: form.nombre_comercial,
          ruc: form.ruc,
          clave_acceso: "",
          cod_doc: "05",
          estab: form.estab,
          ptoEmi: form.ptoEmi,
          secuencial: form.secuencial,
          direccion_matriz: form.direccion_matriz,
        },
        info_nota_debito: infoNotaDebito,
        estado_sri: 'PENDIENTE',
        fecha_creacion: new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString()
      };

      const comprobanteParaSRI = {
        id: nuevaNotaDebito.id,
        tipo_comprobante: '05' as const,
        info_tributaria: nuevaNotaDebito.info_tributaria,
        estado_sri: nuevaNotaDebito.estado_sri,
        fecha_creacion: nuevaNotaDebito.fecha_creacion,
        fecha_actualizacion: nuevaNotaDebito.fecha_actualizacion
      };

      const datosEspecificos = `
  <infoNotaDebito>
    <fechaEmision>${infoNotaDebito.fecha_emision}</fechaEmision>
    <dirEstablecimiento><![CDATA[${infoNotaDebito.direccion_establecimiento}]]></dirEstablecimiento>
    <tipoIdentificacionSujetoRetenido>${infoNotaDebito.tipo_identificacion_sujeto_retenido}</tipoIdentificacionSujetoRetenido>
    <razonSocialSujetoRetenido><![CDATA[${infoNotaDebito.razon_social_sujeto_retenido}]]></razonSocialSujetoRetenido>
    <identificacionSujetoRetenido>${infoNotaDebito.identificacion_sujeto_retenido}</identificacionSujetoRetenido>
    <obligadoContabilidad>${infoNotaDebito.obligado_contabilidad}</obligadoContabilidad>
    <codDocModificado>${infoNotaDebito.cod_doc_modificado}</codDocModificado>
    <numDocModificado>${infoNotaDebito.num_doc_modificado}</numDocModificado>
    <fechaEmisionDocSustento>${infoNotaDebito.fecha_emision_doc_modificado}</fechaEmisionDocSustento>
    <totalSinImpuestos>${infoNotaDebito.total_sin_impuestos.toFixed(2)}</totalSinImpuestos>
    <valorTotal>${infoNotaDebito.valor_total.toFixed(2)}</valorTotal>
    <valorModificacion>${infoNotaDebito.valor_modificacion.toFixed(2)}</valorModificacion>
    <moneda>${infoNotaDebito.moneda}</moneda>
    <motivo><![CDATA[${infoNotaDebito.motivo}]]></motivo>
  </infoNotaDebito>`;

      console.log('🚀 Enviando nota de débito al SRI...', nuevaNotaDebito);
      const respuestaSRI = await sriService.enviarComprobanteSRI(comprobanteParaSRI, datosEspecificos, infoNotaDebito.fecha_emision);

      nuevaNotaDebito.estado_sri = respuestaSRI.estado;
      if (respuestaSRI.success) {
        nuevaNotaDebito.numero_autorizacion = respuestaSRI.numero_autorizacion;
        nuevaNotaDebito.fecha_autorizacion = respuestaSRI.fecha_autorizacion;
        nuevaNotaDebito.xml_generado = respuestaSRI.xml_autorizado;
      }
      nuevaNotaDebito.observaciones_sri = respuestaSRI.observaciones;

      if (editandoId) {
        setNotasDebito((prev) =>
          prev.map((nota) =>
            nota.id === editandoId ? nuevaNotaDebito : nota
          )
        );
      } else {
        setNotasDebito((prev) => [...prev, nuevaNotaDebito]);
      }

      if (respuestaSRI.success) {
        alert(`✅ Nota de Débito ${respuestaSRI.estado.toLowerCase()} exitosamente.\nNúmero de autorización: ${respuestaSRI.numero_autorizacion}`);
        cerrarModal();
      } else {
        alert(`❌ Error del SRI: ${respuestaSRI.mensaje_error}\n\nObservaciones: ${respuestaSRI.observaciones}`);
      }

    } catch (error) {
      console.error('Error procesando nota de débito:', error);
      alert('Error inesperado al procesar la nota de débito');
    } finally {
      setEnviandoSRI(false);
    }
  };

  const eliminarNotaDebito = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta nota de débito?")) {
      setNotasDebito((prev) => prev.filter((nota) => nota.id !== id));
    }
  };

  const notasDebitoFiltradas = notasDebito.filter((nota) =>
    Object.values(nota.info_nota_debito)
      .concat(Object.values(nota.info_tributaria))
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'AUTORIZADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'DEVUELTA': return 'bg-warning text-dark';
      case 'PENDIENTE': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Notas de Débito Electrónicas</h1>
            <p className="text-muted mb-0">Gestión de notas de débito SRI Ecuador</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-info">Ambiente: Pruebas</span>
            <span className="badge bg-warning text-dark">{notasDebito.length} notas</span>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar por cliente, RUC, secuencial..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-warning d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Nota de Débito</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Secuencial</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Doc. Modificado</th>
                <th>Motivo</th>
                <th>Valor</th>
                <th>Estado SRI</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {notasDebitoFiltradas.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-4">
                    <div className="text-muted">
                      No se encontraron notas de débito
                    </div>
                  </td>
                </tr>
              )}
              {notasDebitoFiltradas.map((nota) => (
                <tr key={nota.id}>
                  <td>
                    <strong>{nota.info_tributaria.estab}-{nota.info_tributaria.ptoEmi}-{nota.info_tributaria.secuencial.padStart(9, '0')}</strong>
                  </td>
                  <td>{nota.info_nota_debito.fecha_emision}</td>
                  <td>{nota.info_nota_debito.razon_social_sujeto_retenido}</td>
                  <td>
                    <small className="text-muted">
                      {nota.info_nota_debito.cod_doc_modificado === '01' ? 'Factura' : 'Liquidación'}: {nota.info_nota_debito.num_doc_modificado}
                    </small>
                  </td>
                  <td>
                    <small title={nota.info_nota_debito.motivo}>
                      {nota.info_nota_debito.motivo.substring(0, 20)}
                      {nota.info_nota_debito.motivo.length > 20 ? '...' : ''}
                    </small>
                  </td>
                  <td className="text-end">
                    <strong>${nota.info_nota_debito.valor_modificacion.toFixed(2)}</strong>
                  </td>
                  <td>
                    <span className={`badge ${getEstadoBadgeClass(nota.estado_sri)}`}>
                      {nota.estado_sri}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => abrirModalEditar(nota)}
                        title="Ver detalles"
                      >
                        <Eye size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(nota)}
                        title="Editar"
                        disabled={nota.estado_sri === 'AUTORIZADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      {nota.xml_generado && (
                        <button
                          className="btn btn-outline-success btn-sm"
                          title="Descargar XML"
                          onClick={() => {
                            const blob = new Blob([nota.xml_generado!], { type: 'application/xml' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `nota_debito_${nota.info_tributaria.secuencial}.xml`;
                            a.click();
                          }}
                        >
                          <Download size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarNotaDebito(nota.id)}
                        title="Eliminar"
                        disabled={nota.estado_sri === 'AUTORIZADA'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal simple para notas de débito */}
      {showModal && (
        <>
          <div className="modal-backdrop fade show"></div>
          <div className="modal fade show d-block" style={{ zIndex: 1050 }}>
          <div className="modal-dialog modal-lg">
            <div className="modal-content">
              <form onSubmit={handleSubmit}>
                <div className="modal-header bg-warning text-dark">
                  <h5 className="modal-title">
                    {editandoId ? "Editar Nota de Débito" : "Nueva Nota de Débito"}
                  </h5>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={cerrarModal}
                    disabled={enviandoSRI}
                  />
                </div>
                
                <div className="modal-body" style={{ maxHeight: '70vh', overflowY: 'auto' }}>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label htmlFor="razon_social_sujeto_retenido" className="form-label">Cliente *</label>
                      <input
                        type="text"
                        className="form-control"
                        id="razon_social_sujeto_retenido"
                        name="razon_social_sujeto_retenido"
                        value={form.razon_social_sujeto_retenido}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="identificacion_sujeto_retenido" className="form-label">RUC/Cédula *</label>
                      <input
                        type="text"
                        className="form-control"
                        id="identificacion_sujeto_retenido"
                        name="identificacion_sujeto_retenido"
                        value={form.identificacion_sujeto_retenido}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="num_doc_modificado" className="form-label">Documento Modificado *</label>
                      <input
                        type="text"
                        className="form-control"
                        id="num_doc_modificado"
                        name="num_doc_modificado"
                        value={form.num_doc_modificado}
                        onChange={handleChange}
                        placeholder="001-001-000000001"
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="fecha_emision_doc_modificado" className="form-label">Fecha Documento *</label>
                      <input
                        type="date"
                        className="form-control"
                        id="fecha_emision_doc_modificado"
                        name="fecha_emision_doc_modificado"
                        value={form.fecha_emision_doc_modificado}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="valor_modificacion" className="form-label">Valor de Modificación *</label>
                      <input
                        type="number"
                        className="form-control"
                        id="valor_modificacion"
                        name="valor_modificacion"
                        value={form.valor_modificacion}
                        onChange={handleChange}
                        min="0"
                        step="0.01"
                        required
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="motivo" className="form-label">Motivo *</label>
                      <select
                        className="form-select"
                        id="motivo"
                        name="motivo"
                        value={form.motivo}
                        onChange={handleChange}
                        required
                      >
                        <option value="">Seleccione...</option>
                        <option value="Intereses por mora">Intereses por mora</option>
                        <option value="Gastos de cobranza">Gastos de cobranza</option>
                        <option value="Diferencia de precio">Diferencia de precio</option>
                        <option value="Otros">Otros</option>
                      </select>
                    </div>
                  </div>
                </div>
                
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={cerrarModal}
                    disabled={enviandoSRI}
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit" 
                    className="btn btn-warning"
                    disabled={enviandoSRI}
                  >
                    {enviandoSRI ? 'Enviando...' : 'Crear y Enviar al SRI'}
                  </button>
                </div>
              </form>
            </div>
          </div>
          </div>
        </>
      )}
    </div>
  );
}
