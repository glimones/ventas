ALTER TABLE categorias_productos
DROP COLUMN IF EXISTS categoria_padre_id;
