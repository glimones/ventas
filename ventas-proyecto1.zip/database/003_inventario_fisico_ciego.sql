ALTER TABLE inventarios_fisicos
    ADD COLUMN IF NOT EXISTS responsable_nombre VARCHAR(160),
    ADD COLUMN IF NOT EXISTS aprobado_por_nombre VARCHAR(160),
    ADD COLUMN IF NOT EXISTS aplicado_en TIMESTAMPTZ;

ALTER TABLE inventarios_fisicos
    ALTER COLUMN estado SET DEFAULT 'EN_CONTEO';

ALTER TABLE inventarios_fisicos_detalle
    ALTER COLUMN cantidad_contada DROP NOT NULL,
    ALTER COLUMN cantidad_contada DROP DEFAULT;
