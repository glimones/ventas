BEGIN;

SET LOCAL search_path TO sistema_ventas, public;

ALTER TABLE empresas
    ADD COLUMN IF NOT EXISTS sitio_web_habilitado BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS titulo_web VARCHAR(200),
    ADD COLUMN IF NOT EXISTS imagen_portada_url TEXT,
    ADD COLUMN IF NOT EXISTS contenido_sitio JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE productos
    ADD COLUMN IF NOT EXISTS imagenes_urls JSONB NOT NULL DEFAULT '[]'::jsonb;

UPDATE productos
SET imagenes_urls = CASE
    WHEN imagen_url IS NOT NULL AND btrim(imagen_url) <> '' THEN jsonb_build_array(imagen_url)
    ELSE '[]'::jsonb
END
WHERE jsonb_array_length(COALESCE(imagenes_urls, '[]'::jsonb)) = 0;

ALTER TABLE empresas
    ALTER COLUMN slug DROP NOT NULL;

UPDATE empresas
SET sitio_web_habilitado = FALSE
WHERE sitio_web_habilitado IS NULL;

UPDATE empresas
SET sitio_web_habilitado = TRUE
WHERE sitio_web_habilitado = FALSE
  AND slug IS NOT NULL
  AND btrim(slug) <> ''
  AND NULLIF(btrim(contenido_sitio::text), '') IS NOT NULL
  AND contenido_sitio::text <> '{}';

COMMIT;
