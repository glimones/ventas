ALTER TABLE clientes
ADD COLUMN IF NOT EXISTS tipo_cliente VARCHAR(80);

CREATE INDEX IF NOT EXISTS idx_clientes_grupo
ON clientes (empresa_id, grupo);

CREATE INDEX IF NOT EXISTS idx_clientes_tipo_cliente
ON clientes (empresa_id, tipo_cliente);
