"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  ChevronsUpDown,
  CirclePlus,
  Search,
  SquarePen,
  Trash2,
  X,
} from "lucide-react";

export interface TreasuryField {
  name: string;
  label: string;
  type?: string;
  required?: boolean;
}

type TreasuryRow = Record<string, unknown> & { id: number };
type TreasuryForm = Record<string, unknown>;
type SortDirection = "ascending" | "descending";

type TreasuryModalProps = {
  show: boolean;
  editando: boolean;
  values: TreasuryForm;
  onChange: (
    event: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => void;
  onClose: () => void;
  onSubmit: (event: React.FormEvent) => void;
  saving: boolean;
  formError: string;
};

interface Props {
  title: string;
  searchPlaceholder: string;
  fields: TreasuryField[];
  initialForm: TreasuryForm;
  initialData: TreasuryRow[];
  Modal: React.ElementType;
  css: string;
}

const normalizeSearch = (value: unknown) =>
  String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("es");

export default function TreasuryCrudPage({
  title,
  searchPlaceholder,
  fields,
  initialForm,
  Modal,
}: Props) {
  const pathname = usePathname();
  const [data, setData] = useState<TreasuryRow[]>([]);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] =
    useState<SortDirection>("ascending");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [show, setShow] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<TreasuryForm>(initialForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");
  const [notice, setNotice] = useState("");
  const [writable, setWritable] = useState(false);
  const savingRef = useRef(false);
  const formBaselineRef = useRef<TreasuryForm>(initialForm);

  const loadRows = useCallback(async () => {
    setLoading(true);
    setWritable(false);
    try {
      const response = await fetch(`/api${pathname}`, { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "No se pudieron cargar los registros.");
      }
      setData(result.data as TreasuryRow[]);
      setWritable(
        Boolean(
          result.capabilities?.create &&
            result.capabilities?.update &&
            result.capabilities?.delete,
        ),
      );
      setError("");
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : "Error al cargar los registros.",
      );
    } finally {
      setLoading(false);
    }
  }, [pathname]);

  useEffect(() => {
    void loadRows();
  }, [loadRows]);

  const close = (force = false) => {
    if (savingRef.current && !force) return;
    const hasUnsavedChanges =
      JSON.stringify(form) !== JSON.stringify(formBaselineRef.current);
    if (
      !force &&
      hasUnsavedChanges &&
      !window.confirm("Hay cambios sin guardar. ¿Deseas descartarlos?")
    ) {
      return;
    }
    setShow(false);
    setEditId(null);
    setForm(initialForm);
    formBaselineRef.current = initialForm;
    setFormError("");
  };

  const openNew = () => {
    const newForm = { ...initialForm };
    formBaselineRef.current = newForm;
    setForm(newForm);
    setError("");
    setFormError("");
    setNotice("");
    setEditId(null);
    setShow(true);
  };

  const edit = (item: TreasuryRow) => {
    const editForm = { ...item };
    formBaselineRef.current = editForm;
    setError("");
    setFormError("");
    setNotice("");
    setEditId(item.id);
    setForm(editForm);
    setShow(true);
  };

  const change = (
    event: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => {
    const { name, type, value } = event.target;
    setForm((previous) => ({
      ...previous,
      [name]: type === "number" && value !== "" ? Number(value) : value,
    }));
    setFormError("");
  };

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    if (savingRef.current) return;

    savingRef.current = true;
    setSaving(true);
    setFormError("");
    setError("");
    setNotice("");
    try {
      const response = await fetch(
        editId === null
          ? `/api${pathname}`
          : `/api${pathname}/${editId}`,
        {
          method: editId === null ? "POST" : "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form),
        },
      );
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "No se pudo guardar el registro.");
      }
      await loadRows();
      close(true);
      setNotice(editId === null ? "Registro creado correctamente." : "Cambios guardados correctamente.");
    } catch (saveError) {
      setFormError(
        saveError instanceof Error
          ? saveError.message
          : "Error al guardar el registro.",
      );
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  };

  const remove = async (id: number) => {
    if (!window.confirm("¿Deseas desactivar este registro?")) return;
    setError("");
    setNotice("");
    try {
      const response = await fetch(`/api${pathname}/${id}`, {
        method: "DELETE",
      });
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || "No se pudo desactivar el registro.");
      }
      await loadRows();
      setNotice("Registro desactivado correctamente.");
    } catch (deleteError) {
      setError(
        deleteError instanceof Error
          ? deleteError.message
          : "Error al desactivar el registro.",
      );
    }
  };

  const availableStatuses = Array.from(
    new Set(
      data
        .map((item) => String(item.estado ?? "").trim())
        .filter(Boolean),
    ),
  ).sort((left, right) => left.localeCompare(right, "es"));
  const hasStatusFilter = availableStatuses.length > 1;
  const filteredRows = data.filter((item) => {
    const matchesQuery = Object.values(item).some((value) =>
      normalizeSearch(value).includes(normalizeSearch(query)),
    );
    const matchesStatus =
      statusFilter === "all" || String(item.estado ?? "") === statusFilter;
    return matchesQuery && matchesStatus;
  });
  const sortedRows =
    sortField === null
      ? filteredRows
      : [...filteredRows].sort((left, right) => {
          const leftValue = left[sortField];
          const rightValue = right[sortField];
          const comparison =
            typeof leftValue === "number" && typeof rightValue === "number"
              ? leftValue - rightValue
              : String(leftValue ?? "").localeCompare(
                  String(rightValue ?? ""),
                  "es",
                  { numeric: true, sensitivity: "base" },
                );
          return sortDirection === "ascending" ? comparison : -comparison;
        });
  const pageCount = Math.max(1, Math.ceil(sortedRows.length / rowsPerPage));
  const currentPage = Math.min(page, pageCount - 1);
  const visibleRows = sortedRows.slice(
    currentPage * rowsPerPage,
    (currentPage + 1) * rowsPerPage,
  );
  const firstVisible = sortedRows.length === 0 ? 0 : currentPage * rowsPerPage + 1;
  const lastVisible = Math.min((currentPage + 1) * rowsPerPage, sortedRows.length);

  useEffect(() => {
    if (page !== currentPage) setPage(currentPage);
  }, [currentPage, page]);

  const toggleSort = (fieldName: string) => {
    if (sortField === fieldName) {
      setSortDirection((current) =>
        current === "ascending" ? "descending" : "ascending",
      );
    } else {
      setSortField(fieldName);
      setSortDirection("ascending");
    }
  };

  const clearFilters = () => {
    setQuery("");
    setStatusFilter("all");
    setPage(0);
  };
  const TypedModal = Modal as React.ComponentType<TreasuryModalProps>;

  return (
    <div className="bootstrap-container" aria-busy={saving}>
      <div className="content-wrapper">
        <h1 className="mb-4">{title}</h1>
        <div className="treasury-toolbar d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
          <div className="d-flex flex-column flex-sm-row gap-2 flex-grow-1">
            <div className="treasury-search input-group">
              <span className="input-group-text" aria-hidden="true">
                <Search size={16} />
              </span>
              <input
                className="form-control"
                type="search"
                aria-label={searchPlaceholder}
                placeholder={searchPlaceholder}
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setPage(0);
                }}
              />
              {query && (
                <button
                  type="button"
                  className="btn btn-outline-secondary"
                  onClick={() => {
                    setQuery("");
                    setPage(0);
                  }}
                  aria-label="Limpiar búsqueda"
                >
                  <X size={16} />
                </button>
              )}
            </div>
            {hasStatusFilter && (
              <select
                className="form-select treasury-status-filter"
                aria-label="Filtrar por estado"
                value={statusFilter}
                onChange={(event) => {
                  setStatusFilter(event.target.value);
                  setPage(0);
                }}
              >
                <option value="all">Todos los estados</option>
                {availableStatuses.map((status) => (
                  <option value={status} key={status}>
                    {status}
                  </option>
                ))}
              </select>
            )}
          </div>
          {writable && (
            <button
              className="btn btn-primary treasury-add-button"
              onClick={openNew}
              disabled={saving}
            >
              <CirclePlus size={16} className="me-2" />
              Añadir
            </button>
          )}
        </div>

        {error && (
          <div className="alert alert-danger" role="alert">
            {error}
          </div>
        )}
        {notice && (
          <div className="alert alert-success" role="status">
            {notice}
          </div>
        )}

        <div className="table-responsive">
          <table className="table table-striped treasury-table">
            <caption className="visually-hidden">Listado de {title.toLowerCase()}</caption>
            <thead>
              <tr>
                {fields.map((field) => {
                  const sorted = sortField === field.name;
                  return (
                    <th
                      key={field.name}
                      scope="col"
                      aria-sort={
                        sorted ? sortDirection : "none"
                      }
                    >
                      <button
                        type="button"
                        className="treasury-sort-button"
                        onClick={() => toggleSort(field.name)}
                        aria-label={`Ordenar por ${field.label}`}
                      >
                        {field.label}
                        {sorted ? (
                          sortDirection === "ascending" ? (
                            <ChevronUp size={14} aria-hidden="true" />
                          ) : (
                            <ChevronDown size={14} aria-hidden="true" />
                          )
                        ) : (
                          <ChevronsUpDown size={14} aria-hidden="true" />
                        )}
                      </button>
                    </th>
                  );
                })}
                {writable && <th scope="col">Acciones</th>}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td
                    colSpan={fields.length + (writable ? 1 : 0)}
                    className="text-center treasury-table-message"
                    role="status"
                  >
                    <span
                      className="spinner-border spinner-border-sm me-2"
                      aria-hidden="true"
                    />
                    Cargando registros...
                  </td>
                </tr>
              ) : visibleRows.length === 0 ? (
                <tr>
                  <td
                    colSpan={fields.length + (writable ? 1 : 0)}
                    className="text-center treasury-table-message"
                  >
                    {data.length === 0 && error ? (
                      <div className="treasury-empty-state">
                        <strong>No se pudieron cargar los registros</strong>
                        <span>Revisa tu conexión e inténtalo nuevamente.</span>
                        <button
                          type="button"
                          className="btn btn-outline-secondary btn-sm mt-2"
                          onClick={() => void loadRows()}
                        >
                          Reintentar
                        </button>
                      </div>
                    ) : data.length === 0 ? (
                      <div className="treasury-empty-state">
                        <strong>Aún no hay registros</strong>
                        <span>Cuando agregues uno, aparecerá en esta tabla.</span>
                        {writable && (
                          <button
                            type="button"
                            className="btn btn-primary btn-sm mt-2"
                            onClick={openNew}
                          >
                            <CirclePlus size={15} className="me-1" />
                            Crear primer registro
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="treasury-empty-state">
                        <strong>No encontramos resultados</strong>
                        <span>Prueba con otros términos o cambia los filtros.</span>
                        <button
                          type="button"
                          className="btn btn-outline-secondary btn-sm mt-2"
                          onClick={clearFilters}
                        >
                          Limpiar filtros
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ) : (
                visibleRows.map((item) => {
                  const rowLabel = String(
                    item[fields[0]?.name ?? ""] ?? item.id,
                  );
                  return (
                    <tr key={item.id}>
                      {fields.map((field) => {
                        const value = item[field.name];
                        const isCurrency =
                          typeof value === "number" &&
                          ["monto", "saldo", "importe", "valor", "balance"].some(
                            (part) => field.name.includes(part),
                          );
                        return (
                          <td key={field.name}>
                            {isCurrency ? `$${value.toFixed(2)}` : String(value ?? "")}
                          </td>
                        );
                      })}
                      {writable && (
                        <td className="text-nowrap">
                          <button
                            className="btn btn-warning btn-sm me-1"
                            onClick={() => edit(item)}
                            disabled={saving}
                            aria-label={`Editar ${rowLabel}`}
                            title="Editar"
                          >
                            <SquarePen size={15} />
                          </button>
                          <button
                            className="btn btn-danger btn-sm"
                            onClick={() => void remove(item.id)}
                            disabled={saving}
                            aria-label={`Desactivar ${rowLabel}`}
                            title="Desactivar"
                          >
                            <Trash2 size={15} />
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {!loading && sortedRows.length > 0 && (
          <div className="treasury-pagination">
            <span className="treasury-results-count">
              Mostrando {firstVisible}–{lastVisible} de {sortedRows.length} registros
            </span>
            <div className="d-flex align-items-center gap-2">
              <label className="treasury-page-size-label" htmlFor="treasury-page-size">
                Filas:
              </label>
              <select
                id="treasury-page-size"
                className="form-select form-select-sm treasury-page-size"
                value={rowsPerPage}
                onChange={(event) => {
                  setRowsPerPage(Number(event.target.value));
                  setPage(0);
                }}
                aria-label="Filas por página"
              >
                {[10, 25, 50].map((size) => (
                  <option value={size} key={size}>
                    {size}
                  </option>
                ))}
              </select>
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                onClick={() => setPage((current) => Math.max(0, current - 1))}
                disabled={currentPage === 0}
                aria-label="Página anterior"
              >
                <ChevronLeft size={16} />
              </button>
              <span className="treasury-page-count">
                {currentPage + 1} de {pageCount}
              </span>
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                onClick={() =>
                  setPage((current) => Math.min(pageCount - 1, current + 1))
                }
                disabled={currentPage >= pageCount - 1}
                aria-label="Página siguiente"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}

        {writable && (
          <TypedModal
            show={show}
            editando={editId !== null}
            values={form}
            onChange={change}
            onClose={close}
            onSubmit={submit}
            saving={saving}
            formError={formError}
          />
        )}
      </div>
    </div>
  );
}
