"use client";

import Link from "next/link";
import { ArrowRight, Clock3, Search, ShoppingCart, Star, X } from "lucide-react";
import { useMemo, useState } from "react";

import {
  navigationLinks,
  normalizeNavigationSearch,
  type NavigationLink,
} from "@/components/sidebar-menu";
import { useNavigationPreferences } from "@/components/navigation-preferences";

const quickAccessUrls = [
  "/venta-rapida",
  "/productos",
  "/cliente",
  "/facturas",
  "/pedidos",
  "/proveedores",
  "/caja",
];

function findNavigationLink(url: string): NavigationLink | undefined {
  return navigationLinks.find((link) => link.url === url);
}

function FavoriteToggle({
  isFavorite,
  title,
  onClick,
}: {
  isFavorite: boolean;
  title: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className="home-dashboard-star"
      aria-label={isFavorite ? `Quitar ${title} de favoritos` : `Agregar ${title} a favoritos`}
      title={isFavorite ? "Quitar de favoritos" : "Agregar a favoritos"}
      onClick={onClick}
    >
      <Star
        size={17}
        aria-hidden="true"
        fill={isFavorite ? "currentColor" : "none"}
      />
    </button>
  );
}

function ModuleCard({
  module,
  favorite,
  onToggleFavorite,
}: {
  module: NavigationLink;
  favorite: boolean;
  onToggleFavorite: (url: string) => void;
}) {
  return (
    <article className="home-dashboard-module">
      <Link href={module.url} className="home-dashboard-module-link">
        <span className="home-dashboard-module-copy">
          <span className="home-dashboard-module-group">{module.group}</span>
          <span className="home-dashboard-module-title">{module.title}</span>
        </span>
        <ArrowRight size={17} aria-hidden="true" />
      </Link>
      <FavoriteToggle
        isFavorite={favorite}
        title={module.title}
        onClick={() => onToggleFavorite(module.url)}
      />
    </article>
  );
}

export default function HomeDashboard() {
  const [query, setQuery] = useState("");
  const {
    favorites,
    recent,
    hydrated,
    toggleFavorite,
    clearRecent,
  } = useNavigationPreferences();

  const favoriteModules = useMemo(
    () =>
      favorites
        .map(findNavigationLink)
        .filter((module): module is NavigationLink => Boolean(module)),
    [favorites],
  );
  const recentModules = useMemo(
    () =>
      recent
        .map(findNavigationLink)
        .filter((module): module is NavigationLink => Boolean(module)),
    [recent],
  );
  const quickAccessModules = quickAccessUrls
    .map(findNavigationLink)
    .filter((module): module is NavigationLink => Boolean(module));
  const searchResults = useMemo(() => {
    const search = normalizeNavigationSearch(query);
    if (!search) return [];

    return navigationLinks
      .filter((module) =>
        normalizeNavigationSearch(`${module.title} ${module.group} ${module.url}`).includes(search),
      );
  }, [query]);

  return (
    <div className="home-dashboard">
      <header className="home-dashboard-hero">
        <div>
          <p className="home-dashboard-eyebrow">ESPACIO DE TRABAJO</p>
          <h1>¿Qué necesitas hacer hoy?</h1>
          <p className="home-dashboard-description">
            Encuentra un módulo, retoma una pantalla reciente o abre un acceso rápido.
          </p>
        </div>
        <div className="home-dashboard-hero-actions">
          <Link href="/venta-rapida" className="home-dashboard-hero-action">
            <ShoppingCart size={18} aria-hidden="true" />
            <span>Iniciar venta</span>
            <ArrowRight size={16} aria-hidden="true" />
          </Link>
          <div className="home-dashboard-hero-mark" aria-hidden="true">
            <span>GLM</span>
          </div>
        </div>
      </header>

      <section className="home-dashboard-search-section" aria-label="Buscar módulos">
        <label htmlFor="home-module-search">Buscar en todos los módulos</label>
        <div className="home-dashboard-search">
          <Search size={19} aria-hidden="true" />
          <input
            id="home-module-search"
            type="search"
            placeholder="Ej. productos, caja, cuentas por pagar..."
            spellCheck={false}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
          {query && (
            <button
              type="button"
              aria-label="Limpiar búsqueda"
              onClick={() => setQuery("")}
            >
              <X size={17} aria-hidden="true" />
            </button>
          )}
        </div>
        {query.trim() && (
          <div className="home-dashboard-search-results" role="list">
            {searchResults.length ? (
              searchResults.map((module) => (
                <div
                  key={module.url}
                  className="home-dashboard-search-result"
                  role="listitem"
                >
                  <Link
                    href={module.url}
                    className="home-dashboard-search-result-link"
                    onClick={() => setQuery("")}
                  >
                    <span>
                      <strong>{module.title}</strong>
                      <small>{module.group}</small>
                    </span>
                    <ArrowRight size={16} aria-hidden="true" />
                  </Link>
                  <FavoriteToggle
                    isFavorite={favorites.includes(module.url)}
                    title={module.title}
                    onClick={() => toggleFavorite(module.url)}
                  />
                </div>
              ))
            ) : (
              <p className="home-dashboard-no-results">
                No encontramos módulos con ese nombre.
              </p>
            )}
          </div>
        )}
      </section>

      <div className="home-dashboard-columns">
        <section className="home-dashboard-section">
          <div className="home-dashboard-section-heading">
            <div>
              <span className="home-dashboard-section-icon home-dashboard-section-icon--favorite">
                <Star size={17} aria-hidden="true" />
              </span>
              <div>
                <h2>Mis favoritos</h2>
                <p>Tus módulos de uso frecuente.</p>
              </div>
            </div>
          </div>
          {!hydrated ? (
            <div className="home-dashboard-empty">
              <p>Cargando tus preferencias...</p>
            </div>
          ) : favoriteModules.length ? (
            <div className="home-dashboard-module-list">
              {favoriteModules.map((module) => (
                <ModuleCard
                  key={module.url}
                  module={module}
                  favorite
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          ) : (
            <div className="home-dashboard-empty">
              <p>
                Aún no tienes favoritos. Usa la estrella en un acceso rápido o en
                los resultados de búsqueda para guardarlo aquí.
              </p>
            </div>
          )}
        </section>

        <section className="home-dashboard-section">
          <div className="home-dashboard-section-heading">
            <div>
              <span className="home-dashboard-section-icon home-dashboard-section-icon--recent">
                <Clock3 size={17} aria-hidden="true" />
              </span>
              <div>
                <h2>Visitados recientemente</h2>
                <p>Continúa donde dejaste.</p>
              </div>
            </div>
            {hydrated && recentModules.length > 0 && (
              <button
                type="button"
                className="home-dashboard-clear"
                onClick={clearRecent}
              >
                Limpiar
              </button>
            )}
          </div>
          {!hydrated ? (
            <div className="home-dashboard-empty">
              <p>Cargando tu actividad reciente...</p>
            </div>
          ) : recentModules.length ? (
            <div className="home-dashboard-module-list">
              {recentModules.map((module) => (
                <ModuleCard
                  key={module.url}
                  module={module}
                  favorite={favorites.includes(module.url)}
                  onToggleFavorite={toggleFavorite}
                />
              ))}
            </div>
          ) : (
            <div className="home-dashboard-empty">
              <p>Los módulos que visites aparecerán aquí para que puedas volver rápidamente.</p>
            </div>
          )}
        </section>
      </div>

      <section className="home-dashboard-section home-dashboard-quick-access">
        <div className="home-dashboard-section-heading">
          <div>
            <span className="home-dashboard-section-icon home-dashboard-section-icon--quick">
              <ArrowRight size={17} aria-hidden="true" />
            </span>
            <div>
              <h2>Accesos rápidos</h2>
              <p>Atajos para las tareas más habituales.</p>
            </div>
          </div>
        </div>
        <div className="home-dashboard-quick-grid">
          {quickAccessModules.map((module) => (
            <ModuleCard
              key={module.url}
              module={module}
              favorite={favorites.includes(module.url)}
              onToggleFavorite={toggleFavorite}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
