"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Calculator, LogOut, Menu, X } from "lucide-react";

import { AppSidebarMenu } from "@/components/sidebar-menu";
import { NavigationPreferencesProvider } from "@/components/navigation-preferences";
import { ModalMenuEnhancer } from "@/components/modal-menu-enhancer";

export function AppShell({
  children,
  showFooter = true,
}: {
  children: React.ReactNode;
  showFooter?: boolean;
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (!mobileMenuOpen) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMobileMenuOpen(false);
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [mobileMenuOpen]);

  return (
    <NavigationPreferencesProvider>
      <ModalMenuEnhancer />
      <div className="app-shell flex h-screen flex-col bg-neutral-100">
        <header className="z-20 flex h-[72px] w-full shrink-0 items-center justify-between gap-3 border-b border-white/10 bg-black px-6 py-2 text-white shadow-[0_10px_30px_rgba(0,0,0,0.18)]">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              className="app-shell-mobile-menu-button"
              aria-label={mobileMenuOpen ? "Cerrar menú" : "Abrir menú"}
              aria-expanded={mobileMenuOpen}
              aria-controls="app-navigation"
              onClick={() => setMobileMenuOpen((open) => !open)}
            >
              {mobileMenuOpen ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
            </button>
            <Link href="/" aria-label="Ir al inicio" className="app-shell-brand flex min-w-0 items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-sm bg-lime-500 text-black">
                <Calculator className="h-5 w-5" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <p className="m-0 text-[11px] font-semibold leading-4 uppercase tracking-[0.32em] text-white/60">
                  Empresa
                </p>
                <p className="m-0 truncate text-lg font-semibold leading-5 text-white">Sistema de Ventas</p>
                <p className="m-0 mt-0.5 truncate text-xs leading-4 text-white/55">Gestión comercial y operativa</p>
              </div>
            </Link>
          </div>
          <Link
            href="/login"
            aria-label="Cerrar sesión"
            title="Cerrar sesión"
            className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/15 bg-white/8 text-white transition-colors hover:bg-white hover:text-black"
          >
            <LogOut className="h-4.5 w-4.5" />
          </Link>
        </header>

        {mobileMenuOpen && (
          <button
            type="button"
            className="app-shell-mobile-backdrop"
            aria-label="Cerrar menú de navegación"
            onClick={() => setMobileMenuOpen(false)}
          />
        )}

        <div className="flex min-h-0 flex-1 overflow-hidden bg-neutral-100">
          <div
            id="app-navigation"
            className={`app-shell-sidebar${mobileMenuOpen ? " is-open" : ""}`}
          >
            <AppSidebarMenu onNavigate={() => setMobileMenuOpen(false)} />
          </div>
          <div className="app-shell-main flex min-w-0 flex-1 flex-col overflow-y-auto bg-neutral-100">
            <main className="flex-1">{children}</main>
          </div>
        </div>

        {showFooter ? (
          <footer className="z-20 w-full bg-black px-6 py-2 text-center text-xs text-white">
            Motorizado por GLM
          </footer>
        ) : null}
      </div>
    </NavigationPreferencesProvider>
  );
}