"use client";

import React, { useState } from "react";
import type { TreasuryField } from "./treasury-crud";

type TreasuryFormValues = Record<string, unknown>;

interface TreasuryFormProps {
  values: TreasuryFormValues;
  onChange: (
    event: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >,
  ) => void;
  fields: TreasuryField[];
}

export default function TreasuryForm({
  values,
  onChange,
  fields,
}: TreasuryFormProps) {
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const markTouched = (name: string) => {
    setTouched((previous) => ({ ...previous, [name]: true }));
  };

  const renderField = (field: TreasuryField) => {
    const required = field.required ?? true;
    const value = values[field.name];
    const inputValue =
      typeof value === "string" || typeof value === "number" ? value : "";
    const hasError =
      required &&
      inputValue === "" &&
      Boolean(touched[field.name]);
    const errorId = `${field.name}-required-error`;

    return (
      <div className="col-md-6" key={field.name}>
        <label className="form-label" htmlFor={field.name}>
          {field.label}
          {required ? (
            <span className="text-danger ms-1" aria-hidden="true">
              *
            </span>
          ) : (
            <span className="text-muted ms-1">(opcional)</span>
          )}
        </label>
        <input
          className={`form-control${hasError ? " is-invalid" : ""}`}
          id={field.name}
          name={field.name}
          type={field.type || "text"}
          step={field.type === "number" ? "any" : undefined}
          value={inputValue}
          onChange={onChange}
          onBlur={() => markTouched(field.name)}
          onInvalid={() => markTouched(field.name)}
          required={required}
          aria-required={required}
          aria-invalid={hasError}
          aria-describedby={hasError ? errorId : undefined}
        />
        {hasError && (
          <div className="invalid-feedback d-block" id={errorId}>
            Este campo es obligatorio.
          </div>
        )}
      </div>
    );
  };

  const showStatus =
    Object.prototype.hasOwnProperty.call(values, "estado") &&
    !fields.some((field) => field.name === "estado");
  const statusValue =
    typeof values.estado === "string" ? values.estado : "Activo";

  return (
    <div className="row g-3">
      {fields.map(renderField)}
      {showStatus && (
        <div className="col-md-6">
          <label className="form-label" htmlFor="estado">
            Estado
            <span className="text-danger ms-1" aria-hidden="true">
              *
            </span>
          </label>
          <select
            className="form-select"
            id="estado"
            name="estado"
            value={statusValue}
            onChange={onChange}
            onBlur={() => markTouched("estado")}
            required
            aria-required="true"
          >
            <option>Activo</option>
            <option>Pendiente</option>
            <option>Completado</option>
            <option>Conciliado</option>
            <option>Anulado</option>
            <option>Pagado</option>
          </select>
        </div>
      )}
    </div>
  );
}
