"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { usePathname } from "next/navigation";

const STORAGE_KEY = "ventas.navigation-preferences";
const STORAGE_VERSION = 1;
const MAX_RECENT = 8;

interface NavigationPreferences {
  favorites: string[];
  recent: string[];
}

interface NavigationPreferencesContextValue extends NavigationPreferences {
  hydrated: boolean;
  toggleFavorite: (url: string) => void;
  clearRecent: () => void;
}

interface StorageEnvelope {
  version: number;
  data: NavigationPreferences;
}

const emptyPreferences: NavigationPreferences = { favorites: [], recent: [] };
const NavigationPreferencesContext =
  createContext<NavigationPreferencesContextValue | null>(null);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null;
}

function cleanPaths(value: unknown): string[] {
  if (!Array.isArray(value)) return [];

  return [...new Set(
    value.filter(
      (path): path is string =>
        typeof path === "string" &&
        path.startsWith("/") &&
        path !== "/" &&
        path.length <= 180,
    ),
  )];
}

function readPreferences(): NavigationPreferences {
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return emptyPreferences;

    const parsed: unknown = JSON.parse(stored);
    if (
      !isRecord(parsed) ||
      parsed.version !== STORAGE_VERSION ||
      !isRecord(parsed.data)
    ) {
      return emptyPreferences;
    }

    return {
      favorites: cleanPaths(parsed.data.favorites),
      recent: cleanPaths(parsed.data.recent).slice(0, MAX_RECENT),
    };
  } catch (error) {
    console.warn("No se pudieron cargar las preferencias de navegación.", error);
    return emptyPreferences;
  }
}

function isAppRoute(pathname: string): boolean {
  return pathname !== "/" &&
    pathname !== "/login" &&
    !pathname.startsWith("/sitio/");
}

export function NavigationPreferencesProvider({
  children,
}: {
  children: ReactNode;
}) {
  const pathname = usePathname();
  const [preferences, setPreferences] = useState(emptyPreferences);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const stored = readPreferences();
    const recent = isAppRoute(pathname)
      ? [pathname, ...stored.recent.filter((path) => path !== pathname)].slice(
          0,
          MAX_RECENT,
        )
      : stored.recent;

    setPreferences({ ...stored, recent });
    setHydrated(true);
  }, [pathname]);

  useEffect(() => {
    if (!hydrated) return;

    const envelope: StorageEnvelope = {
      version: STORAGE_VERSION,
      data: preferences,
    };

    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(envelope));
    } catch (error) {
      console.warn("No se pudieron guardar las preferencias de navegación.", error);
    }
  }, [hydrated, preferences]);

  const toggleFavorite = useCallback((url: string) => {
    setPreferences((current) => {
      const alreadyFavorite = current.favorites.includes(url);
      if (alreadyFavorite) {
        return {
          ...current,
          favorites: current.favorites.filter((favorite) => favorite !== url),
        };
      }

      return {
        ...current,
        favorites: [url, ...current.favorites],
      };
    });
  }, []);

  const clearRecent = useCallback(() => {
    setPreferences((current) => ({ ...current, recent: [] }));
  }, []);

  const value = useMemo(
    () => ({ ...preferences, hydrated, toggleFavorite, clearRecent }),
    [preferences, hydrated, toggleFavorite, clearRecent],
  );

  return (
    <NavigationPreferencesContext.Provider value={value}>
      {children}
    </NavigationPreferencesContext.Provider>
  );
}

export function useNavigationPreferences() {
  const context = useContext(NavigationPreferencesContext);
  if (!context) {
    throw new Error(
      "useNavigationPreferences debe usarse dentro de NavigationPreferencesProvider.",
    );
  }
  return context;
}
