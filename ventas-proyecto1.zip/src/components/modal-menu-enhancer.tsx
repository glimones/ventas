"use client";

import { useEffect } from "react";
import { createRoot, type Root } from "react-dom/client";
import { getMenuIconForPath } from "./sidebar-menu";

export function ModalMenuEnhancer() {
  useEffect(() => {
    const roots = new Map<HTMLElement, Root>();

    const enhanceTitles = () => {
      const Icon = getMenuIconForPath(window.location.pathname);
      document.querySelectorAll<HTMLElement>(".modal-title").forEach((title) => {
        if (title.dataset.menuIconEnhanced === "true") return;
        if (title.querySelector("svg")) {
          title.dataset.menuIconEnhanced = "true";
          return;
        }
        if (!Icon) return;

        title.dataset.menuIconEnhanced = "true";
        title.classList.add("menu-modal-title");
        const iconContainer = document.createElement("span");
        iconContainer.className = "menu-modal-title-icon";
        title.insertBefore(iconContainer, title.firstChild);
        const root = createRoot(iconContainer);
        roots.set(iconContainer, root);
        root.render(<Icon size={21} strokeWidth={2} aria-hidden="true" />);
      });
    };

    enhanceTitles();
    const observer = new MutationObserver(enhanceTitles);
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      roots.forEach((root) => root.unmount());
      roots.clear();
      document.querySelectorAll<HTMLElement>(".modal-title[data-menu-icon-enhanced='true']").forEach((title) => {
        delete title.dataset.menuIconEnhanced;
      });
    };
  }, []);

  return null;
}
