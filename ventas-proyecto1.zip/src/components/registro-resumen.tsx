"use client";

export type FiltroEstadoRegistro = "TODOS" | "ACTIVOS" | "INACTIVOS";

interface RegistroResumenProps {
  total: number;
  activos: number;
  inactivos: number;
  filtro: FiltroEstadoRegistro;
  activosLabel?: string;
  inactivosLabel?: string;
  cargando?: boolean;
  onChange: (filtro: FiltroEstadoRegistro) => void;
}

export default function RegistroResumen({
  total,
  activos,
  inactivos,
  filtro,
  activosLabel = "Activos",
  inactivosLabel = "Inactivos",
  cargando = false,
  onChange,
}: RegistroResumenProps) {
  const valores = { total, activos, inactivos };
  const tarjetas: Array<{
    filtro: FiltroEstadoRegistro;
    etiqueta: string;
    propiedad: keyof typeof valores;
  }> = [
    { filtro: "TODOS", etiqueta: "Total", propiedad: "total" },
    { filtro: "ACTIVOS", etiqueta: activosLabel, propiedad: "activos" },
    { filtro: "INACTIVOS", etiqueta: inactivosLabel, propiedad: "inactivos" },
  ];

  return (
    <div className="entity-summary-grid" aria-label="Resumen de registros">
      {tarjetas.map((tarjeta) => (
        <button
          type="button"
          key={tarjeta.filtro}
          className={`entity-summary-card${filtro === tarjeta.filtro ? " is-selected" : ""}`}
          aria-pressed={filtro === tarjeta.filtro}
          disabled={cargando}
          onClick={() => onChange(tarjeta.filtro)}
        >
          <span>{tarjeta.etiqueta}</span>
          <strong>{cargando ? "—" : valores[tarjeta.propiedad]}</strong>
        </button>
      ))}
    </div>
  );
}
