'use client';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { usePathname } from 'next/navigation';
import { CirclePlus, SquarePen, Trash2, X } from 'lucide-react';

export interface DomainField {
  name: string;
  label: string;
  type?: "text" | "number" | "date" | "email" | "tel" | "select";
  options?: Array<{ value: string; label: string }>;
  readOnly?: boolean;
}
export interface DomainConfig { title: string; search: string; fields: DomainField[]; sample: Record<string, string | number>; }
type DomainRow = { id: number } & Record<string, string | number>;

export default function DomainCrud({ config }: { config: DomainConfig }) {
  const pathname = usePathname();
  const [rows, setRows] = useState<DomainRow[]>([]);
  const [query, setQuery] = useState(''); const [open, setOpen] = useState(false); const [editing, setEditing] = useState<number | null>(null); const [form, setForm] = useState<Record<string, string | number>>({ ...config.sample });
  const [statusFilter, setStatusFilter] = useState('all'); const [page, setPage] = useState(0); const [rowsPerPage, setRowsPerPage] = useState(10);
  const [loading, setLoading] = useState(true); const [saving, setSaving] = useState(false); const [error, setError] = useState('');
  const [writable, setWritable] = useState(false);
  const loadRows = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api${pathname}`, { cache: 'no-store' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudieron cargar los registros.');
      setRows(result.data as DomainRow[]);
      setWritable(Boolean(result.capabilities?.create && result.capabilities?.update && result.capabilities?.delete));
      setError('');
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Error al cargar los registros.');
    } finally {
      setLoading(false);
    }
  }, [pathname]);
  useEffect(() => { void loadRows(); }, [loadRows]);
  const close = () => { setOpen(false); setEditing(null); setForm({ ...config.sample }); };
  const openNew = async () => {
    setError('');
    setEditing(null);
    setForm({ ...config.sample });
    try {
      const response = await fetch(`/api${pathname}/siguiente-codigo`, { cache: 'no-store' });
      const result = await response.json();
      if (response.ok && typeof result.codigo === 'string') {
        setForm((previous) => ({ ...previous, codigo: result.codigo }));
      }
    } catch {
      // El código se genera nuevamente en el servidor al guardar.
    }
    setOpen(true);
  };
  const save = async (event: React.FormEvent) => {
    event.preventDefault(); setSaving(true); setError('');
    try {
      const response = await fetch(editing === null ? `/api${pathname}` : `/api${pathname}/${editing}`, {
        method: editing === null ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo guardar el registro.');
      await loadRows(); close();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Error al guardar el registro.');
    } finally { setSaving(false); }
  };
  const remove = async (id: number) => {
    if (!window.confirm('¿Deseas desactivar este registro?')) return;
    try {
      const response = await fetch(`/api${pathname}/${id}`, { method: 'DELETE' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo desactivar el registro.');
      await loadRows();
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : 'Error al desactivar el registro.');
    }
  };
  const availableStatuses = useMemo(
    () => Array.from(new Set(rows.map((row) => String(row.estado ?? '').trim()).filter(Boolean))).sort((a, b) => a.localeCompare(b, 'es')),
    [rows],
  );
  const filtered = useMemo(
    () => rows.filter((row) => {
      const matchesQuery = Object.values(row).join(' ').toLocaleLowerCase().includes(query.toLocaleLowerCase());
      const matchesStatus = statusFilter === 'all' || String(row.estado ?? '') === statusFilter;
      return matchesQuery && matchesStatus;
    }),
    [query, rows, statusFilter],
  );
  const pageCount = Math.max(1, Math.ceil(filtered.length / rowsPerPage));
  const currentPage = Math.min(page, pageCount - 1);
  const visibleRows = filtered.slice(currentPage * rowsPerPage, (currentPage + 1) * rowsPerPage);
  const firstVisible = filtered.length === 0 ? 0 : currentPage * rowsPerPage + 1;
  const lastVisible = Math.min((currentPage + 1) * rowsPerPage, filtered.length);
  const getStatusClass = (value: string) => {
    const status = value.toLocaleLowerCase();
    if (/^(inactiv|rechazad|anulad|vencid|error|fallid)/.test(status)) return 'danger';
    if (/^(activ|aplicad|aprobad|autorizad|pagad|completad|contabilizad|cerrad|procesad)/.test(status)) return 'success';
    if (/^(pendient|revis|parcial|proceso|generad)/.test(status)) return 'warning';
    return 'secondary';
  };
  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">{config.title}</h1>
        <div className="domain-crud-toolbar mb-3">
          <input
            className="form-control"
            type="search"
            aria-label={config.search}
            placeholder={config.search}
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setPage(0);
            }}
          />
          <div className="domain-crud-filters">
            {availableStatuses.length > 1 && (
              <select
                className="form-select"
                aria-label="Filtrar por estado"
                value={statusFilter}
                onChange={(event) => {
                  setStatusFilter(event.target.value);
                  setPage(0);
                }}
              >
                <option value="all">Todos los estados</option>
                {availableStatuses.map((status) => <option value={status} key={status}>{status}</option>)}
              </select>
            )}
            {writable && (
              <button className="btn btn-primary" type="button" onClick={() => void openNew()}>
                <CirclePlus size={16} className="me-2" />Añadir
              </button>
            )}
          </div>
        </div>
        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        {!loading && (
          <p className="entity-result-count" role="status">
            Mostrando {firstVisible}–{lastVisible} de {filtered.length} registros
            {filtered.length !== rows.length && ` (de ${rows.length} en total)`}
          </p>
        )}
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead>
              <tr>
                {config.fields.map((field) => <th scope="col" key={field.name}>{field.label}</th>)}
                {writable && <th scope="col">Acciones</th>}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={config.fields.length + (writable ? 1 : 0)} className="text-center" role="status">Cargando datos...</td></tr>
              ) : visibleRows.length === 0 ? (
                <tr><td colSpan={config.fields.length + (writable ? 1 : 0)} className="text-center">{error ? 'No se pudieron cargar los datos' : 'No hay registros que coincidan con los filtros'}</td></tr>
              ) : visibleRows.map((row) => (
                <tr key={row.id}>
                  {config.fields.map((field) => (
                    <td key={field.name}>
                      {field.name === 'estado' && row[field.name] ? (
                        <span className={`badge text-bg-${getStatusClass(String(row[field.name]))}`}>{row[field.name]}</span>
                      ) : row[field.name] ?? ''}
                    </td>
                  ))}
                  {writable && (
                    <td>
                      <button className="btn btn-warning btn-sm me-1" type="button" aria-label={`Editar ${row.nombre ?? row.codigo ?? row.id}`} onClick={() => { setError(''); setEditing(row.id); setForm({ ...row }); setOpen(true); }}>
                        <SquarePen size={15} />
                      </button>
                      <button className="btn btn-danger btn-sm" type="button" aria-label={`Desactivar ${row.nombre ?? row.codigo ?? row.id}`} onClick={() => void remove(row.id)}>
                        <Trash2 size={15} />
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && filtered.length > 0 && (
          <div className="domain-crud-pagination">
            <label>
              Filas por página
              <select
                className="form-select"
                aria-label="Filas por página"
                value={rowsPerPage}
                onChange={(event) => {
                  setRowsPerPage(Number(event.target.value));
                  setPage(0);
                }}
              >
                {[10, 25, 50].map((size) => <option key={size} value={size}>{size}</option>)}
              </select>
            </label>
            <span>Página {currentPage + 1} de {pageCount}</span>
            <div>
              <button type="button" className="btn btn-outline-secondary btn-sm" disabled={currentPage === 0} onClick={() => setPage(currentPage - 1)}>Anterior</button>
              <button type="button" className="btn btn-outline-secondary btn-sm ms-2" disabled={currentPage >= pageCount - 1} onClick={() => setPage(currentPage + 1)}>Siguiente</button>
            </div>
          </div>
        )}
        {open && writable && (
          <div className="modal d-block" tabIndex={-1} role="dialog" aria-modal="true">
            <div className="modal-dialog modal-lg">
              <div className="modal-content">
                <form onSubmit={save}>
                  <div className="modal-header">
                    <h2 className="modal-title fs-5">{editing === null ? `Nuevo ${config.title}` : `Editar ${config.title}`}</h2>
                    <button type="button" className="btn-close" aria-label="Cerrar" onClick={close} disabled={saving}><X size={16} /></button>
                  </div>
                  <div className="modal-body row g-3">
                    {error && <div className="col-12"><div className="alert alert-danger" role="alert">{error}</div></div>}
                    {config.fields.map((field) => (
                      <div className="col-md-6" key={field.name}>
                        <label className="form-label" htmlFor={field.name}>{field.label}</label>
                        {field.type === "select" ? (
                          <select
                            className="form-select"
                            id={field.name}
                            name={field.name}
                            value={form[field.name] ?? ""}
                            onChange={(event) => setForm((previous) => ({ ...previous, [field.name]: event.target.value }))}
                            required
                          >
                            <option value="">Seleccione {field.label.toLocaleLowerCase()}</option>
                            {field.options?.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
                          </select>
                        ) : (
                          <input
                            className={`form-control${field.name === "codigo" ? " bg-light" : ""}`}
                            id={field.name}
                            name={field.name}
                            type={field.type || "text"}
                            value={form[field.name] ?? ""}
                            readOnly={field.name === "codigo"}
                            onChange={(event) => setForm((previous) => ({ ...previous, [field.name]: field.type === "number" ? Number(event.target.value) : event.target.value }))}
                            required
                          />
                        )}
                      </div>
                    ))}
                  </div>
                  <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={close} disabled={saving}>Cancelar</button>
                    <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Guardando...' : 'Guardar'}</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}