"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  QUICK_SALE_INVOICE_DRAFT_KEY,
  type DetalleFormValues,
  type QuickSaleInvoiceDraft,
} from "../facturas/types";
import {
  ChevronLeft,
  ChevronRight,
  CirclePlus,
  Minus,
  Plus,
  Search,
  ShoppingCart,
  Trash2,
  Upload,
} from "lucide-react";

type CatalogProduct = {
  id: string;
  codigo: string;
  codigo_barras: string;
  nombre: string;
  precio_venta: string;
  controla_stock: boolean;
  stock_by_warehouse: Array<{ warehouseId: string; quantity: string }>;
};

type CatalogTax = {
  id: string;
  nombre: string;
  porcentaje: string;
};

type CatalogOption = {
  id: string;
  nombre: string;
  codigo?: string;
  sucursal_id?: string | null;
};

type CatalogCustomer = {
  id: string;
  nombre: string;
  apellido: string | null;
  razon_social: string | null;
  tipo_documento: string;
  documento: string;
  direccion?: string;
  email?: string;
  celular?: string;
};

type QuickSaleCatalog = {
  company: {
    nombre_legal: string;
    nombre_comercial: string | null;
    ruc: string;
    direccion: string;
    ciudad: string;
  };
  branches: CatalogOption[];
  emissionPoints: CatalogOption[];
  warehouses: CatalogOption[];
  products: CatalogProduct[];
  customers: CatalogCustomer[];
  taxes: CatalogTax[];
  paymentMethods: Array<CatalogOption & { tipo: string }>;
  cashBoxes: CatalogOption[];
  bankAccounts: Array<CatalogOption & { banco: string; numero_cuenta: string }>;
};

type CartLine = {
  productId: string;
  quantity: string;
  taxId: string;
};

type SaleReceipt = {
  number: string;
  date: string;
  issueDate: string;
  companyName: string;
  companyLegalName: string;
  companyRuc: string;
  companyAddress: string;
  establishmentCode: string;
  emissionPointCode: string;
  customerName: string;
  customerDocument: string;
  customerDocumentType: string;
  customerAddress: string;
  paymentMethod: string;
  paymentCode: string;
  paymentDestination: string;
  items: Array<{
    code: string;
    barcode: string;
    name: string;
    quantity: number;
    unitPrice: number;
    taxPercent: number;
    total: number;
  }>;
  subtotal: number;
  taxTotal: number;
  total: number;
};

type ProofImage = {
  file: File;
  previewUrl: string;
};

const money = new Intl.NumberFormat("es-EC", {
  style: "currency",
  currency: "USD",
});

const PRODUCTS_PER_PAGE = 8;

function roundMoney(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

function customerLabel(customer: CatalogCustomer) {
  return (
    customer.razon_social ||
    `${customer.nombre} ${customer.apellido ?? ""}`.trim()
  );
}

const demoCatalog: QuickSaleCatalog = {
  company: {
    nombre_legal: "Comercial GLM Demo S.A.",
    nombre_comercial: "GLM Comercial Demo",
    ruc: "0999999999001",
    direccion: "Av. Principal 100",
    ciudad: "Guayaquil",
  },
  branches: [{ id: "1", codigo: "001", nombre: "Matriz" }],
  emissionPoints: [
    { id: "1", sucursal_id: "1", codigo: "001", nombre: "Punto principal" },
  ],
  warehouses: [
    { id: "1", sucursal_id: "1", codigo: "BOD-001", nombre: "Bodega principal" },
  ],
  products: [
    {
      id: "1",
      codigo: "PROD-001",
      codigo_barras: "0000000000001",
      nombre: "Café molido 500 g",
      precio_venta: "8.50",
      controla_stock: true,
      stock_by_warehouse: [{ warehouseId: "1", quantity: "24" }],
    },
    {
      id: "2",
      codigo: "PROD-002",
      codigo_barras: "0000000000002",
      nombre: "Vaso térmico 450 ml",
      precio_venta: "12.75",
      controla_stock: true,
      stock_by_warehouse: [{ warehouseId: "1", quantity: "8" }],
    },
    {
      id: "3",
      codigo: "SERV-001",
      codigo_barras: "0000000000003",
      nombre: "Servicio de instalación",
      precio_venta: "15.00",
      controla_stock: false,
      stock_by_warehouse: [],
    },
    {
      id: "4",
      codigo: "PROD-004",
      codigo_barras: "0000000000004",
      nombre: "Galletas de avena 250 g",
      precio_venta: "3.25",
      controla_stock: true,
      stock_by_warehouse: [{ warehouseId: "1", quantity: "35" }],
    },
    {
      id: "5",
      codigo: "PROD-005",
      codigo_barras: "0000000000005",
      nombre: "Botella de agua 1 L",
      precio_venta: "1.00",
      controla_stock: true,
      stock_by_warehouse: [{ warehouseId: "1", quantity: "50" }],
    },
    {
      id: "6",
      codigo: "PROD-006",
      codigo_barras: "0000000000006",
      nombre: "Cuaderno universitario",
      precio_venta: "2.50",
      controla_stock: true,
      stock_by_warehouse: [{ warehouseId: "1", quantity: "40" }],
    },
    {
      id: "7",
      codigo: "PROD-007",
      codigo_barras: "0000000000007",
      nombre: "Audífonos Bluetooth",
      precio_venta: "24.99",
      controla_stock: true,
      stock_by_warehouse: [{ warehouseId: "1", quantity: "6" }],
    },
    {
      id: "8",
      codigo: "SERV-002",
      codigo_barras: "0000000000008",
      nombre: "Mantenimiento preventivo",
      precio_venta: "30.00",
      controla_stock: false,
      stock_by_warehouse: [],
    },
    {
      id: "9",
      codigo: "PROD-009",
      codigo_barras: "0000000000009",
      nombre: "Cable USB-C 1 m",
      precio_venta: "5.50",
      controla_stock: true,
      stock_by_warehouse: [{ warehouseId: "1", quantity: "18" }],
    },
  ],
  customers: [
    {
      id: "1",
      nombre: "Comercial",
      apellido: "XYZ",
      razon_social: "Comercial XYZ S.A.",
      tipo_documento: "RUC",
      documento: "0990000001001",
      direccion: "Av. de las Américas 321",
      email: "ventas@comercialxyz.com",
      celular: "0990000001",
    },
    {
      id: "2",
      nombre: "Ana",
      apellido: "Torres",
      razon_social: null,
      tipo_documento: "CEDULA",
      documento: "1712345678",
      direccion: "Cdla. Alborada, Guayaquil",
    },
  ],
  taxes: [
    { id: "1", nombre: "IVA general", porcentaje: "15" },
    { id: "2", nombre: "IVA 0%", porcentaje: "0" },
  ],
  paymentMethods: [
    { id: "1", codigo: "EFE", nombre: "Efectivo", tipo: "CONTADO" },
    { id: "2", codigo: "TARJETA", nombre: "Tarjeta", tipo: "CONTADO" },
    { id: "3", codigo: "TRANSFERENCIA", nombre: "Transferencia", tipo: "CONTADO" },
  ],
  cashBoxes: [{ id: "1", sucursal_id: "1", codigo: "CAJ-001", nombre: "Caja principal" }],
  bankAccounts: [
    {
      id: "1",
      codigo: "CTA-001",
      banco: "Banco Demo",
      numero_cuenta: "**** 0001",
      nombre: "Banco Demo",
    },
  ],
};

export default function QuickSalePage() {
  const [catalog, setCatalog] = useState(demoCatalog);
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [barcode, setBarcode] = useState("");
  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const [productPage, setProductPage] = useState(1);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [branchId, setBranchId] = useState(demoCatalog.branches[0].id);
  const [emissionPointId, setEmissionPointId] = useState(demoCatalog.emissionPoints[0].id);
  const [warehouseId, setWarehouseId] = useState(demoCatalog.warehouses[0].id);
  const [customerId, setCustomerId] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [customerCellphone, setCustomerCellphone] = useState("");
  const [paymentMethodId, setPaymentMethodId] = useState(demoCatalog.paymentMethods[0].id);
  const [destinationType, setDestinationType] = useState<"cash" | "bank">("cash");
  const [destinationId, setDestinationId] = useState(demoCatalog.cashBoxes[0].id);
  const [proofImage, setProofImage] = useState<ProofImage | null>(null);
  const proofImageInputRef = useRef<HTMLInputElement>(null);
  const [receipt, setReceipt] = useState<SaleReceipt | null>(null);
  const [receiptSequence, setReceiptSequence] = useState(1);

  useEffect(
    () => () => {
      if (proofImage) URL.revokeObjectURL(proofImage.previewUrl);
    },
    [proofImage],
  );

  useEffect(() => {
    let active = true;
    void fetch("/api/clientes", { cache: "no-store" })
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "No se pudieron cargar los clientes.");
        return data as Array<{
          id: number;
          nombre: string;
          apellido?: string;
          razon_social?: string;
          tipo_documento: string;
          documento: string;
          direccion?: string;
          email?: string;
          celular?: string;
        }>;
      })
      .then((customers) => {
        if (!active) return;
        setCatalog((current) => ({
          ...current,
          customers: customers.map((customer) => ({
            id: String(customer.id),
            nombre: customer.nombre,
            apellido: customer.apellido ?? null,
            razon_social: customer.razon_social ?? null,
            tipo_documento: customer.tipo_documento,
            documento: customer.documento,
            direccion: customer.direccion,
            email: customer.email ?? "",
            celular: customer.celular ?? "",
          })),
        }));
      })
      .catch(() => {
        // Conserva el catálogo demostrativo si el servicio de clientes no está disponible.
      });
    return () => {
      active = false;
    };
  }, []);

  const availableWarehouses = useMemo(
    () =>
      catalog?.warehouses.filter(
        (warehouse) =>
          !warehouse.sucursal_id || warehouse.sucursal_id === branchId,
      ) ?? [],
    [branchId, catalog],
  );
  const availablePoints = useMemo(
    () =>
      catalog?.emissionPoints.filter(
        (point) => point.sucursal_id === branchId,
      ) ?? [],
    [branchId, catalog],
  );
  const availableCashBoxes = useMemo(
    () =>
      catalog?.cashBoxes.filter(
        (box) => !box.sucursal_id || box.sucursal_id === branchId,
      ) ?? [],
    [branchId, catalog],
  );
  const destinations: CatalogOption[] =
    destinationType === "cash"
      ? availableCashBoxes
      : (catalog?.bankAccounts ?? []).map((account) => ({
          id: account.id,
          nombre: `${account.banco} · ${account.numero_cuenta}`,
        }));

  const filteredProducts = useMemo(() => {
    const normalized = search
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLocaleLowerCase("es")
      .trim();
    return (catalog?.products ?? []).filter((product) =>
      `${product.codigo} ${product.codigo_barras} ${product.nombre}`
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLocaleLowerCase("es")
        .includes(normalized),
    );
  }, [catalog, search]);
  const hasProductSearch = search.trim().length > 0;
  const productPageCount = hasProductSearch
    ? Math.max(1, Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE))
    : 1;
  const visibleProducts = hasProductSearch
    ? filteredProducts.slice(
        (productPage - 1) * PRODUCTS_PER_PAGE,
        productPage * PRODUCTS_PER_PAGE,
      )
    : [];
  const firstVisibleProduct =
    hasProductSearch && filteredProducts.length
      ? (productPage - 1) * PRODUCTS_PER_PAGE + 1
      : 0;
  const lastVisibleProduct = hasProductSearch
    ? Math.min(productPage * PRODUCTS_PER_PAGE, filteredProducts.length)
    : 0;

  const cartDetails = cart
    .map((line) => {
      const product = catalog?.products.find(
        (item) => item.id === line.productId,
      );
      const tax = catalog?.taxes.find((item) => item.id === line.taxId);
      if (!product || !tax) return null;
      const quantity = Number(line.quantity);
      const validQuantity = Number.isFinite(quantity) && quantity > 0;
      const base = validQuantity
        ? roundMoney(Number(product.precio_venta) * quantity)
        : 0;
      const taxAmount = roundMoney(
        (base * Number(tax.porcentaje)) / 100,
      );
      return {
        line,
        product,
        tax,
        validQuantity,
        base,
        taxAmount,
        total: roundMoney(base + taxAmount),
      };
    })
    .filter((entry): entry is NonNullable<typeof entry> => entry !== null);
  const subtotal = roundMoney(
    cartDetails.reduce((sum, item) => sum + item.base, 0),
  );
  const taxTotal = roundMoney(
    cartDetails.reduce((sum, item) => sum + item.taxAmount, 0),
  );
  const total = roundMoney(subtotal + taxTotal);
  const configurationIssues = catalog
    ? [
        !catalog.branches.length && "No hay sucursales activas.",
        !availablePoints.length &&
          "Elige una sucursal con punto de emisión y numeración de factura activos.",
        !availableWarehouses.length &&
          "No hay bodegas activas para la sucursal seleccionada.",
        !catalog.taxes.length && "No hay impuestos IVA vigentes configurados.",
        !catalog.paymentMethods.length &&
          "No hay formas de pago inmediato activas.",
        !availableCashBoxes.length && !catalog.bankAccounts.length &&
          "No hay cajas ni cuentas bancarias activas para registrar el cobro.",
      ].filter((issue): issue is string => Boolean(issue))
    : [];

  const stockFor = (product: CatalogProduct, selectedWarehouse = warehouseId) =>
    Number(
      product.stock_by_warehouse.find(
        (stock) => stock.warehouseId === selectedWarehouse,
      )?.quantity ?? 0,
    );
  const cartHasInvalidLines =
    cartDetails.length !== cart.length ||
    cartDetails.some(
      ({ line, product, validQuantity }) =>
        !validQuantity ||
        (product.controla_stock && Number(line.quantity) > stockFor(product)),
    );
  const checkoutSteps = [
    {
      label: "Productos y stock disponible",
      complete: cart.length > 0 && !cartHasInvalidLines,
    },
    {
      label: "Sucursal, punto de emisión y bodega",
      complete:
        catalog.branches.some((branch) => branch.id === branchId) &&
        availablePoints.some((point) => point.id === emissionPointId) &&
        availableWarehouses.some((warehouse) => warehouse.id === warehouseId),
    },
    {
      label: "Forma de pago y destino",
      complete:
        catalog.paymentMethods.some((method) => method.id === paymentMethodId) &&
        destinations.some((destination) => destination.id === destinationId) &&
        (destinationType !== "bank" || Boolean(proofImage)),
    },
  ];
  const checkoutReady = checkoutSteps.every((step) => step.complete);

  const addProduct = (product: CatalogProduct) => {
    if (!catalog?.taxes.length) {
      setError("Configura al menos un impuesto IVA vigente antes de vender.");
      return;
    }

    const currentQuantity = Number(
      cart.find((line) => line.productId === product.id)?.quantity ?? 0,
    );
    if (
      product.controla_stock &&
      currentQuantity + 1 > stockFor(product)
    ) {
      setError(
        `Stock insuficiente para ${product.nombre}. Disponible: ${stockFor(product)}.`,
      );
      return;
    }

    setError("");
    setReceipt(null);
    setCart((current) => {
      const existing = current.find((line) => line.productId === product.id);
      if (existing) {
        return current.map((line) =>
          line.productId === product.id
            ? { ...line, quantity: String(Number(line.quantity) + 1) }
            : line,
        );
      }
      return [
        ...current,
        {
          productId: product.id,
          quantity: "1",
          taxId: catalog.taxes[0].id,
        },
      ];
    });
  };

  const scanProduct = (scannedCode: string) => {
    const normalizedCode = scannedCode.trim().toLocaleLowerCase("es");
    if (!normalizedCode) return;

    const product = catalog.products.find((item) =>
      [item.codigo_barras, item.codigo].some(
        (code) => code.trim().toLocaleLowerCase("es") === normalizedCode,
      ),
    );
    setBarcode("");

    if (!product) {
      setSearch(scannedCode.trim());
      setProductPage(1);
      setError(`No encontramos el código "${scannedCode.trim()}".`);
      return;
    }

    addProduct(product);
    barcodeInputRef.current?.focus();
  };

  const continueElectronicInvoicing = () => {
    if (!receipt) return;

    const taxCodes = new Map<number, string>([
      [0, "0"],
      [12, "2"],
      [14, "3"],
      [15, "4"],
    ]);
    const invoiceDetails: DetalleFormValues[] = [];

    for (const item of receipt.items) {
      const taxCode = taxCodes.get(item.taxPercent);
      if (taxCode === undefined) {
        setError(
          `No se puede preparar la factura: el IVA ${item.taxPercent}% no tiene código tributario configurado.`,
        );
        return;
      }
      invoiceDetails.push({
        codigo_principal: item.code,
        codigo_auxiliar: item.barcode,
        descripcion: item.name,
        cantidad: item.quantity,
        precio_unitario: item.unitPrice,
        descuento: 0,
        codigo_porcentaje_iva: taxCode,
      });
    }

    const invoiceDraft: QuickSaleInvoiceDraft = {
      saleNumber: receipt.number,
      paymentDestination: receipt.paymentDestination,
      form: {
        ambiente: "1",
        razon_social: receipt.companyLegalName,
        nombre_comercial: receipt.companyName,
        ruc: receipt.companyRuc,
        estab: receipt.establishmentCode,
        ptoEmi: receipt.emissionPointCode,
        secuencial: "1",
        direccion_matriz: receipt.companyAddress,
        fecha_emision: receipt.issueDate,
        direccion_establecimiento: receipt.companyAddress,
        contribuyente_especial: "",
        obligado_contabilidad: "NO",
        tipo_identificacion_comprador: receipt.customerDocumentType,
        guia_remision: "",
        razon_social_comprador: receipt.customerName,
        identificacion_comprador:
          receipt.customerDocument || "9999999999999",
        direccion_comprador: receipt.customerAddress,
        propina: 0,
        moneda: "DOLAR",
        forma_pago: receipt.paymentCode,
      },
      detalles: invoiceDetails,
    };

    try {
      sessionStorage.setItem(
        QUICK_SALE_INVOICE_DRAFT_KEY,
        JSON.stringify(invoiceDraft),
      );
    } catch {
      setError("No se pudo preparar el borrador de factura en esta sesión.");
      return;
    }

    setError("");
    router.push("/facturas");
  };

  const updateLine = (productId: string, patch: Partial<CartLine>) => {
    setCart((current) =>
      current.map((line) =>
        line.productId === productId ? { ...line, ...patch } : line,
      ),
    );
    setError("");
  };

  const changeBranch = (nextBranchId: string) => {
    setBranchId(nextBranchId);
    const nextPoint = catalog?.emissionPoints.find(
      (point) => point.sucursal_id === nextBranchId,
    );
    const nextWarehouse = catalog?.warehouses.find(
      (warehouse) =>
        !warehouse.sucursal_id || warehouse.sucursal_id === nextBranchId,
    );
    const nextBox = catalog?.cashBoxes.find(
      (box) => !box.sucursal_id || box.sucursal_id === nextBranchId,
    );
    setEmissionPointId(nextPoint?.id ?? "");
    setWarehouseId(nextWarehouse?.id ?? "");
    if (destinationType === "cash") setDestinationId(nextBox?.id ?? "");
  };

  const changeWarehouse = (nextWarehouseId: string) => {
    setWarehouseId(nextWarehouseId);
    setError("");
  };

  const changeDestinationType = (nextType: "cash" | "bank") => {
    setDestinationType(nextType);
    if (nextType === "cash") {
      setProofImage(null);
      if (proofImageInputRef.current) proofImageInputRef.current.value = "";
    }
    const nextDestination =
      nextType === "cash"
        ? availableCashBoxes[0]?.id
        : catalog?.bankAccounts[0]?.id;
    setDestinationId(nextDestination ?? "");
  };

  const handleProofImageChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.currentTarget.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setProofImage(null);
      setError("Selecciona un archivo de imagen para el comprobante.");
      event.currentTarget.value = "";
      return;
    }
    setProofImage({ file, previewUrl: URL.createObjectURL(file) });
    setError("");
  };

  const changeCustomer = (nextCustomerId: string) => {
    setCustomerId(nextCustomerId);
    const customer = catalog.customers.find((item) => item.id === nextCustomerId);
    setCustomerEmail(customer?.email ?? "");
    setCustomerCellphone(customer?.celular ?? "");
    setError("");
  };

  const submitSale = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (cart.length === 0) {
      setError("Agrega al menos un producto antes de cobrar.");
      return;
    }
    if (!branchId || !emissionPointId || !warehouseId || !paymentMethodId || !destinationId) {
      setError("Completa la sucursal, punto de emisión, bodega y datos de pago.");
      return;
    }
    if (destinationType === "bank" && !proofImage) {
      setError("Adjunta la imagen del comprobante para registrar el ingreso en cuenta.");
      return;
    }

    for (const line of cart) {
      const product = catalog.products.find(
        (item) => item.id === line.productId,
      );
      const quantity = Number(line.quantity);
      if (!product || !Number.isFinite(quantity) || quantity <= 0) {
        setError("Revisa las cantidades del carrito; deben ser mayores que cero.");
        return;
      }
      if (product.controla_stock && quantity > stockFor(product)) {
        setError(
          `Stock insuficiente para ${product.nombre}. Disponible: ${stockFor(product)}.`,
        );
        return;
      }
    }

    const selectedCustomer = catalog.customers.find(
      (customer) => customer.id === customerId,
    );
    if (selectedCustomer && customerEmail &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(customerEmail)) {
      setError("Ingresa un correo electrónico válido para el cliente.");
      return;
    }
    const selectedPaymentMethod = catalog.paymentMethods.find(
      (method) => method.id === paymentMethodId,
    );
    const selectedDestination = destinations.find(
      (destination) => destination.id === destinationId,
    );
    const selectedBranch = catalog.branches.find(
      (branch) => branch.id === branchId,
    );
    const selectedEmissionPoint = catalog.emissionPoints.find(
      (point) => point.id === emissionPointId,
    );
    const receiptNumber = `DEMO-${String(receiptSequence).padStart(6, "0")}`;

    if (selectedCustomer) {
      const contactResponse = await fetch("/api/clientes", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: Number(selectedCustomer.id),
          email: customerEmail,
          celular: customerCellphone,
        }),
      });
      const contactData = await contactResponse.json().catch(() => ({}));
      if (!contactResponse.ok && contactResponse.status !== 404) {
        setError(contactData.error || "No se pudo actualizar el correo y celular del cliente.");
        return;
      }
      if (contactResponse.ok) {
        setCatalog((current) => ({
          ...current,
          customers: current.customers.map((customer) =>
            customer.id === selectedCustomer.id
              ? { ...customer, email: customerEmail, celular: customerCellphone }
              : customer,
          ),
        }));
      }
    }

    setSaving(true);
    setError("");
    setReceipt(null);
    await new Promise<void>((resolve) => window.setTimeout(resolve, 450));
    const issuedAt = new Date();
    setReceipt({
      number: receiptNumber,
      date: issuedAt.toLocaleString("es-EC"),
      issueDate: issuedAt.toISOString().slice(0, 10),
      companyName: catalog.company.nombre_comercial || catalog.company.nombre_legal,
      companyLegalName: catalog.company.nombre_legal,
      companyRuc: catalog.company.ruc,
      companyAddress: `${catalog.company.direccion}, ${catalog.company.ciudad}`,
      establishmentCode: selectedBranch?.codigo ?? "001",
      emissionPointCode: selectedEmissionPoint?.codigo ?? "001",
      customerName: selectedCustomer
        ? customerLabel(selectedCustomer)
        : "Consumidor final",
      customerDocument: selectedCustomer?.documento ?? "",
      customerDocumentType: selectedCustomer
        ? selectedCustomer.tipo_documento === "RUC"
          ? "04"
          : selectedCustomer.tipo_documento === "CEDULA"
            ? "05"
            : "06"
        : "07",
      customerAddress: selectedCustomer?.direccion ?? "",
      paymentMethod: selectedPaymentMethod?.nombre ?? "No especificado",
      paymentCode: selectedPaymentMethod?.codigo === "EFE" ? "01" : "20",
      paymentDestination: `${destinationType === "cash" ? "Caja" : "Cuenta bancaria"} · ${selectedDestination?.nombre ?? ""}`,
      items: cartDetails.map(({ line, product, tax, total: lineTotal }) => ({
        code: product.codigo,
        barcode: product.codigo_barras,
        name: product.nombre,
        quantity: Number(line.quantity),
        unitPrice: Number(product.precio_venta),
        taxPercent: Number(tax.porcentaje),
        total: lineTotal,
      })),
      subtotal,
      taxTotal,
      total,
    });
    setReceiptSequence((current) => current + 1);
    setCart([]);
    setSearch("");
    setBarcode("");
    setProofImage(null);
    if (proofImageInputRef.current) proofImageInputRef.current.value = "";
    setSaving(false);
  };

  return (
    <main className="quick-sale-page">
      <header className="quick-sale-header">
        <div>
          <p className="quick-sale-eyebrow">PUNTO DE VENTA</p>
          <h1>Venta rápida</h1>
          <p>Agrega productos, confirma el cobro y registra la salida de inventario.</p>
        </div>
        <div className="quick-sale-company">
          <strong>{catalog?.company.nombre_comercial || catalog?.company.nombre_legal}</strong>
          <span>RUC {catalog?.company.ruc}</span>
        </div>
      </header>

      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}
      {receipt && (
        <div className="quick-sale-success" role="status">
          <div>
            <strong>Simulación completada: {receipt.number}</strong>
            <span>
              Total simulado {money.format(receipt.total)}. No se guardó la venta ni
              se modificaron el inventario o la caja.
            </span>
          </div>
          <div className="quick-sale-success-actions">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => window.print()}
            >
              Imprimir factura
            </button>
            <button
              type="button"
              className="btn btn-outline-success"
              onClick={continueElectronicInvoicing}
            >
              Facturar electrónicamente
            </button>
            <button
              type="button"
              className="btn btn-outline-success"
              onClick={() => setReceipt(null)}
            >
              Nueva venta
            </button>
          </div>
        </div>
      )}
      {receipt && (
        <article className="quick-sale-print-receipt" aria-label="Factura de venta">
          <header className="quick-sale-receipt-header">
            <h2>{receipt.companyName}</h2>
            <p>RUC {receipt.companyRuc}</p>
            <p>{receipt.companyAddress}</p>
            <strong>FACTURA DE VENTA · DEMOSTRACIÓN</strong>
          </header>
          <dl className="quick-sale-receipt-meta">
            <div>
              <dt>Número</dt>
              <dd>{receipt.number}</dd>
            </div>
            <div>
              <dt>Fecha</dt>
              <dd>{receipt.date}</dd>
            </div>
            <div>
              <dt>Cliente</dt>
              <dd>{receipt.customerName}</dd>
            </div>
            {receipt.customerDocument && (
              <div>
                <dt>Documento</dt>
                <dd>{receipt.customerDocument}</dd>
              </div>
            )}
          </dl>
          <table className="quick-sale-receipt-items">
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cant.</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {receipt.items.map((item) => (
                <tr key={item.code}>
                  <td>
                    <strong>{item.name}</strong>
                    <small>{item.code} · {money.format(item.unitPrice)} c/u</small>
                  </td>
                  <td>{item.quantity}</td>
                  <td>{money.format(item.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <dl className="quick-sale-receipt-totals">
            <div>
              <dt>Subtotal</dt>
              <dd>{money.format(receipt.subtotal)}</dd>
            </div>
            <div>
              <dt>Impuestos</dt>
              <dd>{money.format(receipt.taxTotal)}</dd>
            </div>
            <div>
              <dt>Total</dt>
              <dd>{money.format(receipt.total)}</dd>
            </div>
          </dl>
          <div className="quick-sale-receipt-payment">
            <span>Forma de pago: {receipt.paymentMethod}</span>
            <span>Ingreso en: {receipt.paymentDestination}</span>
          </div>
          <footer>
            Vista de demostración. No es una factura fiscal; esta venta no fue
            guardada ni transmitida al SRI.
          </footer>
        </article>
      )}
      <div className="quick-sale-demo-banner" role="status">
        <strong>Modo demostración</strong>
        <span>
          Puedes recorrer el flujo completo; no se insertan datos en tablas ni se
          modifica el inventario.
        </span>
      </div>
      {configurationIssues.length > 0 && (
        <div className="alert alert-warning" role="alert">
          <strong>No puedes completar una venta todavía:</strong>
          <ul className="mb-0 mt-1">
            {configurationIssues.map((issue) => (
              <li key={issue}>{issue}</li>
            ))}
          </ul>
        </div>
      )}

      <form className="quick-sale-layout" onSubmit={submitSale}>
          <div className="quick-sale-workspace">
            <section className="quick-sale-panel quick-sale-products">
              <div className="quick-sale-panel-heading">
                <div>
                  <h2>Productos</h2>
                  <p>Escanea un código o busca por nombre o código.</p>
                </div>
                <span className="quick-sale-count">
                  {hasProductSearch
                    ? `${filteredProducts.length} resultados`
                    : "Busca para iniciar"}
                </span>
              </div>
              <label className="quick-sale-scanner">
                <span>Escáner de código de barras</span>
                <div className="quick-sale-search">
                  <input
                    ref={barcodeInputRef}
                    type="text"
                    autoComplete="off"
                    aria-label="Escanear código de barras"
                    placeholder="Escanea o escribe el código y pulsa Enter..."
                    value={barcode}
                    onChange={(event) => {
                      setBarcode(event.target.value);
                      setError("");
                    }}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") {
                        event.preventDefault();
                        scanProduct(barcode);
                      }
                    }}
                  />
                  <kbd>Enter</kbd>
                </div>
                <small>
                  El lector USB funciona como teclado: escanea y termina con Enter.
                </small>
              </label>
              <label className="quick-sale-search">
                <Search size={18} aria-hidden="true" />
                <span className="visually-hidden">Buscar productos</span>
                <input
                  type="search"
                  placeholder="Nombre, código interno o de barras..."
                  value={search}
                  onChange={(event) => {
                    setSearch(event.target.value);
                    setProductPage(1);
                  }}
                />
              </label>
              <div className="quick-sale-product-list">
                {!hasProductSearch ? (
                  <div className="quick-sale-empty">
                    <Search size={22} aria-hidden="true" />
                    <strong>Busca un producto para empezar</strong>
                    <span>
                      Escribe su nombre o código; aquí aparecerán solo las
                      coincidencias.
                    </span>
                  </div>
                ) : filteredProducts.length ? (
                  visibleProducts.map((product) => {
                    const stock = stockFor(product);
                    const quantityInCart = Number(
                      cart.find((line) => line.productId === product.id)?.quantity ?? 0,
                    );
                    const stockUnavailable =
                      product.controla_stock && stock <= quantityInCart;
                    return (
                      <article className="quick-sale-product" key={product.id}>
                        <div className="quick-sale-product-copy">
                          <span className="quick-sale-product-code">{product.codigo}</span>
                          <strong>{product.nombre}</strong>
                          <span className="quick-sale-product-stock">
                            {product.controla_stock
                              ? `${Math.max(0, stock - quantityInCart)} disponibles`
                              : "No controla stock"}
                          </span>
                        </div>
                        <div className="quick-sale-product-action">
                          <strong>{money.format(Number(product.precio_venta))}</strong>
                          <button
                            type="button"
                            className="btn btn-primary btn-sm"
                            onClick={() => addProduct(product)}
                            disabled={stockUnavailable || saving || !catalog.taxes.length}
                            aria-label={`Agregar ${product.nombre}`}
                          >
                            <CirclePlus size={16} aria-hidden="true" />
                            Agregar
                          </button>
                        </div>
                      </article>
                    );
                  })
                ) : (
                  <div className="quick-sale-empty">
                    No encontramos productos con esa búsqueda.
                  </div>
                )}
              </div>
              {hasProductSearch && productPageCount > 1 && (
                <nav
                  className="quick-sale-product-pagination"
                  aria-label="Paginación de productos"
                >
                  <span aria-live="polite">
                    Mostrando {firstVisibleProduct}-{lastVisibleProduct} de{" "}
                    {filteredProducts.length}
                  </span>
                  <div>
                    <button
                      type="button"
                      className="btn btn-outline-secondary btn-sm"
                      aria-label="Productos anteriores"
                      onClick={() =>
                        setProductPage((current) => Math.max(1, current - 1))
                      }
                      disabled={productPage === 1}
                    >
                      <ChevronLeft size={16} aria-hidden="true" />
                      Anterior
                    </button>
                    <span className="quick-sale-product-page-number">
                      Página {productPage} de {productPageCount}
                    </span>
                    <button
                      type="button"
                      className="btn btn-outline-secondary btn-sm"
                      aria-label="Más productos"
                      onClick={() =>
                        setProductPage((current) =>
                          Math.min(productPageCount, current + 1),
                        )
                      }
                      disabled={productPage === productPageCount}
                    >
                      Siguiente
                      <ChevronRight size={16} aria-hidden="true" />
                    </button>
                  </div>
                </nav>
              )}
            </section>

            <section className="quick-sale-panel quick-sale-cart">
              <div className="quick-sale-panel-heading">
                <div>
                  <h2>Carrito</h2>
                  <p>Revisa cantidades e impuestos antes de cobrar.</p>
                </div>
                <span className="quick-sale-count">
                  {cart.length} {cart.length === 1 ? "producto" : "productos"}
                </span>
              </div>
              {cart.length ? (
                <div className="quick-sale-cart-list">
                  {cartDetails.map(({ line, product, validQuantity, base, total: lineTotal }) => {
                    const available = stockFor(product);
                    const quantity = Number(line.quantity);
                    const tooMany =
                      product.controla_stock &&
                      Number.isFinite(quantity) &&
                      quantity > available;
                    return (
                      <article className="quick-sale-cart-item" key={product.id}>
                        <div className="quick-sale-cart-item-main">
                          <div>
                            <strong>{product.nombre}</strong>
                            <span>{money.format(Number(product.precio_venta))} c/u</span>
                          </div>
                          <button
                            type="button"
                            className="quick-sale-remove"
                            onClick={() =>
                              setCart((current) =>
                                current.filter((entry) => entry.productId !== product.id),
                              )
                            }
                            aria-label={`Quitar ${product.nombre}`}
                            disabled={saving}
                          >
                            <Trash2 size={17} />
                          </button>
                        </div>
                        <div className="quick-sale-cart-controls">
                          <div className="quick-sale-quantity">
                            <button
                              type="button"
                              aria-label={`Reducir cantidad de ${product.nombre}`}
                              onClick={() => {
                                const nextQuantity = Math.max(0, quantity - 1);
                                if (nextQuantity === 0) {
                                  setCart((current) =>
                                    current.filter((entry) => entry.productId !== product.id),
                                  );
                                } else {
                                  updateLine(product.id, { quantity: String(nextQuantity) });
                                }
                              }}
                              disabled={saving || !Number.isFinite(quantity) || quantity <= 1}
                            >
                              <Minus size={14} />
                            </button>
                            <input
                              type="number"
                              min="0.0001"
                              step="0.0001"
                              aria-label={`Cantidad de ${product.nombre}`}
                              value={line.quantity}
                              onChange={(event) =>
                                updateLine(product.id, { quantity: event.target.value })
                              }
                              aria-invalid={tooMany || !validQuantity}
                            />
                            <button
                              type="button"
                              aria-label={`Aumentar cantidad de ${product.nombre}`}
                              onClick={() => {
                                const nextQuantity = quantity + 1;
                                if (product.controla_stock && nextQuantity > available) {
                                  setError(
                                    `Stock insuficiente para ${product.nombre}. Disponible: ${available}.`,
                                  );
                                  return;
                                }
                                updateLine(product.id, { quantity: String(nextQuantity) });
                              }}
                              disabled={
                                saving ||
                                (product.controla_stock && quantity >= available)
                              }
                            >
                              <Plus size={14} />
                            </button>
                          </div>
                          <label className="quick-sale-tax">
                            <span>IVA</span>
                            <select
                              value={line.taxId}
                              onChange={(event) =>
                                updateLine(product.id, { taxId: event.target.value })
                              }
                              aria-label={`Impuesto de ${product.nombre}`}
                            >
                              {catalog.taxes.map((taxOption) => (
                                <option key={taxOption.id} value={taxOption.id}>
                                  {taxOption.nombre} ({taxOption.porcentaje}%)
                                </option>
                              ))}
                            </select>
                          </label>
                          <div className="quick-sale-line-total">
                            <span>Base {money.format(base)}</span>
                            <strong>{money.format(lineTotal)}</strong>
                          </div>
                        </div>
                        {!validQuantity && (
                          <small className="text-danger">
                            Ingresa una cantidad mayor que cero.
                          </small>
                        )}
                        {tooMany && (
                          <small className="text-danger">
                            Solo hay {available} unidades en la bodega seleccionada.
                          </small>
                        )}
                      </article>
                    );
                  })}
                </div>
              ) : (
                <div className="quick-sale-empty quick-sale-cart-empty">
                  <ShoppingCart size={26} aria-hidden="true" />
                  <strong>Tu carrito está vacío</strong>
                  <span>Agrega productos para calcular el total de la venta.</span>
                </div>
              )}
            </section>
          </div>

          <aside className="quick-sale-checkout">
            <section className="quick-sale-panel">
              <div className="quick-sale-panel-heading">
                <div>
                  <h2>Datos de la venta</h2>
                  <p>Elige dónde se registra esta operación.</p>
                </div>
              </div>
              <label className="quick-sale-field">
                <span>Sucursal</span>
                <select
                  required
                  value={branchId}
                  onChange={(event) => changeBranch(event.target.value)}
                >
                  <option value="">Selecciona una sucursal</option>
                  {catalog.branches.map((branch) => (
                    <option key={branch.id} value={branch.id}>
                      {branch.codigo} · {branch.nombre}
                    </option>
                  ))}
                </select>
              </label>
              <label className="quick-sale-field">
                <span>Punto de emisión</span>
                <select
                  required
                  value={emissionPointId}
                  onChange={(event) => setEmissionPointId(event.target.value)}
                >
                  <option value="">Selecciona un punto</option>
                  {availablePoints.map((point) => (
                    <option key={point.id} value={point.id}>
                      {point.codigo} · {point.nombre}
                    </option>
                  ))}
                </select>
              </label>
              <label className="quick-sale-field">
                <span>Bodega de salida</span>
                <select
                  required
                  value={warehouseId}
                  onChange={(event) => changeWarehouse(event.target.value)}
                >
                  <option value="">Selecciona una bodega</option>
                  {availableWarehouses.map((warehouse) => (
                    <option key={warehouse.id} value={warehouse.id}>
                      {warehouse.codigo} · {warehouse.nombre}
                    </option>
                  ))}
                </select>
              </label>
              <label className="quick-sale-field">
                <span>Cliente</span>
                <select
                  value={customerId}
                  onChange={(event) => changeCustomer(event.target.value)}
                >
                  <option value="">Consumidor final</option>
                  {catalog.customers.map((customer) => (
                    <option key={customer.id} value={customer.id}>
                      {customerLabel(customer)} · {customer.documento}
                    </option>
                  ))}
                </select>
              </label>
              {customerId && (
                <div className="row g-2">
                  <label className="quick-sale-field col-md-6">
                    <span>Correo del cliente</span>
                    <input
                      type="email"
                      value={customerEmail}
                      onChange={(event) => {
                        setCustomerEmail(event.target.value);
                        setError("");
                      }}
                      placeholder="cliente@correo.com"
                      autoComplete="email"
                    />
                  </label>
                  <label className="quick-sale-field col-md-6">
                    <span>Celular del cliente</span>
                    <input
                      type="tel"
                      value={customerCellphone}
                      onChange={(event) => {
                        setCustomerCellphone(event.target.value);
                        setError("");
                      }}
                      placeholder="0999999999"
                      autoComplete="tel"
                    />
                  </label>
                </div>
              )}
            </section>

            <section className="quick-sale-panel">
              <div className="quick-sale-panel-heading">
                <div>
                  <h2>Cobro</h2>
                  <p>El pago quedará vinculado a la factura.</p>
                </div>
              </div>
              <label className="quick-sale-field">
                <span>Forma de pago</span>
                <select
                  required
                  value={paymentMethodId}
                  onChange={(event) => setPaymentMethodId(event.target.value)}
                >
                  <option value="">Selecciona una forma de pago</option>
                  {catalog.paymentMethods.map((method) => (
                    <option key={method.id} value={method.id}>
                      {method.nombre}
                    </option>
                  ))}
                </select>
              </label>
              <fieldset className="quick-sale-destination">
                <legend>Registrar ingreso en</legend>
                <div>
                  <label>
                    <input
                      type="radio"
                      name="destinationType"
                      value="cash"
                      checked={destinationType === "cash"}
                      onChange={() => changeDestinationType("cash")}
                      disabled={!availableCashBoxes.length}
                    />
                    Caja
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="destinationType"
                      value="bank"
                      checked={destinationType === "bank"}
                      onChange={() => changeDestinationType("bank")}
                      disabled={!catalog.bankAccounts.length}
                    />
                    Cuenta bancaria
                  </label>
                </div>
              </fieldset>
              <label className="quick-sale-field">
                <span>{destinationType === "cash" ? "Caja" : "Cuenta bancaria"}</span>
                <select
                  required
                  value={destinationId}
                  onChange={(event) => setDestinationId(event.target.value)}
                  disabled={!destinations.length}
                >
                  <option value="">
                    {destinations.length
                      ? "Selecciona un destino"
                      : "No hay destinos activos para esta sucursal"}
                  </option>
                  {destinations.map((destination) => (
                    <option key={destination.id} value={destination.id}>
                      {destination.codigo
                        ? `${destination.codigo} · ${destination.nombre}`
                        : destination.nombre}
                    </option>
                  ))}
                </select>
              </label>
              {destinationType === "bank" && (
                <div className="quick-sale-proof">
                  <div className="quick-sale-proof-heading">
                    <div>
                      <strong>
                        Comprobante de ingreso <span aria-hidden="true">*</span>
                      </strong>
                      <p>Adjunta una imagen del depósito o transferencia.</p>
                    </div>
                    <label className="quick-sale-proof-upload">
                      <input
                        ref={proofImageInputRef}
                        type="file"
                        accept="image/*"
                        aria-label="Subir imagen del comprobante"
                        aria-required="true"
                        onChange={handleProofImageChange}
                      />
                      <span>
                        <Upload size={16} aria-hidden="true" />
                        {proofImage ? "Cambiar" : "Subir imagen"}
                      </span>
                    </label>
                  </div>
                  {proofImage ? (
                    <div className="quick-sale-proof-preview">
                      <Image
                        src={proofImage.previewUrl}
                        alt="Vista previa del comprobante cargado"
                        width={64}
                        height={64}
                        unoptimized
                      />
                      <div>
                        <strong title={proofImage.file.name}>
                          {proofImage.file.name}
                        </strong>
                        <span>Vista previa local · no se guarda</span>
                      </div>
                      <button
                        type="button"
                        className="quick-sale-proof-remove"
                        aria-label="Quitar comprobante"
                        onClick={() => {
                          setProofImage(null);
                          if (proofImageInputRef.current) {
                            proofImageInputRef.current.value = "";
                          }
                        }}
                      >
                        <Trash2 size={16} aria-hidden="true" />
                      </button>
                    </div>
                  ) : (
                    <p className="quick-sale-proof-hint">
                      La imagen es obligatoria para este destino y solo se
                      mostrará durante la demostración.
                    </p>
                  )}
                </div>
              )}
            </section>

            <section className="quick-sale-panel quick-sale-total-panel">
              <div
                id="quick-sale-readiness"
                className="alert alert-info py-2 mb-3"
                aria-live="polite"
              >
                <strong>
                  Preparación para cobrar: {checkoutSteps.filter((step) => step.complete).length} de{" "}
                  {checkoutSteps.length} pasos
                </strong>
                <ul className="small mb-0 mt-1 ps-3">
                  {checkoutSteps.map((step) => (
                    <li key={step.label}>
                      <span className={`badge me-1 ${step.complete ? "text-bg-success" : "text-bg-secondary"}`}>
                        {step.complete ? "Listo" : "Pendiente"}
                      </span>
                      {step.label}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="quick-sale-total-row">
                <span>Subtotal</span>
                <strong>{money.format(subtotal)}</strong>
              </div>
              <div className="quick-sale-total-row">
                <span>Impuestos</span>
                <strong>{money.format(taxTotal)}</strong>
              </div>
              <div className="quick-sale-total-row quick-sale-grand-total">
                <span>Total a cobrar</span>
                <strong>{money.format(total)}</strong>
              </div>
              <button
                type="submit"
                className="btn btn-primary quick-sale-submit"
                disabled={
                  saving ||
                  !checkoutReady ||
                  !catalog.taxes.length
                }
                aria-describedby="quick-sale-readiness"
              >
                {saving ? (
                  <>
                    <span className="spinner-border spinner-border-sm" aria-hidden="true" />
                    Registrando venta...
                  </>
                ) : (
                  <>
                    <ShoppingCart size={18} aria-hidden="true" />
                    Completar venta demo · {money.format(total)}
                  </>
                )}
              </button>
              <p className="quick-sale-sri-note">
                En este modo no se envía nada al SRI ni se guarda ningún movimiento
                de caja o inventario.
              </p>
            </section>
          </aside>
      </form>
    </main>
  );
}
