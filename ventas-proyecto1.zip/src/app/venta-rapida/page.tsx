import { AppShell } from "@/components/app-shell";
import QuickSalePage from "./QuickSalePage";

export default function Page() {
  return (
    <AppShell>
      <QuickSalePage />
    </AppShell>
  );
}
