"use client";

import React, { useState, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import { CirclePlus, ShoppingCart, SquarePen, Trash2 } from "lucide-react";
import { SolicitudCompra, SolicitudesCompraFormValues } from "./types";
import SolicitudesCompraModal from "./SolicitudesCompraModal";
import "../compras-ui.css";

const INITIAL: SolicitudesCompraFormValues = {
  numero_solicitud: "",
  fecha_solicitud: "",
  solicitante: "",
  departamento: "",
  centro_costo: "",
  prioridad: "NORMAL",
  estado: "BORRADOR",
  total_estimado: 0,
  justificacion: "",
};

const ESTADOS = [
  "BORRADOR", "PENDIENTE_APROBACION", "APROBADA", "RECHAZADA", "CONVERTIDA_OC", "CANCELADA",
];

export default function SolicitudesCompraPage() {
  const router = useRouter();
  const [data, setData] = useState<SolicitudCompra[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [storageError, setStorageError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editando, setEditando] = useState(false);
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [form, setForm] = useState<SolicitudesCompraFormValues>(INITIAL);
  const [filtro, setFiltro] = useState("");
  const [estadoFiltro, setEstadoFiltro] = useState("");
  const nextId = Math.max(0, ...data.map((solicitud) => solicitud.id)) + 1;

  const loadRequests = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/compras/solicitudes", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudieron cargar las solicitudes.");
      setData(result.data as SolicitudCompra[]);
      setStorageError("");
    } catch (loadError) {
      setData([]);
      setStorageError(loadError instanceof Error ? loadError.message : "Error al cargar las solicitudes.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void loadRequests(); }, [loadRequests]);

  const filtered = data.filter(
    (s) =>
      (!filtro || s.solicitante.toLowerCase().includes(filtro.toLowerCase()) || s.numero_solicitud.toLowerCase().includes(filtro.toLowerCase()) || s.departamento.toLowerCase().includes(filtro.toLowerCase())) &&
      (!estadoFiltro || s.estado === estadoFiltro)
  );
  const pendientesAprobacion = data.filter((solicitud) => solicitud.estado === "PENDIENTE_APROBACION").length;
  const solicitudesAprobadas = data.filter((solicitud) => solicitud.estado === "APROBADA").length;

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setForm((prev) => ({ ...prev, [name]: type === "number" ? parseFloat(value) || 0 : value }));
  }, []);

  const openNew = () => {
    setEditando(false);
    setCurrentId(null);
    setForm({
      ...INITIAL,
      numero_solicitud: `SC-${new Date().getFullYear()}-${String(nextId).padStart(3, "0")}`,
      fecha_solicitud: today(),
    });
    setModalOpen(true);
  };

  const openEdit = (s: SolicitudCompra) => {
    setEditando(true);
    setCurrentId(s.id);
    setForm({
      numero_solicitud: s.numero_solicitud,
      fecha_solicitud: s.fecha_solicitud,
      solicitante: s.solicitante,
      departamento: s.departamento,
      centro_costo: s.centro_costo,
      prioridad: s.prioridad,
      estado: s.estado,
      total_estimado: s.total_estimado,
      justificacion: s.justificacion,
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setStorageError("");
    try {
      const response = await fetch(
        editando && currentId !== null
          ? `/api/compras/solicitudes/${currentId}`
          : "/api/compras/solicitudes",
        {
          method: editando ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(form),
        },
      );
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo guardar la solicitud.");
      await loadRequests();
      setFiltro("");
      setEstadoFiltro("");
      setModalOpen(false);
    } catch (saveError) {
      setStorageError(saveError instanceof Error ? saveError.message : "Error al guardar la solicitud.");
    } finally {
      setSaving(false);
    }
  };

  const handleBuy = (solicitud: SolicitudCompra) => {
    if (solicitud.estado === "APROBADA") {
      router.push(`/cotizaciones?solicitudId=${solicitud.id}`);
    }
  };

  const handleDelete = async (id: number) => {
    if (!window.confirm("¿Eliminar esta solicitud en borrador?")) return;
    setStorageError("");
    try {
      const response = await fetch(`/api/compras/solicitudes/${id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo eliminar la solicitud.");
      await loadRequests();
    } catch (deleteError) {
      setStorageError(deleteError instanceof Error ? deleteError.message : "Error al eliminar la solicitud.");
    }
  };

  return (
    <div className="bootstrap-container purchase-page purchase-page--requests">
      <div className="content-wrapper">
      <header className="purchase-page-header">
        <div>
          <p className="purchase-eyebrow">GESTIÓN DE COMPRAS</p>
          <h1>Solicitudes de compra</h1>
          <p>Revisa las solicitudes, su prioridad y los pasos pendientes antes de generar una orden.</p>
        </div>
        <button className="btn btn-primary purchase-create-button" onClick={openNew} disabled={loading || saving}>
          <CirclePlus size={18} /> Nueva solicitud
        </button>
      </header>
      {storageError && <div className="alert alert-danger" role="alert">{storageError}</div>}

      <section className="purchase-summary-grid" aria-label="Resumen de solicitudes de compra">
        <article className="purchase-summary-card"><span>Solicitudes registradas</span><strong>{loading ? "—" : data.length}</strong></article>
        <article className="purchase-summary-card purchase-summary-card--warning"><span>Pendientes de aprobación</span><strong>{loading ? "—" : pendientesAprobacion}</strong></article>
        <article className="purchase-summary-card purchase-summary-card--success"><span>Aprobadas</span><strong>{loading ? "—" : solicitudesAprobadas}</strong></article>
      </section>

      <div className="purchase-toolbar">
        <div className="purchase-filter-controls">
          <input type="search" className="form-control purchase-search" aria-label="Buscar solicitudes de compra" placeholder="Buscar solicitante, número o departamento..." value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <select className="form-select purchase-status-filter" aria-label="Filtrar solicitudes por estado" value={estadoFiltro} onChange={(e) => setEstadoFiltro(e.target.value)}>
            <option value="">Todos los estados</option>
            {ESTADOS.map((estado) => <option key={estado} value={estado}>{estado.replace(/_/g, " ")}</option>)}
          </select>
        </div>
        <span className="purchase-result-count" role="status">Mostrando {filtered.length} de {data.length} solicitudes</span>
      </div>

      <div className="table-responsive purchase-table-wrap">
        <table className="table table-hover align-middle purchase-table">
          <thead>
            <tr>
              <th>N# Solicitud</th>
              <th>Fecha</th>
              <th>Solicitante</th>
              <th>Departamento</th>
              <th>Ítems</th>
              <th>Total Estimado</th>
              <th>Prioridad</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={9} className="text-center text-muted py-4">Cargando solicitudes...</td></tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={9} className="text-center text-muted py-4">Sin solicitudes registradas</td>
              </tr>
            ) : (
              filtered.map((s) => (
                <tr key={s.id}>
                  <td><strong>{s.numero_solicitud}</strong></td>
                  <td>{s.fecha_solicitud}</td>
                  <td>{s.solicitante}</td>
                  <td><span className="badge bg-secondary">{s.departamento}</span></td>
                  <td>{s.items_solicitados}</td>
                  <td className="fw-bold">${s.total_estimado.toFixed(2)}</td>
                  <td>
                    <span className={`purchase-badge purchase-badge--${getPriorityTone(s.prioridad)}`}>
                      {s.prioridad}
                    </span>
                  </td>
                  <td>
                    <span className={`purchase-badge purchase-badge--${getStatusTone(s.estado)}`}>
                      {s.estado.replace(/_/g, " ")}
                    </span>
                    <div className="purchase-status-context">{getSolicitudStatusContext(s.estado)}</div>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      {s.estado === "APROBADA" && <button className="btn btn-sm btn-outline-success" title="Crear cotización" aria-label={`Crear cotización desde ${s.numero_solicitud}`} onClick={() => handleBuy(s)}><ShoppingCart size={16} /></button>}
                      <button className="btn btn-sm btn-outline-primary" title="Editar" onClick={() => openEdit(s)} disabled={saving}><SquarePen size={16} /></button>
                      <button className="btn btn-sm btn-outline-danger" title="Eliminar" onClick={() => handleDelete(s.id)} disabled={saving}><Trash2 size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <SolicitudesCompraModal show={modalOpen} editando={editando} values={form} onChange={handleChange} onClose={() => setModalOpen(false)} onSubmit={handleSubmit} />
      </div>
    </div>
  );
}

function today(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}

function getSolicitudStatusContext(estado: string): string {
  const contextos: Record<string, string> = {
    BORRADOR: "Borrador interno",
    PENDIENTE_APROBACION: "Requiere revisión",
    APROBADA: "Lista para generar orden",
    RECHAZADA: "No aprobada",
    CONVERTIDA_OC: "Orden de compra generada",
    CANCELADA: "Solicitud cancelada",
  };
  return contextos[estado] ?? estado.replace(/_/g, " ");
}

function getStatusTone(estado: string): string {
  if (["RECHAZADA", "CANCELADA"].includes(estado)) return "danger";
  if (["APROBADA", "CONVERTIDA_OC"].includes(estado)) return "success";
  if (estado === "PENDIENTE_APROBACION") return "warning";
  return "neutral";
}

function getPriorityTone(prioridad: string): string {
  if (prioridad === "URGENTE") return "danger";
  if (prioridad === "ALTA") return "warning";
  if (prioridad === "BAJA") return "success";
  return "info";
}