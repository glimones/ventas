'use client';
import React, { useState, useCallback, useEffect } from 'react';
import { UnidadesMedida, UnidadesMedidaFormValues } from './types';
import UnidadesMedidaModal from './UnidadesMedidaModal';
import RegistroResumen, { type FiltroEstadoRegistro } from '@/components/registro-resumen';
import './bootstrap-unidades-medida.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: UnidadesMedidaFormValues = {
  codigo: '',
  nombre: '',
  abreviatura: '',
  estado: 'Activo',
};

export default function UnidadesMedidaPage() {
  const [data, setData] = useState<UnidadesMedida[]>([]);
  const [filtro, setFiltro] = useState<string>('');
  const [filtroEstado, setFiltroEstado] = useState<FiltroEstadoRegistro>('TODOS');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<UnidadesMedidaFormValues>(initialForm);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');

  const cargarUnidades = useCallback(async () => {
    setCargando(true);
    try {
      const response = await fetch('/api/unidades-medida', { cache: 'no-store' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudieron cargar las unidades.');
      setData(result.data as UnidadesMedida[]);
      setError('');
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Error al cargar unidades.');
    } finally { setCargando(false); }
  }, []);

  useEffect(() => { void cargarUnidades(); }, [cargarUnidades]);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = async () => {
    limpiarForm();
    try {
      const response = await fetch('/api/unidades-medida/siguiente-codigo', { cache: 'no-store' });
      const result = await response.json();
      if (response.ok && typeof result.codigo === 'string') {
        setForm((previous) => ({ ...previous, codigo: result.codigo }));
      }
    } catch {
      setError('No se pudo cargar el código secuencial.');
    }
    setShowModal(true);
  };

  const abrirModalEditar = (item: UnidadesMedida) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      nombre: item.nombre || '',
      abreviatura: item.abreviatura || '',
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(editandoId !== null ? `/api/unidades-medida/${editandoId}` : '/api/unidades-medida', {
        method: editandoId !== null ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo guardar la unidad.');
      await cargarUnidades();
      cerrarModal();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Error al guardar la unidad.');
    }
  };

  const eliminar = async (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      try {
        const response = await fetch(`/api/unidades-medida/${id}`, { method: 'DELETE' });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'No se pudo desactivar la unidad.');
        await cargarUnidades();
      } catch (deleteError) {
        setError(deleteError instanceof Error ? deleteError.message : 'Error al desactivar la unidad.');
      }
    }
  };

  const unidadesActivas = data.filter((item) =>
    (item.estado || '').toLocaleLowerCase().startsWith('activ'),
  ).length;
  const unidadesInactivas = data.filter((item) =>
    (item.estado || '').toLocaleLowerCase().startsWith('inactiv'),
  ).length;
  const filtered = data.filter((item) => {
    const termino = filtro.toLocaleLowerCase();
    const coincideBusqueda =
      !termino ||
      [item.codigo, item.nombre, item.abreviatura]
        .join(' ')
        .toLocaleLowerCase()
        .includes(termino);
    const estado = (item.estado || '').toLocaleLowerCase();
    const coincideEstado =
      filtroEstado === 'TODOS' ||
      (filtroEstado === 'ACTIVOS' && estado.startsWith('activ')) ||
      (filtroEstado === 'INACTIVOS' && estado.startsWith('inactiv'));
    return coincideBusqueda && coincideEstado;
  });

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Unidades de Medida</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <RegistroResumen
          total={data.length}
          activos={unidadesActivas}
          inactivos={unidadesInactivas}
          filtro={filtroEstado}
          cargando={cargando}
          onChange={setFiltroEstado}
        />
        {!cargando && (
          <p className='entity-result-count' role='status'>
            Mostrando {filtered.length} de {data.length} unidades
          </p>
        )}
        {error && <div className='alert alert-danger' role='alert'>{error}</div>}
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Abreviatura</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && <tr><td colSpan={6} className='text-center'>Cargando unidades...</td></tr>}
              {!cargando && filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className='text-center text-muted py-4'>
                    {error ? 'No se pudieron cargar las unidades' : 'No se encontraron registros'}
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.nombre}</td>
                  <td>{item.abreviatura}</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <UnidadesMedidaModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
