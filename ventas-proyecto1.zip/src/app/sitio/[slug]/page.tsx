import { notFound } from "next/navigation";
import { buscarEmpresaPorSlug } from "@/services/empresas.service";
import { listarProductosPublicadosPorEmpresa } from "@/services/productos.service";
import BusinessSite from "./site-page";

export const dynamic = "force-dynamic";

export default async function BusinessSiteRoute({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const company = await buscarEmpresaPorSlug(slug);

  if (!company) notFound();

  const publishedIds = company.contenido_sitio?.productos_publicados_ids ?? [];
  const productos = await listarProductosPublicadosPorEmpresa(company.id, publishedIds);

  return <BusinessSite company={company} productos={productos} />;
}