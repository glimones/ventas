import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight, Store } from "lucide-react";
import { listarEmpresasActivas } from "@/services/empresas.service";
import { siteTemplates } from "./template-data";
import "./sitio.css";

export const dynamic = "force-dynamic";

export default async function SitesDirectoryPage() {
  const companies = await listarEmpresasActivas();

  return (
    <main className="sites-directory">
      <header className="sites-directory-header">
        <Link href="/" className="sites-directory-brand"><Store size={18} /> GLM <span>EMPRESAS</span></Link>
        <span className="directory-overline">EXPERIENCIAS LOCALES</span>
        <h1>Un sitio propio<br />para cada negocio.</h1>
        <p>Plantillas diseñadas según el giro, la marca y la forma de vender de cada empresa.</p>
      </header>
      <section className="sites-directory-grid" aria-label="Sitios de empresas">
        {companies.map((company) => {
          const template = siteTemplates[company.giro_negocio];
          const content = company.contenido_sitio;
          return (
            <Link
              className="site-directory-card"
              href={`/sitio/${company.slug}`}
              key={company.id}
              style={{ "--company-primary": company.color_primario, "--company-secondary": company.color_secundario } as React.CSSProperties}
            >
              <div className="site-directory-image">
                <Image src={content?.heroImage || company.imagen_portada_url || template.heroImage} alt="" fill sizes="(max-width: 700px) 100vw, 33vw" unoptimized />
                <span>{company.giro_negocio}</span>
              </div>
              <div className="site-directory-copy">
                <span className="site-directory-colors"><i /><i /></span>
                <h2>{company.nombre_comercial}</h2>
                <p>{content?.description || company.descripcion_web || template.description}</p>
                <span className="site-directory-visit">Visitar sitio <ArrowUpRight size={15} /></span>
              </div>
            </Link>
          );
        })}
      </section>
      {companies.length === 0 && <p className="sites-directory-empty">Todavía no hay empresas activas para mostrar.</p>}
      <footer className="sites-directory-footer">GLM Gestión Empresarial <span>·</span> Sitios de demostración</footer>
    </main>
  );
}