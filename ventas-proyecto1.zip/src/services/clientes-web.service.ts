import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { getDatabasePool } from "@/lib/db";

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [algorithm, salt, expectedHex] = stored.split("$");
  if (algorithm !== "scrypt" || !salt || !expectedHex) return false;
  const actual = scryptSync(password, salt, 64);
  const expected = Buffer.from(expectedHex, "hex");
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export async function findCompanyBySlug(slug: string) {
  const result = await getDatabasePool().query<{
    id: string;
    cuenta_clientes_habilitada: boolean;
    nombre_comercial: string | null;
    nombre_legal: string;
    telefono: string | null;
    logo_url: string | null;
  }>(
    `SELECT id::text, cuenta_clientes_habilitada, nombre_comercial, nombre_legal, telefono, logo_url
     FROM empresas
     WHERE slug = $1 AND estado = 'ACTIVA'
     LIMIT 1`,
    [slug],
  );
  return result.rows[0]
    ? {
        id: Number(result.rows[0].id),
        cuentasHabilitadas: result.rows[0].cuenta_clientes_habilitada,
        nombre_comercial: result.rows[0].nombre_comercial,
        nombre_legal: result.rows[0].nombre_legal,
        telefono: result.rows[0].telefono,
        logo_url: result.rows[0].logo_url,
      }
    : null;
}

export async function findOrCreateGeneralCustomer(params: {
  empresaId: number;
  name: string;
  surname: string;
  identification: string;
  email: string;
  phone: string;
  city: string;
  address: string;
}) {
  const pool = getDatabasePool();
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const existing = await client.query<{ id: string }>(
      `SELECT id::text
       FROM terceros
       WHERE empresa_id = $1 AND tipo = 'CLIENTE'
         AND (lower(email) = lower($2) OR documento = $3)
       LIMIT 1`,
      [params.empresaId, params.email, params.identification],
    );

    let clienteId: string;
    if (existing.rows[0]) {
      clienteId = existing.rows[0].id;
      await client.query(
        `UPDATE terceros
         SET tipo_documento = 'CEDULA',
             documento = $3,
             nombre = CASE WHEN $4 = '' THEN nombre ELSE $4 END,
             apellido = CASE WHEN $5 = '' THEN apellido ELSE $5 END,
             email = CASE WHEN $6 = '' THEN email ELSE $6 END,
             telefono = CASE WHEN $7 = '' THEN telefono ELSE $7 END,
             direccion = CASE WHEN $8 = '' THEN direccion ELSE $8 END,
             ciudad = CASE WHEN $9 = '' THEN ciudad ELSE $9 END,
             estado = 'ACTIVO', actualizado_en = now()
         WHERE id = $1 AND empresa_id = $2 AND tipo = 'CLIENTE'`,
        [
          clienteId,
          params.empresaId,
          params.identification,
          params.name,
          params.surname,
          params.email,
          params.phone,
          params.address,
          params.city,
        ],
      );
    } else {
      const created = await client.query<{ id: string }>(
        `INSERT INTO terceros (
           empresa_id, tipo, tipo_documento, documento, nombre, apellido,
           email, telefono, direccion, ciudad, pais, estado
         ) VALUES (
           $1, 'CLIENTE', 'CEDULA', $2, $3, $4, $5, $6, $7, $8, 'Ecuador', 'ACTIVO'
         ) RETURNING id::text`,
        [
          params.empresaId,
          params.identification,
          params.name,
          params.surname || null,
          params.email,
          params.phone || null,
          params.address || null,
          params.city || null,
        ],
      );
      clienteId = created.rows[0].id;
      await client.query(
        `INSERT INTO clientes (tercero_id, empresa_id)
         VALUES ($1, $2)
         ON CONFLICT (tercero_id) DO NOTHING`,
        [clienteId, params.empresaId],
      );
    }

    await client.query("COMMIT");
    return Number(clienteId);
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}
