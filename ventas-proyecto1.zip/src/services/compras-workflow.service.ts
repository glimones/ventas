import { getDatabasePool, getEmpresaId } from "@/lib/db";

const SOLICITUD_STATES = new Set([
  "BORRADOR",
  "PENDIENTE_APROBACION",
  "APROBADA",
  "RECHAZADA",
  "CONVERTIDA_OC",
  "CANCELADA",
]);
const PRIORITIES = new Set(["BAJA", "NORMAL", "ALTA", "URGENTE"]);

export class CompraValidationError extends Error {}

type SolicitudInput = {
  numero_solicitud: string;
  fecha_solicitud: string;
  solicitante: string;
  departamento: string;
  centro_costo: string;
  prioridad: string;
  estado: string;
  total_estimado: number;
  justificacion: string;
};

function normalizeSolicitud(input: unknown): SolicitudInput {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new CompraValidationError("Los datos de la solicitud no son válidos.");
  }
  const data = input as Record<string, unknown>;
  const requiredText = (key: string, label: string) => {
    const value = typeof data[key] === "string" ? data[key].trim() : "";
    if (!value) throw new CompraValidationError(`${label} es obligatorio.`);
    return value;
  };
  const fecha = requiredText("fecha_solicitud", "La fecha");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(fecha) || Number.isNaN(Date.parse(`${fecha}T00:00:00Z`))) {
    throw new CompraValidationError("La fecha de solicitud no es válida.");
  }
  const prioridad = String(data.prioridad ?? "NORMAL").toUpperCase();
  if (!PRIORITIES.has(prioridad)) {
    throw new CompraValidationError("La prioridad de la solicitud no es válida.");
  }
  const estado = String(data.estado ?? "BORRADOR").toUpperCase();
  if (!SOLICITUD_STATES.has(estado)) {
    throw new CompraValidationError("El estado de la solicitud no es válido.");
  }
  const total = Number(data.total_estimado ?? 0);
  if (!Number.isFinite(total) || total < 0) {
    throw new CompraValidationError("El total estimado debe ser mayor o igual a cero.");
  }
  return {
    numero_solicitud: requiredText("numero_solicitud", "El número de solicitud"),
    fecha_solicitud: fecha,
    solicitante: requiredText("solicitante", "El solicitante"),
    departamento: requiredText("departamento", "El departamento"),
    centro_costo: typeof data.centro_costo === "string" ? data.centro_costo.trim() : "",
    prioridad,
    estado,
    total_estimado: total,
    justificacion: typeof data.justificacion === "string" ? data.justificacion.trim() : "",
  };
}

function mapSolicitud(row: Record<string, unknown>) {
  return {
    id: Number(row.id),
    numero_solicitud: String(row.numero),
    fecha_solicitud: String(row.fecha_solicitud),
    solicitante: String(row.solicitante),
    departamento: String(row.departamento),
    centro_costo: String(row.centro_costo ?? ""),
    prioridad: String(row.prioridad),
    estado: String(row.estado),
    items_solicitados: Number(row.items_solicitados ?? 0),
    total_estimado: Number(row.total_estimado),
    justificacion: String(row.justificacion ?? ""),
    fecha_creacion: String(row.creado_en),
  };
}

export async function listarSolicitudesCompra() {
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `SELECT s.id, s.numero, s.fecha_solicitud, s.solicitante, s.departamento,
            s.centro_costo, s.prioridad, s.estado, s.total_estimado, s.justificacion,
            s.creado_en, COUNT(d.id)::int AS items_solicitados
     FROM solicitudes_compra s
     LEFT JOIN solicitudes_compra_detalle d
       ON d.solicitud_id = s.id AND d.empresa_id = s.empresa_id
     WHERE s.empresa_id = $1
     GROUP BY s.id
     ORDER BY s.fecha_solicitud DESC, s.id DESC`,
    [getEmpresaId()],
  );
  return result.rows.map(mapSolicitud);
}

export async function guardarSolicitudCompra(input: unknown, id?: number) {
  const solicitud = normalizeSolicitud(input);
  const empresaId = getEmpresaId();
  const pool = getDatabasePool();
  const columns = [
    "numero", "fecha_solicitud", "solicitante", "departamento", "centro_costo",
    "prioridad", "estado", "total_estimado", "justificacion",
  ];
  const values = [
    solicitud.numero_solicitud, solicitud.fecha_solicitud, solicitud.solicitante,
    solicitud.departamento, solicitud.centro_costo || null, solicitud.prioridad,
    solicitud.estado, solicitud.total_estimado, solicitud.justificacion,
  ];
  if (id === undefined) {
    const result = await pool.query<Record<string, unknown>>(
      `INSERT INTO solicitudes_compra (empresa_id, ${columns.join(", ")})
       VALUES ($1, ${values.map((_, index) => `$${index + 2}`).join(", ")})
       RETURNING id, numero, fecha_solicitud, solicitante, departamento, centro_costo,
                 prioridad, estado, total_estimado, justificacion, creado_en`,
      [empresaId, ...values],
    );
    return mapSolicitud(result.rows[0]);
  }

  const assignments = columns.map((column, index) => `"${column}" = $${index + 1}`);
  assignments.push('"actualizado_en" = now()');
  const result = await pool.query<Record<string, unknown>>(
    `UPDATE solicitudes_compra SET ${assignments.join(", ")}
     WHERE id = $${values.length + 1} AND empresa_id = $${values.length + 2}
     RETURNING id, numero, fecha_solicitud, solicitante, departamento, centro_costo,
               prioridad, estado, total_estimado, justificacion, creado_en`,
    [...values, id, empresaId],
  );
  return result.rows[0] ? mapSolicitud(result.rows[0]) : null;
}

export async function eliminarSolicitudCompra(id: number) {
  const result = await getDatabasePool().query(
    `DELETE FROM solicitudes_compra
     WHERE id = $1 AND empresa_id = $2 AND estado = 'BORRADOR'
     RETURNING id`,
    [id, getEmpresaId()],
  );
  return Boolean(result.rowCount);
}
