import { getDatabasePool, getEmpresaId } from "@/lib/db";

export class UnsupportedModuleError extends Error {}
export class UnsupportedFieldError extends Error {}
export class InvalidRecordError extends Error {}

const SEARCHABLE_FIELD_NAMES = new Set([
  "abreviatura",
  "actividad",
  "apellidos",
  "asunto",
  "banco",
  "beneficiario",
  "categoria",
  "ciudad",
  "cliente",
  "codigo",
  "concepto",
  "contacto",
  "descripcion",
  "email",
  "empresa",
  "estado",
  "etapa",
  "identificacion",
  "nombre",
  "nombre_comercial",
  "nombre_legal",
  "nombres",
  "numero_cuenta",
  "periodo",
  "proxima_accion",
  "resultado",
  "responsable",
  "ruc",
  "telefono",
  "tipo",
  "ubicacion",
]);
const MAX_SEARCH_LENGTH = 100;
const DEFAULT_PAGE_SIZE = 50;
const MAX_PAGE_SIZE = 100;

type ModuleDefinition = {
  table: string;
  fields: Record<string, string>;
  companyScoped?: boolean;
  primaryKey?: string;
  stateValues?: { active: string; inactive: string };
  stateLabels?: { active: string; inactive: string };
  paymentType?: boolean;
  uppercaseFields?: string[];
  readOnly?: boolean;
  updatedAtColumn?: string;
  codePrefix?: string;
  codePadding?: number;
};

type ModuleRecord = { id: number } & Record<string, unknown>;

const modules: Record<string, ModuleDefinition> = {
  empresas: {
    table: "empresas",
    companyScoped: false,
    fields: {
      nombre_comercial: "nombre_comercial", nombre_legal: "nombre_legal", ruc: "ruc",
      direccion: "direccion", ciudad: "ciudad", provincia: "provincia", pais: "pais",
      email: "email", telefono: "telefono", logo_url: "logo_url", moneda: "moneda_base", estado: "estado",
      slug: "slug", sitio_web_habilitado: "sitio_web_habilitado",
      titulo_web: "titulo_web", imagen_portada_url: "imagen_portada_url",
      contenido_sitio: "contenido_sitio",
      giro_negocio: "giro_negocio", descripcion_web: "descripcion_web",
      color_primario: "color_primario", color_secundario: "color_secundario",
      tienda_online: "tienda_online", cuenta_clientes_habilitada: "cuenta_clientes_habilitada",
    },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    updatedAtColumn: "actualizado_en",
  },
  "unidades-medida": {
    table: "unidades_medida",
    fields: { codigo: "codigo", nombre: "nombre", abreviatura: "abreviatura", estado: "estado" },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    codePrefix: "UM",
    codePadding: 11,
  },
  bodegas: {
    table: "bodegas",
    fields: {
      codigo: "codigo", nombre: "nombre", ubicacion: "direccion", responsable: "responsable",
      capacidad: "capacidad", tipo: "tipo", ciudad: "ciudad", telefono: "telefono", notas: "notas", estado: "estado",
    },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    codePrefix: "BOD",
    codePadding: 11,
  },
  categorias: {
    table: "categorias_productos",
    fields: { codigo: "codigo", nombre: "nombre", estado: "estado" },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    codePrefix: "CAT",
    codePadding: 10,
  },
  marcas: {
    table: "marcas",
    fields: { codigo: "codigo", nombre: "nombre", estado: "estado" },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    codePrefix: "MAR",
    codePadding: 11,
  },
  "plan-cuentas": {
    table: "cuentas_contables",
    fields: { codigo: "codigo", nombre: "nombre", tipo: "tipo", naturaleza: "naturaleza", estado: "estado" },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    uppercaseFields: ["tipo", "naturaleza"],
    readOnly: true,
  },
  "centros-costos": {
    table: "centros_costos",
    fields: { codigo: "codigo", nombre: "nombre", presupuesto: "presupuesto", estado: "estado" },
    stateValues: { active: "ACTIVO", inactive: "INACTIVO" },
    codePrefix: "CC",
    codePadding: 11,
  },
  activos: {
    table: "activos_fijos",
    fields: {
      codigo: "codigo", nombre: "nombre", categoria: "categoria", fecha_adquisicion: "fecha_adquisicion",
      costo: "costo", estado: "estado",
    },
    stateValues: { active: "ACTIVO", inactive: "INACTIVO" },
    codePrefix: "ACT",
    codePadding: 11,
  },
  "cierre-periodos": {
    table: "periodos_contables",
    fields: { periodo: "codigo", fecha_inicio: "fecha_inicio", fecha_fin: "fecha_fin", estado: "estado" },
    stateValues: { active: "ABIERTO", inactive: "CERRADO" },
    stateLabels: { active: "Abierto", inactive: "Cerrado" },
  },
  oportunidades: {
    table: "oportunidades",
    fields: {
      nombre: "nombre", cliente: "prospecto_nombre", valor: "valor", etapa: "etapa", cierre_estimado: "cierre_estimado", estado: "estado",
    },
    stateValues: { active: "ABIERTA", inactive: "CERRADA" },
    stateLabels: { active: "Abierta", inactive: "Cerrada" },
  },
  prospectos: {
    table: "oportunidades",
    fields: {
      nombre: "nombre", empresa: "prospecto_nombre", etapa: "etapa", valor: "valor",
      cierre_estimado: "cierre_estimado", estado: "estado",
    },
    stateValues: { active: "ABIERTA", inactive: "CERRADA" },
    stateLabels: { active: "Abierta", inactive: "Cerrada" },
  },
  "parametros/formas-pago": {
    table: "formas_pago",
    fields: { codigo: "codigo", nombre: "nombre", tipo: "tipo", dias_credito: "dias_credito", estado: "estado" },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    codePrefix: "FPA",
    codePadding: 11,
    paymentType: true,
  },
  "parametros/impuestos": {
    table: "impuestos",
    fields: { codigo: "codigo", nombre: "nombre", tipo: "tipo", porcentaje: "porcentaje", estado: "estado" },
    stateValues: { active: "ACTIVO", inactive: "INACTIVO" },
    codePrefix: "IMP",
    codePadding: 11,
  },
  "parametros/sucursales": {
    table: "sucursales",
    fields: { codigo: "codigo", nombre: "nombre", direccion: "direccion", ciudad: "ciudad", telefono: "telefono", responsable: "responsable", estado: "estado" },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    codePrefix: "SUC",
    codePadding: 11,
  },
  "parametros/puntos-emision": {
    table: "puntos_emision",
    fields: { codigo: "codigo", nombre: "nombre", direccion: "direccion", estado: "estado" },
    stateValues: { active: "ACTIVO", inactive: "INACTIVO" },
    readOnly: true,
  },
  actividades: {
    table: "actividades_comerciales",
    fields: {
      tipo: "tipo", asunto: "asunto", contacto: "contacto", fecha: "fecha",
      resultado: "resultado", proxima_accion: "proxima_accion", estado: "estado",
    },
  },
  "seguimiento-comercial": {
    table: "actividades_comerciales",
    fields: {
      actividad: "tipo", oportunidad: "asunto", cliente: "contacto", fecha: "fecha",
      resultado: "resultado", proxima_accion: "proxima_accion", estado: "estado",
    },
  },
  empleados: {
    table: "empleados",
    fields: {
      codigo: "codigo", tipo_documento: "tipo_documento", identificacion: "identificacion",
      nombres: "nombres", apellidos: "apellidos", email: "email", telefono: "telefono",
      cargo: "cargo", departamento: "departamento", fecha_ingreso: "fecha_ingreso",
      sueldo_base: "sueldo_base", estado: "estado",
    },
    stateValues: { active: "ACTIVO", inactive: "INACTIVO" },
    codePrefix: "EMP",
    codePadding: 11,
  },
  "seguridad/roles": {
    table: "roles",
    fields: { codigo: "codigo", nombre: "nombre", descripcion: "descripcion", estado: "estado" },
    stateValues: { active: "ACTIVO", inactive: "INACTIVO" },
    codePrefix: "ROL",
    codePadding: 11,
  },
  bancos: {
    table: "cuentas_bancarias",
    fields: {
      codigo: "codigo", nombre: "banco", numero_cuenta: "numero_cuenta", tipo_cuenta: "tipo_cuenta",
      moneda: "moneda", saldo: "saldo_inicial", estado: "estado",
    },
    stateValues: { active: "ACTIVO", inactive: "INACTIVO" },
    codePrefix: "BAN",
    codePadding: 11,
  },
  caja: {
    table: "cajas",
    fields: {
      codigo: "codigo", nombre: "nombre", ubicacion: "ubicacion", moneda: "moneda",
      saldo: "saldo_inicial", estado: "estado",
    },
    stateValues: { active: "ACTIVA", inactive: "INACTIVA" },
    codePrefix: "CAJ",
    codePadding: 11,
  },
  "conciliacion-bancaria": {
    table: "conciliaciones_bancarias",
    fields: {
      periodo: "periodo", fecha_conciliacion: "fecha_conciliacion", saldo_libros: "saldo_libros",
      saldo_banco: "saldo_banco", diferencia: "diferencia", estado: "estado",
    },
    readOnly: true,
  },
  "transferencias-bancarias": {
    table: "transferencias_bancarias",
    fields: {
      codigo: "codigo", beneficiario: "beneficiario", fecha: "fecha", importe: "importe",
      concepto: "concepto", estado: "estado",
    },
    readOnly: true,
  },
};

function getDefinition(moduleKey: string): ModuleDefinition {
  const definition = modules[moduleKey];
  if (!definition) {
    throw new UnsupportedModuleError(`El módulo "${moduleKey}" aún no tiene un servicio de base de datos.`);
  }
  return definition;
}

function quoteIdentifier(identifier: string) {
  return `"${identifier.replaceAll('"', '""')}"`;
}

function projection(definition: ModuleDefinition) {
  const fields = Object.entries(definition.fields).map(
    ([field, column]) => `${quoteIdentifier(column)} AS ${quoteIdentifier(field)}`,
  );
  return [`${quoteIdentifier(definition.primaryKey ?? "id")}::text AS "id"`, ...fields].join(", ");
}

function fromRow(row: Record<string, unknown>): ModuleRecord {
  return { ...row, id: Number(row.id) };
}

function normalizeFromDatabase(definition: ModuleDefinition, row: Record<string, unknown>) {
  const normalized = { ...row };
  if (typeof normalized.estado === "string") {
    normalized.estado = definition.stateLabels && normalized.estado === definition.stateValues?.active
      ? definition.stateLabels.active
      : definition.stateLabels && normalized.estado === definition.stateValues?.inactive
        ? definition.stateLabels.inactive
        : normalized.estado.startsWith("INACT")
      ? "Inactivo"
      : normalized.estado.startsWith("ACT") || normalized.estado === "ABIERTA"
        ? "Activo"
        : normalized.estado;
  }
  if (definition.paymentType && typeof normalized.tipo === "string") {
    normalized.tipo = normalized.tipo === "CREDITO"
      ? "Crédito"
      : normalized.tipo === "CONTADO" ? "Contado" : "Otro";
  }
  return normalized;
}

function normalizeToDatabase(definition: ModuleDefinition, field: string, value: unknown) {
  if (field === "estado" && definition.stateValues) {
    const inactive = String(value).toLowerCase().startsWith("inact") ||
      String(value).toLowerCase() === definition.stateLabels?.inactive.toLowerCase() ||
      value === "CERRADA";
    return inactive ? definition.stateValues.inactive : definition.stateValues.active;
  }
  if (definition.paymentType && field === "tipo") {
    const normalized = String(value).toLowerCase();
    if (normalized.startsWith("cr")) return "CREDITO";
    if (normalized.startsWith("con")) return "CONTADO";
    return "OTRO";
  }
  if (definition.uppercaseFields?.includes(field) && typeof value === "string") {
    return value.toUpperCase();
  }
  if (field === "contenido_sitio") {
    if (value === null || value === undefined || value === "") return "{}";
    return typeof value === "string" ? value : JSON.stringify(value);
  }
  return value === "" || value === undefined ? null : value;
}

function fieldValues(definition: ModuleDefinition, values: Record<string, unknown>) {
  const allowedFields = new Set([...Object.keys(definition.fields), "id", "created_at", "updated_at"]);
  const unsupportedFields = Object.keys(values).filter((field) => !allowedFields.has(field));
  if (unsupportedFields.length) {
    throw new UnsupportedFieldError(
      `La tabla asociada no guarda estos campos: ${unsupportedFields.join(", ")}.`,
    );
  }
  for (const [field, value] of Object.entries(values)) {
    if (
      Object.hasOwn(definition.fields, field) &&
      field !== "contenido_sitio" &&
      value !== null &&
      typeof value === "object"
    ) {
      throw new InvalidRecordError(`El campo "${field}" debe contener un valor simple.`);
    }
    if (typeof value === "number" && !Number.isFinite(value)) {
      throw new InvalidRecordError(`El campo "${field}" debe contener un número válido.`);
    }
  }
  return Object.entries(definition.fields).flatMap(([field, column]) =>
    Object.hasOwn(values, field) ? [[column, values[field]] as const] : [],
  );
}

export async function listarRegistros(
  moduleKey: string,
  options: { search?: string; page?: number; pageSize?: number } = {},
) {
  const definition = getDefinition(moduleKey);
  const pool = getDatabasePool();
  const requestedPage = options.page ?? 1;
  const page = Number.isSafeInteger(requestedPage) && requestedPage >= 1 ? requestedPage : 1;
  const requestedPageSize = options.pageSize ?? DEFAULT_PAGE_SIZE;
  const pageSize = Number.isSafeInteger(requestedPageSize) && requestedPageSize > 0
    ? Math.min(MAX_PAGE_SIZE, requestedPageSize)
    : DEFAULT_PAGE_SIZE;
  const params: unknown[] = [];
  const conditions: string[] = [];

  if (definition.companyScoped !== false) {
    params.push(getEmpresaId());
    conditions.push(`empresa_id = $${params.length}`);
  }
  const search = options.search?.trim();
  if (search && search.length > MAX_SEARCH_LENGTH) {
    throw new InvalidRecordError(`La búsqueda no puede superar ${MAX_SEARCH_LENGTH} caracteres.`);
  }
  if (search) {
    params.push(`%${search}%`);
    const searchParam = `$${params.length}`;
    const searchableColumns = Object.entries(definition.fields)
      .filter(([field]) => SEARCHABLE_FIELD_NAMES.has(field))
      .map(([, column]) => (
        `COALESCE(${quoteIdentifier(column)}::text, '') ILIKE ${searchParam}`
      ));
    if (searchableColumns.length) {
      conditions.push(`(${searchableColumns.join(" OR ")})`);
    }
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const [count, result] = await Promise.all([
    pool.query<{ total: string }>(
      `SELECT count(*)::text AS total FROM ${quoteIdentifier(definition.table)} ${where}`,
      params,
    ),
    pool.query<Record<string, unknown>>(
      `SELECT ${projection(definition)} FROM ${quoteIdentifier(definition.table)} ${where}
       ORDER BY ${quoteIdentifier(definition.primaryKey ?? "id")} DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, pageSize, (page - 1) * pageSize],
    ),
  ]);
  const total = Number(count.rows[0].total);

  return {
    data: result.rows.map((row) => fromRow(normalizeFromDatabase(definition, row))),
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
    adapter: "postgresql",
    capabilities: {
      create: !definition.readOnly,
      update: !definition.readOnly,
      delete: !definition.readOnly && Boolean(definition.fields.estado),
    },
  };
}

export async function buscarRegistro(moduleKey: string, id: number) {
  const definition = getDefinition(moduleKey);
  const conditions = [`${quoteIdentifier(definition.primaryKey ?? "id")} = $1`];
  const params: unknown[] = [id];
  if (definition.companyScoped !== false) {
    params.push(getEmpresaId());
    conditions.push(`empresa_id = $${params.length}`);
  }
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `SELECT ${projection(definition)} FROM ${quoteIdentifier(definition.table)}
     WHERE ${conditions.join(" AND ")}`,
    params,
  );
  return result.rows[0]
    ? fromRow(normalizeFromDatabase(definition, result.rows[0]))
    : undefined;
}

export async function obtenerSiguienteCodigoModulo(moduleKey: string): Promise<string> {
  const definition = getDefinition(moduleKey);
  if (!definition.codePrefix || !definition.fields.codigo) {
    throw new UnsupportedModuleError("Este módulo no genera códigos secuenciales.");
  }
  const codeColumn = definition.fields.codigo;
  const padding = definition.codePadding ?? 11;
  const prefix = definition.codePrefix;
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const codePattern = `^${escapedPrefix}-([0-9]+)$`;
  const result = await getDatabasePool().query<{ maximo: string }>(
    definition.companyScoped === false
      ? `SELECT COALESCE(MAX((regexp_match(${quoteIdentifier(codeColumn)}, '${codePattern}'))[1]::bigint), 0)::text AS maximo
         FROM ${quoteIdentifier(definition.table)}
         WHERE ${quoteIdentifier(codeColumn)} ~ '${codePattern}'`
      : `SELECT COALESCE(MAX((regexp_match(${quoteIdentifier(codeColumn)}, '${codePattern}'))[1]::bigint), 0)::text AS maximo
     FROM ${quoteIdentifier(definition.table)}
     WHERE empresa_id = $1
       AND ${quoteIdentifier(codeColumn)} ~ '${codePattern}'`,
    definition.companyScoped === false ? [] : [getEmpresaId()],
  );
  const maximo = Number(result.rows[0]?.maximo ?? 0);
  return `${prefix}-${String(Number.isSafeInteger(maximo) ? maximo + 1 : 1).padStart(padding, "0")}`;
}

export async function crearRegistro(moduleKey: string, values: Record<string, unknown>) {
  const definition = getDefinition(moduleKey);
  if (definition.readOnly) {
    throw new UnsupportedModuleError("Este módulo requiere seleccionar sus registros relacionados antes de guardar.");
  }
  const createValues = { ...values };
  if (definition.codePrefix && definition.fields.codigo) {
    createValues.codigo = await obtenerSiguienteCodigoModulo(moduleKey);
  }
  const entries = fieldValues(definition, createValues);
  if (!entries.length) throw new InvalidRecordError("Incluye al menos un campo para crear el registro.");
  const columns = entries.map(([column]) => quoteIdentifier(column));
  const params = entries.map(([field, value]) => normalizeToDatabase(definition, field, value));
  if (definition.companyScoped !== false) {
    columns.unshift('"empresa_id"');
    params.unshift(getEmpresaId());
  }
  const placeholders = params.map((_, index) => `$${index + 1}`);
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `INSERT INTO ${quoteIdentifier(definition.table)} (${columns.join(", ")})
     VALUES (${placeholders.join(", ")}) RETURNING ${projection(definition)}`,
    params,
  );
  return fromRow(result.rows[0]);
}

export async function actualizarRegistro(
  moduleKey: string,
  id: number,
  values: Record<string, unknown>,
) {
  const definition = getDefinition(moduleKey);
  if (definition.readOnly) {
    throw new UnsupportedModuleError("Este módulo requiere una edición con sus registros relacionados.");
  }
  const entries = fieldValues(definition, values);
  if (!entries.length) throw new InvalidRecordError("Incluye al menos un campo para actualizar el registro.");
  const params: unknown[] = entries.map(([field, value]) => normalizeToDatabase(definition, field, value));
  const assignments = entries.map(([column], index) => `${quoteIdentifier(column)} = $${index + 1}`);
  if (definition.updatedAtColumn) {
    assignments.push(`${quoteIdentifier(definition.updatedAtColumn)} = now()`);
  }
  params.push(id);
  const conditions = [`${quoteIdentifier(definition.primaryKey ?? "id")} = $${params.length}`];
  if (definition.companyScoped !== false) {
    params.push(getEmpresaId());
    conditions.push(`empresa_id = $${params.length}`);
  }
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `UPDATE ${quoteIdentifier(definition.table)} SET ${assignments.join(", ")}
     WHERE ${conditions.join(" AND ")} RETURNING ${projection(definition)}`,
    params,
  );
  return result.rows[0] ? fromRow(result.rows[0]) : undefined;
}

export async function eliminarRegistro(moduleKey: string, id: number) {
  const definition = getDefinition(moduleKey);
  if (definition.readOnly) {
    throw new UnsupportedModuleError("Este módulo requiere una operación específica para modificar registros.");
  }
  if (!definition.fields.estado) {
    throw new UnsupportedModuleError("Este registro no permite eliminación lógica.");
  }
  const params: unknown[] = [id];
  const conditions = [`${quoteIdentifier(definition.primaryKey ?? "id")} = $1`];
  if (definition.companyScoped !== false) {
    params.push(getEmpresaId());
    conditions.push(`empresa_id = $${params.length}`);
  }
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `UPDATE ${quoteIdentifier(definition.table)}
     SET ${quoteIdentifier(definition.fields.estado)} = $${params.length + 1}
     WHERE ${conditions.join(" AND ")} RETURNING ${projection(definition)}`,
    [...params, definition.stateValues?.inactive ?? "INACTIVO"],
  );
  return result.rows[0]
    ? fromRow(normalizeFromDatabase(definition, result.rows[0]))
    : undefined;
}
