import { getDatabasePool, getEmpresaId } from "@/lib/db";
import type { PoolClient } from "pg";
import { randomUUID } from "node:crypto";
import type { Producto, TransferenciaSugerida } from "@/app/productos/types";

export class ProductoValidationError extends Error {}
export class ProductoConflictError extends ProductoValidationError {}

export type ProductoInput = {
  codigo: string;
  nombre: string;
  descripcion?: string;
  categoria_id: number;
  marca_id?: number | null;
  unidad_medida_id: number;
  ubicacion_id?: number | null;
  proveedor_id?: number | null;
  bodega_id?: number | null;
  stock_actual?: number;
  precio_compra: number;
  precio_venta: number;
  costo: number;
  stock_minimo: number;
  stock_maximo: number;
  imagen_url?: string;
  imagenes_urls?: string[];
  estado: string;
};

type ProductoNormalizado = Omit<
  ProductoInput,
  "marca_id" | "ubicacion_id" | "proveedor_id" | "bodega_id" | "stock_actual"
> & {
  marca_id: number | null;
  ubicacion_id: number | null;
  proveedor_id: number | null;
  bodega_id: number | null;
  stock_actual: number;
};

function toPositiveId(value: unknown, label: string, optional = false): number | null {
  if (optional && (value === undefined || value === null || value === "")) return null;
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new ProductoValidationError(`${label} no es válido.`);
  }
  return id;
}

function toNonNegative(value: unknown, label: string) {
  const number = Number(value ?? 0);
  if (!Number.isFinite(number) || number < 0) {
    throw new ProductoValidationError(`${label} debe ser un número igual o mayor que cero.`);
  }
  return number;
}

function normalizeProducto(input: unknown): ProductoNormalizado {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new ProductoValidationError("Los datos del producto no son válidos.");
  }
  const data = input as Record<string, unknown>;
  if (typeof data.codigo !== "string" || !data.codigo.trim() ||
      typeof data.nombre !== "string" || !data.nombre.trim()) {
    throw new ProductoValidationError("El código y el nombre del producto son obligatorios.");
  }
  const rawImages = Array.isArray(data.imagenes_urls)
    ? data.imagenes_urls.filter((image): image is string => typeof image === "string" && image.trim().length > 0)
    : [];
  const legacyImage = typeof data.imagen_url === "string" ? data.imagen_url.trim() : "";
  const images = rawImages.length ? rawImages.slice(0, 4) : legacyImage ? [legacyImage] : [];
  if (images.length < 2 || images.length > 4) {
    throw new ProductoValidationError("Cada producto debe tener entre 2 y 4 imágenes.");
  }
  const state = String(data.estado ?? "Activo").toLowerCase();
  if (state !== "activo" && state !== "inactivo") {
    throw new ProductoValidationError("El estado del producto debe ser Activo o Inactivo.");
  }
  return {
    codigo: data.codigo.trim(),
    nombre: data.nombre.trim(),
    descripcion: typeof data.descripcion === "string" ? data.descripcion.trim() : "",
    categoria_id: toPositiveId(data.categoria_id, "La categoría") as number,
    marca_id: toPositiveId(data.marca_id, "La marca", true),
    unidad_medida_id: toPositiveId(data.unidad_medida_id, "La unidad de medida") as number,
    ubicacion_id: toPositiveId(data.ubicacion_id, "La ubicación", true),
    proveedor_id: toPositiveId(data.proveedor_id, "El proveedor", true),
    bodega_id: toPositiveId(data.bodega_id, "La bodega", true),
    stock_actual: toNonNegative(data.stock_actual, "El stock inicial"),
    precio_compra: toNonNegative(data.precio_compra, "El precio de compra"),
    precio_venta: toNonNegative(data.precio_venta, "El precio de venta"),
    costo: toNonNegative(data.costo, "El costo"),
    stock_minimo: toNonNegative(data.stock_minimo, "El stock mínimo"),
    stock_maximo: toNonNegative(data.stock_maximo, "El stock máximo"),
    imagen_url: images[0] ?? "",
    imagenes_urls: images,
    estado: state === "inactivo" ? "INACTIVO" : "ACTIVO",
  };
}

async function validateForeignKeys(client: PoolClient, companyId: number, form: ProductoNormalizado) {
  const references: Array<[string, number | null, string]> = [
    ["categorias_productos", form.categoria_id, "La categoría"],
    ["marcas", form.marca_id, "La marca"],
    ["unidades_medida", form.unidad_medida_id, "La unidad de medida"],
    ["ubicaciones_bodega", form.ubicacion_id, "La ubicación"],
    ["proveedores", form.proveedor_id, "El proveedor"],
    ["bodegas", form.bodega_id, "La bodega"],
  ];
  for (const [table, id, label] of references) {
    if (id === null) continue;
    const key = table === "proveedores" ? "tercero_id" : "id";
    const result = await client.query(
      `SELECT 1 FROM ${table} WHERE ${key} = $1 AND empresa_id = $2 LIMIT 1`,
      [id, companyId],
    );
    if (!result.rowCount) throw new ProductoValidationError(`${label} no existe para esta empresa.`);
  }
}

async function rollbackQuietly(client: PoolClient) {
  await client.query("ROLLBACK").catch(() => undefined);
}

export async function listarCatalogosProducto() {
  const empresaId = getEmpresaId();
  const pool = getDatabasePool();
  const [categorias, marcas, unidades, bodegas, ubicaciones, proveedores] = await Promise.all([
    pool.query("SELECT id, codigo, nombre FROM categorias_productos WHERE empresa_id = $1 AND estado = 'ACTIVA' ORDER BY nombre", [empresaId]),
    pool.query("SELECT id, codigo, nombre FROM marcas WHERE empresa_id = $1 AND estado = 'ACTIVA' ORDER BY nombre", [empresaId]),
    pool.query("SELECT id, codigo, nombre, abreviatura FROM unidades_medida WHERE empresa_id = $1 AND estado = 'ACTIVA' ORDER BY nombre", [empresaId]),
    pool.query("SELECT id, codigo, nombre FROM bodegas WHERE empresa_id = $1 AND estado = 'ACTIVA' ORDER BY nombre", [empresaId]),
    pool.query("SELECT id, bodega_id, codigo, pasillo, estanteria, nivel FROM ubicaciones_bodega WHERE empresa_id = $1 ORDER BY codigo", [empresaId]),
    pool.query("SELECT p.tercero_id AS id, p.codigo_proveedor AS codigo, t.razon_social AS nombre FROM proveedores p JOIN terceros t ON t.id = p.tercero_id AND t.empresa_id = p.empresa_id WHERE p.empresa_id = $1 AND t.estado = 'ACTIVO' ORDER BY t.razon_social", [empresaId]),
  ]);
  return {
    categorias: categorias.rows,
    marcas: marcas.rows,
    unidades: unidades.rows,
    bodegas: bodegas.rows,
    ubicaciones: ubicaciones.rows,
    proveedores: proveedores.rows,
  };
}

export async function listarProductosPublicadosPorEmpresa(empresaId: number, productIds: string[]) {
  if (!productIds.length) return [];
  const ids = [...new Set(productIds.map(Number).filter((id) => Number.isSafeInteger(id) && id > 0))];
  if (!ids.length) return [];
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `SELECT p.id::text, p.nombre, p.descripcion, p.precio_venta, p.imagen_url,
            COALESCE(p.imagenes_urls, '[]'::jsonb) AS imagenes_urls,
            CASE WHEN p.estado = 'ACTIVO' THEN 'Activo' ELSE 'Inactivo' END AS estado,
            COALESCE(SUM(sb.cantidad), 0)::numeric AS stock_actual
     FROM productos p
     LEFT JOIN stock_bodega sb
       ON sb.empresa_id = p.empresa_id AND sb.producto_id = p.id
     WHERE p.empresa_id = $1 AND p.estado = 'ACTIVO' AND p.id = ANY($2::bigint[])
     GROUP BY p.id, p.nombre, p.descripcion, p.precio_venta, p.imagen_url, p.imagenes_urls, p.estado
     ORDER BY array_position($2::bigint[], p.id)`,
    [empresaId, ids],
  );
  return result.rows.map((row) => ({
    id: Number(row.id),
    nombre: String(row.nombre),
    descripcion: typeof row.descripcion === "string" ? row.descripcion : "",
    precio_venta: Number(row.precio_venta),
    imagen_url: typeof row.imagen_url === "string" ? row.imagen_url : undefined,
    imagenes_urls: Array.isArray(row.imagenes_urls)
      ? row.imagenes_urls.filter((image): image is string => typeof image === "string")
      : [],
    estado: String(row.estado),
    stock_actual: Number(row.stock_actual),
  })) as Producto[];
}

export async function listarProductosPorEmpresa(empresaId: number, search = "") {
  const params: unknown[] = [empresaId];
  const searchText = search.trim();
  const searchClause = searchText
    ? (params.push(`%${searchText}%`), `AND (p.codigo ILIKE $2 OR p.nombre ILIKE $2 OR COALESCE(p.descripcion, '') ILIKE $2)`)
    : "";
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `SELECT p.id::text, p.nombre, p.descripcion, p.precio_venta, p.imagen_url,
            COALESCE(p.imagenes_urls, '[]'::jsonb) AS imagenes_urls,
            CASE WHEN p.estado = 'ACTIVO' THEN 'Activo' ELSE 'Inactivo' END AS estado,
            COALESCE(SUM(sb.cantidad), 0)::numeric AS stock_actual
     FROM productos p
     LEFT JOIN stock_bodega sb
       ON sb.empresa_id = p.empresa_id AND sb.producto_id = p.id
     WHERE p.empresa_id = $1 AND p.estado = 'ACTIVO' ${searchClause}
     GROUP BY p.id, p.nombre, p.descripcion, p.precio_venta, p.imagen_url, p.imagenes_urls, p.estado
     ORDER BY p.nombre, p.id`,
    params,
  );
  return result.rows.map((row) => ({
    id: Number(row.id),
    nombre: String(row.nombre),
    descripcion: typeof row.descripcion === "string" ? row.descripcion : "",
    precio_venta: Number(row.precio_venta),
    imagen_url: typeof row.imagen_url === "string" ? row.imagen_url : undefined,
    imagenes_urls: Array.isArray(row.imagenes_urls) ? row.imagenes_urls.filter((image): image is string => typeof image === "string") : [],
    estado: String(row.estado),
    stock_actual: Number(row.stock_actual),
  })) as Producto[];
}

export async function obtenerSiguienteCodigoProducto(): Promise<string> {
  const empresaId = getEmpresaId();
  const result = await getDatabasePool().query<{ maximo: string }>(
    `SELECT COALESCE(MAX((regexp_match(codigo, '^PRD-([0-9]+)$'))[1]::bigint), 0)::text AS maximo
     FROM productos
     WHERE empresa_id = $1 AND codigo ~ '^PRD-[0-9]+$'`,
    [empresaId],
  );
  const maximo = Number(result.rows[0]?.maximo ?? 0);
  return `PRD-${String(Number.isSafeInteger(maximo) ? maximo + 1 : 1).padStart(7, "0")}`;
}

export async function listarProductos(search = "") {
  const params: unknown[] = [getEmpresaId()];
  const searchText = search.trim();
  const searchClause = searchText
    ? (params.push(`%${searchText}%`), `AND (p.codigo ILIKE $2 OR p.nombre ILIKE $2 OR COALESCE(p.descripcion, '') ILIKE $2)`)
    : "";
  const result = await getDatabasePool().query<Record<string, unknown>>(
        `SELECT p.id::text, p.codigo, p.nombre, p.descripcion,
          p.categoria_id, p.marca_id, p.unidad_medida_id, p.ubicacion_id,
            proveedor.proveedor_id AS proveedor_id,
            COALESCE(c.nombre, '') AS categoria,
            COALESCE(m.nombre, '') AS marca,
            COALESCE(u.nombre, '') AS unidad_medida,
            p.precio_compra, p.precio_venta, p.costo,
            p.stock_minimo, p.stock_maximo, p.controla_stock, p.imagen_url,
            COALESCE(p.imagenes_urls, '[]'::jsonb) AS imagenes_urls,
            CASE WHEN p.estado = 'ACTIVO' THEN 'Activo' ELSE 'Inactivo' END AS estado,
            COALESCE(SUM(sb.cantidad), 0)::numeric AS stock_actual
     FROM productos p
     LEFT JOIN categorias_productos c
       ON c.id = p.categoria_id AND c.empresa_id = p.empresa_id
     LEFT JOIN marcas m
       ON m.id = p.marca_id AND m.empresa_id = p.empresa_id
     LEFT JOIN unidades_medida u
       ON u.id = p.unidad_medida_id AND u.empresa_id = p.empresa_id
     LEFT JOIN stock_bodega sb
       ON sb.producto_id = p.id AND sb.empresa_id = p.empresa_id
     LEFT JOIN LATERAL (
       SELECT pp.proveedor_id FROM productos_proveedores pp
       WHERE pp.producto_id = p.id AND pp.empresa_id = p.empresa_id
       ORDER BY pp.proveedor_id LIMIT 1
     ) proveedor ON TRUE
     WHERE p.empresa_id = $1 ${searchClause}
     GROUP BY p.id, c.nombre, m.nombre, u.nombre, proveedor.proveedor_id
     ORDER BY p.nombre, p.id`,
    params,
  );

  return result.rows.map((row) => ({
    ...row,
    id: Number(row.id),
    categoria_id: Number(row.categoria_id),
    marca_id: row.marca_id == null ? null : Number(row.marca_id),
    unidad_medida_id: Number(row.unidad_medida_id),
    ubicacion_id: row.ubicacion_id == null ? null : Number(row.ubicacion_id),
    proveedor_id: row.proveedor_id == null ? null : Number(row.proveedor_id),
    precio_compra: Number(row.precio_compra),
    precio_venta: Number(row.precio_venta),
    costo: Number(row.costo),
    stock_actual: Number(row.stock_actual),
    stock_minimo: Number(row.stock_minimo),
    stock_maximo: Number(row.stock_maximo),
    imagenes_urls: Array.isArray(row.imagenes_urls)
      ? row.imagenes_urls.filter((image): image is string => typeof image === "string")
      : [],
  }));
}

export async function listarMovimientosProducto(productoId: number) {
  const result = await getDatabasePool().query<{
    id: string;
    producto_id: string;
    tipo: string;
    bodega_id: string;
    bodega_nombre: string;
    cantidad: string;
    fecha: Date | string;
    motivo: string | null;
    documento_referencia: string | null;
  }>(
    `SELECT mi.id::text, mi.producto_id::text, mi.tipo, mi.bodega_id::text,
            COALESCE(b.nombre, '') AS bodega_nombre, mi.cantidad::text, mi.fecha,
            mi.motivo, mi.documento_referencia
     FROM movimientos_inventario mi
     LEFT JOIN bodegas b
       ON b.id = mi.bodega_id AND b.empresa_id = mi.empresa_id
     WHERE mi.empresa_id = $1 AND mi.producto_id = $2
     ORDER BY mi.fecha DESC, mi.id DESC
     LIMIT 50`,
    [getEmpresaId(), productoId],
  );

  return result.rows.map((row) => {
    if (
      row.tipo !== "ENTRADA" &&
      row.tipo !== "SALIDA" &&
      row.tipo !== "TRANSFERENCIA" &&
      row.tipo !== "AJUSTE"
    ) {
      throw new Error("Se encontró un tipo de movimiento de inventario no reconocido.");
    }

    return {
      id: row.id,
      producto_id: Number(row.producto_id),
      tipo: row.tipo,
      bodega_id: Number(row.bodega_id),
      bodega_nombre: row.bodega_nombre,
      cantidad: Number(row.cantidad),
      fecha:
        row.fecha instanceof Date ? row.fecha.toISOString() : String(row.fecha),
      motivo: row.motivo ?? "",
      documento_referencia: row.documento_referencia,
    };
  });
}

export async function listarTransferenciasSugeridas(): Promise<TransferenciaSugerida[]> {
  const result = await getDatabasePool().query<{
    producto_id: string;
    producto_codigo: string;
    producto_nombre: string;
    unidad_medida: string;
    bodega_id: string;
    bodega_nombre: string;
    stock_actual: string;
    stock_minimo: string;
    stock_total: string;
  }>(
    `WITH stock_por_bodega AS (
       SELECT p.id AS producto_id, p.codigo AS producto_codigo,
              p.nombre AS producto_nombre,
              COALESCE(u.abreviatura, u.nombre, '') AS unidad_medida,
              p.stock_minimo, b.id AS bodega_id, b.nombre AS bodega_nombre,
              COALESCE(sb.cantidad, 0)::numeric AS stock_actual
       FROM productos p
       LEFT JOIN unidades_medida u
         ON u.id = p.unidad_medida_id AND u.empresa_id = p.empresa_id
       JOIN bodegas b
         ON b.empresa_id = p.empresa_id AND b.estado = 'ACTIVA'
       LEFT JOIN stock_bodega sb
         ON sb.producto_id = p.id AND sb.bodega_id = b.id
        AND sb.empresa_id = p.empresa_id
       WHERE p.empresa_id = $1 AND p.estado = 'ACTIVO'
         AND p.controla_stock = TRUE AND p.stock_minimo > 0
     ),
     productos_transferibles AS (
       SELECT producto_id
       FROM stock_por_bodega
       GROUP BY producto_id, stock_minimo
       HAVING SUM(stock_actual) > stock_minimo
          AND BOOL_OR(stock_actual > stock_minimo)
          AND BOOL_OR(stock_actual < stock_minimo)
     )
     SELECT spb.producto_id::text, spb.producto_codigo,
            spb.producto_nombre, spb.unidad_medida,
            spb.bodega_id::text, spb.bodega_nombre,
            spb.stock_actual::text, spb.stock_minimo::text,
            SUM(spb.stock_actual) OVER (PARTITION BY spb.producto_id)::text AS stock_total
     FROM stock_por_bodega spb
     JOIN productos_transferibles pt ON pt.producto_id = spb.producto_id
     ORDER BY spb.producto_nombre, spb.bodega_nombre`,
    [getEmpresaId()],
  );

  const productos = new Map<number, {
    producto_codigo: string;
    producto_nombre: string;
    unidad_medida: string;
    stock_minimo: number;
    stock_total: number;
    bodegas: Array<{ id: number; nombre: string; stock: number }>;
  }>();

  for (const row of result.rows) {
    const productoId = Number(row.producto_id);
    const producto = productos.get(productoId) ?? {
      producto_codigo: row.producto_codigo,
      producto_nombre: row.producto_nombre,
      unidad_medida: row.unidad_medida,
      stock_minimo: Number(row.stock_minimo),
      stock_total: Number(row.stock_total),
      bodegas: [],
    };
    producto.bodegas.push({
      id: Number(row.bodega_id),
      nombre: row.bodega_nombre,
      stock: Number(row.stock_actual),
    });
    productos.set(productoId, producto);
  }

  const roundStock = (value: number) =>
    Math.round((value + Number.EPSILON) * 10_000) / 10_000;
  const suggestions: TransferenciaSugerida[] = [];

  for (const [productoId, producto] of productos) {
    let stockTransferibleEmpresa = roundStock(
      producto.stock_total - producto.stock_minimo,
    );
    const origenes = producto.bodegas
      .filter((bodega) => bodega.stock > producto.stock_minimo)
      .sort((a, b) => b.stock - a.stock || a.nombre.localeCompare(b.nombre));
    const destinos = producto.bodegas
      .filter((bodega) => bodega.stock < producto.stock_minimo)
      .sort(
        (a, b) =>
          a.stock / producto.stock_minimo - b.stock / producto.stock_minimo ||
          a.nombre.localeCompare(b.nombre),
      );

    for (const destino of destinos) {
      let faltante = roundStock(producto.stock_minimo - destino.stock);
      for (const origen of origenes) {
        if (origen.id === destino.id || faltante <= 0 || stockTransferibleEmpresa <= 0) {
          continue;
        }
        const excedenteOrigen = roundStock(origen.stock - producto.stock_minimo);
        const cantidadSugerida = roundStock(
          Math.min(faltante, excedenteOrigen, stockTransferibleEmpresa),
        );
        if (cantidadSugerida <= 0) continue;

        const stockOrigenDespues = roundStock(origen.stock - cantidadSugerida);
        const stockDestinoDespues = roundStock(destino.stock + cantidadSugerida);
        suggestions.push({
          producto_id: productoId,
          producto_codigo: producto.producto_codigo,
          producto_nombre: producto.producto_nombre,
          unidad_medida: producto.unidad_medida,
          bodega_origen_id: origen.id,
          bodega_origen_nombre: origen.nombre,
          stock_origen: origen.stock,
          stock_origen_despues: stockOrigenDespues,
          bodega_destino_id: destino.id,
          bodega_destino_nombre: destino.nombre,
          stock_destino: destino.stock,
          stock_destino_despues: stockDestinoDespues,
          stock_minimo: producto.stock_minimo,
          stock_total: producto.stock_total,
          cantidad_sugerida: cantidadSugerida,
        });

        origen.stock = stockOrigenDespues;
        destino.stock = stockDestinoDespues;
        faltante = roundStock(faltante - cantidadSugerida);
        stockTransferibleEmpresa = roundStock(
          stockTransferibleEmpresa - cantidadSugerida,
        );
      }
    }
  }

  return suggestions.sort(
    (a, b) =>
      a.stock_destino / a.stock_minimo -
        b.stock_destino / b.stock_minimo ||
      a.producto_nombre.localeCompare(b.producto_nombre) ||
      a.bodega_destino_nombre.localeCompare(b.bodega_destino_nombre),
  );
}

export async function registrarTransferenciaSugerida(
  productoId: number,
  input: unknown,
) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new ProductoValidationError("Los datos de la transferencia no son válidos.");
  }

  const data = input as Record<string, unknown>;
  const bodegaOrigenId = toPositiveId(
    data.bodega_origen_id,
    "La bodega de origen",
  ) as number;
  const bodegaDestinoId = toPositiveId(
    data.bodega_destino_id,
    "La bodega de destino",
  ) as number;
  const cantidad = Number(data.cantidad);
  const cantidadNormalizada = Math.round(cantidad * 10_000) / 10_000;

  if (bodegaOrigenId === bodegaDestinoId) {
    throw new ProductoValidationError("El origen y el destino deben ser distintos.");
  }
  if (
    !Number.isFinite(cantidad) ||
    cantidad <= 0 ||
    Math.abs(cantidad - cantidadNormalizada) > 0.0000001
  ) {
    throw new ProductoValidationError(
      "La cantidad debe ser mayor que cero y tener hasta cuatro decimales.",
    );
  }

  const companyId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const productResult = await client.query<{
      stock_minimo: string;
      controla_stock: boolean;
    }>(
      `SELECT stock_minimo::text, controla_stock
       FROM productos
       WHERE id=$1 AND empresa_id=$2 AND estado='ACTIVO'
       FOR UPDATE`,
      [productoId, companyId],
    );
    if (!productResult.rowCount || !productResult.rows[0].controla_stock) {
      throw new ProductoValidationError(
        "El producto no existe, está inactivo o no controla stock.",
      );
    }

    const warehouses = await client.query<{ id: string; nombre: string }>(
      `SELECT id::text, nombre
       FROM bodegas
       WHERE empresa_id=$1 AND id=ANY($2::bigint[]) AND estado='ACTIVA'`,
      [companyId, [bodegaOrigenId, bodegaDestinoId]],
    );
    if (warehouses.rowCount !== 2) {
      throw new ProductoValidationError(
        "Las bodegas deben existir y estar activas para esta empresa.",
      );
    }
    const warehouseById = new Map(
      warehouses.rows.map((warehouse) => [Number(warehouse.id), warehouse.nombre]),
    );
    const origenNombre = warehouseById.get(bodegaOrigenId);
    const destinoNombre = warehouseById.get(bodegaDestinoId);
    if (!origenNombre || !destinoNombre) {
      throw new ProductoValidationError("No se pudieron validar las bodegas.");
    }

    const stockResult = await client.query<{
      bodega_id: string;
      cantidad: string;
    }>(
      `SELECT bodega_id::text, cantidad::text
       FROM stock_bodega
       WHERE empresa_id=$1 AND producto_id=$2
         AND bodega_id=ANY($3::bigint[])
       ORDER BY bodega_id
       FOR UPDATE`,
      [companyId, productoId, [bodegaOrigenId, bodegaDestinoId]],
    );
    const stockPorBodega = new Map(
      stockResult.rows.map((row) => [Number(row.bodega_id), Number(row.cantidad)]),
    );
    const stockOrigen = stockPorBodega.get(bodegaOrigenId) ?? 0;
    const stockDestino = stockPorBodega.get(bodegaDestinoId) ?? 0;
    const stockMinimo = Number(productResult.rows[0].stock_minimo);

    if (stockOrigen < cantidadNormalizada) {
      throw new ProductoConflictError(
        "La cantidad supera el stock disponible en la bodega de origen.",
      );
    }
    if (stockOrigen - cantidadNormalizada < stockMinimo) {
      throw new ProductoConflictError(
        "La transferencia dejaría la bodega de origen por debajo del stock mínimo.",
      );
    }
    if (
      stockDestino >= stockMinimo ||
      stockDestino + cantidadNormalizada > stockMinimo + 0.0000001
    ) {
      throw new ProductoConflictError(
        "La bodega de destino ya no requiere esa transferencia.",
      );
    }

    const stockTotalResult = await client.query<{ stock_total: string }>(
      `SELECT COALESCE(SUM(sb.cantidad), 0)::text AS stock_total
       FROM stock_bodega sb
       JOIN bodegas b
         ON b.id=sb.bodega_id AND b.empresa_id=sb.empresa_id
        AND b.estado='ACTIVA'
       WHERE sb.empresa_id=$1 AND sb.producto_id=$2`,
      [companyId, productoId],
    );
    const stockTotal = Number(stockTotalResult.rows[0]?.stock_total ?? 0);
    if (
      stockTotal <= stockMinimo ||
      cantidadNormalizada > stockTotal - stockMinimo + 0.0000001
    ) {
      throw new ProductoConflictError(
        "El stock disponible ya no tiene excedente suficiente para sugerir esta transferencia.",
      );
    }

    const codigo = `TR-${randomUUID().toUpperCase()}`;
    const transferResult = await client.query<{ id: string }>(
      `INSERT INTO transferencias_inventario
         (empresa_id, codigo, bodega_origen_id, bodega_destino_id,
          motivo, estado)
       VALUES ($1, $2, $3, $4, $5, 'COMPLETADA')
       RETURNING id::text`,
      [
        companyId,
        codigo,
        bodegaOrigenId,
        bodegaDestinoId,
        `Redistribución de inventario: ${origenNombre} a ${destinoNombre}`,
      ],
    );
    const transferenciaId = Number(transferResult.rows[0].id);

    await client.query(
      `INSERT INTO transferencias_inventario_detalle
         (empresa_id, transferencia_id, producto_id, cantidad)
       VALUES ($1, $2, $3, $4)`,
      [companyId, transferenciaId, productoId, cantidadNormalizada],
    );
    await client.query(
      `INSERT INTO stock_bodega (empresa_id, producto_id, bodega_id, cantidad)
       VALUES ($1, $2, $3, $4), ($1, $2, $5, $6)
       ON CONFLICT (producto_id, bodega_id)
       DO UPDATE SET cantidad=EXCLUDED.cantidad, actualizado_en=now()`,
      [
        companyId,
        productoId,
        bodegaOrigenId,
        stockOrigen - cantidadNormalizada,
        bodegaDestinoId,
        stockDestino + cantidadNormalizada,
      ],
    );
    await client.query(
      `INSERT INTO movimientos_inventario
         (empresa_id, producto_id, bodega_id, tipo, cantidad, motivo,
          documento_tipo, documento_id, documento_referencia)
       VALUES
         ($1, $2, $3, 'TRANSFERENCIA', $4, $5, 'TRANSFERENCIA', $7, $8),
         ($1, $2, $6, 'TRANSFERENCIA', $4, $9, 'TRANSFERENCIA', $7, $8)`,
      [
        companyId,
        productoId,
        bodegaOrigenId,
        cantidadNormalizada,
        `Salida hacia ${destinoNombre}`,
        bodegaDestinoId,
        transferenciaId,
        codigo,
        `Entrada desde ${origenNombre}`,
      ],
    );

    await client.query("COMMIT");
    return {
      id: transferenciaId,
      codigo,
      producto_id: productoId,
      cantidad: cantidadNormalizada,
      bodega_origen_id: bodegaOrigenId,
      bodega_destino_id: bodegaDestinoId,
      stock_origen_despues: stockOrigen - cantidadNormalizada,
      stock_destino_despues: stockDestino + cantidadNormalizada,
    };
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function crearProducto(input: unknown) {
  const form = normalizeProducto(input);
  const empresaId = getEmpresaId();
  if (form.stock_actual > 0 && form.bodega_id === null) {
    throw new ProductoValidationError("Selecciona la bodega para registrar el stock inicial.");
  }
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    await validateForeignKeys(client, empresaId, form);
    const result = await client.query<{ id: string }>(
      `INSERT INTO productos (
         empresa_id, codigo, nombre, descripcion, categoria_id, marca_id,
         unidad_medida_id, ubicacion_id, precio_compra, precio_venta, costo,
         stock_minimo, stock_maximo, imagen_url, imagenes_urls
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15::jsonb)
       RETURNING id::text`,
      [empresaId, form.codigo, form.nombre, form.descripcion || null, form.categoria_id, form.marca_id,
        form.unidad_medida_id, form.ubicacion_id, form.precio_compra, form.precio_venta, form.costo,
        form.stock_minimo, form.stock_maximo, form.imagen_url || null,
        JSON.stringify(form.imagenes_urls ?? [])],
    );
    const productId = Number(result.rows[0].id);
    if (form.proveedor_id !== null) {
      await client.query(
        `INSERT INTO productos_proveedores (empresa_id, producto_id, proveedor_id, costo_referencia)
         VALUES ($1, $2, $3, $4)`,
        [empresaId, productId, form.proveedor_id, form.costo],
      );
    }
    if (form.stock_actual > 0 && form.bodega_id !== null) {
      await client.query(
        `INSERT INTO stock_bodega (empresa_id, producto_id, bodega_id, cantidad)
         VALUES ($1, $2, $3, $4)`,
        [empresaId, productId, form.bodega_id, form.stock_actual],
      );
      await client.query(
        `INSERT INTO movimientos_inventario
           (empresa_id, producto_id, bodega_id, tipo, cantidad, motivo, documento_referencia)
         VALUES ($1, $2, $3, 'ENTRADA', $4, 'STOCK_INICIAL', 'ALTA_PRODUCTO')`,
        [empresaId, productId, form.bodega_id, form.stock_actual],
      );
    }
    await client.query("COMMIT");
    return productId;
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function actualizarProducto(id: number, input: unknown) {
  const form = normalizeProducto(input);
  const empresaId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    await validateForeignKeys(client, empresaId, form);
    const result = await client.query(
      `UPDATE productos SET
         codigo=$3, nombre=$4, descripcion=$5, categoria_id=$6, marca_id=$7,
         unidad_medida_id=$8, ubicacion_id=$9, precio_compra=$10,
         precio_venta=$11, costo=$12, stock_minimo=$13, stock_maximo=$14,
         imagen_url=$15, imagenes_urls=$16::jsonb, estado=$17, actualizado_en=now()
       WHERE id=$1 AND empresa_id=$2`,
      [id, empresaId, form.codigo, form.nombre, form.descripcion || null, form.categoria_id,
        form.marca_id, form.unidad_medida_id, form.ubicacion_id, form.precio_compra,
        form.precio_venta, form.costo, form.stock_minimo, form.stock_maximo,
        form.imagen_url || null, JSON.stringify(form.imagenes_urls ?? []), form.estado],
    );
    if (!result.rowCount) {
      await rollbackQuietly(client);
      return false;
    }
    await client.query("DELETE FROM productos_proveedores WHERE empresa_id=$1 AND producto_id=$2", [empresaId, id]);
    if (form.proveedor_id !== null) {
      await client.query(
        `INSERT INTO productos_proveedores (empresa_id, producto_id, proveedor_id, costo_referencia)
         VALUES ($1, $2, $3, $4)`,
        [empresaId, id, form.proveedor_id, form.costo],
      );
    }
    await client.query("COMMIT");
    return true;
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function desactivarProducto(id: number) {
  const result = await getDatabasePool().query(
    `UPDATE productos SET estado='INACTIVO', actualizado_en=now()
     WHERE id=$1 AND empresa_id=$2`,
    [id, getEmpresaId()],
  );
  return (result.rowCount ?? 0) > 0;
}

export async function registrarMovimientoProducto(productoId: number, input: unknown) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new ProductoValidationError("Los datos del movimiento no son válidos.");
  }
  const data = input as Record<string, unknown>;
  const warehouseId = toPositiveId(data.bodega_id, "La bodega") as number;
  const quantity = Number(data.cantidad);
  const type = String(data.tipo).toUpperCase();
  if (!Number.isFinite(quantity) || quantity <= 0) throw new ProductoValidationError("La cantidad debe ser mayor que cero.");
  if (type !== "ENTRADA" && type !== "SALIDA") throw new ProductoValidationError("El tipo debe ser entrada o salida.");
  const date = typeof data.fecha === "string" && data.fecha ? data.fecha : new Date().toISOString();
  const companyId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const product = await client.query(
      "SELECT id FROM productos WHERE id=$1 AND empresa_id=$2 AND estado='ACTIVO' FOR UPDATE",
      [productoId, companyId],
    );
    const warehouse = await client.query(
      "SELECT id FROM bodegas WHERE id=$1 AND empresa_id=$2 AND estado='ACTIVA'",
      [warehouseId, companyId],
    );
    if (!product.rowCount || !warehouse.rowCount) {
      throw new ProductoValidationError("El producto o la bodega no existe o está inactivo.");
    }
    const current = await client.query<{ cantidad: string }>(
      `SELECT cantidad FROM stock_bodega WHERE producto_id=$1 AND bodega_id=$2 FOR UPDATE`,
      [productoId, warehouseId],
    );
    const currentQuantity = Number(current.rows[0]?.cantidad ?? 0);
    if (type === "SALIDA" && currentQuantity < quantity) {
      throw new ProductoValidationError("La salida excede el stock disponible en esa bodega.");
    }
    const nextQuantity = currentQuantity + (type === "ENTRADA" ? quantity : -quantity);
    await client.query(
      `INSERT INTO stock_bodega (empresa_id, producto_id, bodega_id, cantidad)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (producto_id, bodega_id)
       DO UPDATE SET cantidad=EXCLUDED.cantidad, actualizado_en=now()`,
      [companyId, productoId, warehouseId, nextQuantity],
    );
    await client.query(
      `INSERT INTO movimientos_inventario
         (empresa_id, producto_id, bodega_id, tipo, cantidad, fecha, motivo, documento_referencia)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [companyId, productoId, warehouseId, type, quantity, date, String(data.motivo ?? ""), String(data.documento_referencia ?? "") || null],
    );
    await client.query("COMMIT");
    return { producto_id: productoId, bodega_id: warehouseId, cantidad: nextQuantity };
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}
