import { randomUUID } from "node:crypto";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import type {
  InventarioFisico,
  InventarioFisicoDetalle,
  ProductoConteoFisico,
} from "@/app/inventario-fisico/types";

export class InventarioFisicoValidationError extends Error {}
export class InventarioFisicoConflictError extends Error {}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const positiveId = (value: unknown, label: string, optional = false) => {
  if (optional && (value === undefined || value === null || value === "")) {
    return null;
  }
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new InventarioFisicoValidationError(`${label} no es válido.`);
  }
  return id;
};

const roundStock = (value: number) =>
  Math.round((value + Number.EPSILON) * 10_000) / 10_000;

const parseCountedQuantity = (value: unknown) => {
  if (value === null) return null;
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
    throw new InventarioFisicoValidationError(
      "Las cantidades contadas deben ser números iguales o mayores que cero.",
    );
  }
  const normalized = roundStock(value);
  if (Math.abs(value - normalized) > 0.0000001) {
    throw new InventarioFisicoValidationError(
      "Las cantidades contadas permiten hasta cuatro decimales.",
    );
  }
  return normalized;
};

const isValidDateOnly = (value: unknown): value is string => {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
};

function mapInventory(row: {
  id: string;
  codigo: string;
  bodega_id: string;
  bodega: string;
  fecha_conteo: string;
  responsable_nombre: string | null;
  aprobado_por_nombre: string | null;
  aplicado_en: Date | string | null;
  estado: string;
  productos_total: string;
  productos_contados: string;
  diferencias: string;
  valor_diferencia: string;
}): InventarioFisico {
  return {
    id: Number(row.id),
    codigo: row.codigo,
    bodega_id: Number(row.bodega_id),
    bodega: row.bodega,
    fecha_conteo: row.fecha_conteo.slice(0, 10),
    responsable_nombre: row.responsable_nombre ?? "",
    aprobado_por_nombre: row.aprobado_por_nombre,
    aplicado_en:
      row.aplicado_en instanceof Date
        ? row.aplicado_en.toISOString()
        : row.aplicado_en,
    estado: row.estado,
    productos_total: Number(row.productos_total),
    productos_contados: Number(row.productos_contados),
    diferencias: Number(row.diferencias),
    valor_diferencia: Number(row.valor_diferencia),
  };
}

const inventorySummaryQuery = `
  SELECT i.id::text, i.codigo, i.bodega_id::text,
         b.nombre AS bodega, i.fecha_conteo::text,
         i.responsable_nombre, i.aprobado_por_nombre, i.aplicado_en,
         i.estado, COUNT(d.id)::text AS productos_total,
         COUNT(d.id) FILTER (
           WHERE d.cantidad_contada IS NOT NULL
         )::text AS productos_contados,
         COUNT(d.id) FILTER (
           WHERE d.cantidad_contada IS NOT NULL
             AND d.cantidad_contada <> d.cantidad_sistema
         )::text AS diferencias,
         COALESCE(
           SUM(ABS(d.cantidad_contada - d.cantidad_sistema) * d.costo_unitario)
             FILTER (WHERE d.cantidad_contada IS NOT NULL),
           0
         )::text AS valor_diferencia
  FROM inventarios_fisicos i
  JOIN bodegas b
    ON b.id=i.bodega_id AND b.empresa_id=i.empresa_id
  LEFT JOIN inventarios_fisicos_detalle d
    ON d.inventario_fisico_id=i.id AND d.empresa_id=i.empresa_id
`;

export async function listarInventariosFisicos(): Promise<InventarioFisico[]> {
  const result = await getDatabasePool().query(
    `${inventorySummaryQuery}
     WHERE i.empresa_id=$1
     GROUP BY i.id, b.nombre
     ORDER BY i.fecha_conteo DESC, i.id DESC`,
    [getEmpresaId()],
  );
  return result.rows.map(mapInventory);
}

export async function obtenerInventarioFisico(
  inventarioId: number,
): Promise<InventarioFisicoDetalle | null> {
  const companyId = getEmpresaId();
  const pool = getDatabasePool();
  const summary = await pool.query(
    `${inventorySummaryQuery}
     WHERE i.empresa_id=$1 AND i.id=$2
     GROUP BY i.id, b.nombre`,
    [companyId, inventarioId],
  );
  if (!summary.rowCount) return null;

  const inventario = mapInventory(summary.rows[0]);
  const includeExpectedStock = inventario.estado !== "EN_CONTEO";
  const details = await pool.query<{
    producto_id: string;
    codigo: string;
    nombre: string;
    categoria: string;
    ubicacion: string;
    unidad_medida: string;
    cantidad_contada: string | null;
    cantidad_sistema: string;
    costo_unitario: string;
  }>(
    `SELECT p.id::text AS producto_id, p.codigo, p.nombre,
            COALESCE(c.nombre, '') AS categoria,
            COALESCE(ub.codigo, 'Sin ubicación') AS ubicacion,
            COALESCE(u.abreviatura, u.nombre, '') AS unidad_medida,
            d.cantidad_contada::text, d.cantidad_sistema::text,
            d.costo_unitario::text
     FROM inventarios_fisicos_detalle d
     JOIN productos p
       ON p.id=d.producto_id AND p.empresa_id=d.empresa_id
     LEFT JOIN categorias_productos c
       ON c.id=p.categoria_id AND c.empresa_id=p.empresa_id
     LEFT JOIN unidades_medida u
       ON u.id=p.unidad_medida_id AND u.empresa_id=p.empresa_id
     LEFT JOIN ubicaciones_bodega ub
       ON ub.id=p.ubicacion_id AND ub.empresa_id=p.empresa_id
     WHERE d.empresa_id=$1 AND d.inventario_fisico_id=$2
     ORDER BY p.codigo, p.nombre, p.id`,
    [companyId, inventarioId],
  );

  const productos: ProductoConteoFisico[] = details.rows.map((row) => ({
    producto_id: Number(row.producto_id),
    codigo: row.codigo,
    nombre: row.nombre,
    categoria: row.categoria,
    ubicacion: row.ubicacion,
    unidad_medida: row.unidad_medida,
    cantidad_contada:
      row.cantidad_contada === null ? null : Number(row.cantidad_contada),
    ...(includeExpectedStock
      ? {
          cantidad_sistema: Number(row.cantidad_sistema),
          costo_unitario: Number(row.costo_unitario),
        }
      : {}),
  }));

  return { inventario, productos };
}

export async function crearInventarioFisico(input: unknown) {
  if (!isRecord(input)) {
    throw new InventarioFisicoValidationError(
      "Los datos del conteo físico no son válidos.",
    );
  }
  const empresaId = getEmpresaId();
  const bodegaId = positiveId(input.bodega_id, "La bodega") as number;
  const categoriaId = positiveId(
    input.categoria_id,
    "La categoría",
    true,
  );
  const ubicacionId = positiveId(
    input.ubicacion_id,
    "La ubicación",
    true,
  );
  const responsableNombre =
    typeof input.responsable_nombre === "string"
      ? input.responsable_nombre.trim()
      : "";
  const fechaConteo = input.fecha_conteo;
  if (!responsableNombre || responsableNombre.length > 160) {
    throw new InventarioFisicoValidationError(
      "Ingresa el nombre del responsable (máximo 160 caracteres).",
    );
  }
  if (!isValidDateOnly(fechaConteo)) {
    throw new InventarioFisicoValidationError(
      "La fecha del conteo debe ser una fecha válida.",
    );
  }

  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const warehouse = await client.query(
      "SELECT id FROM bodegas WHERE id=$1 AND empresa_id=$2 AND estado='ACTIVA'",
      [bodegaId, empresaId],
    );
    if (!warehouse.rowCount) {
      throw new InventarioFisicoValidationError(
        "La bodega no existe o está inactiva.",
      );
    }

    if (categoriaId !== null) {
      const category = await client.query(
        "SELECT id FROM categorias_productos WHERE id=$1 AND empresa_id=$2 AND estado='ACTIVA'",
        [categoriaId, empresaId],
      );
      if (!category.rowCount) {
        throw new InventarioFisicoValidationError(
          "La categoría no existe o está inactiva.",
        );
      }
    }

    if (ubicacionId !== null) {
      const location = await client.query(
        `SELECT id FROM ubicaciones_bodega
         WHERE id=$1 AND bodega_id=$2 AND empresa_id=$3`,
        [ubicacionId, bodegaId, empresaId],
      );
      if (!location.rowCount) {
        throw new InventarioFisicoValidationError(
          "La ubicación no pertenece a la bodega seleccionada.",
        );
      }
    }

    const params: unknown[] = [empresaId, bodegaId];
    const filters = [
      "p.empresa_id=$1",
      "p.estado='ACTIVO'",
      "p.controla_stock=TRUE",
      "(sb.bodega_id=$2 OR ub.bodega_id=$2)",
    ];
    if (categoriaId !== null) {
      params.push(categoriaId);
      filters.push(`p.categoria_id=$${params.length}`);
    }
    if (ubicacionId !== null) {
      params.push(ubicacionId);
      filters.push(`p.ubicacion_id=$${params.length}`);
    }
    const products = await client.query<{
      id: string;
      cantidad_sistema: string;
      costo: string;
    }>(
      `SELECT p.id::text, COALESCE(sb.cantidad, 0)::text AS cantidad_sistema,
              p.costo::text AS costo
       FROM productos p
       LEFT JOIN ubicaciones_bodega ub
         ON ub.id=p.ubicacion_id AND ub.empresa_id=p.empresa_id
       LEFT JOIN stock_bodega sb
         ON sb.producto_id=p.id AND sb.bodega_id=$2
        AND sb.empresa_id=p.empresa_id
       WHERE ${filters.join(" AND ")}
       GROUP BY p.id, sb.cantidad
       ORDER BY p.codigo, p.id`,
      params,
    );
    if (!products.rowCount) {
      throw new InventarioFisicoValidationError(
        "No hay productos activos con control de stock para los filtros seleccionados.",
      );
    }

    const codigo = `IF-${randomUUID().toUpperCase()}`;
    const inventoryResult = await client.query<{ id: string }>(
      `INSERT INTO inventarios_fisicos
         (empresa_id, bodega_id, codigo, fecha_conteo,
          responsable_nombre, estado)
       VALUES ($1, $2, $3, $4, $5, 'EN_CONTEO')
       RETURNING id::text`,
      [empresaId, bodegaId, codigo, fechaConteo, responsableNombre],
    );
    const inventarioId = Number(inventoryResult.rows[0].id);
    await client.query(
      `INSERT INTO inventarios_fisicos_detalle
         (empresa_id, inventario_fisico_id, producto_id,
          cantidad_sistema, cantidad_contada, costo_unitario)
       SELECT $1, $2, items.producto_id, items.cantidad_sistema, NULL,
              items.costo_unitario
       FROM UNNEST($3::bigint[], $4::numeric[], $5::numeric[])
         AS items(producto_id, cantidad_sistema, costo_unitario)`,
      [
        empresaId,
        inventarioId,
        products.rows.map((product) => Number(product.id)),
        products.rows.map((product) => Number(product.cantidad_sistema)),
        products.rows.map((product) => Number(product.costo)),
      ],
    );
    await client.query("COMMIT");
    return {
      id: inventarioId,
      codigo,
      productos_total: products.rowCount,
    };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

export async function guardarConteoFisico(
  inventarioId: number,
  input: unknown,
) {
  if (!isRecord(input) || !Array.isArray(input.conteos)) {
    throw new InventarioFisicoValidationError(
      "Debes enviar la lista de cantidades contadas.",
    );
  }
  const seen = new Set<number>();
  const conteos = input.conteos.map((item) => {
    if (!isRecord(item)) {
      throw new InventarioFisicoValidationError(
        "Uno de los productos contados no es válido.",
      );
    }
    const productoId = positiveId(item.producto_id, "El producto") as number;
    if (seen.has(productoId)) {
      throw new InventarioFisicoValidationError(
        "No se puede enviar un producto contado más de una vez.",
      );
    }
    seen.add(productoId);
    return {
      producto_id: productoId,
      cantidad_contada: parseCountedQuantity(item.cantidad_contada),
    };
  });
  const enviarARevision = input.enviar_a_revision === true;
  const empresaId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const inventory = await client.query<{ estado: string }>(
      `SELECT estado FROM inventarios_fisicos
       WHERE id=$1 AND empresa_id=$2
       FOR UPDATE`,
      [inventarioId, empresaId],
    );
    if (!inventory.rowCount) {
      throw new InventarioFisicoValidationError(
        "El conteo físico no existe.",
      );
    }
    if (inventory.rows[0].estado !== "EN_CONTEO") {
      throw new InventarioFisicoConflictError(
        "Este conteo ya no acepta cambios.",
      );
    }

    for (const conteo of conteos) {
      const result = await client.query(
        `UPDATE inventarios_fisicos_detalle
         SET cantidad_contada=$4
         WHERE empresa_id=$1 AND inventario_fisico_id=$2 AND producto_id=$3`,
        [
          empresaId,
          inventarioId,
          conteo.producto_id,
          conteo.cantidad_contada,
        ],
      );
      if (!result.rowCount) {
        throw new InventarioFisicoValidationError(
          "Un producto enviado no pertenece a este conteo.",
        );
      }
    }

    if (enviarARevision) {
      const pending = await client.query<{ pendientes: string }>(
        `SELECT COUNT(*) FILTER (
           WHERE cantidad_contada IS NULL
         )::text AS pendientes
         FROM inventarios_fisicos_detalle
         WHERE empresa_id=$1 AND inventario_fisico_id=$2`,
        [empresaId, inventarioId],
      );
      if (Number(pending.rows[0]?.pendientes ?? 0) > 0) {
        throw new InventarioFisicoValidationError(
          "Cuenta todos los productos antes de enviar el conteo a revisión.",
        );
      }
      await client.query(
        `UPDATE inventarios_fisicos
         SET estado='EN_REVISION'
         WHERE id=$1 AND empresa_id=$2`,
        [inventarioId, empresaId],
      );
    }

    await client.query("COMMIT");
    return { id: inventarioId, estado: enviarARevision ? "EN_REVISION" : "EN_CONTEO" };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}

export async function aplicarConteoFisico(
  inventarioId: number,
  input: unknown,
) {
  if (!isRecord(input)) {
    throw new InventarioFisicoValidationError(
      "Los datos de aprobación no son válidos.",
    );
  }
  const aprobadoPorNombre =
    typeof input.aprobado_por_nombre === "string"
      ? input.aprobado_por_nombre.trim()
      : "";
  if (!aprobadoPorNombre || aprobadoPorNombre.length > 160) {
    throw new InventarioFisicoValidationError(
      "Ingresa quién autoriza los ajustes (máximo 160 caracteres).",
    );
  }

  const empresaId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const inventoryResult = await client.query<{
      codigo: string;
      bodega_id: string;
      estado: string;
    }>(
      `SELECT codigo, bodega_id::text, estado
       FROM inventarios_fisicos
       WHERE id=$1 AND empresa_id=$2
       FOR UPDATE`,
      [inventarioId, empresaId],
    );
    if (!inventoryResult.rowCount) {
      throw new InventarioFisicoValidationError(
        "El conteo físico no existe.",
      );
    }
    const inventory = inventoryResult.rows[0];
    if (inventory.estado !== "EN_REVISION") {
      throw new InventarioFisicoConflictError(
        "Solo se pueden aplicar conteos enviados a revisión.",
      );
    }

    const details = await client.query<{
      producto_id: string;
      codigo: string;
      nombre: string;
      cantidad_sistema: string;
      cantidad_contada: string | null;
    }>(
      `SELECT p.id::text AS producto_id, p.codigo, p.nombre,
              d.cantidad_sistema::text, d.cantidad_contada::text
       FROM inventarios_fisicos_detalle d
       JOIN productos p
         ON p.id=d.producto_id AND p.empresa_id=d.empresa_id
       WHERE d.empresa_id=$1 AND d.inventario_fisico_id=$2
       ORDER BY p.id
       FOR UPDATE OF p, d`,
      [empresaId, inventarioId],
    );
    if (!details.rowCount || details.rows.some((row) => row.cantidad_contada === null)) {
      throw new InventarioFisicoConflictError(
        "El conteo está incompleto y no se puede aplicar.",
      );
    }

    const productIds = details.rows.map((row) => Number(row.producto_id));
    const stockResult = await client.query<{
      producto_id: string;
      cantidad: string;
    }>(
      `SELECT producto_id::text, cantidad::text
       FROM stock_bodega
       WHERE empresa_id=$1 AND bodega_id=$2
         AND producto_id=ANY($3::bigint[])
       ORDER BY producto_id
       FOR UPDATE`,
      [empresaId, Number(inventory.bodega_id), productIds],
    );
    const currentStock = new Map(
      stockResult.rows.map((row) => [
        Number(row.producto_id),
        Number(row.cantidad),
      ]),
    );
    const adjustments: Array<{
      producto_id: number;
      cantidad: number;
      diferencia: number;
    }> = [];

    for (const detail of details.rows) {
      const productoId = Number(detail.producto_id);
      const expected = Number(detail.cantidad_sistema);
      const counted = Number(detail.cantidad_contada);
      const current = currentStock.get(productoId) ?? 0;
      if (roundStock(current) !== roundStock(expected)) {
        throw new InventarioFisicoConflictError(
          `El stock de ${detail.codigo} cambió durante el conteo. Inicia un conteo nuevo antes de aplicar ajustes.`,
        );
      }
      const diferencia = roundStock(counted - expected);
      if (diferencia !== 0) {
        adjustments.push({
          producto_id: productoId,
          cantidad: counted,
          diferencia,
        });
      }
    }

    if (adjustments.length > 0) {
      await client.query(
        `INSERT INTO stock_bodega
           (empresa_id, producto_id, bodega_id, cantidad)
         SELECT $1, cambios.producto_id, $2, cambios.cantidad
         FROM UNNEST($3::bigint[], $4::numeric[])
           AS cambios(producto_id, cantidad)
         ON CONFLICT (producto_id, bodega_id)
         DO UPDATE SET cantidad=EXCLUDED.cantidad, actualizado_en=now()`,
        [
          empresaId,
          Number(inventory.bodega_id),
          adjustments.map((adjustment) => adjustment.producto_id),
          adjustments.map((adjustment) => adjustment.cantidad),
        ],
      );
      await client.query(
        `INSERT INTO movimientos_inventario
           (empresa_id, producto_id, bodega_id, tipo, cantidad, motivo,
            documento_tipo, documento_id, documento_referencia)
         SELECT $1, cambios.producto_id, $2, 'AJUSTE',
                ABS(cambios.diferencia),
                CASE WHEN cambios.diferencia > 0
                  THEN 'Conteo físico ' || $4 || ': sobrante +' || ABS(cambios.diferencia)
                  ELSE 'Conteo físico ' || $4 || ': faltante -' || ABS(cambios.diferencia)
                END,
                'INVENTARIO_FISICO', $3, $4
         FROM UNNEST($5::bigint[], $6::numeric[])
           AS cambios(producto_id, diferencia)`,
        [
          empresaId,
          Number(inventory.bodega_id),
          inventarioId,
          inventory.codigo,
          adjustments.map((adjustment) => adjustment.producto_id),
          adjustments.map((adjustment) => adjustment.diferencia),
        ],
      );
    }

    await client.query(
      `UPDATE inventarios_fisicos
       SET estado='APLICADO', aprobado_por_nombre=$3, aplicado_en=now()
       WHERE id=$1 AND empresa_id=$2`,
      [inventarioId, empresaId, aprobadoPorNombre],
    );
    await client.query("COMMIT");
    return {
      id: inventarioId,
      codigo: inventory.codigo,
      estado: "APLICADO",
      productos_ajustados: adjustments.length,
    };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw error;
  } finally {
    client.release();
  }
}
