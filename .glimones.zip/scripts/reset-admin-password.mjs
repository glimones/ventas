import { randomBytes, scryptSync } from "node:crypto";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { Pool } from "pg";

function loadLocalEnvironment() {
  let contents;
  try {
    contents = readFileSync(resolve(process.cwd(), ".env.local"), "utf8");
  } catch {
    return;
  }
  for (const line of contents.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!match || process.env[match[1]]) continue;
    const value = match[2].replace(/^(['"])(.*)\1$/, "$2");
    process.env[match[1]] = value;
  }
}

function readHiddenPassword(prompt) {
  if (!process.stdin.isTTY || typeof process.stdin.setRawMode !== "function") {
    throw new Error("Ejecuta este comando en una terminal interactiva.");
  }
  return new Promise((resolvePromise, reject) => {
    const input = process.stdin;
    let value = "";
    process.stdout.write(prompt);
    input.setRawMode(true);
    input.resume();
    input.setEncoding("utf8");
    function finish(error) {
      input.setRawMode(false);
      input.pause();
      input.removeListener("data", onData);
      process.stdout.write("\n");
      if (error) reject(error);
      else resolvePromise(value);
    }
    function onData(character) {
      if (character === "\u0003") return finish(new Error("Operación cancelada."));
      if (character === "\r" || character === "\n") return finish();
      if (character === "\u007f" || character === "\b") {
        value = value.slice(0, -1);
        return;
      }
      if (character >= " " && character !== "\u007f") value += character;
    }
    input.on("data", onData);
  });
}

loadLocalEnvironment();

const username = process.argv[2] || "adminGeneral";
const connectionString = process.env.DATABASE_URL;
const schema = process.env.DATABASE_SCHEMA || "ventas";
const empresaId = Number(process.env.DATABASE_EMPRESA_ID);
if (!connectionString || !/^[a-z_][a-z0-9_]*$/.test(schema) ||
    !Number.isSafeInteger(empresaId) || empresaId <= 0) {
  throw new Error("Configura DATABASE_URL, DATABASE_SCHEMA y DATABASE_EMPRESA_ID en .env.local.");
}

const password = await readHiddenPassword("Nueva contraseña (mínimo 12 caracteres): ");
if (password.length < 12 || password.length > 256) {
  throw new Error("La contraseña debe tener entre 12 y 256 caracteres.");
}
const confirmation = await readHiddenPassword("Confirma la nueva contraseña: ");
if (password !== confirmation) throw new Error("Las contraseñas no coinciden.");

const salt = randomBytes(16).toString("hex");
const passwordHash = `scrypt$${salt}$${scryptSync(password, salt, 64).toString("hex")}`;
const pool = new Pool({
  connectionString,
  options: `-c search_path=${schema},public`,
  max: 1,
  connectionTimeoutMillis: 5000,
});
try {
  const result = await pool.query(
    `UPDATE usuarios SET password_hash = $1, actualizado_en = now()
     WHERE empresa_id = $2 AND lower(usuario) = lower($3)
     RETURNING id`,
    [passwordHash, empresaId, username],
  );
  if (result.rowCount !== 1) {
    throw new Error(`No se encontró exactamente una cuenta "${username}" en la empresa configurada.`);
  }
  await pool.query(
    `DELETE FROM usuarios_sesiones
     WHERE empresa_id = $1 AND usuario_id = $2`,
    [empresaId, result.rows[0].id],
  );
  console.log(`Contraseña actualizada para ${username}; las sesiones previas fueron revocadas.`);
} finally {
  await pool.end();
}
