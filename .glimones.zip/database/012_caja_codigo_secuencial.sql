\set ON_ERROR_STOP on

BEGIN;

SET LOCAL search_path TO ventas, public;

CREATE SEQUENCE IF NOT EXISTS cajas_codigo_seq START WITH 1;

SELECT setval(
    'cajas_codigo_seq',
    GREATEST(
        COALESCE((
            SELECT MAX((regexp_match(codigo, '^CAJA-([0-9]+)$'))[1]::BIGINT)
            FROM cajas
            WHERE codigo ~ '^CAJA-[0-9]+$'
        ), 0),
        (SELECT last_value FROM cajas_codigo_seq),
        1
    ),
    (SELECT is_called FROM cajas_codigo_seq)
        OR EXISTS (SELECT 1 FROM cajas WHERE codigo ~ '^CAJA-[0-9]+$')
);

COMMIT;
