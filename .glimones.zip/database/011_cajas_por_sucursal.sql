\set ON_ERROR_STOP on

BEGIN;

SET LOCAL search_path TO ventas, public;

DO $$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM cajas
        WHERE sucursal_id IS NOT NULL
          AND estado IN ('ACTIVA', 'ACTIVO')
        GROUP BY empresa_id, sucursal_id
        HAVING count(*) > 1
    ) THEN
        RAISE EXCEPTION
            'No se puede aplicar la regla de caja única: hay sucursales con más de una caja activa.';
    END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cajas_empresa_sucursal_activa
    ON cajas (empresa_id, sucursal_id)
    WHERE sucursal_id IS NOT NULL AND estado IN ('ACTIVA', 'ACTIVO');

COMMIT;
