"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Building2, CirclePlus, RotateCw, SquarePen, Trash2 } from "lucide-react";
import { useAccessMenu } from "@/components/access-menu-context";
import "./bootstrap-sucursales.css";

type Company = { id: number; nombre_comercial: string };
type Branch = {
  id: number;
  empresa_id: number;
  empresa: string;
  codigo: string;
  nombre: string;
  direccion: string | null;
  ciudad: string | null;
  telefono: string | null;
  responsable: string | null;
  estado: "Activa" | "Inactiva";
};
type BranchForm = {
  empresa_id: string;
  codigo: string;
  nombre: string;
  direccion: string;
  ciudad: string;
  telefono: string;
  responsable: string;
  estado: "ACTIVA" | "INACTIVA";
};

const emptyForm: BranchForm = {
  empresa_id: "",
  codigo: "",
  nombre: "",
  direccion: "",
  ciudad: "",
  telefono: "",
  responsable: "",
  estado: "ACTIVA",
};

async function readJson(response: Response) {
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "No se pudo completar la operación.");
  return result;
}

export default function SucursalesPage() {
  const { options } = useAccessMenu();
  const access = options.find((option) => option.ruta === "/parametros/sucursales")?.actions ?? 0;
  const canWrite = (access & 2) === 2;
  const canDelete = (access & 4) === 4;
  const [companies, setCompanies] = useState<Company[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [companyFilter, setCompanyFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [form, setForm] = useState<BranchForm>(emptyForm);
  const [editId, setEditId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const loadData = useCallback(async (signal?: AbortSignal) => {
    setLoading(true);
    setError("");
    try {
      const [catalogResult, branchResult] = await Promise.all([
        fetch("/api/parametros/sucursales/catalogos", { cache: "no-store", signal }).then(readJson),
        fetch("/api/parametros/sucursales", { cache: "no-store", signal }).then(readJson),
      ]);
      setCompanies(catalogResult.data.companies as Company[]);
      setBranches(branchResult.data as Branch[]);
    } catch (loadError) {
      if (signal?.aborted) return;
      setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar las sucursales.");
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void loadData(controller.signal);
    return () => controller.abort();
  }, [loadData]);

  const visibleBranches = useMemo(() => {
    const search = query.trim().toLocaleLowerCase();
    return branches.filter((branch) => (
      (companyFilter === "all" || String(branch.empresa_id) === companyFilter) &&
      (!search || `${branch.empresa} ${branch.codigo} ${branch.nombre} ${branch.ciudad ?? ""} ${branch.direccion ?? ""}`
        .toLocaleLowerCase().includes(search))
    ));
  }, [branches, companyFilter, query]);

  function openNew() {
    setEditId(null);
    setForm({ ...emptyForm, empresa_id: companies[0] ? String(companies[0].id) : "" });
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function openEdit(branch: Branch) {
    setEditId(branch.id);
    setForm({
      empresa_id: String(branch.empresa_id),
      codigo: branch.codigo,
      nombre: branch.nombre,
      direccion: branch.direccion ?? "",
      ciudad: branch.ciudad ?? "",
      telefono: branch.telefono ?? "",
      responsable: branch.responsable ?? "",
      estado: branch.estado === "Inactiva" ? "INACTIVA" : "ACTIVA",
    });
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function handleChange(event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");
    setNotice("");
    try {
      const response = await fetch(editId === null ? "/api/parametros/sucursales" : `/api/parametros/sucursales/${editId}`, {
        method: editId === null ? "POST" : "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, empresa_id: Number(form.empresa_id) }),
      });
      await readJson(response);
      setShowModal(false);
      await loadData();
      setNotice(editId === null ? "Sucursal creada correctamente." : "Sucursal actualizada correctamente.");
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "No se pudo guardar la sucursal.");
    } finally {
      setSaving(false);
    }
  }

  async function deactivate(branch: Branch) {
    if (!window.confirm(`¿Inactivar la sucursal "${branch.nombre}" de ${branch.empresa}?`)) return;
    setError("");
    setNotice("");
    try {
      await readJson(await fetch(`/api/parametros/sucursales/${branch.id}`, { method: "DELETE" }));
      await loadData();
      setNotice("Sucursal inactivada correctamente.");
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : "No se pudo inactivar la sucursal.");
    }
  }

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
          <div>
            <h1 className="mb-1">Sucursales</h1>
            <p className="text-muted mb-0">Administra las sucursales asociadas a las empresas registradas.</p>
          </div>
          {canWrite && (
            <button type="button" className="btn btn-primary" onClick={openNew} disabled={loading || companies.length === 0}>
              <CirclePlus size={16} className="me-2" />Nueva sucursal
            </button>
          )}
        </div>

        <div className="d-flex flex-column flex-md-row gap-2 mb-3">
          <div className="input-group">
            <span className="input-group-text"><Building2 size={16} /></span>
            <select className="form-select" aria-label="Filtrar por empresa" value={companyFilter} onChange={(event) => setCompanyFilter(event.target.value)}>
              <option value="all">Todas las empresas</option>
              {companies.map((company) => <option key={company.id} value={company.id}>{company.nombre_comercial}</option>)}
            </select>
          </div>
          <input className="form-control" type="search" placeholder="Buscar sucursal, código o ciudad..." aria-label="Buscar sucursal" value={query} onChange={(event) => setQuery(event.target.value)} />
        </div>

        {error && !showModal && <div className="alert alert-danger" role="alert">{error}</div>}
        {notice && <div className="alert alert-success" role="status">{notice}</div>}
        <div className="table-responsive">
          <table className="table table-striped table-hover align-middle">
            <caption className="visually-hidden">Sucursales de las empresas registradas</caption>
            <thead>
              <tr><th>Empresa</th><th>Código</th><th>Sucursal</th><th>Ciudad</th><th>Dirección</th><th>Responsable</th><th>Estado</th>{(canWrite || canDelete) && <th>Acciones</th>}</tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={canWrite || canDelete ? 8 : 7} className="text-center py-4" role="status">Cargando sucursales...</td></tr>
              ) : visibleBranches.length === 0 ? (
                <tr><td colSpan={canWrite || canDelete ? 8 : 7} className="text-center py-4 text-muted">No hay sucursales para mostrar.</td></tr>
              ) : visibleBranches.map((branch) => (
                <tr key={branch.id}>
                  <td>{branch.empresa}</td><td>{branch.codigo}</td><td>{branch.nombre}</td>
                  <td>{branch.ciudad || "—"}</td><td>{branch.direccion || "—"}</td><td>{branch.responsable || "—"}</td>
                  <td><span className={`badge text-bg-${branch.estado === "Activa" ? "success" : "secondary"}`}>{branch.estado}</span></td>
                  {(canWrite || canDelete) && <td className="text-nowrap">
                    {canWrite && <button type="button" className="btn btn-outline-primary btn-sm me-1" aria-label={`Editar ${branch.nombre}`} onClick={() => openEdit(branch)}><SquarePen size={15} /></button>}
                    {canDelete && branch.estado === "Activa" && <button type="button" className="btn btn-outline-danger btn-sm" aria-label={`Inactivar ${branch.nombre}`} onClick={() => void deactivate(branch)}><Trash2 size={15} /></button>}
                  </td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && error && (
          <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => void loadData()}>
            <RotateCw size={14} className="me-1" />Reintentar
          </button>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" role="presentation" onMouseDown={(event) => {
          if (event.target === event.currentTarget && !saving) setShowModal(false);
        }}>
          <div className="modal-container sucursales-modal" role="dialog" aria-modal="true" aria-labelledby="sucursal-modal-title">
            <form onSubmit={(event) => void handleSubmit(event)}>
              <div className="modal-header text-white">
                <h2 className="modal-title fs-5" id="sucursal-modal-title">{editId === null ? "Nueva sucursal" : "Editar sucursal"}</h2>
                <button type="button" className="btn-close btn-close-white" aria-label="Cerrar" onClick={() => setShowModal(false)} disabled={saving} />
              </div>
              <div className="modal-body">
                {error && <div className="alert alert-danger" role="alert">{error}</div>}
                <div className="row g-3">
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="branch-company">Empresa *</label>
                    <select className="form-select" id="branch-company" name="empresa_id" value={form.empresa_id} onChange={handleChange} required disabled={editId !== null}>
                      <option value="">Seleccione una empresa...</option>
                      {companies.map((company) => <option key={company.id} value={company.id}>{company.nombre_comercial}</option>)}
                    </select>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="branch-code">Código *</label>
                    <input className="form-control" id="branch-code" name="codigo" value={form.codigo} onChange={handleChange} maxLength={20} required />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="branch-name">Nombre de sucursal *</label>
                    <input className="form-control" id="branch-name" name="nombre" value={form.nombre} onChange={handleChange} maxLength={120} required />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="branch-city">Ciudad</label>
                    <input className="form-control" id="branch-city" name="ciudad" value={form.ciudad} onChange={handleChange} maxLength={100} />
                  </div>
                  <div className="col-12">
                    <label className="form-label" htmlFor="branch-address">Dirección</label>
                    <input className="form-control" id="branch-address" name="direccion" value={form.direccion} onChange={handleChange} maxLength={250} />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="branch-phone">Teléfono</label>
                    <input className="form-control" id="branch-phone" name="telefono" value={form.telefono} onChange={handleChange} maxLength={40} />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="branch-manager">Responsable</label>
                    <input className="form-control" id="branch-manager" name="responsable" value={form.responsable} onChange={handleChange} maxLength={160} />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label" htmlFor="branch-state">Estado</label>
                    <select className="form-select" id="branch-state" name="estado" value={form.estado} onChange={handleChange}>
                      <option value="ACTIVA">Activa</option><option value="INACTIVA">Inactiva</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline-secondary" onClick={() => setShowModal(false)} disabled={saving}>Cancelar</button>
                <button type="submit" className="btn btn-primary" disabled={saving || !companies.length}>
                  {saving && <span className="spinner-border spinner-border-sm me-2" aria-hidden="true" />}
                  {saving ? "Guardando..." : editId === null ? "Crear sucursal" : "Guardar cambios"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
