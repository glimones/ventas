"use client";

import { useCallback, useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import { CirclePlus, Search } from "lucide-react";
import { useAccessMenu } from "@/components/access-menu-context";
import MovimientosCajaModal from "./MovimientosCajaModal";
import type {
  MovimientoCaja,
  MovimientoCajaFormValues,
  SesionCajaOpcion,
  TipoMovimientoCaja,
  UsuarioMovimientoCaja,
} from "./types";
import "./bootstrap-movimientos-caja.css";

const emptyForm: MovimientoCajaFormValues = {
  sesion_id: "",
  responsable_id: "",
  tipo: "INGRESO",
  concepto: "",
  importe: "",
};

async function readJson(response: Response) {
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "No se pudo completar la operación.");
  return result;
}

function formatAmount(amount: number) {
  return new Intl.NumberFormat("es-EC", { style: "currency", currency: "USD" }).format(amount);
}

export default function MovimientosCajaPage() {
  const { options } = useAccessMenu();
  const access = options.find((option) => option.ruta === "/movimientos-caja")?.actions ?? 0;
  const canWrite = (access & 2) === 2;
  const [movements, setMovements] = useState<MovimientoCaja[]>([]);
  const [openSessions, setOpenSessions] = useState<SesionCajaOpcion[]>([]);
  const [users, setUsers] = useState<UsuarioMovimientoCaja[]>([]);
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [form, setForm] = useState<MovimientoCajaFormValues>(emptyForm);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");
  const [notice, setNotice] = useState("");

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const result = await readJson(await fetch("/api/movimientos-caja", { cache: "no-store" }));
      setMovements(result.data as MovimientoCaja[]);
      setOpenSessions(result.openSessions as SesionCajaOpcion[]);
      setUsers(result.users as UsuarioMovimientoCaja[]);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar los movimientos.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const visibleMovements = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return movements.filter((movement) => {
      const searchable = `${movement.codigo} ${movement.sesion} ${movement.codigo_caja} ${movement.caja} ${movement.concepto} ${movement.responsable}`
        .toLocaleLowerCase();
      return searchable.includes(normalized) && (!typeFilter || movement.tipo === typeFilter);
    });
  }, [movements, query, typeFilter]);

  function openNew() {
    const session = openSessions[0];
    setForm({
      ...emptyForm,
      sesion_id: session ? String(session.id) : "",
      responsable_id: session ? String(session.responsable_id) : "",
    });
    setFormError("");
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function handleChange(event: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) {
    const { name, value, type } = event.target;
    setForm((current) => {
      if (name === "sesion_id") {
        const session = openSessions.find((item) => String(item.id) === value);
        return {
          ...current,
          sesion_id: value,
          responsable_id: session ? String(session.responsable_id) : "",
        };
      }
      return {
        ...current,
        [name]: name === "tipo"
          ? value as TipoMovimientoCaja
          : type === "number" && value !== "" ? Number(value) : value,
      };
    });
    setFormError("");
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    setNotice("");
    try {
      const result = await readJson(await fetch("/api/movimientos-caja", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          sesion_id: Number(form.sesion_id),
          responsable_id: Number(form.responsable_id),
          importe: Number(form.importe),
        }),
      }));
      setShowModal(false);
      await loadData();
      setNotice(`Movimiento ${result.data.codigo} registrado correctamente.`);
    } catch (saveError) {
      setFormError(saveError instanceof Error ? saveError.message : "No se pudo registrar el movimiento.");
    } finally {
      setSaving(false);
    }
  }

  const incomingTotal = movements
    .filter((movement) => movement.tipo === "INGRESO")
    .reduce((sum, movement) => sum + movement.importe, 0);
  const outgoingTotal = movements
    .filter((movement) => movement.tipo === "EGRESO")
    .reduce((sum, movement) => sum + movement.importe, 0);
  const incomingCount = movements.filter((movement) => movement.tipo === "INGRESO").length;
  const outgoingCount = movements.filter((movement) => movement.tipo === "EGRESO").length;

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
          <div>
            <h1 className="mb-1">Movimientos de Caja</h1>
            <p className="text-muted mb-0">Registra ingresos y egresos únicamente en sesiones abiertas.</p>
          </div>
          {canWrite && (
            <button type="button" className="btn btn-primary treasury-add-button" onClick={openNew} disabled={loading || openSessions.length === 0}>
              <CirclePlus size={16} className="me-2" />Nuevo movimiento
            </button>
          )}
        </div>

        <div className="entity-summary-grid inventory-status-summary-grid" role="group" aria-label="Resumen de movimientos de caja">
          <button type="button" className={`entity-summary-card${typeFilter === "" ? " is-selected" : ""}`} aria-pressed={typeFilter === ""} onClick={() => setTypeFilter("")}>
            <span>Total movimientos ({movements.length})</span><strong>{loading ? "—" : movements.length}</strong>
          </button>
          <button type="button" className={`entity-summary-card${typeFilter === "INGRESO" ? " is-selected" : ""}`} aria-pressed={typeFilter === "INGRESO"} onClick={() => setTypeFilter("INGRESO")}>
            <span>Ingresos ({incomingCount})</span><strong>{loading ? "—" : formatAmount(incomingTotal)}</strong>
          </button>
          <button type="button" className={`entity-summary-card${typeFilter === "EGRESO" ? " is-selected" : ""}`} aria-pressed={typeFilter === "EGRESO"} onClick={() => setTypeFilter("EGRESO")}>
            <span>Egresos ({outgoingCount})</span><strong>{loading ? "—" : formatAmount(outgoingTotal)}</strong>
          </button>
          <div className="entity-summary-card" aria-label={`${openSessions.length} sesiones abiertas`}>
            <span>Sesiones abiertas</span><strong>{loading ? "—" : openSessions.length}</strong>
          </div>
        </div>

        {openSessions.length === 0 && !loading && (
          <div className="alert alert-info" role="status">Abre una caja antes de registrar movimientos.</div>
        )}
        <div className="row g-2 mb-3">
          <div className="col-md-8">
            <div className="input-group">
              <span className="input-group-text"><Search size={16} /></span>
              <input className="form-control" type="search" aria-label="Buscar movimiento" placeholder="Buscar caja, sesión, concepto o responsable..." value={query} onChange={(event) => setQuery(event.target.value)} />
            </div>
          </div>
          <div className="col-md-4">
            <select className="form-select" aria-label="Filtrar por tipo de movimiento" value={typeFilter} onChange={(event) => setTypeFilter(event.target.value)}>
              <option value="">Todos los tipos</option>
              <option value="INGRESO">Ingresos</option>
              <option value="EGRESO">Egresos</option>
            </select>
          </div>
        </div>

        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        {notice && <div className="alert alert-success" role="status">{notice}</div>}
        <div className="table-responsive">
          <table className="table table-striped table-hover align-middle">
            <thead className="table-dark">
              <tr><th>Código</th><th>Fecha</th><th>Sesión</th><th>Caja</th><th>Tipo</th><th>Concepto</th><th>Responsable</th><th className="text-end">Importe</th></tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="text-center py-4" role="status">Cargando movimientos...</td></tr>
              ) : visibleMovements.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-4 text-muted">No hay movimientos para mostrar.</td></tr>
              ) : visibleMovements.map((movement) => (
                <tr key={movement.id}>
                  <td>{movement.codigo}</td>
                  <td>{new Date(movement.fecha).toLocaleString("es-EC")}</td>
                  <td>{movement.sesion}</td>
                  <td>{movement.codigo_caja} — {movement.caja}</td>
                  <td><span className={`badge text-bg-${movement.tipo === "INGRESO" ? "success" : "danger"}`}>{movement.tipo === "INGRESO" ? "Ingreso" : "Egreso"}</span></td>
                  <td>{movement.concepto}</td>
                  <td>{movement.responsable}</td>
                  <td className="text-end">{formatAmount(movement.importe)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && error && <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => void loadData()}>Reintentar</button>}
      </div>

      <MovimientosCajaModal
        show={showModal}
        values={form}
        sessions={openSessions}
        users={users}
        onChange={handleChange}
        onClose={() => {
          if (!saving) setShowModal(false);
        }}
        onSubmit={(event) => void handleSubmit(event)}
        saving={saving}
        formError={formError}
      />
    </div>
  );
}
