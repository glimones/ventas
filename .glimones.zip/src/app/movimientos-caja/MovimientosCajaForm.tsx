import type { ChangeEvent } from "react";
import type {
  MovimientoCajaFormValues,
  SesionCajaOpcion,
  UsuarioMovimientoCaja,
} from "./types";

interface Props {
  values: MovimientoCajaFormValues;
  sessions: SesionCajaOpcion[];
  users: UsuarioMovimientoCaja[];
  onChange: (event: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

export default function MovimientosCajaForm({ values, sessions, users, onChange }: Props) {
  const selectedSession = sessions.find((session) => String(session.id) === values.sesion_id);
  const companyUsers = selectedSession
    ? users.filter((user) => user.empresa_id === selectedSession.empresa_id)
    : [];

  return (
    <div className="row g-3">
      <div className="col-md-6">
        <label className="form-label" htmlFor="movimiento-sesion">Sesión de caja abierta *</label>
        <select className="form-select" id="movimiento-sesion" name="sesion_id" value={values.sesion_id} onChange={onChange} required>
          <option value="">Seleccione una sesión...</option>
          {sessions.map((session) => (
            <option key={session.id} value={session.id}>{session.codigo} — {session.caja}</option>
          ))}
        </select>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="movimiento-tipo">Tipo *</label>
        <select className="form-select" id="movimiento-tipo" name="tipo" value={values.tipo} onChange={onChange}>
          <option value="INGRESO">Ingreso</option>
          <option value="EGRESO">Egreso</option>
        </select>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="movimiento-responsable">Responsable *</label>
        <select className="form-select" id="movimiento-responsable" name="responsable_id" value={values.responsable_id} onChange={onChange} required disabled={!selectedSession}>
          <option value="">Seleccione un responsable...</option>
          {companyUsers.map((user) => <option key={user.id} value={user.id}>{user.nombre}</option>)}
        </select>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="movimiento-importe">Importe *</label>
        <input className="form-control" id="movimiento-importe" name="importe" type="number" min="0.01" step="0.01" value={values.importe} onChange={onChange} required />
      </div>
      <div className="col-12">
        <label className="form-label" htmlFor="movimiento-concepto">Concepto *</label>
        <textarea className="form-control" id="movimiento-concepto" name="concepto" value={values.concepto} onChange={onChange} maxLength={250} rows={3} required />
      </div>
    </div>
  );
}
