export type TipoMovimientoCaja = "INGRESO" | "EGRESO";

export interface MovimientoCaja {
  id: number;
  codigo: string;
  sesion_id: number;
  sesion: string;
  caja_id: number;
  caja: string;
  codigo_caja: string;
  tipo: TipoMovimientoCaja;
  concepto: string;
  fecha: string;
  importe: number;
  responsable_id: number;
  responsable: string;
}

export interface SesionCajaOpcion {
  id: number;
  codigo: string;
  caja: string;
  empresa_id: number;
  responsable_id: number;
}

export interface UsuarioMovimientoCaja {
  id: number;
  empresa_id: number;
  nombre: string;
}

export interface MovimientoCajaFormValues {
  sesion_id: string;
  responsable_id: string;
  tipo: TipoMovimientoCaja;
  concepto: string;
  importe: number | string;
}
