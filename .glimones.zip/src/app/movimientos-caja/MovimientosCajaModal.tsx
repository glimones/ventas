import { useEffect, type ChangeEvent, type FormEvent } from "react";
import type {
  MovimientoCajaFormValues,
  SesionCajaOpcion,
  UsuarioMovimientoCaja,
} from "./types";
import MovimientosCajaForm from "./MovimientosCajaForm";

interface Props {
  show: boolean;
  values: MovimientoCajaFormValues;
  sessions: SesionCajaOpcion[];
  users: UsuarioMovimientoCaja[];
  onChange: (event: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (event: FormEvent) => void;
  saving: boolean;
  formError: string;
}

export default function MovimientosCajaModal({
  show,
  values,
  sessions,
  users,
  onChange,
  onClose,
  onSubmit,
  saving,
  formError,
}: Props) {
  useEffect(() => {
    document.body.style.overflow = show ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [show]);

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && show && !saving) onClose();
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [show, onClose, saving]);

  if (!show) return null;

  const canSubmit = Boolean(
    values.sesion_id &&
    values.responsable_id &&
    values.concepto.trim() &&
    Number(values.importe) > 0,
  );
  return (
    <div
      className="modal-overlay"
      onClick={(event) => {
        if (event.target === event.currentTarget && !saving) onClose();
      }}
      style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0, 0, 0, 0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1050, padding: "20px" }}
    >
      <div className="modal-container" style={{ background: "white", borderRadius: "12px", width: "100%", maxWidth: "800px", maxHeight: "95vh", overflow: "hidden", boxShadow: "0 20px 60px rgba(0, 0, 0, 0.3)", display: "flex", flexDirection: "column" }}>
        <form onSubmit={onSubmit}>
          <div className="modal-header text-white" style={{ padding: "1.5rem", display: "flex", alignItems: "center", justifyContent: "space-between", background: "#343a40" }}>
            <h5 className="modal-title">Registrar movimiento de caja</h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose} disabled={saving} aria-label="Cerrar modal" style={{ filter: "brightness(0) invert(1)" }} />
          </div>
          <div className="modal-body" style={{ padding: "1.5rem", overflowY: "auto", maxHeight: "calc(85vh - 140px)" }}>
            {formError && <div className="alert alert-danger" role="alert">{formError}</div>}
            <MovimientosCajaForm values={values} sessions={sessions} users={users} onChange={onChange} />
          </div>
          <div className="modal-footer" style={{ padding: "1rem 1.5rem", display: "flex", justifyContent: "flex-end", gap: "0.5rem", borderTop: "1px solid #dee2e6", background: "#f8f9fa" }}>
            <button type="button" className="btn btn-secondary" onClick={onClose} disabled={saving}>Cancelar</button>
            <button type="submit" className="btn btn-primary" disabled={saving || !canSubmit}>
              {saving && <span className="spinner-border spinner-border-sm me-2" aria-hidden="true" />}
              {saving ? "Guardando..." : "Registrar movimiento"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
