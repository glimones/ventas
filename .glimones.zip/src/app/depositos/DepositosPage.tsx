"use client";

import TreasuryDocumentPage from "@/components/treasury-document-page";
import "./bootstrap-depositos.css";

const today = new Date().toISOString().slice(0, 10);
const fields = [
  { name: "cuenta_bancaria_id", label: "Cuenta bancaria", type: "select" as const },
  { name: "fecha", label: "Fecha", type: "date" as const },
  { name: "origen", label: "Origen de fondos", type: "text" as const },
  { name: "importe", label: "Importe", type: "number" as const },
  { name: "referencia", label: "Referencia", type: "text" as const, required: false },
  {
    name: "comprobante_base64",
    label: "Comprobante de depósito",
    type: "image" as const,
    mimeField: "comprobante_mime_type",
    help: "PNG, JPG o WebP; máximo 5 MB.",
  },
];

const columns = [
  { name: "numero_deposito", label: "Depósito" },
  { name: "cuenta_bancaria", label: "Cuenta" },
  { name: "fecha", label: "Fecha", type: "date" as const },
  { name: "origen", label: "Origen" },
  { name: "importe", label: "Importe", type: "currency" as const },
  { name: "referencia", label: "Referencia" },
  { name: "comprobante_base64", label: "Comprobante", type: "image" as const, mimeField: "comprobante_mime_type" },
  { name: "estado", label: "Estado" },
];

export default function DepositosPage() {
  return (
    <TreasuryDocumentPage
      title="Depósitos Bancarios"
      route="/depositos"
      endpoint="/api/depositos"
      searchPlaceholder="Buscar depósito o referencia..."
      fields={fields}
      columns={columns}
      initialForm={{
        cuenta_bancaria_id: "",
        fecha: today,
        origen: "",
        importe: "",
        referencia: "",
        comprobante_base64: "",
        comprobante_mime_type: "",
      }}
      pendingLabel="Registrados"
      completedLabel="Anulados"
    />
  );
}
