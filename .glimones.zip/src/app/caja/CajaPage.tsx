"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Building2, CirclePlus, RotateCw, SquarePen, Trash2 } from "lucide-react";
import { useAccessMenu } from "@/components/access-menu-context";
import RegistroResumen, { contarRegistrosPorEstado, type FiltroEstadoRegistro } from "@/components/registro-resumen";
import { getNextCajaCode } from "@/lib/caja-code";
import CajaModal from "./CajaModal";
import type { Caja, CajaFormValues, TreasuryBranch, TreasuryCompany, TreasuryUser } from "./types";
import "./bootstrap-caja.css";

type Catalogs = {
  companies: TreasuryCompany[];
  branches: TreasuryBranch[];
  users: TreasuryUser[];
  occupiedBranchIds: number[];
};

const emptyForm: CajaFormValues = {
  empresa_id: "",
  sucursal_id: "",
  codigo: "",
  nombre: "",
  ubicacion: "",
  responsable_id: "",
  moneda: "USD",
  saldo_inicial: 0,
  estado: "ACTIVA",
};

async function readJson(response: Response) {
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "No se pudo completar la operación.");
  return result;
}

export default function CajaPage() {
  const { options } = useAccessMenu();
  const access = options.find((option) => option.ruta === "/caja")?.actions ?? 0;
  const canWrite = (access & 2) === 2;
  const canDelete = (access & 4) === 4;
  const [catalogs, setCatalogs] = useState<Catalogs>({
    companies: [],
    branches: [],
    users: [],
    occupiedBranchIds: [],
  });
  const [boxes, setBoxes] = useState<Caja[]>([]);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<FiltroEstadoRegistro>("TODOS");
  const [form, setForm] = useState<CajaFormValues>(emptyForm);
  const [editId, setEditId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");
  const [notice, setNotice] = useState("");

  const loadData = useCallback(async (signal?: AbortSignal) => {
    setLoading(true);
    setError("");
    try {
      const [catalogResult, boxResult] = await Promise.all([
        fetch("/api/caja/catalogos", { cache: "no-store", signal }).then(readJson),
        fetch("/api/caja", { cache: "no-store", signal }).then(readJson),
      ]);
      setCatalogs(catalogResult.data as Catalogs);
      setBoxes(boxResult.data as Caja[]);
    } catch (loadError) {
      if (signal?.aborted) return;
      setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar las cajas.");
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void loadData(controller.signal);
    return () => controller.abort();
  }, [loadData]);

  const visibleBoxes = useMemo(() => {
    const search = query.trim().toLocaleLowerCase();
    return boxes.filter((box) =>
      {
        const matchesSearch = `${box.empresa} ${box.sucursal} ${box.codigo} ${box.nombre} ${box.ubicacion ?? ""} ${box.responsable ?? ""}`
          .toLocaleLowerCase()
          .includes(search);
        const status = box.estado.toLocaleLowerCase();
        const matchesStatus =
          statusFilter === "TODOS" ||
          (statusFilter === "ACTIVOS" && status.startsWith("activ")) ||
          (statusFilter === "INACTIVOS" && status.startsWith("inactiv"));
        return matchesSearch && matchesStatus;
      },
    );
  }, [boxes, query, statusFilter]);

  function openNew() {
    const company = catalogs.companies[0];
    setEditId(null);
    setForm({
      ...emptyForm,
      empresa_id: company ? String(company.id) : "",
      codigo: getNextCajaCode(boxes.map((box) => box.codigo)),
      moneda: company?.moneda_base || "USD",
    });
    setFormError("");
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function openEdit(box: Caja) {
    setEditId(box.id);
    setForm({
      empresa_id: String(box.empresa_id),
      sucursal_id: String(box.sucursal_id ?? ""),
      codigo: box.codigo,
      nombre: box.nombre,
      ubicacion: box.ubicacion ?? "",
      responsable_id: String(box.responsable_id ?? ""),
      moneda: box.moneda,
      saldo_inicial: box.saldo_inicial,
      estado: box.estado.toLocaleLowerCase().startsWith("inact") ? "INACTIVA" : "ACTIVA",
    });
    setFormError("");
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function handleChange(event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) {
    const { name, value, type } = event.target;
    setForm((current) => {
      if (name === "empresa_id") {
        const selectedCompany = catalogs.companies.find((company) => String(company.id) === value);
        return {
          ...current,
          empresa_id: value,
          sucursal_id: "",
          responsable_id: "",
          moneda: selectedCompany?.moneda_base || "USD",
        };
      }
      return {
        ...current,
        [name]: type === "number" && value !== "" ? Number(value) : value,
      };
    });
    setFormError("");
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    setNotice("");
    try {
      const response = await fetch(editId === null ? "/api/caja" : `/api/caja/${editId}`, {
        method: editId === null ? "POST" : "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          empresa_id: Number(form.empresa_id),
          sucursal_id: Number(form.sucursal_id),
          responsable_id: form.responsable_id ? Number(form.responsable_id) : null,
        }),
      });
      const saved = await readJson(response);
      setShowModal(false);
      await loadData();
      setNotice(editId === null
        ? `Caja registrada correctamente con el código ${saved.data.codigo}.`
        : "Caja actualizada correctamente.");
    } catch (saveError) {
      setFormError(saveError instanceof Error ? saveError.message : "No se pudo guardar la caja.");
    } finally {
      setSaving(false);
    }
  }

  async function deactivate(box: Caja) {
    if (!window.confirm(`¿Inactivar la caja "${box.nombre}" de ${box.empresa} — ${box.sucursal}?`)) return;
    setError("");
    setNotice("");
    try {
      await readJson(await fetch(`/api/caja/${box.id}`, { method: "DELETE" }));
      await loadData();
      setNotice("Caja inactivada correctamente.");
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : "No se pudo inactivar la caja.");
    }
  }

  const boxCounts = contarRegistrosPorEstado(boxes);

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
          <div>
            <h1 className="mb-1">Cajas</h1>
            <p className="text-muted mb-0">Registra una caja activa por cada sucursal de las empresas.</p>
          </div>
          {canWrite && (
            <button type="button" className="btn btn-primary treasury-add-button" onClick={openNew} disabled={loading || catalogs.companies.length === 0}>
              <CirclePlus size={16} className="me-2" />Nueva caja
            </button>
          )}
        </div>

        <div className="row g-3 mb-3">
          <div className="col-md-4">
            <div className="input-group">
              <span className="input-group-text"><Building2 size={16} /></span>
              <input className="form-control" type="search" placeholder="Buscar empresa, sucursal o caja..." aria-label="Buscar caja" value={query} onChange={(event) => setQuery(event.target.value)} />
            </div>
          </div>
        </div>

        <RegistroResumen
          total={boxes.length}
          activos={boxCounts.activos}
          inactivos={boxCounts.inactivos}
          filtro={statusFilter}
          cargando={loading}
          onChange={setStatusFilter}
        />
        {!loading && (
          <p className="entity-result-count" role="status">
            Mostrando {visibleBoxes.length} de {boxes.length} cajas
          </p>
        )}
        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        {notice && <div className="alert alert-success" role="status">{notice}</div>}
        <div className="table-responsive">
          <table className="table table-striped table-hover treasury-table align-middle">
            <caption className="visually-hidden">Cajas por empresa y sucursal</caption>
            <thead>
              <tr><th>Empresa</th><th>Sucursal</th><th>Código</th><th>Caja</th><th>Ubicación</th><th>Responsable</th><th className="text-end">Saldo inicial</th><th>Estado</th>{(canWrite || canDelete) && <th>Acciones</th>}</tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={canWrite || canDelete ? 9 : 8} className="text-center py-4" role="status">Cargando cajas...</td></tr>
              ) : visibleBoxes.length === 0 ? (
                <tr><td colSpan={canWrite || canDelete ? 9 : 8} className="text-center py-4 text-muted">No hay cajas para mostrar.</td></tr>
              ) : visibleBoxes.map((box) => (
                <tr key={box.id}>
                  <td>{box.empresa}</td><td>{box.sucursal || "—"}</td><td>{box.codigo}</td><td>{box.nombre}</td>
                  <td>{box.ubicacion || "—"}</td><td>{box.responsable || "—"}</td>
                  <td className="text-end">{new Intl.NumberFormat("es-EC", { style: "currency", currency: box.moneda || "USD" }).format(box.saldo_inicial)}</td>
                  <td><span className={`badge text-bg-${box.estado === "Activa" ? "success" : "secondary"}`}>{box.estado}</span></td>
                  {(canWrite || canDelete) && <td className="text-nowrap">
                    {canWrite && <button type="button" className="btn btn-outline-primary btn-sm me-1" aria-label={`Editar ${box.nombre}`} onClick={() => openEdit(box)}><SquarePen size={15} /></button>}
                    {canDelete && box.estado === "Activa" && <button type="button" className="btn btn-outline-danger btn-sm" aria-label={`Inactivar ${box.nombre}`} onClick={() => void deactivate(box)}><Trash2 size={15} /></button>}
                  </td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && error && <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => void loadData()}><RotateCw size={14} className="me-1" />Reintentar</button>}
      </div>

      <CajaModal
        show={showModal}
        editando={editId !== null}
        editingId={editId}
        values={form}
        onChange={handleChange}
        onClose={() => {
          if (!saving) setShowModal(false);
        }}
        onSubmit={(event) => void handleSubmit(event)}
        saving={saving}
        formError={formError}
        companies={catalogs.companies}
        branches={catalogs.branches}
        users={catalogs.users}
        occupiedBranchIds={catalogs.occupiedBranchIds}
      />
    </div>
  );
}
