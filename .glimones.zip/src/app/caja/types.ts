export type TreasuryCompany = { id: number; nombre_comercial: string; moneda_base: string };
export type TreasuryBranch = { id: number; empresa_id: number; codigo: string; nombre: string; estado: string };
export type TreasuryUser = { id: number; empresa_id: number; nombre: string };

export interface Caja {
  id: number;
  empresa_id: number;
  empresa: string;
  sucursal_id: number | null;
  sucursal: string;
  codigo: string;
  nombre: string;
  ubicacion: string | null;
  responsable_id: number | null;
  responsable: string | null;
  moneda: string;
  saldo_inicial: number;
  estado: string;
}

export interface CajaFormValues {
  empresa_id: string;
  sucursal_id: string;
  codigo: string;
  nombre: string;
  ubicacion: string;
  responsable_id: string;
  moneda: string;
  saldo_inicial: number | string;
  estado: "ACTIVA" | "INACTIVA";
}
