import type { ChangeEvent } from "react";
import type { CajaFormValues, TreasuryBranch, TreasuryCompany, TreasuryUser } from "./types";

interface CajaFormProps {
  values: CajaFormValues;
  onChange: (
    event: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>,
  ) => void;
  companies: TreasuryCompany[];
  branches: TreasuryBranch[];
  users: TreasuryUser[];
  occupiedBranchIds: number[];
  editingId: number | null;
}

export default function CajaForm({
  values,
  onChange,
  companies,
  branches,
  users,
  occupiedBranchIds,
  editingId,
}: CajaFormProps) {
  const companyId = Number(values.empresa_id);
  const companyBranches = branches.filter((branch) => branch.empresa_id === companyId);
  const selectableBranches = companyBranches.filter((branch) =>
    branch.estado === "ACTIVA" || Number(values.sucursal_id) === branch.id,
  );
  const activeBranchCount = companyBranches.filter((branch) => branch.estado === "ACTIVA").length;
  const companyUsers = users.filter((user) => user.empresa_id === companyId);

  return (
    <div className="row g-3">
      <div className="col-md-6">
        <label className="form-label" htmlFor="caja-empresa">Empresa *</label>
        <select className="form-select" id="caja-empresa" name="empresa_id" value={values.empresa_id} onChange={onChange} required disabled={editingId !== null}>
          <option value="">Seleccione una empresa...</option>
          {companies.map((company) => <option key={company.id} value={company.id}>{company.nombre_comercial}</option>)}
        </select>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="caja-sucursal">Sucursal *</label>
        <select className="form-select" id="caja-sucursal" name="sucursal_id" value={values.sucursal_id} onChange={onChange} required disabled={!values.empresa_id || editingId !== null}>
          <option value="">Seleccione una sucursal...</option>
          {selectableBranches.map((branch) => {
            const alreadyHasCash = occupiedBranchIds.includes(branch.id) && Number(values.sucursal_id) !== branch.id;
            return <option key={branch.id} value={branch.id} disabled={alreadyHasCash}>
              {branch.codigo} — {branch.nombre}{branch.estado !== "ACTIVA" ? " (inactiva)" : alreadyHasCash ? " (ya tiene caja activa)" : ""}
            </option>;
          })}
        </select>
        {values.empresa_id && activeBranchCount === 0 && <div className="form-text text-danger">La empresa no tiene sucursales activas. Registra una sucursal antes de crear la caja.</div>}
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="caja-codigo">Código *</label>
        <input className="form-control" id="caja-codigo" name="codigo" value={values.codigo} readOnly maxLength={30} required />
        <div className="form-text">Código secuencial generado automáticamente.</div>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="caja-nombre">Nombre de caja *</label>
        <input className="form-control" id="caja-nombre" name="nombre" value={values.nombre} onChange={onChange} maxLength={100} required />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="caja-ubicacion">Ubicación</label>
        <input className="form-control" id="caja-ubicacion" name="ubicacion" value={values.ubicacion} onChange={onChange} maxLength={160} />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="caja-responsable">Responsable</label>
        <select className="form-select" id="caja-responsable" name="responsable_id" value={values.responsable_id} onChange={onChange} disabled={!values.empresa_id}>
          <option value="">Sin responsable</option>
          {companyUsers.map((user) => <option key={user.id} value={user.id}>{user.nombre}</option>)}
        </select>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="caja-saldo">Saldo inicial *</label>
        <input className="form-control" id="caja-saldo" name="saldo_inicial" type="number" min="0" step="0.01" value={values.saldo_inicial} onChange={onChange} required />
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="caja-estado">Estado</label>
        <select className="form-select" id="caja-estado" name="estado" value={values.estado} onChange={onChange}>
          <option value="ACTIVA">Activa</option><option value="INACTIVA">Inactiva</option>
        </select>
      </div>
      {editingId !== null && <div className="col-12"><div className="form-text">Una sucursal puede tener una sola caja activa.</div></div>}
    </div>
  );
}
