"use client";

import TreasuryDocumentPage from "@/components/treasury-document-page";
import "./bootstrap-cheques.css";

const today = new Date().toISOString().slice(0, 10);
const fields = [
  { name: "numero_cheque", label: "Número de cheque", type: "text" as const },
  { name: "cuenta_bancaria_id", label: "Cuenta bancaria", type: "select" as const },
  { name: "beneficiario", label: "Beneficiario", type: "text" as const },
  { name: "fecha_emision", label: "Fecha de emisión", type: "date" as const },
  { name: "fecha_cobro", label: "Fecha estimada de cobro", type: "date" as const, required: false },
  { name: "importe", label: "Importe", type: "number" as const },
  { name: "concepto", label: "Concepto", type: "text" as const },
  { name: "referencia", label: "Referencia", type: "text" as const, required: false },
  {
    name: "comprobante_base64",
    label: "Comprobante de pago",
    type: "image" as const,
    mimeField: "comprobante_mime_type",
    help: "PNG, JPG o WebP; máximo 5 MB.",
  },
  {
    name: "cheque_base64",
    label: "Imagen del cheque",
    type: "image" as const,
    mimeField: "cheque_mime_type",
    help: "PNG, JPG o WebP; máximo 5 MB.",
  },
];

const columns = [
  { name: "numero_cheque", label: "Cheque" },
  { name: "cuenta", label: "Cuenta" },
  { name: "beneficiario", label: "Beneficiario" },
  { name: "fecha_emision", label: "Emisión", type: "date" as const },
  { name: "fecha_cobro", label: "Cobro", type: "date" as const },
  { name: "importe", label: "Importe", type: "currency" as const },
  { name: "concepto", label: "Concepto" },
  { name: "comprobante_base64", label: "Comprobante", type: "image" as const, mimeField: "comprobante_mime_type" },
  { name: "cheque_base64", label: "Cheque", type: "image" as const, mimeField: "cheque_mime_type" },
  { name: "estado", label: "Estado" },
];

export default function ChequesPage() {
  return (
    <TreasuryDocumentPage
      title="Cheques"
      route="/cheques"
      endpoint="/api/cheques"
      searchPlaceholder="Buscar cheque o beneficiario..."
      fields={fields}
      columns={columns}
      initialForm={{
        numero_cheque: "",
        cuenta_bancaria_id: "",
        beneficiario: "",
        fecha_emision: today,
        fecha_cobro: "",
        importe: "",
        concepto: "",
        referencia: "",
        comprobante_base64: "",
        comprobante_mime_type: "",
        cheque_base64: "",
        cheque_mime_type: "",
      }}
      pendingLabel="Pendientes"
      completedLabel="Cobrados/anulados"
    />
  );
}
