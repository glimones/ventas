"use client";

import { useAccessMenu } from "@/components/access-menu-context";
import RegistroResumen, { type FiltroEstadoRegistro } from "@/components/registro-resumen";
import { useCallback, useEffect, useMemo, useState } from "react";
import "./bootstrap-conciliacion-bancaria.css";
import "./conciliacion-bancaria-page.css";

type Account = { id: number; cuenta: string; moneda: string; saldo_actual: number };
type Movement = {
  id: number;
  fecha: string;
  concepto: string;
  referencia: string;
  tipo: string;
  importe: number;
};
type Reconciliation = {
  id: number;
  cuenta: string;
  moneda: string;
  periodo: string;
  fecha_hasta: string;
  saldo_libros: number;
  saldo_banco: number;
  diferencia: number;
  motivo_diferencia: string;
  responsable: string;
  estado: string;
  movimientos_total: number;
  movimientos_conciliados: number;
};

function readJson(response: Response) {
  return response.json().then((result) => {
    if (!response.ok) throw new Error(result.error || "No se pudo completar la operación.");
    return result;
  });
}

function isBalanced(item: Reconciliation) {
  return Math.abs(item.diferencia) < 0.01;
}

function money(value: number, currency = "USD") {
  return value.toLocaleString("es-EC", { style: "currency", currency });
}

export default function ConciliacionBancariaPage() {
  const { options } = useAccessMenu();
  const access = options.find((option) => option.ruta === "/conciliacion-bancaria")?.actions ?? 0;
  const canWrite = (access & 2) === 2;
  const currentPeriod = new Date().toISOString().slice(0, 7);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [reconciliations, setReconciliations] = useState<Reconciliation[]>([]);
  const [movements, setMovements] = useState<Movement[]>([]);
  const [accountId, setAccountId] = useState("");
  const [period, setPeriod] = useState(currentPeriod);
  const [bankBalance, setBankBalance] = useState("");
  const [bookBalance, setBookBalance] = useState<number | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [reason, setReason] = useState("");
  const [query, setQuery] = useState("");
  const [summaryFilter, setSummaryFilter] = useState<FiltroEstadoRegistro>("TODOS");
  const [page, setPage] = useState(0);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMovements, setLoadingMovements] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");
  const [notice, setNotice] = useState("");

  const loadData = useCallback(async (signal?: AbortSignal) => {
    setLoading(true);
    setError("");
    try {
      const [reconciliationResult, catalogResult] = await Promise.all([
        fetch("/api/conciliacion-bancaria", { cache: "no-store", signal }).then(readJson),
        fetch("/api/tesoreria/catalogos", { cache: "no-store", signal }).then(readJson),
      ]);
      setReconciliations(reconciliationResult.data as Reconciliation[]);
      setAccounts(catalogResult.data.accounts as Account[]);
    } catch (loadError) {
      if (signal?.aborted) return;
      setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar las conciliaciones.");
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void loadData(controller.signal);
    return () => controller.abort();
  }, [loadData]);

  useEffect(() => {
    if (!showForm) return;
    document.body.style.overflow = "hidden";
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !saving) setShowForm(false);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = "";
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [showForm, saving]);

  useEffect(() => {
    if (!showForm || !accountId || !period) {
      setMovements([]);
      setBookBalance(null);
      return;
    }
    const controller = new AbortController();
    setLoadingMovements(true);
    setFormError("");
    fetch(`/api/conciliacion-bancaria/movimientos?cuenta_bancaria_id=${accountId}&periodo=${period}`, {
      cache: "no-store",
      signal: controller.signal,
    })
      .then(readJson)
      .then((result) => {
        setMovements(result.data as Movement[]);
        setBookBalance(Number(result.saldo_libros));
        setSelectedIds(new Set());
      })
      .catch((loadError: unknown) => {
        if (!controller.signal.aborted) {
          setFormError(loadError instanceof Error ? loadError.message : "No se pudieron cargar los movimientos.");
        }
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoadingMovements(false);
      });
    return () => controller.abort();
  }, [accountId, period, showForm]);

  const filtered = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return reconciliations.filter((item) => {
      const matchesQuery = [item.cuenta, item.periodo, item.responsable, item.estado, item.motivo_diferencia]
        .join(" ").toLocaleLowerCase().includes(normalized);
      const balanced = isBalanced(item);
      const matchesSummary = summaryFilter === "TODOS" ||
        (summaryFilter === "ACTIVOS" && balanced) ||
        (summaryFilter === "INACTIVOS" && !balanced);
      return matchesQuery && matchesSummary;
    });
  }, [query, reconciliations, summaryFilter]);
  const pageSize = 10;
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, pageCount - 1);
  const visibleRows = filtered.slice(currentPage * pageSize, (currentPage + 1) * pageSize);
  const balancedCount = reconciliations.filter(isBalanced).length;
  const selectedAccount = accounts.find((account) => account.id === Number(accountId));
  const numericBankBalance = Number(bankBalance);
  const difference = bookBalance === null || bankBalance === "" || !Number.isFinite(numericBankBalance)
    ? null
    : Math.round((bookBalance - numericBankBalance) * 100) / 100;
  const reasonRequired = difference !== null && Math.abs(difference) >= 0.01;

  useEffect(() => {
    if (page !== currentPage) setPage(currentPage);
  }, [currentPage, page]);

  function openForm() {
    setAccountId("");
    setPeriod(currentPeriod);
    setBankBalance("");
    setBookBalance(null);
    setMovements([]);
    setSelectedIds(new Set());
    setReason("");
    setError("");
    setFormError("");
    setNotice("");
    setShowForm(true);
  }

  function closeForm() {
    if (saving) return;
    setShowForm(false);
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    setNotice("");
    try {
      const result = await readJson(await fetch("/api/conciliacion-bancaria", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cuenta_bancaria_id: Number(accountId),
          periodo: period,
          saldo_banco: Number(bankBalance),
          movimientos_conciliados: [...selectedIds],
          motivo_diferencia: reason,
        }),
      }));
      setShowForm(false);
      setNotice(result.data.diferencia === 0
        ? "Conciliación cerrada sin diferencias."
        : "Conciliación cerrada con diferencia justificada.");
      await loadData();
    } catch (saveError) {
      setFormError(saveError instanceof Error ? saveError.message : "No se pudo cerrar la conciliación.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">Conciliación Bancaria</h1>
        <div className="treasury-toolbar d-flex flex-column flex-md-row justify-content-between gap-2 mb-3">
          <div className="input-group treasury-search">
            <span className="input-group-text" aria-hidden="true">⌕</span>
            <input
              className="form-control"
              type="search"
              placeholder="Buscar cuenta, período o responsable..."
              aria-label="Buscar conciliaciones"
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setPage(0);
              }}
            />
          </div>
          {canWrite && (
            <button type="button" className="btn btn-primary" onClick={openForm} disabled={loading}>
              Nueva conciliación
            </button>
          )}
        </div>

        {!error && (
          <RegistroResumen
            total={reconciliations.length}
            activos={balancedCount}
            inactivos={reconciliations.length - balancedCount}
            activosLabel="Cuadradas"
            inactivosLabel="Con diferencia"
            filtro={summaryFilter}
            cargando={loading}
            onChange={(filter) => {
              setSummaryFilter(filter);
              setPage(0);
            }}
          />
        )}
        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        {notice && <div className="alert alert-success" role="status">{notice}</div>}

        <div className="table-responsive" role="region" aria-label="Tabla de conciliaciones bancarias" tabIndex={0}>
          <table className="table table-striped treasury-table">
            <caption className="visually-hidden">Historial de conciliaciones bancarias</caption>
            <thead>
              <tr>
                <th scope="col">Código</th><th scope="col">Cuenta</th><th scope="col">Período</th>
                <th scope="col">Saldo libros</th><th scope="col">Saldo banco</th><th scope="col">Diferencia</th>
                <th scope="col">Movimientos cotejados</th><th scope="col">Responsable</th><th scope="col">Estado</th><th scope="col">Justificación</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={10} className="text-center" role="status">Cargando conciliaciones...</td></tr>
              ) : visibleRows.length === 0 ? (
                <tr><td colSpan={10} className="text-center treasury-table-message">
                  {reconciliations.length ? "No encontramos resultados." : "Aún no hay conciliaciones registradas."}
                </td></tr>
              ) : visibleRows.map((item) => (
                <tr key={item.id}>
                  <td>{`CON-${String(item.id).padStart(6, "0")}`}</td>
                  <td>{item.cuenta}</td>
                  <td>{item.periodo}</td>
                  <td>{money(item.saldo_libros, item.moneda)}</td>
                  <td>{money(item.saldo_banco, item.moneda)}</td>
                  <td className={isBalanced(item) ? "text-success" : "text-danger"}>{money(item.diferencia, item.moneda)}</td>
                  <td>{item.movimientos_conciliados} / {item.movimientos_total}</td>
                  <td>{item.responsable}</td>
                  <td><span className={`badge ${isBalanced(item) ? "text-bg-success" : "text-bg-warning"}`}>{item.estado}</span></td>
                  <td className="reconciliation-reason">{item.motivo_diferencia || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {!loading && filtered.length > pageSize && (
          <div className="treasury-pagination">
            <span>Mostrando {currentPage * pageSize + 1}–{Math.min((currentPage + 1) * pageSize, filtered.length)} de {filtered.length}</span>
            <div className="d-flex align-items-center gap-2">
              <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => setPage((value) => Math.max(0, value - 1))} disabled={currentPage === 0}>Anterior</button>
              <span>{currentPage + 1} de {pageCount}</span>
              <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => setPage((value) => Math.min(pageCount - 1, value + 1))} disabled={currentPage >= pageCount - 1}>Siguiente</button>
            </div>
          </div>
        )}

        {showForm && (
          <div className="reconciliation-overlay" onMouseDown={(event) => {
            if (event.target === event.currentTarget) closeForm();
          }}>
            <div className="modal-container reconciliation-modal" role="dialog" aria-modal="true" aria-labelledby="reconciliation-title">
              <form onSubmit={submit}>
                <div className="modal-header text-white">
                  <h2 id="reconciliation-title" className="modal-title">Nueva conciliación bancaria</h2>
                  <button type="button" className="btn-close btn-close-white" onClick={closeForm} disabled={saving} aria-label="Cerrar" />
                </div>
                <div className="modal-body">
                  {formError && <div className="alert alert-danger" role="alert">{formError}</div>}
                  <p className="alert alert-info">
                    El saldo de libros se calcula desde el saldo inicial de la cuenta hasta el último día del período.
                    La diferencia es saldo de libros menos saldo bancario.
                  </p>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label className="form-label" htmlFor="reconciliation-account">Cuenta bancaria <span className="text-danger">*</span></label>
                      <select id="reconciliation-account" className="form-select" value={accountId} required onChange={(event) => setAccountId(event.target.value)} disabled={saving}>
                        <option value="">Selecciona una cuenta...</option>
                        {accounts.map((account) => <option value={account.id} key={account.id}>{account.cuenta} ({account.moneda})</option>)}
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label className="form-label" htmlFor="reconciliation-period">Período <span className="text-danger">*</span></label>
                      <input id="reconciliation-period" className="form-control" type="month" value={period} required onChange={(event) => setPeriod(event.target.value)} disabled={saving} />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label" htmlFor="reconciliation-bank-balance">Saldo final del estado bancario <span className="text-danger">*</span></label>
                      <input id="reconciliation-bank-balance" className="form-control" type="number" step="0.01" value={bankBalance} required onChange={(event) => setBankBalance(event.target.value)} disabled={saving} />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Saldo final según libros</label>
                      <input className="form-control" value={bookBalance === null ? "" : money(bookBalance, selectedAccount?.moneda)} readOnly aria-readonly="true" />
                    </div>
                    <div className="col-md-6">
                      <label className="form-label">Diferencia (libros − banco)</label>
                      <input className={`form-control${difference !== null && Math.abs(difference) >= 0.01 ? " is-invalid" : ""}`} value={difference === null ? "" : money(difference, selectedAccount?.moneda)} readOnly aria-readonly="true" />
                    </div>
                    {reasonRequired && (
                      <div className="col-12">
                        <label className="form-label" htmlFor="reconciliation-reason">Justificación de la diferencia <span className="text-danger">*</span></label>
                        <textarea id="reconciliation-reason" className="form-control" rows={3} maxLength={1000} value={reason} required onChange={(event) => setReason(event.target.value)} disabled={saving} />
                      </div>
                    )}
                  </div>

                  <div className="mt-4">
                    <h3 className="h6">Movimientos del período</h3>
                    <p className="small text-muted">Marca cada movimiento que aparece en el estado de cuenta. Los no marcados quedan identificados como pendientes de cotejo.</p>
                    {loadingMovements ? (
                      <div className="text-muted" role="status">Cargando movimientos...</div>
                    ) : !accountId ? (
                      <div className="text-muted">Selecciona una cuenta y período para listar los movimientos.</div>
                    ) : movements.length === 0 ? (
                      <div className="text-muted">No existen movimientos registrados en este período.</div>
                    ) : (
                      <div className="table-responsive reconciliation-movements">
                        <table className="table table-sm table-hover align-middle">
                          <thead><tr><th scope="col">En estado</th><th scope="col">Fecha</th><th scope="col">Concepto</th><th scope="col">Referencia</th><th scope="col">Tipo</th><th scope="col" className="text-end">Importe</th></tr></thead>
                          <tbody>
                            {movements.map((movement) => (
                              <tr key={movement.id}>
                                <td><input
                                  type="checkbox"
                                  className="form-check-input"
                                  aria-label={`Marcar movimiento ${movement.concepto} del ${movement.fecha}`}
                                  checked={selectedIds.has(movement.id)}
                                  onChange={(event) => setSelectedIds((current) => {
                                    const next = new Set(current);
                                    if (event.target.checked) next.add(movement.id);
                                    else next.delete(movement.id);
                                    return next;
                                  })}
                                  disabled={saving}
                                /></td>
                                <td>{movement.fecha}</td>
                                <td>{movement.concepto}</td>
                                <td>{movement.referencia}</td>
                                <td>{movement.tipo}</td>
                                <td className="text-end">{money(movement.importe, selectedAccount?.moneda)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                    <div className="small text-muted mt-2">Seleccionados: {selectedIds.size} de {movements.length}</div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-secondary" onClick={closeForm} disabled={saving}>Cancelar</button>
                  <button type="submit" className="btn btn-primary" disabled={saving || loadingMovements || !accountId || bookBalance === null || accounts.length === 0}>
                    {saving ? "Cerrando..." : "Cerrar conciliación"}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
