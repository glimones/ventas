"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Building2, CirclePlus, CreditCard, Landmark, RotateCw, SquarePen, Trash2 } from "lucide-react";
import { useAccessMenu } from "@/components/access-menu-context";
import RegistroResumen, { contarRegistrosPorEstado, type FiltroEstadoRegistro } from "@/components/registro-resumen";
import "./bootstrap-bancos.css";

type Bank = {
  id: number;
  codigo: string;
  nombre: string;
  pais: string;
  swift_bic: string;
  estado: "ACTIVO" | "INACTIVO";
};
type BankAccount = {
  id: number;
  empresa_id: number;
  banco_id: number;
  codigo: string;
  banco: string;
  empresa: string;
  numero_cuenta: string;
  titular: string;
  tipo_cuenta: string;
  sucursal_bancaria: string;
  moneda: string;
  fecha_saldo_inicial: string;
  saldo_inicial: number;
  saldo_actual: number;
  cuenta_contable_id: number | null;
  cuenta_contable: string;
  estado: "ACTIVA" | "INACTIVA";
};
type Catalogs = {
  companies: Array<{ id: number; nombre_comercial: string; moneda_base: string }>;
  banks: Array<{ id: number; codigo: string; nombre: string }>;
  currencies: Array<{ codigo: string; nombre: string }>;
  chartAccounts: Array<{ id: number; empresa_id: number; codigo: string; nombre: string }>;
};
type FormValues = Record<string, string | number>;
type Section = "banks" | "accounts";

const emptyBankForm: FormValues = { codigo: "", nombre: "", pais: "Ecuador", swift_bic: "", estado: "ACTIVO" };
const emptyAccountForm: FormValues = {
  empresa_id: "", banco_id: "", codigo: "", numero_cuenta: "", titular: "",
  tipo_cuenta: "CORRIENTE", sucursal_bancaria: "", moneda: "USD",
  fecha_saldo_inicial: new Date().toISOString().slice(0, 10), saldo_inicial: 0,
  cuenta_contable_id: "", estado: "ACTIVA",
};

async function readJson(response: Response) {
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "No se pudo completar la operación.");
  return result;
}

export default function BancosPage() {
  const { options } = useAccessMenu();
  const access = options.find((option) => option.ruta === "/bancos")?.actions ?? 0;
  const canWrite = (access & 2) === 2;
  const canDelete = (access & 4) === 4;
  const [section, setSection] = useState<Section>("banks");
  const [banks, setBanks] = useState<Bank[]>([]);
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [catalogs, setCatalogs] = useState<Catalogs>({ companies: [], banks: [], currencies: [], chartAccounts: [] });
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<FiltroEstadoRegistro>("TODOS");
  const [form, setForm] = useState<FormValues>(emptyBankForm);
  const [editId, setEditId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [formError, setFormError] = useState("");
  const [notice, setNotice] = useState("");

  const loadData = useCallback(async (signal?: AbortSignal) => {
    setLoading(true);
    setError("");
    try {
      const [bankResult, accountResult, catalogResult] = await Promise.all([
        fetch("/api/bancos", { cache: "no-store", signal }).then(readJson),
        fetch("/api/cuentas-bancarias", { cache: "no-store", signal }).then(readJson),
        fetch("/api/cuentas-bancarias/catalogos", { cache: "no-store", signal }).then(readJson),
      ]);
      setBanks(bankResult.data as Bank[]);
      setAccounts(accountResult.data as BankAccount[]);
      setCatalogs(catalogResult.data as Catalogs);
    } catch (loadError) {
      if (signal?.aborted) return;
      setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar los datos bancarios.");
    } finally {
      if (!signal?.aborted) setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    void loadData(controller.signal);
    return () => controller.abort();
  }, [loadData]);

  const rows = section === "banks" ? banks : accounts;
  const counts = contarRegistrosPorEstado(rows);
  const visibleBanks = useMemo(() => {
    const search = query.trim().toLocaleLowerCase();
    return banks.filter((bank) => {
      const searchable = `${bank.codigo} ${bank.nombre} ${bank.pais} ${bank.swift_bic}`.toLocaleLowerCase();
      const matchesStatus = statusFilter === "TODOS" ||
        (statusFilter === "ACTIVOS" && bank.estado === "ACTIVO") ||
        (statusFilter === "INACTIVOS" && bank.estado === "INACTIVO");
      return searchable.includes(search) && matchesStatus;
    });
  }, [banks, query, statusFilter]);
  const visibleAccounts = useMemo(() => {
    const search = query.trim().toLocaleLowerCase();
    return accounts.filter((account) => {
      const searchable = `${account.empresa} ${account.banco} ${account.codigo} ${account.numero_cuenta} ${account.titular} ${account.tipo_cuenta}`.toLocaleLowerCase();
      const matchesStatus = statusFilter === "TODOS" ||
        (statusFilter === "ACTIVOS" && account.estado === "ACTIVA") ||
        (statusFilter === "INACTIVOS" && account.estado === "INACTIVA");
      return searchable.includes(search) && matchesStatus;
    });
  }, [accounts, query, statusFilter]);

  function openNew() {
    setEditId(null);
    setForm(section === "banks"
      ? { ...emptyBankForm }
      : {
          ...emptyAccountForm,
          empresa_id: catalogs.companies[0] ? String(catalogs.companies[0].id) : "",
          banco_id: catalogs.banks[0] ? String(catalogs.banks[0].id) : "",
          moneda: catalogs.companies[0]?.moneda_base || catalogs.currencies[0]?.codigo || "USD",
        });
    setFormError("");
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function openEdit(row: Bank | BankAccount) {
    setEditId(row.id);
    if (section === "banks") {
      const bank = row as Bank;
      setForm({ codigo: bank.codigo, nombre: bank.nombre, pais: bank.pais, swift_bic: bank.swift_bic, estado: bank.estado });
    } else {
      const account = row as BankAccount;
      setForm({
        empresa_id: String(account.empresa_id),
        banco_id: String(account.banco_id),
        codigo: account.codigo,
        numero_cuenta: "",
        titular: account.titular,
        tipo_cuenta: account.tipo_cuenta,
        sucursal_bancaria: account.sucursal_bancaria || "",
        moneda: account.moneda,
        fecha_saldo_inicial: account.fecha_saldo_inicial,
        saldo_inicial: account.saldo_inicial,
        cuenta_contable_id: account.cuenta_contable_id ? String(account.cuenta_contable_id) : "",
        estado: account.estado,
      });
    }
    setFormError("");
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function handleChange(event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    const { name, value, type } = event.target;
    setForm((current) => {
      if (name === "empresa_id") {
        const company = catalogs.companies.find((item) => String(item.id) === value);
        return {
          ...current,
          empresa_id: value,
          moneda: company?.moneda_base || catalogs.currencies[0]?.codigo || "USD",
          cuenta_contable_id: "",
        };
      }
      return { ...current, [name]: type === "number" && value !== "" ? Number(value) : value };
    });
    setFormError("");
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    setNotice("");
    try {
      const isBank = section === "banks";
      const payload = isBank ? form : {
        ...form,
        empresa_id: Number(form.empresa_id),
        banco_id: Number(form.banco_id),
        cuenta_contable_id: form.cuenta_contable_id ? Number(form.cuenta_contable_id) : null,
        saldo_inicial: Number(form.saldo_inicial),
      };
      const endpoint = isBank ? "/api/bancos" : "/api/cuentas-bancarias";
      const response = await fetch(editId === null ? endpoint : `${endpoint}/${editId}`, {
        method: editId === null ? "POST" : "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      await readJson(response);
      setShowModal(false);
      await loadData();
      setNotice(isBank
        ? editId === null ? "Banco registrado correctamente." : "Banco actualizado correctamente."
        : editId === null ? "Cuenta bancaria registrada correctamente." : "Cuenta bancaria actualizada correctamente.");
    } catch (saveError) {
      setFormError(saveError instanceof Error ? saveError.message : "No se pudo guardar el registro.");
    } finally {
      setSaving(false);
    }
  }

  async function deactivate(row: Bank | BankAccount) {
    const name = "banco" in row ? `${row.banco} ${row.codigo}` : row.nombre;
    if (!window.confirm(`¿Inactivar "${name}"?`)) return;
    setError("");
    setNotice("");
    try {
      await readJson(await fetch(`${section === "banks" ? "/api/bancos" : "/api/cuentas-bancarias"}/${row.id}`, { method: "DELETE" }));
      await loadData();
      setNotice("Registro inactivado correctamente.");
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : "No se pudo inactivar el registro.");
    }
  }

  const selectedCompanyId = Number(form.empresa_id);
  const chartAccounts = catalogs.chartAccounts.filter((item) => item.empresa_id === selectedCompanyId);

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
          <div>
            <h1 className="mb-1">Bancos y Cuentas Bancarias</h1>
            <p className="text-muted mb-0">Administra las instituciones financieras y las cuentas de cada empresa.</p>
          </div>
          {canWrite && (
            <button type="button" className="btn btn-primary treasury-add-button" onClick={openNew} disabled={loading || (section === "accounts" && (!catalogs.companies.length || !catalogs.banks.length))}>
              <CirclePlus size={16} className="me-2" />{section === "banks" ? "Nuevo banco" : "Nueva cuenta"}
            </button>
          )}
        </div>

        <div className="btn-group mb-3" role="group" aria-label="Sección bancaria">
          <button type="button" className={`btn ${section === "banks" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => { setSection("banks"); setQuery(""); setStatusFilter("TODOS"); setError(""); setNotice(""); }}>
            <Landmark size={16} className="me-2" />Bancos
          </button>
          <button type="button" className={`btn ${section === "accounts" ? "btn-primary" : "btn-outline-primary"}`} onClick={() => { setSection("accounts"); setQuery(""); setStatusFilter("TODOS"); setError(""); setNotice(""); }}>
            <CreditCard size={16} className="me-2" />Cuentas bancarias
          </button>
        </div>

        <div className="row g-3 mb-3">
          <div className="col-md-6">
            <div className="input-group">
              <span className="input-group-text"><Building2 size={16} /></span>
              <input className="form-control" type="search" placeholder={section === "banks" ? "Buscar por banco, código o SWIFT/BIC..." : "Buscar por empresa, banco o cuenta..."} aria-label="Buscar" value={query} onChange={(event) => setQuery(event.target.value)} />
            </div>
          </div>
        </div>

        <RegistroResumen total={rows.length} activos={counts.activos} inactivos={counts.inactivos} filtro={statusFilter} cargando={loading} onChange={setStatusFilter} />
        {!loading && <p className="entity-result-count" role="status">Mostrando {section === "banks" ? visibleBanks.length : visibleAccounts.length} de {rows.length} registros</p>}
        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        {notice && <div className="alert alert-success" role="status">{notice}</div>}

        <div className="table-responsive">
          {section === "banks" ? (
            <table className="table table-striped table-hover treasury-table align-middle">
              <caption className="visually-hidden">Catálogo de bancos</caption>
              <thead><tr><th>Código</th><th>Banco</th><th>País</th><th>SWIFT/BIC</th><th>Estado</th>{(canWrite || canDelete) && <th>Acciones</th>}</tr></thead>
              <tbody>
                {loading ? <tr><td colSpan={canWrite || canDelete ? 6 : 5} className="text-center py-4" role="status">Cargando bancos...</td></tr>
                  : visibleBanks.length === 0 ? <tr><td colSpan={canWrite || canDelete ? 6 : 5} className="text-center py-4 text-muted">No hay bancos para mostrar.</td></tr>
                    : visibleBanks.map((bank) => <tr key={bank.id}>
                      <td>{bank.codigo}</td><td>{bank.nombre}</td><td>{bank.pais}</td><td>{bank.swift_bic || "—"}</td>
                      <td><span className={`badge text-bg-${bank.estado === "ACTIVO" ? "success" : "secondary"}`}>{bank.estado === "ACTIVO" ? "Activo" : "Inactivo"}</span></td>
                      {(canWrite || canDelete) && <td className="text-nowrap">
                        {canWrite && <button type="button" className="btn btn-outline-primary btn-sm me-1" aria-label={`Editar ${bank.nombre}`} onClick={() => openEdit(bank)}><SquarePen size={15} /></button>}
                        {canDelete && bank.estado === "ACTIVO" && <button type="button" className="btn btn-outline-danger btn-sm" aria-label={`Inactivar ${bank.nombre}`} onClick={() => void deactivate(bank)}><Trash2 size={15} /></button>}
                      </td>}
                    </tr>)}
              </tbody>
            </table>
          ) : (
            <table className="table table-striped table-hover treasury-table align-middle">
              <caption className="visually-hidden">Cuentas bancarias registradas por empresa</caption>
              <thead><tr><th>Empresa</th><th>Banco</th><th>Código</th><th>Número de cuenta</th><th>Titular</th><th>Tipo</th><th>Moneda</th><th className="text-end">Saldo actual</th><th>Estado</th>{(canWrite || canDelete) && <th>Acciones</th>}</tr></thead>
              <tbody>
                {loading ? <tr><td colSpan={canWrite || canDelete ? 10 : 9} className="text-center py-4" role="status">Cargando cuentas...</td></tr>
                  : visibleAccounts.length === 0 ? <tr><td colSpan={canWrite || canDelete ? 10 : 9} className="text-center py-4 text-muted">No hay cuentas para mostrar.</td></tr>
                    : visibleAccounts.map((account) => <tr key={account.id}>
                      <td>{account.empresa}</td><td>{account.banco}</td><td>{account.codigo}</td><td>{account.numero_cuenta}</td>
                      <td>{account.titular}</td><td>{account.tipo_cuenta}</td><td>{account.moneda}</td>
                      <td className="text-end">{new Intl.NumberFormat("es-EC", { style: "currency", currency: account.moneda || "USD" }).format(account.saldo_actual)}</td>
                      <td><span className={`badge text-bg-${account.estado === "ACTIVA" ? "success" : "secondary"}`}>{account.estado === "ACTIVA" ? "Activa" : "Inactiva"}</span></td>
                      {(canWrite || canDelete) && <td className="text-nowrap">
                        {canWrite && <button type="button" className="btn btn-outline-primary btn-sm me-1" aria-label={`Editar cuenta ${account.codigo}`} onClick={() => openEdit(account)}><SquarePen size={15} /></button>}
                        {canDelete && account.estado === "ACTIVA" && <button type="button" className="btn btn-outline-danger btn-sm" aria-label={`Inactivar cuenta ${account.codigo}`} onClick={() => void deactivate(account)}><Trash2 size={15} /></button>}
                      </td>}
                    </tr>)}
              </tbody>
            </table>
          )}
        </div>
        {!loading && error && <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => void loadData()}><RotateCw size={14} className="me-1" />Reintentar</button>}
      </div>

      {showModal && (
        <div className="modal-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget && !saving) setShowModal(false); }} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.5)", zIndex: 1050, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
          <div className="modal-container" role="dialog" aria-modal="true" aria-labelledby="bank-modal-title" style={{ background: "white", borderRadius: 12, width: "100%", maxWidth: 800, maxHeight: "95vh", overflow: "auto", boxShadow: "0 20px 60px rgba(0,0,0,.3)" }}>
            <form onSubmit={(event) => void handleSubmit(event)}>
              <div className="modal-header text-white" style={{ padding: "1.25rem 1.5rem", display: "flex", justifyContent: "space-between", background: "#343a40" }}>
                <h2 className="modal-title fs-5" id="bank-modal-title">{editId === null ? "Nuevo" : "Editar"} {section === "banks" ? "banco" : "cuenta bancaria"}</h2>
                <button type="button" className="btn-close btn-close-white" aria-label="Cerrar" onClick={() => setShowModal(false)} disabled={saving} />
              </div>
              <div className="modal-body" style={{ padding: "1.5rem", maxHeight: "calc(85vh - 140px)", overflowY: "auto" }}>
                {formError && <div className="alert alert-danger" role="alert">{formError}</div>}
                <div className="row g-3">
                  {section === "banks" ? (
                    <>
                      <div className="col-md-6"><label className="form-label" htmlFor="codigo">Código *</label><input className="form-control" id="codigo" name="codigo" value={form.codigo ?? ""} onChange={handleChange} maxLength={30} required /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="nombre">Nombre del banco *</label><input className="form-control" id="nombre" name="nombre" value={form.nombre ?? ""} onChange={handleChange} maxLength={120} required /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="pais">País *</label><input className="form-control" id="pais" name="pais" value={form.pais ?? ""} onChange={handleChange} maxLength={80} required /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="swift_bic">SWIFT/BIC</label><input className="form-control" id="swift_bic" name="swift_bic" value={form.swift_bic ?? ""} onChange={handleChange} maxLength={11} placeholder="8 u 11 caracteres" /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="estado">Estado</label><select className="form-select" id="estado" name="estado" value={form.estado ?? "ACTIVO"} onChange={handleChange}><option value="ACTIVO">Activo</option><option value="INACTIVO">Inactivo</option></select></div>
                    </>
                  ) : (
                    <>
                      <div className="col-md-6"><label className="form-label" htmlFor="empresa_id">Empresa *</label><select className="form-select" id="empresa_id" name="empresa_id" value={form.empresa_id ?? ""} onChange={handleChange} required disabled={editId !== null}><option value="">Seleccione...</option>{catalogs.companies.map((item) => <option key={item.id} value={item.id}>{item.nombre_comercial}</option>)}</select></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="banco_id">Banco *</label><select className="form-select" id="banco_id" name="banco_id" value={form.banco_id ?? ""} onChange={handleChange} required><option value="">Seleccione...</option>{catalogs.banks.map((item) => <option key={item.id} value={item.id}>{item.nombre}</option>)}</select></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="codigo">Código interno *</label><input className="form-control" id="codigo" name="codigo" value={form.codigo ?? ""} onChange={handleChange} maxLength={30} required /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="numero_cuenta">Número de cuenta {editId === null ? "*" : ""}</label><input className="form-control" id="numero_cuenta" name="numero_cuenta" value={form.numero_cuenta ?? ""} onChange={handleChange} maxLength={80} required={editId === null} placeholder={editId === null ? "" : "Dejar vacío para conservarla"} /><div className="form-text">{editId === null ? "El número se mostrará enmascarado en los listados." : "Por seguridad, el número actual no se muestra. Déjalo vacío para conservarlo."}</div></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="titular">Titular *</label><input className="form-control" id="titular" name="titular" value={form.titular ?? ""} onChange={handleChange} maxLength={160} required /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="tipo_cuenta">Tipo de cuenta *</label><select className="form-select" id="tipo_cuenta" name="tipo_cuenta" value={form.tipo_cuenta ?? "CORRIENTE"} onChange={handleChange} required><option value="CORRIENTE">Corriente</option><option value="AHORROS">Ahorros</option><option value="OTRA">Otra</option></select></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="sucursal_bancaria">Sucursal bancaria</label><input className="form-control" id="sucursal_bancaria" name="sucursal_bancaria" value={form.sucursal_bancaria ?? ""} onChange={handleChange} maxLength={120} /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="moneda">Moneda *</label><select className="form-select" id="moneda" name="moneda" value={form.moneda ?? ""} onChange={handleChange} required>{catalogs.currencies.map((item) => <option key={item.codigo} value={item.codigo}>{item.codigo} — {item.nombre}</option>)}</select></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="fecha_saldo_inicial">Fecha del saldo inicial *</label><input className="form-control" id="fecha_saldo_inicial" name="fecha_saldo_inicial" type="date" value={form.fecha_saldo_inicial ?? ""} onChange={handleChange} required /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="saldo_inicial">Saldo inicial *</label><input className="form-control" id="saldo_inicial" name="saldo_inicial" type="number" min="0" step="0.01" value={form.saldo_inicial ?? 0} onChange={handleChange} required /></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="cuenta_contable_id">Cuenta contable</label><select className="form-select" id="cuenta_contable_id" name="cuenta_contable_id" value={form.cuenta_contable_id ?? ""} onChange={handleChange}><option value="">Sin asociar</option>{chartAccounts.map((item) => <option key={item.id} value={item.id}>{item.codigo} — {item.nombre}</option>)}</select></div>
                      <div className="col-md-6"><label className="form-label" htmlFor="estado">Estado</label><select className="form-select" id="estado" name="estado" value={form.estado ?? "ACTIVA"} onChange={handleChange}><option value="ACTIVA">Activa</option><option value="INACTIVA">Inactiva</option></select></div>
                    </>
                  )}
                </div>
              </div>
              <div className="modal-footer" style={{ padding: "1rem 1.5rem", display: "flex", justifyContent: "flex-end", gap: ".5rem", borderTop: "1px solid #dee2e6" }}>
                <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)} disabled={saving}>Cancelar</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? "Guardando..." : editId === null ? "Guardar" : "Actualizar"}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
