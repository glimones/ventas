import type { ChangeEvent } from "react";
import type {
  AperturaCierreCaja,
  AperturaCierreCajaFormValues,
  CajaOpcion,
  UsuarioCaja,
} from "./types";

interface Props {
  mode: "APERTURA" | "CIERRE";
  values: AperturaCierreCajaFormValues;
  session: AperturaCierreCaja | null;
  boxes: CajaOpcion[];
  users: UsuarioCaja[];
  onChange: (event: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

export default function AperturaCierreCajaForm({
  mode,
  values,
  session,
  boxes,
  users,
  onChange,
}: Props) {
  const selectedBox = boxes.find((box) => String(box.id) === values.caja_id);
  const companyUsers = selectedBox
    ? users.filter((user) => user.empresa_id === selectedBox.empresa_id)
    : [];
  const counted = values.efectivo_contado === "" ? null : Number(values.efectivo_contado);

  if (mode === "CIERRE" && session) {
    const difference = counted === null || !Number.isFinite(counted)
      ? null
      : Number((counted - session.saldo_esperado).toFixed(2));
    return (
      <div className="row g-3">
        <div className="col-md-6">
          <label className="form-label">Caja</label>
          <input className="form-control" value={`${session.codigo_caja} — ${session.caja}`} readOnly />
        </div>
        <div className="col-md-6">
          <label className="form-label">Saldo esperado</label>
          <input className="form-control" value={session.saldo_esperado.toFixed(2)} readOnly />
        </div>
        <div className="col-md-6">
          <label className="form-label" htmlFor="cierre-efectivo-contado">Efectivo contado *</label>
          <input
            className="form-control"
            id="cierre-efectivo-contado"
            name="efectivo_contado"
            type="number"
            min="0"
            step="0.01"
            value={values.efectivo_contado}
            onChange={onChange}
            required
          />
        </div>
        <div className="col-md-6">
          <label className="form-label">Diferencia</label>
          <input className="form-control" value={difference === null ? "—" : difference.toFixed(2)} readOnly />
        </div>
        <div className="col-12">
          <label className="form-label" htmlFor="cierre-observacion">Observación</label>
          <textarea
            className="form-control"
            id="cierre-observacion"
            name="observacion"
            value={values.observacion}
            onChange={onChange}
            maxLength={500}
            rows={3}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="row g-3">
      <div className="col-md-6">
        <label className="form-label" htmlFor="apertura-caja">Caja activa *</label>
        <select className="form-select" id="apertura-caja" name="caja_id" value={values.caja_id} onChange={onChange} required>
          <option value="">Seleccione una caja...</option>
          {boxes.map((box) => (
            <option key={box.id} value={box.id}>
              {box.codigo} — {box.nombre}{box.empresa ? ` · ${box.empresa}` : ""}
            </option>
          ))}
        </select>
        {boxes.length === 0 && <div className="form-text text-danger">No hay cajas activas disponibles para apertura.</div>}
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="apertura-responsable">Responsable de apertura *</label>
        <select className="form-select" id="apertura-responsable" name="responsable_id" value={values.responsable_id} onChange={onChange} required disabled={!selectedBox}>
          <option value="">Seleccione un responsable...</option>
          {companyUsers.map((user) => <option key={user.id} value={user.id}>{user.nombre}</option>)}
        </select>
      </div>
      <div className="col-md-6">
        <label className="form-label" htmlFor="apertura-saldo-inicial">Saldo físico inicial *</label>
        <input
          className="form-control"
          id="apertura-saldo-inicial"
          name="saldo_inicial"
          type="number"
          min="0"
          step="0.01"
          value={values.saldo_inicial}
          onChange={onChange}
          required
        />
      </div>
    </div>
  );
}
