export type EstadoCajaSesion = "ABIERTA" | "CERRADA";

export interface AperturaCierreCaja {
  id: number;
  codigo: string;
  caja_id: number;
  caja: string;
  codigo_caja: string;
  empresa: string;
  sucursal: string;
  responsable_id: number;
  responsable: string;
  fecha_apertura: string;
  saldo_inicial: number;
  fecha_cierre: string | null;
  cerrado_por: string | null;
  saldo_esperado: number;
  efectivo_contado: number | null;
  diferencia: number | null;
  observacion: string;
  estado: EstadoCajaSesion;
}

export interface CajaOpcion {
  id: number;
  nombre: string;
  codigo: string;
  empresa?: string;
  empresa_id?: number;
  sucursal?: string;
  responsable_id?: number | null;
}

export interface UsuarioCaja {
  id: number;
  empresa_id: number;
  nombre: string;
}

export interface AperturaCierreCajaFormValues {
  caja_id: string;
  responsable_id: string;
  saldo_inicial: number | string;
  efectivo_contado: number | string;
  observacion: string;
}
