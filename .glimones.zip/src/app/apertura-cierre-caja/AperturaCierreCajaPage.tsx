"use client";

import { useCallback, useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import { CirclePlus, RotateCw } from "lucide-react";
import { useAccessMenu } from "@/components/access-menu-context";
import RegistroResumen, { type FiltroEstadoRegistro } from "@/components/registro-resumen";
import AperturaCierreCajaModal from "./AperturaCierreCajaModal";
import type {
  AperturaCierreCaja,
  AperturaCierreCajaFormValues,
  CajaOpcion,
  UsuarioCaja,
} from "./types";
import "./bootstrap-apertura-cierre-caja.css";

type Catalogs = {
  availableBoxes: CajaOpcion[];
  boxes: CajaOpcion[];
  users: UsuarioCaja[];
};

const emptyForm: AperturaCierreCajaFormValues = {
  caja_id: "",
  responsable_id: "",
  saldo_inicial: "",
  efectivo_contado: "",
  observacion: "",
};

async function readJson(response: Response) {
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "No se pudo completar la operación.");
  return result;
}

function formatAmount(amount: number) {
  return new Intl.NumberFormat("es-EC", { style: "currency", currency: "USD" }).format(amount);
}

function formatDate(value: string | null) {
  return value ? new Date(value).toLocaleString("es-EC") : "—";
}

export default function AperturaCierreCajaPage() {
  const { options } = useAccessMenu();
  const access = options.find((option) => option.ruta === "/apertura-cierre-caja")?.actions ?? 0;
  const canWrite = (access & 2) === 2;
  const [sessions, setSessions] = useState<AperturaCierreCaja[]>([]);
  const [catalogs, setCatalogs] = useState<Catalogs>({ availableBoxes: [], boxes: [], users: [] });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [formError, setFormError] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [mode, setMode] = useState<"APERTURA" | "CIERRE">("APERTURA");
  const [selectedSession, setSelectedSession] = useState<AperturaCierreCaja | null>(null);
  const [form, setForm] = useState<AperturaCierreCajaFormValues>(emptyForm);
  const [boxFilter, setBoxFilter] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [responsibleFilter, setResponsibleFilter] = useState("");
  const [summaryFilter, setSummaryFilter] = useState<FiltroEstadoRegistro>("TODOS");

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const result = await readJson(await fetch("/api/apertura-cierre-caja", { cache: "no-store" }));
      setSessions(result.data as AperturaCierreCaja[]);
      setCatalogs(result.catalogs as Catalogs);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar las aperturas y cierres.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const filteredSessions = useMemo(() => sessions.filter((session) =>
    (!boxFilter || String(session.caja_id) === boxFilter) &&
    (!dateFilter || session.fecha_apertura.slice(0, 10) === dateFilter) &&
    (!responsibleFilter || String(session.responsable_id) === responsibleFilter) &&
    (summaryFilter === "TODOS" ||
      (summaryFilter === "ACTIVOS" && session.estado === "ABIERTA") ||
      (summaryFilter === "INACTIVOS" && session.estado === "CERRADA")),
  ), [sessions, boxFilter, dateFilter, responsibleFilter, summaryFilter]);

  function openOpening() {
    const box = catalogs.availableBoxes[0];
    const defaultResponsible = box
      ? catalogs.users.find((user) => user.id === box.responsable_id && user.empresa_id === box.empresa_id)
        ?? catalogs.users.find((user) => user.empresa_id === box.empresa_id)
      : undefined;
    setMode("APERTURA");
    setSelectedSession(null);
    setForm({
      ...emptyForm,
      caja_id: box ? String(box.id) : "",
      responsable_id: defaultResponsible ? String(defaultResponsible.id) : "",
      saldo_inicial: "",
    });
    setFormError("");
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function openClosing(session: AperturaCierreCaja) {
    setMode("CIERRE");
    setSelectedSession(session);
    setForm({ ...emptyForm, efectivo_contado: "", observacion: "" });
    setFormError("");
    setError("");
    setNotice("");
    setShowModal(true);
  }

  function handleChange(event: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) {
    const { name, value, type } = event.target;
    setForm((current) => ({
      ...current,
      [name]: type === "number" && value !== "" ? Number(value) : value,
      ...(name === "caja_id" ? { responsable_id: "" } : {}),
    }));
    setFormError("");
  }

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setFormError("");
    setNotice("");
    try {
      const opening = mode === "APERTURA";
      const endpoint = opening
        ? "/api/apertura-cierre-caja"
        : `/api/apertura-cierre-caja/${selectedSession?.id}`;
      const response = await fetch(endpoint, {
        method: opening ? "POST" : "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(opening
          ? {
              caja_id: Number(form.caja_id),
              responsable_id: Number(form.responsable_id),
              saldo_inicial: Number(form.saldo_inicial),
            }
          : {
              efectivo_contado: Number(form.efectivo_contado),
              observacion: form.observacion,
            }),
      });
      const result = await readJson(response);
      setShowModal(false);
      await loadData();
      setNotice(opening
        ? `Caja abierta con el registro ${result.data.codigo}.`
        : `Caja cerrada. Diferencia: ${formatAmount(result.data.diferencia)}.`);
    } catch (saveError) {
      setFormError(saveError instanceof Error ? saveError.message : "No se pudo guardar la apertura o cierre.");
    } finally {
      setSaving(false);
    }
  }

  const openCount = sessions.filter((session) => session.estado === "ABIERTA").length;
  const closedCount = sessions.length - openCount;

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
          <div>
            <h1 className="mb-1">Apertura y Cierre de Caja</h1>
            <p className="text-muted mb-0">Controla las sesiones, movimientos y diferencias de efectivo.</p>
          </div>
          {canWrite && (
            <button type="button" className="btn btn-primary treasury-add-button" onClick={openOpening} disabled={loading || catalogs.availableBoxes.length === 0}>
              <CirclePlus size={16} className="me-2" />Abrir caja
            </button>
          )}
        </div>

        <RegistroResumen
          total={sessions.length}
          activos={openCount}
          inactivos={closedCount}
          activosLabel="Abiertas"
          inactivosLabel="Cerradas"
          filtro={summaryFilter}
          cargando={loading}
          onChange={setSummaryFilter}
        />

        <div className="row g-2 mb-3">
          <div className="col-md-4">
            <select className="form-select" aria-label="Filtrar por caja" value={boxFilter} onChange={(event) => setBoxFilter(event.target.value)}>
              <option value="">Todas las cajas</option>
              {catalogs.boxes.map((box) => <option key={box.id} value={box.id}>{box.codigo} — {box.nombre}</option>)}
            </select>
          </div>
          <div className="col-md-4">
            <input className="form-control" type="date" aria-label="Filtrar por fecha de apertura" value={dateFilter} onChange={(event) => setDateFilter(event.target.value)} />
          </div>
          <div className="col-md-4">
            <select className="form-select" aria-label="Filtrar por responsable" value={responsibleFilter} onChange={(event) => setResponsibleFilter(event.target.value)}>
              <option value="">Todos los responsables</option>
              {catalogs.users.map((user) => <option key={user.id} value={user.id}>{user.nombre}</option>)}
            </select>
          </div>
        </div>

        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        {notice && <div className="alert alert-success" role="status">{notice}</div>}
        <div className="table-responsive">
          <table className="table table-striped table-hover align-middle">
            <thead className="table-dark">
              <tr>
                <th>Registro</th><th>Caja</th><th>Apertura</th><th>Cierre</th><th>Responsable</th>
                <th className="text-end">Saldo inicial</th><th className="text-end">Esperado</th>
                <th className="text-end">Contado</th><th className="text-end">Diferencia</th><th>Estado</th>
                {canWrite && <th>Acción</th>}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={canWrite ? 11 : 10} className="text-center py-4" role="status">Cargando sesiones...</td></tr>
              ) : filteredSessions.length === 0 ? (
                <tr><td colSpan={canWrite ? 11 : 10} className="text-center py-4 text-muted">No hay aperturas o cierres para mostrar.</td></tr>
              ) : filteredSessions.map((session) => (
                <tr key={session.id}>
                  <td>{session.codigo}</td>
                  <td>{session.codigo_caja} — {session.caja}<small className="d-block text-muted">{session.empresa} · {session.sucursal}</small></td>
                  <td>{formatDate(session.fecha_apertura)}</td>
                  <td>{formatDate(session.fecha_cierre)}</td>
                  <td>{session.responsable}</td>
                  <td className="text-end">{formatAmount(session.saldo_inicial)}</td>
                  <td className="text-end">{formatAmount(session.saldo_esperado)}</td>
                  <td className="text-end">{session.efectivo_contado === null ? "—" : formatAmount(session.efectivo_contado)}</td>
                  <td className="text-end">{session.diferencia === null ? "—" : formatAmount(session.diferencia)}</td>
                  <td><span className={`badge text-bg-${session.estado === "ABIERTA" ? "success" : "secondary"}`}>{session.estado === "ABIERTA" ? "Abierta" : "Cerrada"}</span></td>
                  {canWrite && <td>{session.estado === "ABIERTA"
                    ? <button type="button" className="btn btn-outline-primary btn-sm" onClick={() => openClosing(session)}>Cerrar caja</button>
                    : <span className="text-muted">Bloqueada</span>}</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {!loading && error && <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => void loadData()}><RotateCw size={14} className="me-1" />Reintentar</button>}
      </div>

      <AperturaCierreCajaModal
        show={showModal}
        mode={mode}
        session={selectedSession}
        values={form}
        onChange={handleChange}
        onClose={() => {
          if (!saving) setShowModal(false);
        }}
        onSubmit={(event) => void handleSubmit(event)}
        saving={saving}
        formError={formError}
        boxes={catalogs.availableBoxes}
        users={catalogs.users}
      />
    </div>
  );
}
