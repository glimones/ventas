import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import { getMockTreasuryState, type TreasuryBankTransfer } from "@/lib/mock-treasury";
import { parseTransfer } from "@/lib/transferencias-bancarias";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

function parseId(value: string) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

function mockAccountValid(transfer: TreasuryBankTransfer) {
  const state = getMockTreasuryState();
  const source = state.bankAccounts.find((account) => account.id === transfer.cuenta_origen_id);
  const destination = state.bankAccounts.find((account) => account.id === transfer.cuenta_destino_id);
  const sourceBank = source && state.banks.find((bank) => bank.id === source.banco_id);
  const destinationBank = destination && state.banks.find((bank) => bank.id === destination.banco_id);
  const users = state.users.filter((user) => user.empresa_id === transfer.empresa_id);
  return Boolean(
    source && destination &&
    source.empresa_id === transfer.empresa_id && destination.empresa_id === transfer.empresa_id &&
    source.estado === "ACTIVA" && destination.estado === "ACTIVA" &&
    source.moneda === destination.moneda && source.moneda === transfer.moneda &&
    sourceBank?.estado === "ACTIVO" && destinationBank?.estado === "ACTIVO" &&
    users.some((user) => user.id === transfer.responsable_id) &&
    (transfer.autorizado_por_id === null || users.some((user) => user.id === transfer.autorizado_por_id))
  );
}

export async function GET(request: NextRequest, context: RouteContext) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = parseId((await context.params).id);
  if (id === null) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  if (isMockAuthEnabled()) {
    const transfer = getMockTreasuryState().bankTransfers.find((item) => item.id === id);
    return transfer
      ? NextResponse.json({ data: transfer })
      : NextResponse.json({ error: "Transferencia no encontrada." }, { status: 404 });
  }
  const result = await getDatabasePool().query(
    `SELECT id::text, empresa_id::text, codigo, cuenta_origen_id::text, cuenta_destino_id::text,
            beneficiario, fecha::text, importe, moneda, concepto, referencia_bancaria,
            comprobante_base64, comprobante_mime_type,
            responsable_id::text, autorizado_por_id::text, estado, completada_en,
            completada_por_id::text, reversada_en, reversada_por_id::text, motivo_reversion
     FROM transferencias_bancarias
     WHERE id = $1 AND empresa_id = $2`,
    [id, getEmpresaId()],
  );
  if (!result.rows[0]) return NextResponse.json({ error: "Transferencia no encontrada." }, { status: 404 });
  const row = result.rows[0];
  return NextResponse.json({
    data: {
      ...row,
      id: Number(row.id),
      empresa_id: Number(row.empresa_id),
      cuenta_origen_id: Number(row.cuenta_origen_id),
      cuenta_destino_id: Number(row.cuenta_destino_id),
      responsable_id: row.responsable_id === null ? null : Number(row.responsable_id),
      autorizado_por_id: row.autorizado_por_id === null ? null : Number(row.autorizado_por_id),
      completada_por_id: row.completada_por_id === null ? null : Number(row.completada_por_id),
      reversada_por_id: row.reversada_por_id === null ? null : Number(row.reversada_por_id),
      importe: Number(row.importe),
      estado: String(row.estado).toUpperCase(),
      comprobante_base64: String(row.comprobante_base64 ?? ""),
      comprobante_mime_type: String(row.comprobante_mime_type ?? ""),
    },
  });
}

export async function PUT(request: NextRequest, context: RouteContext) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = parseId((await context.params).id);
  if (id === null) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  const input = parseTransfer(body);
  if (!input) return NextResponse.json({ error: "Revisa los datos de la transferencia y que el comprobante sea PNG, JPG o WebP válido de hasta 5 MB." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const transfer = state.bankTransfers.find((item) => item.id === id);
    if (!transfer) return NextResponse.json({ error: "Transferencia no encontrada." }, { status: 404 });
    if (transfer.estado !== "PENDIENTE") return NextResponse.json({ error: "Solo se pueden editar transferencias pendientes." }, { status: 409 });
    const updated: TreasuryBankTransfer = { ...transfer, ...input };
    if (!state.companies.some((company) => company.id === input.empresa_id) ||
        input.empresa_id !== transfer.empresa_id ||
        !mockAccountValid(updated)) {
      return NextResponse.json({ error: "Las cuentas y los usuarios deben pertenecer a la empresa y estar activos, con la misma moneda." }, { status: 400 });
    }
    Object.assign(transfer, input);
    const actor = Number(claims.sub);
    state.bankTransferHistory.push({
      id: state.bankTransferHistory.reduce((max, event) => Math.max(max, event.id), 0) + 1,
      transferencia_id: transfer.id,
      estado_anterior: "PENDIENTE",
      estado_nuevo: "PENDIENTE",
      ocurrido_en: new Date().toISOString(),
      usuario_id: Number.isSafeInteger(actor) && actor > 0
        ? actor
        : state.users.find((user) => user.empresa_id === transfer.empresa_id)?.id ?? null,
      detalle: "Transferencia pendiente actualizada.",
    });
    return NextResponse.json({ data: { id: transfer.id, codigo: transfer.codigo, estado: transfer.estado } });
  }

  const companyId = getEmpresaId();
  if (input.empresa_id !== companyId) return NextResponse.json({ error: "La empresa seleccionada no coincide con la empresa configurada." }, { status: 400 });
  const client = await getDatabasePool().connect();
  let transactionOpen = false;
  try {
    await client.query("BEGIN");
    transactionOpen = true;
    const existing = await client.query<{ estado: string; empresa_id: string }>(
      `SELECT estado, empresa_id::text FROM transferencias_bancarias
       WHERE id = $1 AND empresa_id = $2 FOR UPDATE`,
      [id, companyId],
    );
    if (!existing.rows[0]) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Transferencia no encontrada." }, { status: 404 });
    }
    if (existing.rows[0].estado !== "PENDIENTE") {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Solo se pueden editar transferencias pendientes." }, { status: 409 });
    }
    const accounts = await client.query<{ id: string; moneda: string; estado: string; banco_estado: string }>(
      `SELECT cuenta.id::text, cuenta.moneda, cuenta.estado, banco.estado AS banco_estado
       FROM cuentas_bancarias AS cuenta
       JOIN bancos AS banco ON banco.id = cuenta.banco_id
       WHERE cuenta.id = ANY($1::bigint[]) AND cuenta.empresa_id = $2
       ORDER BY cuenta.id FOR UPDATE OF cuenta`,
      [[input.cuenta_origen_id, input.cuenta_destino_id], companyId],
    );
    const source = accounts.rows.find((account) => Number(account.id) === input.cuenta_origen_id);
    const destination = accounts.rows.find((account) => Number(account.id) === input.cuenta_destino_id);
    if (!source || !destination || source.estado !== "ACTIVA" || destination.estado !== "ACTIVA" ||
        source.banco_estado !== "ACTIVO" || destination.banco_estado !== "ACTIVO" ||
        source.moneda !== destination.moneda || source.moneda !== input.moneda) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Las cuentas deben estar activas, pertenecer a la empresa y usar la misma moneda." }, { status: 400 });
    }
    const users = await client.query<{ id: string }>(
      `SELECT id::text FROM usuarios
       WHERE empresa_id = $1 AND estado = 'ACTIVO' AND id = ANY($2::bigint[])`,
      [companyId, [input.responsable_id, input.autorizado_por_id].filter((value): value is number => value !== null)],
    );
    const validUserIds = new Set(users.rows.map((user) => Number(user.id)));
    if (!validUserIds.has(input.responsable_id) ||
        (input.autorizado_por_id !== null && !validUserIds.has(input.autorizado_por_id))) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "El responsable y el autorizador deben pertenecer a la empresa y estar activos." }, { status: 400 });
    }
    await client.query(
      `UPDATE transferencias_bancarias
       SET cuenta_origen_id = $3, cuenta_destino_id = $4, beneficiario = $5, fecha = $6,
           importe = $7, moneda = $8, concepto = $9, referencia_bancaria = NULLIF($10, ''),
           comprobante_base64 = NULLIF($11, ''), comprobante_mime_type = NULLIF($12, ''),
           responsable_id = $13, autorizado_por_id = $14
       WHERE id = $1 AND empresa_id = $2`,
      [id, companyId, input.cuenta_origen_id, input.cuenta_destino_id, input.beneficiario,
        input.fecha, input.importe, input.moneda, input.concepto, input.referencia_bancaria,
        input.comprobante_base64, input.comprobante_mime_type,
        input.responsable_id, input.autorizado_por_id],
    );
    await client.query(
      `INSERT INTO transferencias_bancarias_historial
         (empresa_id, transferencia_id, estado_anterior, estado_nuevo, usuario_id, detalle)
       VALUES ($1, $2, 'PENDIENTE', 'PENDIENTE', $3, 'Transferencia pendiente actualizada.')`,
      [companyId, id, Number.isSafeInteger(Number(claims.sub)) ? Number(claims.sub) : null],
    );
    await client.query("COMMIT");
    transactionOpen = false;
    return NextResponse.json({ data: { id, estado: "PENDIENTE" } });
  } catch (error) {
    if (transactionOpen) await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function PATCH(request: NextRequest, context: RouteContext) {
  return PUT(request, context);
}
