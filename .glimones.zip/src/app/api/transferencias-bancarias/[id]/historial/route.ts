import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import { getMockTreasuryState } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

function parseId(value: string) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

export async function GET(request: NextRequest, context: RouteContext) {
  if (!await getActiveAccessClaims(request)) {
    return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  }
  const id = parseId((await context.params).id);
  if (id === null) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const transfer = state.bankTransfers.find((item) => item.id === id);
    if (!transfer) return NextResponse.json({ error: "Transferencia no encontrada." }, { status: 404 });
    const data = state.bankTransferHistory
      .filter((event) => event.transferencia_id === id)
      .sort((left, right) => left.ocurrido_en.localeCompare(right.ocurrido_en))
      .map((event) => ({
        ...event,
        usuario: state.users.find((user) => user.id === event.usuario_id)?.nombre ?? "Sistema",
      }));
    return NextResponse.json({ data });
  }
  const result = await getDatabasePool().query(
    `SELECT historial.id::text, historial.estado_anterior, historial.estado_nuevo,
            historial.ocurrido_en, historial.detalle, usuario.nombre AS usuario
     FROM transferencias_bancarias_historial AS historial
     LEFT JOIN usuarios AS usuario
       ON usuario.id = historial.usuario_id AND usuario.empresa_id = historial.empresa_id
     WHERE historial.empresa_id = $1 AND historial.transferencia_id = $2
     ORDER BY historial.ocurrido_en, historial.id`,
    [getEmpresaId(), id],
  );
  return NextResponse.json({
    data: result.rows.map((row) => ({
      ...row,
      id: Number(row.id),
      estado_anterior: row.estado_anterior ? String(row.estado_anterior).toUpperCase() : null,
      estado_nuevo: String(row.estado_nuevo).toUpperCase(),
      usuario: row.usuario ?? "Sistema",
    })),
  });
}
