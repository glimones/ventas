import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import {
  getExpectedBankBalance,
  getMockTreasuryState,
  nextMockId,
  type TreasuryBankTransfer,
  type TreasuryBankTransferHistory,
  type TreasuryBankTransferStatus,
} from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };
type ActionInput = { estado?: TreasuryBankTransferStatus; accion?: "REVERTIR"; detalle?: string; motivo?: string };

function parseId(value: string) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

function parseAction(input: unknown): ActionInput | null {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const body = input as Record<string, unknown>;
  const state = body.estado;
  const detail = typeof body.detalle === "string" ? body.detalle.trim() : "";
  const reason = typeof body.motivo === "string" ? body.motivo.trim() : "";
  if (body.accion === "REVERTIR" && reason.length >= 5 && reason.length <= 2000) {
    return { accion: "REVERTIR", motivo: reason };
  }
  if (typeof state === "string" &&
      ["EN_PROCESO", "COMPLETADA", "RECHAZADA", "ANULADA"].includes(state) &&
      detail.length <= 2000 &&
      (!["RECHAZADA", "ANULADA"].includes(state) || detail.length >= 5)) {
    return { estado: state as TreasuryBankTransferStatus, detalle: detail };
  }
  return null;
}

function actorId(sub: string, companyId: number) {
  const id = Number(sub);
  if (Number.isSafeInteger(id) && id > 0) return id;
  return isMockAuthEnabled()
    ? getMockTreasuryState().users.find((user) => user.empresa_id === companyId)?.id ?? null
    : null;
}

function appendHistory(
  transfer: TreasuryBankTransfer,
  previous: TreasuryBankTransferStatus,
  next: TreasuryBankTransferStatus,
  userId: number | null,
  detail: string,
) {
  const state = getMockTreasuryState();
  const history: TreasuryBankTransferHistory = {
    id: nextMockId(state.bankTransferHistory),
    transferencia_id: transfer.id,
    estado_anterior: previous,
    estado_nuevo: next,
    ocurrido_en: new Date().toISOString(),
    usuario_id: userId,
    detalle: detail,
  };
  state.bankTransferHistory.push(history);
}

function changeMockTransfer(
  transfer: TreasuryBankTransfer,
  action: ActionInput,
  userId: number | null,
) {
  const state = getMockTreasuryState();
  const previous = transfer.estado;
  const requiresAccounts = action.accion === "REVERTIR" || action.estado === "COMPLETADA";
  if (requiresAccounts) {
    const source = state.bankAccounts.find((account) => account.id === transfer.cuenta_origen_id);
    const destination = state.bankAccounts.find((account) => account.id === transfer.cuenta_destino_id);
    const sourceBank = source && state.banks.find((bank) => bank.id === source.banco_id);
    const destinationBank = destination && state.banks.find((bank) => bank.id === destination.banco_id);
    if (!source || !destination || source.estado !== "ACTIVA" || destination.estado !== "ACTIVA" ||
        source.moneda !== destination.moneda || source.moneda !== transfer.moneda ||
        sourceBank?.estado !== "ACTIVO" || destinationBank?.estado !== "ACTIVO") {
      return { status: 409, error: "Las cuentas ya no están activas o no tienen la misma moneda." };
    }
  }
  if (action.accion === "REVERTIR") {
    if (previous !== "COMPLETADA" || transfer.reversada_en) {
      return { status: 409, error: "Solo se pueden revertir transferencias completadas y aún no revertidas." };
    }
    const source = state.bankAccounts.find((account) => account.id === transfer.cuenta_origen_id);
    const destination = state.bankAccounts.find((account) => account.id === transfer.cuenta_destino_id);
    if (!source || !destination || getExpectedBankBalance(destination, state.bankMovements) < transfer.importe) {
      return { status: 409, error: "La cuenta de destino no tiene saldo suficiente para revertir esta transferencia." };
    }
    const now = new Date().toISOString();
    const movementId = state.bankMovements.reduce((max, movement) => Math.max(max, movement.id ?? 0), 0) + 1;
    state.bankMovements.push(
      { id: movementId, cuenta_bancaria_id: source.id, tipo: "INGRESO", importe: transfer.importe, fecha: now.slice(0, 10), concepto: "Reversión de transferencia", referencia: transfer.codigo },
      { id: movementId + 1, cuenta_bancaria_id: destination.id, tipo: "EGRESO", importe: transfer.importe, fecha: now.slice(0, 10), concepto: "Reversión de transferencia", referencia: transfer.codigo },
    );
    transfer.estado = "REVERTIDA";
    transfer.reversada_en = now;
    transfer.reversada_por_id = userId;
    transfer.motivo_reversion = action.motivo ?? "";
    appendHistory(transfer, previous, "REVERTIDA", userId, `Reversión: ${action.motivo}`);
    return { status: 200, data: transfer };
  }

  const next = action.estado;
  const allowed =
    (previous === "PENDIENTE" && ["EN_PROCESO", "RECHAZADA", "ANULADA"].includes(next ?? "")) ||
    (previous === "EN_PROCESO" && ["COMPLETADA", "RECHAZADA", "ANULADA"].includes(next ?? ""));
  if (!next || !allowed) return { status: 409, error: `No se puede cambiar de ${previous} a ${next ?? "ese estado"}.` };

  if (next === "COMPLETADA") {
    const source = state.bankAccounts.find((account) => account.id === transfer.cuenta_origen_id);
    if (!source || getExpectedBankBalance(source, state.bankMovements) < transfer.importe) {
      return { status: 409, error: "La cuenta de origen no tiene saldo suficiente para completar la transferencia." };
    }
    const now = new Date().toISOString();
    const movementId = state.bankMovements.reduce((max, movement) => Math.max(max, movement.id ?? 0), 0) + 1;
    state.bankMovements.push(
      { id: movementId, cuenta_bancaria_id: transfer.cuenta_origen_id, tipo: "EGRESO", importe: transfer.importe, fecha: now.slice(0, 10), concepto: `Transferencia ${transfer.codigo}`, referencia: transfer.codigo },
      { id: movementId + 1, cuenta_bancaria_id: transfer.cuenta_destino_id, tipo: "INGRESO", importe: transfer.importe, fecha: now.slice(0, 10), concepto: `Transferencia ${transfer.codigo}`, referencia: transfer.codigo },
    );
    transfer.completada_en = now;
    transfer.completada_por_id = userId;
  }
  transfer.estado = next;
  const detail = action.detalle || `Estado actualizado a ${next}.`;
  appendHistory(transfer, previous, next, userId, detail);
  return { status: 200, data: transfer };
}

export async function POST(request: NextRequest, context: RouteContext) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = parseId((await context.params).id);
  if (id === null) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  const action = parseAction(body);
  if (!action) return NextResponse.json({ error: "Indica un estado permitido o un motivo de reversión válido." }, { status: 400 });
  const companyId = isMockAuthEnabled() ? null : getEmpresaId();

  if (isMockAuthEnabled()) {
    const transfer = getMockTreasuryState().bankTransfers.find((item) => item.id === id);
    if (!transfer) return NextResponse.json({ error: "Transferencia no encontrada." }, { status: 404 });
    const result = changeMockTransfer(transfer, action, actorId(claims.sub, transfer.empresa_id));
    if (result.status !== 200) return NextResponse.json({ error: result.error }, { status: result.status });
    return NextResponse.json({ data: result.data });
  }

  const client = await getDatabasePool().connect();
  let transactionOpen = false;
  try {
    await client.query("BEGIN");
    transactionOpen = true;
    const result = await client.query<{
      id: string;
      empresa_id: string;
      estado: TreasuryBankTransferStatus;
      cuenta_origen_id: string;
      cuenta_destino_id: string;
      codigo: string;
      fecha: string;
      importe: string;
      moneda: string;
      referencia_bancaria: string | null;
      concepto: string;
      reversada_en: string | null;
    }>(
      `SELECT id::text, empresa_id::text, estado, cuenta_origen_id::text,
              cuenta_destino_id::text, codigo, fecha::text, importe::text,
              moneda, referencia_bancaria, concepto, reversada_en
       FROM transferencias_bancarias
       WHERE id = $1 AND empresa_id = $2
       FOR UPDATE`,
      [id, companyId],
    );
    const transfer = result.rows[0];
    if (!transfer) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Transferencia no encontrada." }, { status: 404 });
    }

    const sourceId = Number(transfer.cuenta_origen_id);
    const destinationId = Number(transfer.cuenta_destino_id);
    const amount = Number(transfer.importe);
    const isReversal = action.accion === "REVERTIR";
    const next = isReversal ? "REVERTIDA" : action.estado;
    const allowed = isReversal
      ? transfer.estado === "COMPLETADA" && transfer.reversada_en === null
      : (transfer.estado === "PENDIENTE" && ["EN_PROCESO", "RECHAZADA", "ANULADA"].includes(next ?? "")) ||
        (transfer.estado === "EN_PROCESO" && ["COMPLETADA", "RECHAZADA", "ANULADA"].includes(next ?? ""));
    if (!allowed || !next) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: isReversal
        ? "Solo se pueden revertir transferencias completadas y aún no revertidas."
        : `No se puede cambiar de ${transfer.estado} a ${next ?? "ese estado"}.` }, { status: 409 });
    }

    if (next === "COMPLETADA" || isReversal) {
      const accounts = await client.query<{
        id: string;
        moneda: string;
        estado: string;
        banco_estado: string;
        fecha_saldo_inicial: string;
        saldo_inicial: string;
      }>(
        `SELECT cuenta.id::text, cuenta.moneda, cuenta.estado, banco.estado AS banco_estado,
                cuenta.fecha_saldo_inicial::text, cuenta.saldo_inicial::text
         FROM cuentas_bancarias AS cuenta
         JOIN bancos AS banco ON banco.id = cuenta.banco_id
         WHERE cuenta.id = ANY($1::bigint[]) AND cuenta.empresa_id = $2
         ORDER BY cuenta.id FOR UPDATE OF cuenta`,
        [[sourceId, destinationId], companyId],
      );
      const source = accounts.rows.find((account) => Number(account.id) === sourceId);
      const destination = accounts.rows.find((account) => Number(account.id) === destinationId);
      if (!source || !destination || source.estado !== "ACTIVA" || destination.estado !== "ACTIVA" ||
          source.banco_estado !== "ACTIVO" || destination.banco_estado !== "ACTIVO" ||
          source.moneda !== destination.moneda || source.moneda !== transfer.moneda) {
        await client.query("ROLLBACK");
        transactionOpen = false;
        return NextResponse.json({ error: "Las cuentas ya no están activas o no tienen la misma moneda." }, { status: 409 });
      }
      const balances = await client.query<{ id: string; saldo_actual: string }>(
        `SELECT cuenta.id::text,
                cuenta.saldo_inicial + COALESCE(SUM(
                  CASE WHEN movimiento.tipo IN ('INGRESO', 'DEPOSITO', 'ABONO') THEN movimiento.importe
                       WHEN movimiento.tipo IN ('EGRESO', 'CHEQUE', 'PAGO') THEN -movimiento.importe
                       ELSE 0 END
                ), 0) AS saldo_actual
         FROM cuentas_bancarias AS cuenta
         LEFT JOIN movimientos_tesoreria AS movimiento
           ON movimiento.cuenta_bancaria_id = cuenta.id
          AND movimiento.fecha::date >= cuenta.fecha_saldo_inicial
         WHERE cuenta.id = ANY($1::bigint[]) AND cuenta.empresa_id = $2
         GROUP BY cuenta.id`,
        [[sourceId, destinationId], companyId],
      );
      const balanceById = new Map(balances.rows.map((row) => [Number(row.id), Number(row.saldo_actual)]));
      const outgoingId = isReversal ? destinationId : sourceId;
      if ((balanceById.get(outgoingId) ?? 0) < amount) {
        await client.query("ROLLBACK");
        transactionOpen = false;
        return NextResponse.json({
          error: isReversal
            ? "La cuenta de destino no tiene saldo suficiente para revertir esta transferencia."
            : "La cuenta de origen no tiene saldo suficiente para completar la transferencia.",
        }, { status: 409 });
      }
      const now = new Date().toISOString();
      const movementConcept = isReversal
        ? `Reversión de transferencia ${transfer.codigo}`
        : `Transferencia ${transfer.codigo}`;
      const reference = transfer.referencia_bancaria ?? transfer.codigo;
      if (isReversal) {
        await client.query(
          `INSERT INTO movimientos_tesoreria
             (empresa_id, cuenta_bancaria_id, tipo, fecha, concepto, referencia, importe, documento_tipo, documento_id, usuario_id)
           VALUES
             ($1, $2, 'INGRESO', $3, $4, $5, $6, 'REVERSO_TRANSFERENCIA', $7, $8),
             ($1, $9, 'EGRESO', $3, $4, $5, $6, 'REVERSO_TRANSFERENCIA', $7, $8)`,
          [companyId, sourceId, now, movementConcept, reference, amount, id,
            Number.isSafeInteger(Number(claims.sub)) ? Number(claims.sub) : null, destinationId],
        );
        await client.query(
          `UPDATE transferencias_bancarias
           SET estado = 'REVERTIDA', reversada_en = $3, reversada_por_id = $4, motivo_reversion = $5
           WHERE id = $1 AND empresa_id = $2`,
          [id, companyId, now, Number.isSafeInteger(Number(claims.sub)) ? Number(claims.sub) : null, action.motivo],
        );
      } else {
        await client.query(
          `INSERT INTO movimientos_tesoreria
             (empresa_id, cuenta_bancaria_id, tipo, fecha, concepto, referencia, importe, documento_tipo, documento_id, usuario_id)
           VALUES
             ($1, $2, 'EGRESO', $3, $4, $5, $6, 'TRANSFERENCIA_BANCARIA', $7, $8),
             ($1, $9, 'INGRESO', $3, $4, $5, $6, 'TRANSFERENCIA_BANCARIA', $7, $8)`,
          [companyId, sourceId, now, `${transfer.concepto} · ${transfer.codigo}`.slice(0, 250),
            reference, amount, id,
            Number.isSafeInteger(Number(claims.sub)) ? Number(claims.sub) : null, destinationId],
        );
        await client.query(
          `UPDATE transferencias_bancarias
           SET estado = 'COMPLETADA', completada_en = $3, completada_por_id = $4
           WHERE id = $1 AND empresa_id = $2`,
          [id, companyId, now, Number.isSafeInteger(Number(claims.sub)) ? Number(claims.sub) : null],
        );
      }
    } else {
      await client.query(
        `UPDATE transferencias_bancarias SET estado = $3
         WHERE id = $1 AND empresa_id = $2`,
        [id, companyId, next],
      );
    }

    const detail = isReversal ? `Reversión: ${action.motivo}` : action.detalle || `Estado actualizado a ${next}.`;
    await client.query(
      `INSERT INTO transferencias_bancarias_historial
         (empresa_id, transferencia_id, estado_anterior, estado_nuevo, usuario_id, detalle)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [companyId, id, transfer.estado, next,
        Number.isSafeInteger(Number(claims.sub)) ? Number(claims.sub) : null, detail],
    );
    await client.query("COMMIT");
    transactionOpen = false;
    return NextResponse.json({ data: { id, estado: next } });
  } catch (error) {
    if (transactionOpen) await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
