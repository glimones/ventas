import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import {
  getMockTreasuryState,
  nextMockId,
  type TreasuryBankTransfer,
  type TreasuryBankTransferHistory,
  type TreasuryBankTransferStatus,
} from "@/lib/mock-treasury";
import { formatTransferCode, getNextTransferCode } from "@/lib/transfer-code";
import { parseTransfer } from "@/lib/transferencias-bancarias";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const TRANSFER_SELECT = `
  SELECT transferencia.id::text, transferencia.empresa_id::text, transferencia.codigo,
         transferencia.cuenta_origen_id::text, transferencia.cuenta_destino_id::text,
         transferencia.beneficiario, to_char(transferencia.fecha, 'YYYY-MM-DD') AS fecha,
         transferencia.importe, transferencia.moneda, transferencia.concepto,
         COALESCE(transferencia.referencia_bancaria, '') AS referencia_bancaria,
         COALESCE(transferencia.comprobante_base64, '') AS comprobante_base64,
         COALESCE(transferencia.comprobante_mime_type, '') AS comprobante_mime_type,
         transferencia.responsable_id::text, responsable.nombre AS responsable,
         transferencia.autorizado_por_id::text, autorizador.nombre AS autorizado_por,
         transferencia.estado, transferencia.completada_en,
         transferencia.completada_por_id::text, transferencia.reversada_en,
         transferencia.reversada_por_id::text, transferencia.motivo_reversion,
         empresa.nombre_comercial AS empresa,
         banco_origen.nombre || ' · ' || origen.codigo || ' · ' ||
           CASE WHEN LENGTH(origen.numero_cuenta) > 4 THEN '**** ' || RIGHT(origen.numero_cuenta, 4) ELSE '****' END AS cuenta_origen,
         banco_destino.nombre || ' · ' || destino.codigo || ' · ' ||
           CASE WHEN LENGTH(destino.numero_cuenta) > 4 THEN '**** ' || RIGHT(destino.numero_cuenta, 4) ELSE '****' END AS cuenta_destino
  FROM transferencias_bancarias AS transferencia
  JOIN empresas AS empresa ON empresa.id = transferencia.empresa_id
  JOIN cuentas_bancarias AS origen
    ON origen.id = transferencia.cuenta_origen_id AND origen.empresa_id = transferencia.empresa_id
  JOIN bancos AS banco_origen ON banco_origen.id = origen.banco_id
  JOIN cuentas_bancarias AS destino
    ON destino.id = transferencia.cuenta_destino_id AND destino.empresa_id = transferencia.empresa_id
  JOIN bancos AS banco_destino ON banco_destino.id = destino.banco_id
  LEFT JOIN usuarios AS responsable
    ON responsable.id = transferencia.responsable_id AND responsable.empresa_id = transferencia.empresa_id
  LEFT JOIN usuarios AS autorizador
    ON autorizador.id = transferencia.autorizado_por_id AND autorizador.empresa_id = transferencia.empresa_id
`;

function actorId(claims: { sub: string }, empresaId: number) {
  const parsed = Number(claims.sub);
  if (Number.isSafeInteger(parsed) && parsed > 0) return parsed;
  if (isMockAuthEnabled()) {
    return getMockTreasuryState().users.find((user) => user.empresa_id === empresaId)?.id ?? null;
  }
  return null;
}

function maskAccountNumber(value: string) {
  return value.length > 4 ? `**** ${value.slice(-4)}` : "****";
}

function mockAccountLabel(accountId: number, companyId: number) {
  const state = getMockTreasuryState();
  const account = state.bankAccounts.find((item) => item.id === accountId && item.empresa_id === companyId);
  if (!account) return "";
  const bank = state.banks.find((item) => item.id === account.banco_id)?.nombre ?? "";
  return `${bank} · ${account.codigo} · ${maskAccountNumber(account.numero_cuenta)}`;
}

function mockTransferView(transfer: TreasuryBankTransfer) {
  const state = getMockTreasuryState();
  return {
    ...transfer,
    empresa: state.companies.find((company) => company.id === transfer.empresa_id)?.nombre_comercial ?? "",
    cuenta_origen: mockAccountLabel(transfer.cuenta_origen_id, transfer.empresa_id),
    cuenta_destino: mockAccountLabel(transfer.cuenta_destino_id, transfer.empresa_id),
    comprobante_base64: transfer.comprobante_base64 ?? "",
    comprobante_mime_type: transfer.comprobante_mime_type ?? "",
    responsable: state.users.find((user) => user.id === transfer.responsable_id)?.nombre ?? "",
    autorizado_por: transfer.autorizado_por_id === null
      ? ""
      : state.users.find((user) => user.id === transfer.autorizado_por_id)?.nombre ?? "",
    importe: Number(transfer.importe),
  };
}

function formatDatabaseTransfer(row: Record<string, unknown>) {
  return {
    ...row,
    id: Number(row.id),
    empresa_id: Number(row.empresa_id),
    cuenta_origen_id: Number(row.cuenta_origen_id),
    cuenta_destino_id: Number(row.cuenta_destino_id),
    responsable_id: row.responsable_id === null ? null : Number(row.responsable_id),
    autorizado_por_id: row.autorizado_por_id === null ? null : Number(row.autorizado_por_id),
    completada_por_id: row.completada_por_id === null ? null : Number(row.completada_por_id),
    reversada_por_id: row.reversada_por_id === null ? null : Number(row.reversada_por_id),
    importe: Number(row.importe),
    estado: String(row.estado).toUpperCase() as TreasuryBankTransferStatus,
    motivo_reversion: String(row.motivo_reversion ?? ""),
    comprobante_base64: String(row.comprobante_base64 ?? ""),
    comprobante_mime_type: String(row.comprobante_mime_type ?? ""),
  };
}

function recordMockHistory(
  transferId: number,
  previous: TreasuryBankTransferStatus | null,
  next: TreasuryBankTransferStatus,
  userId: number | null,
  detail: string,
) {
  const state = getMockTreasuryState();
  const event: TreasuryBankTransferHistory = {
    id: nextMockId(state.bankTransferHistory),
    transferencia_id: transferId,
    estado_anterior: previous,
    estado_nuevo: next,
    ocurrido_en: new Date().toISOString(),
    usuario_id: userId,
    detalle: detail,
  };
  state.bankTransferHistory.push(event);
  return event;
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const data = state.bankTransfers.map(mockTransferView);
    return NextResponse.json({
      data,
      counts: {
        total: data.length,
        pending: data.filter((item) => item.estado === "PENDIENTE").length,
        inProgress: data.filter((item) => item.estado === "EN_PROCESO").length,
        completed: data.filter((item) => item.estado === "COMPLETADA").length,
        rejected: data.filter((item) => item.estado === "RECHAZADA").length,
        cancelled: data.filter((item) => item.estado === "ANULADA").length,
        reversed: data.filter((item) => item.estado === "REVERTIDA").length,
      },
    });
  }
  const result = await getDatabasePool().query(
    `${TRANSFER_SELECT}
     WHERE transferencia.empresa_id = $1
     ORDER BY transferencia.fecha DESC, transferencia.id DESC`,
    [getEmpresaId()],
  );
  const data = result.rows.map((row) => formatDatabaseTransfer(row));
  return NextResponse.json({
    data,
    counts: {
      total: data.length,
      pending: data.filter((item) => item.estado === "PENDIENTE").length,
      inProgress: data.filter((item) => item.estado === "EN_PROCESO").length,
      completed: data.filter((item) => item.estado === "COMPLETADA").length,
      rejected: data.filter((item) => item.estado === "RECHAZADA").length,
      cancelled: data.filter((item) => item.estado === "ANULADA").length,
      reversed: data.filter((item) => item.estado === "REVERTIDA").length,
    },
  });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  const transfer = parseTransfer(body);
  if (!transfer) return NextResponse.json({ error: "Revisa los datos de la transferencia y que el comprobante sea PNG, JPG o WebP válido de hasta 5 MB." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const source = state.bankAccounts.find((item) => item.id === transfer.cuenta_origen_id);
    const destination = state.bankAccounts.find((item) => item.id === transfer.cuenta_destino_id);
    const users = state.users.filter((user) => user.empresa_id === transfer.empresa_id);
    const company = state.companies.find((item) => item.id === transfer.empresa_id);
    const sourceBank = source && state.banks.find((item) => item.id === source.banco_id);
    const destinationBank = destination && state.banks.find((item) => item.id === destination.banco_id);
    if (!company || !source || !destination || source.empresa_id !== transfer.empresa_id ||
        destination.empresa_id !== transfer.empresa_id || source.estado !== "ACTIVA" ||
        destination.estado !== "ACTIVA" || source.moneda !== destination.moneda ||
        transfer.moneda !== source.moneda || sourceBank?.estado !== "ACTIVO" ||
        destinationBank?.estado !== "ACTIVO" ||
        !users.some((user) => user.id === transfer.responsable_id) ||
        (transfer.autorizado_por_id !== null && !users.some((user) => user.id === transfer.autorizado_por_id))) {
      return NextResponse.json({ error: "Las cuentas deben estar activas, pertenecer a la empresa y usar la misma moneda; valida también a los usuarios." }, { status: 400 });
    }
    const created: TreasuryBankTransfer = {
      id: nextMockId(state.bankTransfers),
      ...transfer,
      codigo: getNextTransferCode(state.bankTransfers.map((item) => item.codigo)),
      estado: "PENDIENTE",
      completada_en: null,
      completada_por_id: null,
      reversada_en: null,
      reversada_por_id: null,
      motivo_reversion: "",
    };
    state.bankTransfers.push(created);
    recordMockHistory(created.id, null, "PENDIENTE", actorId(claims, created.empresa_id), "Transferencia registrada.");
    return NextResponse.json({ data: mockTransferView(created) }, { status: 201 });
  }

  const companyId = getEmpresaId();
  if (transfer.empresa_id !== companyId) {
    return NextResponse.json({ error: "La empresa seleccionada no coincide con la empresa configurada." }, { status: 400 });
  }
  const client = await getDatabasePool().connect();
  let transactionOpen = false;
  try {
    await client.query("BEGIN");
    transactionOpen = true;
    const accounts = await client.query<{
      id: string;
      empresa_id: string;
      moneda: string;
      estado: string;
      banco_estado: string;
    }>(
      `SELECT cuenta.id::text, cuenta.empresa_id::text, cuenta.moneda, cuenta.estado,
              banco.estado AS banco_estado
       FROM cuentas_bancarias AS cuenta
       JOIN bancos AS banco ON banco.id = cuenta.banco_id
       WHERE cuenta.id = ANY($1::bigint[]) AND cuenta.empresa_id = $2
       ORDER BY cuenta.id
       FOR UPDATE OF cuenta`,
      [[transfer.cuenta_origen_id, transfer.cuenta_destino_id], companyId],
    );
    const source = accounts.rows.find((account) => Number(account.id) === transfer.cuenta_origen_id);
    const destination = accounts.rows.find((account) => Number(account.id) === transfer.cuenta_destino_id);
    if (!source || !destination || source.estado !== "ACTIVA" || destination.estado !== "ACTIVA" ||
        source.banco_estado !== "ACTIVO" || destination.banco_estado !== "ACTIVO" ||
        source.moneda !== destination.moneda || transfer.moneda !== source.moneda) {
      await client.query("ROLLBACK");
      return NextResponse.json({ error: "Las cuentas deben estar activas, pertenecer a la empresa y usar la misma moneda." }, { status: 400 });
    }
    const users = await client.query<{ id: string }>(
      `SELECT id::text FROM usuarios
       WHERE empresa_id = $1 AND estado = 'ACTIVO'
         AND id = ANY($2::bigint[])`,
      [companyId, [transfer.responsable_id, transfer.autorizado_por_id].filter((id): id is number => id !== null)],
    );
    const validUserIds = new Set(users.rows.map((user) => Number(user.id)));
    if (!validUserIds.has(transfer.responsable_id) ||
        (transfer.autorizado_por_id !== null && !validUserIds.has(transfer.autorizado_por_id))) {
      await client.query("ROLLBACK");
      return NextResponse.json({ error: "El responsable y el autorizador deben pertenecer a la empresa y estar activos." }, { status: 400 });
    }
    const sequence = await client.query<{ value: string }>(
      "SELECT nextval('transferencias_bancarias_codigo_seq')::text AS value",
    );
    const codigo = formatTransferCode(sequence.rows[0].value);
    const inserted = await client.query<{ id: string }>(
      `INSERT INTO transferencias_bancarias
         (empresa_id, codigo, cuenta_origen_id, cuenta_destino_id, beneficiario, fecha,
          importe, moneda, concepto, referencia_bancaria, comprobante_base64, comprobante_mime_type,
          responsable_id, autorizado_por_id, estado)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NULLIF($10, ''),
               NULLIF($11, ''), NULLIF($12, ''), $13, $14, 'PENDIENTE')
       RETURNING id::text`,
      [companyId, codigo, transfer.cuenta_origen_id, transfer.cuenta_destino_id, transfer.beneficiario,
        transfer.fecha, transfer.importe, transfer.moneda, transfer.concepto,
        transfer.referencia_bancaria, transfer.comprobante_base64, transfer.comprobante_mime_type,
        transfer.responsable_id, transfer.autorizado_por_id],
    );
    await client.query(
      `INSERT INTO transferencias_bancarias_historial
         (empresa_id, transferencia_id, estado_anterior, estado_nuevo, usuario_id, detalle)
       VALUES ($1, $2, NULL, 'PENDIENTE', $3, 'Transferencia registrada.')`,
      [companyId, inserted.rows[0].id, actorId(claims, companyId)],
    );
    await client.query("COMMIT");
    transactionOpen = false;
    const saved = await getDatabasePool().query(
      `${TRANSFER_SELECT}
       WHERE transferencia.id = $1 AND transferencia.empresa_id = $2`,
      [inserted.rows[0].id, companyId],
    );
    return NextResponse.json({ data: formatDatabaseTransfer(saved.rows[0]) }, { status: 201 });
  } catch (error) {
    if (transactionOpen) await client.query("ROLLBACK");
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "El código de transferencia ya está registrado." }, { status: 409 });
    }
    throw error;
  } finally {
    client.release();
  }
}
