import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import { getExpectedBankBalance, getMockTreasuryState } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function maskAccountNumber(value: string) {
  return value.length > 4 ? `**** ${value.slice(-4)}` : "****";
}

export async function GET(request: NextRequest) {
  if (!await getActiveAccessClaims(request)) {
    return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  }

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    return NextResponse.json({
      data: {
        companies: state.companies,
        accounts: state.bankAccounts
          .filter((account) => account.estado === "ACTIVA" &&
            state.banks.some((bank) => bank.id === account.banco_id && bank.estado === "ACTIVO"))
          .map((account) => ({
            id: account.id,
            empresa_id: account.empresa_id,
            codigo: account.codigo,
            banco: state.banks.find((bank) => bank.id === account.banco_id)?.nombre ?? "",
            numero_cuenta: maskAccountNumber(account.numero_cuenta),
            titular: account.titular,
            moneda: account.moneda,
            saldo_actual: getExpectedBankBalance(account, state.bankMovements),
          })),
        users: state.users,
      },
    });
  }

  const companyId = getEmpresaId();
  const pool = getDatabasePool();
  const [companies, accounts, users] = await Promise.all([
    pool.query(
      `SELECT id::text, nombre_comercial, moneda_base
       FROM empresas WHERE id = $1 AND estado = 'ACTIVA'`,
      [companyId],
    ),
    pool.query(
      `SELECT cuenta.id::text, cuenta.empresa_id::text, cuenta.codigo, banco.nombre AS banco,
              CASE WHEN LENGTH(cuenta.numero_cuenta) > 4
                   THEN '**** ' || RIGHT(cuenta.numero_cuenta, 4)
                   ELSE '****' END AS numero_cuenta,
              cuenta.titular, cuenta.moneda,
              cuenta.saldo_inicial + COALESCE(SUM(
                CASE WHEN movimiento.tipo IN ('INGRESO', 'DEPOSITO', 'ABONO') THEN movimiento.importe
                     WHEN movimiento.tipo IN ('EGRESO', 'CHEQUE', 'PAGO') THEN -movimiento.importe
                     ELSE 0 END
              ), 0) AS saldo_actual
       FROM cuentas_bancarias AS cuenta
       JOIN bancos AS banco ON banco.id = cuenta.banco_id AND banco.estado = 'ACTIVO'
       LEFT JOIN movimientos_tesoreria AS movimiento
         ON movimiento.cuenta_bancaria_id = cuenta.id
        AND movimiento.fecha::date >= cuenta.fecha_saldo_inicial
       WHERE cuenta.empresa_id = $1 AND cuenta.estado = 'ACTIVA'
       GROUP BY cuenta.id, banco.nombre
       ORDER BY cuenta.codigo`,
      [companyId],
    ),
    pool.query(
      `SELECT id::text, empresa_id::text, nombre
       FROM usuarios WHERE empresa_id = $1 AND estado = 'ACTIVO' ORDER BY nombre`,
      [companyId],
    ),
  ]);
  return NextResponse.json({
    data: {
      companies: companies.rows.map((row) => ({ ...row, id: Number(row.id) })),
      accounts: accounts.rows.map((row) => ({
        ...row,
        id: Number(row.id),
        empresa_id: Number(row.empresa_id),
        saldo_actual: Number(row.saldo_actual),
      })),
      users: users.rows.map((row) => ({
        ...row,
        id: Number(row.id),
        empresa_id: Number(row.empresa_id),
      })),
    },
  });
}
