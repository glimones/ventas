import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool } from "@/lib/db";
import { getMockCompanyId, getMockTreasuryState, nextMockId, type TreasuryDeposit } from "@/lib/mock-treasury";
import { parseDeposit } from "@/lib/tesoreria-documentos";
import { hasRoutePermission } from "@/lib/route-permissions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function actorId(claims: { sub: string; empresaId: number }) {
  const parsed = Number(claims.sub);
  if (Number.isSafeInteger(parsed) && parsed > 0) return parsed;
  if (isMockAuthEnabled()) {
    const companyId = getMockCompanyId(claims.empresaId);
    return getMockTreasuryState().users.find((user) => user.empresa_id === companyId)?.id ?? null;
  }
  return null;
}

function mockView(deposit: TreasuryDeposit) {
  const state = getMockTreasuryState();
  const account = state.bankAccounts.find((item) => item.id === deposit.cuenta_bancaria_id);
  const bank = account && state.banks.find((item) => item.id === account.banco_id);
  return {
    ...deposit,
    cuenta_bancaria: account ? `${bank?.nombre ?? ""} · ${account.codigo} · **** ${account.numero_cuenta.slice(-4)}` : "",
    responsable: state.users.find((item) => item.id === deposit.responsable_id)?.nombre ?? "",
    moneda: account?.moneda ?? "USD",
  };
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!hasRoutePermission(claims, "/depositos", 1)) return NextResponse.json({ error: "No tienes permiso para consultar depósitos." }, { status: 403 });
  if (isMockAuthEnabled()) {
    const companyId = getMockCompanyId(claims.empresaId);
    return NextResponse.json({
      data: getMockTreasuryState().deposits
        .filter((deposit) => deposit.empresa_id === companyId)
        .map(mockView),
    });
  }

  const result = await getDatabasePool().query(
    `SELECT deposito.id::text, deposito.empresa_id::text, deposito.numero_deposito,
            deposito.cuenta_bancaria_id::text, to_char(deposito.fecha, 'YYYY-MM-DD') AS fecha,
            deposito.origen, deposito.importe, COALESCE(deposito.referencia, '') AS referencia,
            deposito.comprobante_base64, deposito.comprobante_mime_type,
            deposito.responsable_id::text, responsable.nombre AS responsable, deposito.estado,
            banco.nombre || ' · ' || cuenta.codigo || ' · ' ||
              CASE WHEN LENGTH(cuenta.numero_cuenta) > 4
                   THEN '**** ' || RIGHT(cuenta.numero_cuenta, 4)
                   ELSE '****' END AS cuenta_bancaria,
            cuenta.moneda
     FROM depositos_bancarios AS deposito
     JOIN cuentas_bancarias AS cuenta
       ON cuenta.id = deposito.cuenta_bancaria_id AND cuenta.empresa_id = deposito.empresa_id
     JOIN bancos AS banco ON banco.id = cuenta.banco_id
     LEFT JOIN usuarios AS responsable
       ON responsable.id = deposito.responsable_id AND responsable.empresa_id = deposito.empresa_id
     WHERE deposito.empresa_id = $1
     ORDER BY deposito.fecha DESC, deposito.id DESC`,
    [claims.empresaId],
  );
  return NextResponse.json({
    data: result.rows.map((row) => ({
      ...row,
      id: Number(row.id),
      empresa_id: Number(row.empresa_id),
      cuenta_bancaria_id: Number(row.cuenta_bancaria_id),
      responsable_id: Number(row.responsable_id),
      importe: Number(row.importe),
      comprobante_base64: String(row.comprobante_base64 ?? ""),
    })),
  });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!hasRoutePermission(claims, "/depositos", 2)) return NextResponse.json({ error: "No tienes permiso para registrar depósitos." }, { status: 403 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  const input = parseDeposit(body);
  if (!input) {
    return NextResponse.json({
      error: "Revisa los datos del depósito. Adjunta un comprobante PNG, JPG o WebP de hasta 5 MB.",
    }, { status: 400 });
  }
  const responsibleId = actorId(claims);
  const companyId = isMockAuthEnabled() ? getMockCompanyId(claims.empresaId) : claims.empresaId;
  if (!responsibleId) return NextResponse.json({ error: "No se pudo identificar al responsable activo." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const account = state.bankAccounts.find((item) =>
      item.id === input.cuenta_bancaria_id && item.empresa_id === companyId && item.estado === "ACTIVA");
    const bank = account && state.banks.find((item) => item.id === account.banco_id);
    if (!account || bank?.estado !== "ACTIVO" || !state.users.some((item) =>
      item.id === responsibleId && item.empresa_id === companyId)) {
      return NextResponse.json({ error: "Selecciona una cuenta bancaria activa de tu empresa." }, { status: 400 });
    }
    const number = state.deposits.reduce((max, row) => {
      const match = /^DEP-(\d+)$/.exec(row.numero_deposito);
      return Math.max(max, Number(match?.[1] ?? 0));
    }, 0) + 1;
    const created: TreasuryDeposit = {
      id: nextMockId(state.deposits),
      empresa_id: companyId,
      numero_deposito: `DEP-${String(number).padStart(12, "0")}`,
      ...input,
      responsable_id: responsibleId,
      estado: "REGISTRADO",
    };
    state.deposits.push(created);
    state.bankMovements.push({
      id: nextMockId(state.bankMovements),
      cuenta_bancaria_id: account.id,
      tipo: "DEPOSITO",
      importe: input.importe,
      fecha: input.fecha,
      concepto: input.origen,
      referencia: input.referencia,
    });
    return NextResponse.json({ data: mockView(created) }, { status: 201 });
  }

  const client = await getDatabasePool().connect();
  let transactionOpen = false;
  try {
    await client.query("BEGIN");
    transactionOpen = true;
    const account = await client.query<{ id: string }>(
      `SELECT cuenta.id::text
       FROM cuentas_bancarias AS cuenta
       JOIN bancos AS banco ON banco.id = cuenta.banco_id AND banco.estado = 'ACTIVO'
       WHERE cuenta.id = $1 AND cuenta.empresa_id = $2 AND cuenta.estado = 'ACTIVA'
       FOR UPDATE OF cuenta`,
      [input.cuenta_bancaria_id, claims.empresaId],
    );
    if (!account.rows[0]) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Selecciona una cuenta bancaria activa de tu empresa." }, { status: 400 });
    }
    const user = await client.query(
      "SELECT id FROM usuarios WHERE id = $1 AND empresa_id = $2 AND estado = 'ACTIVO'",
      [responsibleId, claims.empresaId],
    );
    if (!user.rows[0]) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "El responsable debe estar activo y pertenecer a la empresa." }, { status: 400 });
    }
    const sequence = await client.query<{ value: string }>(
      "SELECT nextval('depositos_bancarios_codigo_seq')::text AS value",
    );
    const code = `DEP-${sequence.rows[0].value.padStart(12, "0")}`;
    const inserted = await client.query<{ id: string }>(
      `INSERT INTO depositos_bancarios
         (empresa_id, numero_deposito, cuenta_bancaria_id, fecha, origen, importe,
          referencia, comprobante_base64, comprobante_mime_type, responsable_id)
       VALUES ($1, $2, $3, $4, $5, $6, NULLIF($7, ''), $8, $9, $10)
       RETURNING id::text`,
      [companyId, code, input.cuenta_bancaria_id, input.fecha, input.origen,
        input.importe, input.referencia, input.comprobante_base64, input.comprobante_mime_type,
        responsibleId],
    );
    await client.query(
      `INSERT INTO movimientos_tesoreria
         (empresa_id, cuenta_bancaria_id, tipo, fecha, concepto, referencia,
          importe, documento_tipo, documento_id, usuario_id)
       VALUES ($1, $2, 'DEPOSITO', $3::date, $4, NULLIF($5, ''), $6, 'DEPOSITO', $7, $8)`,
      [companyId, input.cuenta_bancaria_id, input.fecha, input.origen, input.referencia,
        input.importe, inserted.rows[0].id, responsibleId],
    );
    await client.query("COMMIT");
    transactionOpen = false;
    const saved = await getDatabasePool().query(
      `SELECT deposito.id::text, deposito.empresa_id::text, deposito.numero_deposito,
              deposito.cuenta_bancaria_id::text, to_char(deposito.fecha, 'YYYY-MM-DD') AS fecha,
              deposito.origen, deposito.importe, COALESCE(deposito.referencia, '') AS referencia,
              deposito.comprobante_base64, deposito.comprobante_mime_type,
              deposito.responsable_id::text, responsable.nombre AS responsable, deposito.estado,
              banco.nombre || ' · ' || cuenta.codigo || ' · ' ||
                CASE WHEN LENGTH(cuenta.numero_cuenta) > 4
                     THEN '**** ' || RIGHT(cuenta.numero_cuenta, 4)
                     ELSE '****' END AS cuenta_bancaria,
              cuenta.moneda
       FROM depositos_bancarios AS deposito
       JOIN cuentas_bancarias AS cuenta ON cuenta.id = deposito.cuenta_bancaria_id
       JOIN bancos AS banco ON banco.id = cuenta.banco_id
       LEFT JOIN usuarios AS responsable ON responsable.id = deposito.responsable_id
       WHERE deposito.id = $1 AND deposito.empresa_id = $2`,
      [inserted.rows[0].id, companyId],
    );
    const row = saved.rows[0];
    return NextResponse.json({
      data: {
        ...row,
        id: Number(row.id),
        empresa_id: Number(row.empresa_id),
        cuenta_bancaria_id: Number(row.cuenta_bancaria_id),
        responsable_id: Number(row.responsable_id),
        importe: Number(row.importe),
      },
    }, { status: 201 });
  } catch (error) {
    if (transactionOpen) await client.query("ROLLBACK");
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "No se pudo generar un número de depósito único." }, { status: 409 });
    }
    throw error;
  } finally {
    client.release();
  }
}
