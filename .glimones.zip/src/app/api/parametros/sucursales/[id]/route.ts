import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getMockTreasuryState } from "@/lib/mock-treasury";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

function parseId(value: string) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

export async function PUT(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = parseId((await context.params).id);
  if (!id) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
  }
  const input = body as Record<string, unknown>;
  const empresaId = Number(input.empresa_id);
  const codigo = typeof input.codigo === "string" ? input.codigo.trim().toUpperCase() : "";
  const nombre = typeof input.nombre === "string" ? input.nombre.trim() : "";
  const direccion = typeof input.direccion === "string" ? input.direccion.trim() : "";
  const ciudad = typeof input.ciudad === "string" ? input.ciudad.trim() : "";
  const telefono = typeof input.telefono === "string" ? input.telefono.trim() : "";
  const responsable = typeof input.responsable === "string" ? input.responsable.trim() : "";
  const estado = typeof input.estado === "string" && input.estado.toUpperCase().startsWith("INACT") ? "INACTIVA" : "ACTIVA";
  if (!Number.isSafeInteger(empresaId) || empresaId <= 0 || !codigo || codigo.length > 20 ||
      !nombre || nombre.length > 120 || direccion.length > 250 || ciudad.length > 100 ||
      telefono.length > 40 || responsable.length > 160) {
    return NextResponse.json({ error: "Revisa la empresa, código y datos de la sucursal." }, { status: 400 });
  }

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const branch = state.branches.find((item) => item.id === id);
    if (!branch) return NextResponse.json({ error: "Sucursal no encontrada." }, { status: 404 });
    if (branch.empresa_id !== empresaId) {
      return NextResponse.json({ error: "La empresa de una sucursal existente no se puede cambiar." }, { status: 400 });
    }
    if (!state.companies.some((company) => company.id === empresaId)) {
      return NextResponse.json({ error: "La empresa no está registrada o no está activa." }, { status: 400 });
    }
    if (state.branches.some((item) => item.id !== id && item.empresa_id === empresaId && item.codigo === codigo)) {
      return NextResponse.json({ error: "Ya existe una sucursal con ese código en la empresa." }, { status: 409 });
    }
    if (estado === "INACTIVA" && state.boxes.some((box) => box.sucursal_id === id && box.estado === "ACTIVA")) {
      return NextResponse.json({ error: "No puedes inactivar una sucursal que tiene una caja activa." }, { status: 409 });
    }
    Object.assign(branch, { empresa_id: empresaId, codigo, nombre, direccion, ciudad, telefono, responsable, estado });
    return NextResponse.json({ data: branch });
  }

  const pool = getDatabasePool();
  const company = await pool.query(`SELECT 1 FROM empresas WHERE id = $1 AND estado = 'ACTIVA'`, [empresaId]);
  if (!company.rowCount) return NextResponse.json({ error: "La empresa no está registrada o no está activa." }, { status: 400 });
  const currentBranch = await pool.query<{ empresa_id: string }>(
    `SELECT empresa_id::text FROM sucursales WHERE id = $1`,
    [id],
  );
  if (!currentBranch.rows[0]) return NextResponse.json({ error: "Sucursal no encontrada." }, { status: 404 });
  if (Number(currentBranch.rows[0].empresa_id) !== empresaId) {
    return NextResponse.json({ error: "La empresa de una sucursal existente no se puede cambiar." }, { status: 400 });
  }
  if (estado === "INACTIVA") {
    const activeBox = await pool.query(
      `SELECT 1 FROM cajas WHERE empresa_id = $1 AND sucursal_id = $2 AND estado IN ('ACTIVA', 'ACTIVO') LIMIT 1`,
      [empresaId, id],
    );
    if (activeBox.rowCount) return NextResponse.json({ error: "No puedes inactivar una sucursal que tiene una caja activa." }, { status: 409 });
  }
  try {
    const result = await pool.query(
      `UPDATE sucursales
       SET empresa_id = $1, codigo = $2, nombre = $3, direccion = $4, ciudad = $5,
           telefono = $6, responsable = $7, estado = $8
       WHERE id = $9
       RETURNING id::text, empresa_id::text, codigo, nombre, direccion, ciudad, telefono, responsable, estado`,
      [empresaId, codigo, nombre, direccion || null, ciudad || null, telefono || null, responsable || null, estado, id],
    );
    return result.rows[0]
      ? NextResponse.json({ data: { ...result.rows[0], id: Number(result.rows[0].id), empresa_id: Number(result.rows[0].empresa_id) } })
      : NextResponse.json({ error: "Sucursal no encontrada." }, { status: 404 });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "Ya existe una sucursal con ese código en la empresa." }, { status: 409 });
    }
    throw error;
  }
}

export async function DELETE(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = parseId((await context.params).id);
  if (!id) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const branch = state.branches.find((item) => item.id === id);
    if (!branch) return NextResponse.json({ error: "Sucursal no encontrada." }, { status: 404 });
    if (state.boxes.some((box) => box.sucursal_id === id && box.estado === "ACTIVA")) {
      return NextResponse.json({ error: "No puedes inactivar una sucursal que tiene una caja activa." }, { status: 409 });
    }
    branch.estado = "INACTIVA";
    return NextResponse.json({ data: { id } });
  }

  const result = await getDatabasePool().query(
    `UPDATE sucursales SET estado = 'INACTIVA'
     WHERE id = $1
       AND NOT EXISTS (
         SELECT 1 FROM cajas
         WHERE cajas.empresa_id = sucursales.empresa_id
           AND cajas.sucursal_id = sucursales.id
           AND cajas.estado IN ('ACTIVA', 'ACTIVO')
       )
     RETURNING id`,
    [id],
  );
  if (result.rows[0]) return NextResponse.json({ data: result.rows[0] });
  const branch = await getDatabasePool().query(`SELECT 1 FROM sucursales WHERE id = $1`, [id]);
  return branch.rowCount
    ? NextResponse.json({ error: "No puedes inactivar una sucursal que tiene una caja activa." }, { status: 409 })
    : NextResponse.json({ error: "Sucursal no encontrada." }, { status: 404 });
}
