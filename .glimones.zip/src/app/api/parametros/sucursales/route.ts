import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getMockTreasuryState, nextMockId } from "@/lib/mock-treasury";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type BranchInput = {
  empresa_id: number;
  codigo: string;
  nombre: string;
  direccion: string;
  ciudad: string;
  telefono: string;
  responsable: string;
  estado: "ACTIVA" | "INACTIVA";
};

function parseBranch(body: unknown): BranchInput | null {
  if (body === null || typeof body !== "object" || Array.isArray(body)) return null;
  const input = body as Record<string, unknown>;
  const empresaId = Number(input.empresa_id);
  const codigo = typeof input.codigo === "string" ? input.codigo.trim().toUpperCase() : "";
  const nombre = typeof input.nombre === "string" ? input.nombre.trim() : "";
  const direccion = typeof input.direccion === "string" ? input.direccion.trim() : "";
  const ciudad = typeof input.ciudad === "string" ? input.ciudad.trim() : "";
  const telefono = typeof input.telefono === "string" ? input.telefono.trim() : "";
  const responsable = typeof input.responsable === "string" ? input.responsable.trim() : "";
  const estado = typeof input.estado === "string" && input.estado.toUpperCase().startsWith("INACT")
    ? "INACTIVA"
    : "ACTIVA";
  if (!Number.isSafeInteger(empresaId) || empresaId <= 0 ||
      !codigo || codigo.length > 20 || !nombre || nombre.length > 120 ||
      direccion.length > 250 || ciudad.length > 100 || telefono.length > 40 || responsable.length > 160) return null;
  return { empresa_id: empresaId, codigo, nombre, direccion, ciudad, telefono, responsable, estado };
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const data = state.branches.map((branch) => ({
      ...branch,
      empresa: state.companies.find((company) => company.id === branch.empresa_id)?.nombre_comercial ?? "",
      estado: branch.estado === "ACTIVA" ? "Activa" : "Inactiva",
    }));
    return NextResponse.json({ data });
  }

  const result = await getDatabasePool().query(
    `SELECT sucursal.id::text, sucursal.empresa_id::text, empresa.nombre_comercial AS empresa,
            sucursal.codigo, sucursal.nombre, sucursal.direccion, sucursal.ciudad,
            sucursal.telefono, sucursal.responsable,
            CASE WHEN sucursal.estado IN ('ACTIVA', 'ACTIVO') THEN 'Activa' ELSE 'Inactiva' END AS estado
     FROM sucursales AS sucursal
     JOIN empresas AS empresa ON empresa.id = sucursal.empresa_id
     ORDER BY empresa.nombre_comercial, sucursal.nombre`,
  );
  return NextResponse.json({ data: result.rows.map((row) => ({
    ...row,
    id: Number(row.id),
    empresa_id: Number(row.empresa_id),
  })) });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  const branch = parseBranch(body);
  if (!branch) return NextResponse.json({ error: "Revisa la empresa, código y datos de la sucursal." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    if (!state.companies.some((company) => company.id === branch.empresa_id)) {
      return NextResponse.json({ error: "La empresa no está registrada o no está activa." }, { status: 400 });
    }
    if (state.branches.some((current) => current.empresa_id === branch.empresa_id && current.codigo === branch.codigo)) {
      return NextResponse.json({ error: "Ya existe una sucursal con ese código en la empresa." }, { status: 409 });
    }
    const created = { id: nextMockId(state.branches), ...branch };
    state.branches.push(created);
    return NextResponse.json({ data: created }, { status: 201 });
  }

  const pool = getDatabasePool();
  const company = await pool.query(`SELECT 1 FROM empresas WHERE id = $1 AND estado = 'ACTIVA'`, [branch.empresa_id]);
  if (!company.rowCount) return NextResponse.json({ error: "La empresa no está registrada o no está activa." }, { status: 400 });
  try {
    const result = await pool.query(
      `INSERT INTO sucursales (empresa_id, codigo, nombre, direccion, ciudad, telefono, responsable, estado)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id::text, empresa_id::text, codigo, nombre, direccion, ciudad, telefono, responsable, estado`,
      [branch.empresa_id, branch.codigo, branch.nombre, branch.direccion || null, branch.ciudad || null,
        branch.telefono || null, branch.responsable || null, branch.estado],
    );
    return NextResponse.json({ data: { ...result.rows[0], id: Number(result.rows[0].id), empresa_id: Number(result.rows[0].empresa_id) } }, { status: 201 });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "Ya existe una sucursal con ese código en la empresa." }, { status: 409 });
    }
    throw error;
  }
}
