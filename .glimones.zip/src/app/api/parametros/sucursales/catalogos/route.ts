import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getMockTreasuryState } from "@/lib/mock-treasury";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });

  if (isMockAuthEnabled()) {
    return NextResponse.json({ data: { companies: getMockTreasuryState().companies } });
  }

  const result = await getDatabasePool().query<{ id: string; nombre_comercial: string }>(
    `SELECT id::text, nombre_comercial
     FROM empresas
     WHERE estado = 'ACTIVA'
     ORDER BY nombre_comercial`,
  );
  return NextResponse.json({
    data: { companies: result.rows.map((company) => ({ ...company, id: Number(company.id) })) },
  });
}
