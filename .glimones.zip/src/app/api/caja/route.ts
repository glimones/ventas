import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getMockTreasuryState, nextMockId } from "@/lib/mock-treasury";
import { getDatabasePool } from "@/lib/db";
import { formatCajaCode, getNextCajaCode } from "@/lib/caja-code";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type CashInput = {
  empresa_id: number;
  sucursal_id: number;
  codigo: string;
  nombre: string;
  ubicacion: string;
  responsable_id: number | null;
  moneda: string;
  saldo_inicial: number;
  estado: "ACTIVA" | "INACTIVA";
};

function parseCash(body: unknown, requireCode = true): CashInput | null {
  if (body === null || typeof body !== "object" || Array.isArray(body)) return null;
  const input = body as Record<string, unknown>;
  const empresaId = Number(input.empresa_id);
  const branchId = Number(input.sucursal_id);
  const responsibleId = input.responsable_id === "" || input.responsable_id === null || input.responsable_id === undefined
    ? null
    : Number(input.responsable_id);
  const codigo = typeof input.codigo === "string" ? input.codigo.trim().toUpperCase() : "";
  const nombre = typeof input.nombre === "string" ? input.nombre.trim() : "";
  const ubicacion = typeof input.ubicacion === "string" ? input.ubicacion.trim() : "";
  const moneda = typeof input.moneda === "string" && input.moneda.trim() ? input.moneda.trim().toUpperCase() : "USD";
  const saldo = Number(input.saldo_inicial ?? 0);
  const estado = typeof input.estado === "string" && input.estado.toUpperCase().startsWith("INACT") ? "INACTIVA" : "ACTIVA";
  if (!Number.isSafeInteger(empresaId) || empresaId <= 0 ||
      !Number.isSafeInteger(branchId) || branchId <= 0 ||
      responsibleId !== null && (!Number.isSafeInteger(responsibleId) || responsibleId <= 0) ||
      (requireCode && !codigo) || codigo.length > 30 || !nombre || nombre.length > 100 ||
      ubicacion.length > 160 || !/^[A-Z]{3}$/.test(moneda) ||
      !Number.isFinite(saldo) || saldo < 0) return null;
  return {
    empresa_id: empresaId,
    sucursal_id: branchId,
    codigo,
    nombre,
    ubicacion,
    responsable_id: responsibleId,
    moneda,
    saldo_inicial: saldo,
    estado,
  };
}

function formatCash(row: Record<string, unknown>) {
  return {
    ...row,
    saldo_inicial: Number(row.saldo_inicial ?? 0),
    estado: String(row.estado).toUpperCase().startsWith("INACT") ? "Inactiva" : "Activa",
  };
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const data = state.boxes.map((box) => ({
      ...box,
      empresa: state.companies.find((company) => company.id === box.empresa_id)?.nombre_comercial ?? "",
      sucursal: state.branches.find((branch) => branch.id === box.sucursal_id)?.nombre ?? "",
      responsable: state.users.find((user) => user.id === box.responsable_id)?.nombre ?? "",
      saldo_inicial: box.saldo_inicial,
      estado: box.estado === "ACTIVA" ? "Activa" : "Inactiva",
    }));
    return NextResponse.json({
      data,
      counts: {
        total: data.length,
        active: data.filter((row) => row.estado === "Activa").length,
        inactive: data.filter((row) => row.estado === "Inactiva").length,
      },
      capabilities: { create: true, update: true, delete: true },
    });
  }

  const result = await getDatabasePool().query(
    `SELECT caja.id::text, caja.empresa_id::text, empresa.nombre_comercial AS empresa,
            caja.sucursal_id::text, sucursal.nombre AS sucursal, caja.codigo, caja.nombre,
            caja.ubicacion, caja.responsable_id::text, usuario.nombre AS responsable,
            caja.moneda, caja.saldo_inicial, caja.estado
     FROM cajas AS caja
     JOIN empresas AS empresa ON empresa.id = caja.empresa_id
     LEFT JOIN sucursales AS sucursal ON sucursal.id = caja.sucursal_id AND sucursal.empresa_id = caja.empresa_id
     LEFT JOIN usuarios AS usuario ON usuario.id = caja.responsable_id AND usuario.empresa_id = caja.empresa_id
     ORDER BY empresa.nombre_comercial, sucursal.nombre, caja.codigo`,
  );
  const data = result.rows.map((row) => ({
    ...formatCash(row),
    id: Number(row.id),
    empresa_id: Number(row.empresa_id),
    sucursal_id: row.sucursal_id === null ? null : Number(row.sucursal_id),
    responsable_id: row.responsable_id === null ? null : Number(row.responsable_id),
  }));
  return NextResponse.json({
    data,
    counts: {
      total: data.length,
      active: data.filter((row) => row.estado === "Activa").length,
      inactive: data.filter((row) => row.estado === "Inactiva").length,
    },
    capabilities: { create: true, update: true, delete: true },
  });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  const cash = parseCash(body, false);
  if (!cash) return NextResponse.json({ error: "Revisa la empresa, sucursal, código, nombre y saldo inicial." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const branch = state.branches.find((item) => item.id === cash.sucursal_id && item.empresa_id === cash.empresa_id && item.estado === "ACTIVA");
    if (!state.companies.some((company) => company.id === cash.empresa_id) || !branch) {
      return NextResponse.json({ error: "La sucursal debe pertenecer a una empresa activa." }, { status: 400 });
    }
    if (state.boxes.some((box) => box.sucursal_id === cash.sucursal_id && box.estado === "ACTIVA")) {
      return NextResponse.json({ error: "La sucursal ya tiene una caja activa." }, { status: 409 });
    }
    if (cash.responsable_id !== null && !state.users.some((user) => user.id === cash.responsable_id && user.empresa_id === cash.empresa_id)) {
      return NextResponse.json({ error: "El responsable debe pertenecer a la empresa seleccionada." }, { status: 400 });
    }
    const created = {
      id: nextMockId(state.boxes),
      ...cash,
      codigo: getNextCajaCode(state.boxes.map((box) => box.codigo)),
    };
    state.boxes.push(created);
    return NextResponse.json({ data: created }, { status: 201 });
  }

  const pool = getDatabasePool();
  const validBranch = await pool.query(
    `SELECT 1
     FROM sucursales AS sucursal
     JOIN empresas AS empresa ON empresa.id = sucursal.empresa_id AND empresa.estado = 'ACTIVA'
     WHERE sucursal.id = $1 AND sucursal.empresa_id = $2
       AND sucursal.estado IN ('ACTIVA', 'ACTIVO')`,
    [cash.sucursal_id, cash.empresa_id],
  );
  if (!validBranch.rowCount) return NextResponse.json({ error: "La sucursal debe pertenecer a una empresa activa." }, { status: 400 });
  const existingBox = await pool.query(
    `SELECT 1 FROM cajas
     WHERE empresa_id = $1 AND sucursal_id = $2 AND estado IN ('ACTIVA', 'ACTIVO')
     LIMIT 1`,
    [cash.empresa_id, cash.sucursal_id],
  );
  if (existingBox.rowCount) return NextResponse.json({ error: "La sucursal ya tiene una caja activa." }, { status: 409 });
  if (cash.responsable_id !== null) {
    const validUser = await pool.query(
      `SELECT 1 FROM usuarios
       WHERE id = $1 AND empresa_id = $2 AND estado = 'ACTIVO'`,
      [cash.responsable_id, cash.empresa_id],
    );
    if (!validUser.rowCount) return NextResponse.json({ error: "El responsable debe pertenecer a la empresa seleccionada." }, { status: 400 });
  }
  try {
    const codeResult = await pool.query<{ secuencial: string }>(
      `SELECT nextval('cajas_codigo_seq')::text AS secuencial`,
    );
    const codigo = formatCajaCode(codeResult.rows[0].secuencial);
    const result = await pool.query(
      `INSERT INTO cajas (empresa_id, sucursal_id, codigo, nombre, ubicacion, responsable_id, moneda, saldo_inicial, estado)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING id::text, empresa_id::text, sucursal_id::text, codigo, nombre, ubicacion,
                 responsable_id::text, moneda, saldo_inicial, estado`,
      [cash.empresa_id, cash.sucursal_id, codigo, cash.nombre, cash.ubicacion || null,
        cash.responsable_id, cash.moneda, cash.saldo_inicial, cash.estado],
    );
    const row = result.rows[0];
    return NextResponse.json({
      data: {
        ...formatCash(row),
        id: Number(row.id),
        empresa_id: Number(row.empresa_id),
        sucursal_id: Number(row.sucursal_id),
        responsable_id: row.responsable_id === null ? null : Number(row.responsable_id),
      },
    }, { status: 201 });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "La sucursal ya tiene una caja activa o el código ya está registrado en la empresa." }, { status: 409 });
    }
    throw error;
  }
}
