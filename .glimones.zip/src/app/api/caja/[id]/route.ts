import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getMockTreasuryState } from "@/lib/mock-treasury";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

function parseId(value: string) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

async function readCash(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return { error: "El cuerpo debe ser JSON válido." } as const;
  }
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return { error: "El cuerpo debe ser un objeto JSON." } as const;
  }
  const input = body as Record<string, unknown>;
  const empresaId = Number(input.empresa_id);
  const branchId = Number(input.sucursal_id);
  const responsibleId = input.responsable_id === "" || input.responsable_id === null || input.responsable_id === undefined
    ? null
    : Number(input.responsable_id);
  const codigo = typeof input.codigo === "string" ? input.codigo.trim().toUpperCase() : "";
  const nombre = typeof input.nombre === "string" ? input.nombre.trim() : "";
  const ubicacion = typeof input.ubicacion === "string" ? input.ubicacion.trim() : "";
  const moneda = typeof input.moneda === "string" && input.moneda.trim() ? input.moneda.trim().toUpperCase() : "USD";
  const saldo = Number(input.saldo_inicial ?? 0);
  const estado = typeof input.estado === "string" && input.estado.toUpperCase().startsWith("INACT") ? "INACTIVA" : "ACTIVA";
  if (!Number.isSafeInteger(empresaId) || empresaId <= 0 || !Number.isSafeInteger(branchId) || branchId <= 0 ||
      responsibleId !== null && (!Number.isSafeInteger(responsibleId) || responsibleId <= 0) ||
      !codigo || codigo.length > 30 || !nombre || nombre.length > 100 || ubicacion.length > 160 ||
      !/^[A-Z]{3}$/.test(moneda) || !Number.isFinite(saldo) || saldo < 0) {
    return { error: "Revisa la empresa, sucursal, código, nombre y saldo inicial." } as const;
  }
  return {
    data: {
      empresa_id: empresaId,
      sucursal_id: branchId,
      responsable_id: responsibleId,
      codigo,
      nombre,
      ubicacion,
      moneda,
      saldo_inicial: saldo,
      estado,
    },
  } as const;
}

export async function PUT(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = parseId((await context.params).id);
  if (!id) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  const parsed = await readCash(request);
  if ("error" in parsed) return NextResponse.json({ error: parsed.error }, { status: 400 });
  const cash = parsed.data;

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const current = state.boxes.find((box) => box.id === id);
    if (!current) return NextResponse.json({ error: "Caja no encontrada." }, { status: 404 });
    if (current.empresa_id !== cash.empresa_id || current.sucursal_id !== cash.sucursal_id) {
      return NextResponse.json({ error: "La empresa y sucursal de una caja existente no se pueden cambiar." }, { status: 400 });
    }
    if (!state.companies.some((company) => company.id === cash.empresa_id) ||
        !state.branches.some((branch) => branch.id === cash.sucursal_id && branch.empresa_id === cash.empresa_id &&
          (branch.estado === "ACTIVA" || cash.estado === "INACTIVA"))) {
      return NextResponse.json({ error: "La sucursal debe pertenecer a una empresa activa." }, { status: 400 });
    }
    if (cash.responsable_id !== null && !state.users.some((user) => user.id === cash.responsable_id && user.empresa_id === cash.empresa_id)) {
      return NextResponse.json({ error: "El responsable debe pertenecer a la empresa seleccionada." }, { status: 400 });
    }
    if (cash.estado === "ACTIVA" && state.boxes.some((box) => box.id !== id && box.sucursal_id === cash.sucursal_id && box.estado === "ACTIVA")) {
      return NextResponse.json({ error: "La sucursal ya tiene una caja activa." }, { status: 409 });
    }
    Object.assign(current, cash);
    return NextResponse.json({ data: current });
  }

  const pool = getDatabasePool();
  const validBranch = await pool.query(
    `SELECT 1
     FROM sucursales AS sucursal
     JOIN empresas AS empresa ON empresa.id = sucursal.empresa_id AND empresa.estado = 'ACTIVA'
     WHERE sucursal.id = $1 AND sucursal.empresa_id = $2
       AND (sucursal.estado IN ('ACTIVA', 'ACTIVO') OR $3 = 'INACTIVA')`,
    [cash.sucursal_id, cash.empresa_id, cash.estado],
  );
  if (!validBranch.rowCount) return NextResponse.json({ error: "La sucursal debe pertenecer a una empresa activa." }, { status: 400 });
  const existing = await pool.query<{ empresa_id: string; sucursal_id: string }>(
    `SELECT empresa_id::text, sucursal_id::text FROM cajas WHERE id = $1`,
    [id],
  );
  if (!existing.rows[0]) return NextResponse.json({ error: "Caja no encontrada." }, { status: 404 });
  if (Number(existing.rows[0].empresa_id) !== cash.empresa_id || Number(existing.rows[0].sucursal_id) !== cash.sucursal_id) {
    return NextResponse.json({ error: "La empresa y sucursal de una caja existente no se pueden cambiar." }, { status: 400 });
  }
  if (cash.responsable_id !== null) {
    const validUser = await pool.query(
      `SELECT 1 FROM usuarios WHERE id = $1 AND empresa_id = $2 AND estado = 'ACTIVO'`,
      [cash.responsable_id, cash.empresa_id],
    );
    if (!validUser.rowCount) return NextResponse.json({ error: "El responsable debe pertenecer a la empresa seleccionada." }, { status: 400 });
  }
  try {
    const result = await pool.query(
      `UPDATE cajas
       SET empresa_id = $1, sucursal_id = $2, codigo = $3, nombre = $4, ubicacion = $5,
           responsable_id = $6, moneda = $7, saldo_inicial = $8, estado = $9
       WHERE id = $10
       RETURNING id::text, empresa_id::text, sucursal_id::text, codigo, nombre, ubicacion,
                 responsable_id::text, moneda, saldo_inicial, estado`,
      [cash.empresa_id, cash.sucursal_id, cash.codigo, cash.nombre, cash.ubicacion || null,
        cash.responsable_id, cash.moneda, cash.saldo_inicial, cash.estado, id],
    );
    const row = result.rows[0];
    return row
      ? NextResponse.json({
        data: {
          ...row,
          id: Number(row.id),
          empresa_id: Number(row.empresa_id),
          sucursal_id: Number(row.sucursal_id),
          responsable_id: row.responsable_id === null ? null : Number(row.responsable_id),
          saldo_inicial: Number(row.saldo_inicial),
          estado: String(row.estado).toUpperCase().startsWith("INACT") ? "Inactiva" : "Activa",
        },
      })
      : NextResponse.json({ error: "Caja no encontrada." }, { status: 404 });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "La sucursal ya tiene una caja activa o el código ya está registrado en la empresa." }, { status: 409 });
    }
    throw error;
  }
}

export async function DELETE(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = parseId((await context.params).id);
  if (!id) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const box = getMockTreasuryState().boxes.find((item) => item.id === id);
    if (!box) return NextResponse.json({ error: "Caja no encontrada." }, { status: 404 });
    box.estado = "INACTIVA";
    return NextResponse.json({ data: { id } });
  }

  const result = await getDatabasePool().query(
    `UPDATE cajas SET estado = 'INACTIVA' WHERE id = $1 RETURNING id`,
    [id],
  );
  return result.rows[0]
    ? NextResponse.json({ data: result.rows[0] })
    : NextResponse.json({ error: "Caja no encontrada." }, { status: 404 });
}
