import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getMockTreasuryState } from "@/lib/mock-treasury";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    return NextResponse.json({
      data: {
          companies: state.companies,
          branches: state.branches,
        users: state.users,
        occupiedBranchIds: state.boxes
          .filter((box) => box.estado === "ACTIVA")
          .map((box) => box.sucursal_id),
      },
    });
  }

  const pool = getDatabasePool();
  const [companies, branches, users, occupiedBranches] = await Promise.all([
    pool.query<{ id: string; nombre_comercial: string; moneda_base: string }>(
      `SELECT id::text, nombre_comercial, moneda_base FROM empresas
       WHERE estado = 'ACTIVA' ORDER BY nombre_comercial`,
    ),
    pool.query<{ id: string; empresa_id: string; codigo: string; nombre: string; estado: string }>(
      `SELECT sucursal.id::text, sucursal.empresa_id::text, sucursal.codigo, sucursal.nombre, sucursal.estado
       FROM sucursales AS sucursal
       JOIN empresas AS empresa ON empresa.id = sucursal.empresa_id AND empresa.estado = 'ACTIVA'
       ORDER BY sucursal.empresa_id, sucursal.nombre`,
    ),
    pool.query<{ id: string; empresa_id: string; nombre: string }>(
      `SELECT usuario.id::text, usuario.empresa_id::text, usuario.nombre
       FROM usuarios AS usuario
       JOIN empresas AS empresa ON empresa.id = usuario.empresa_id AND empresa.estado = 'ACTIVA'
       WHERE usuario.estado = 'ACTIVO'
       ORDER BY usuario.empresa_id, usuario.nombre`,
    ),
    pool.query<{ sucursal_id: string }>(
      `SELECT sucursal_id::text FROM cajas
       WHERE sucursal_id IS NOT NULL AND estado IN ('ACTIVA', 'ACTIVO')`,
    ),
  ]);
  return NextResponse.json({
    data: {
      companies: companies.rows.map((company) => ({ ...company, id: Number(company.id) })),
      branches: branches.rows.map((branch) => ({
        ...branch,
        id: Number(branch.id),
        empresa_id: Number(branch.empresa_id),
        estado: String(branch.estado).toUpperCase().startsWith("INACT") ? "INACTIVA" : "ACTIVA",
      })),
      users: users.rows.map((user) => ({
        ...user,
        id: Number(user.id),
        empresa_id: Number(user.empresa_id),
      })),
      occupiedBranchIds: occupiedBranches.rows.map((row) => Number(row.sucursal_id)),
    },
  });
}
