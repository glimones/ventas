import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool } from "@/lib/db";
import {
  getMockTreasuryState,
  getExpectedBankBalance,
  getMockCompanyId,
  nextMockId,
  type TreasuryReconciliation,
} from "@/lib/mock-treasury";
import { parseReconciliation } from "@/lib/tesoreria-documentos";
import { hasRoutePermission } from "@/lib/route-permissions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function actorId(claims: { sub: string; empresaId: number }) {
  const parsed = Number(claims.sub);
  if (Number.isSafeInteger(parsed) && parsed > 0) return parsed;
  if (isMockAuthEnabled()) {
    const companyId = getMockCompanyId(claims.empresaId);
    return getMockTreasuryState().users.find((user) => user.empresa_id === companyId)?.id ?? null;
  }
  return null;
}

function periodDates(period: string) {
  const [year, month] = period.split("-").map(Number);
  const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return {
    desde: `${period}-01`,
    hasta: `${period}-${String(lastDay).padStart(2, "0")}`,
  };
}

function mockView(reconciliation: TreasuryReconciliation) {
  const state = getMockTreasuryState();
  const account = state.bankAccounts.find((item) => item.id === reconciliation.cuenta_bancaria_id);
  const bank = account && state.banks.find((item) => item.id === account.banco_id);
  return {
    ...reconciliation,
    banco: bank?.nombre ?? "",
    cuenta: account ? `${bank?.nombre ?? ""} · ${account.codigo} · **** ${account.numero_cuenta.slice(-4)}` : "",
    moneda: account?.moneda ?? "USD",
    responsable: state.users.find((item) => item.id === reconciliation.responsable_id)?.nombre ?? "",
    movimientos_total: state.bankMovements.filter((movement) =>
      movement.cuenta_bancaria_id === reconciliation.cuenta_bancaria_id &&
      movement.fecha >= reconciliation.fecha_desde && movement.fecha <= reconciliation.fecha_hasta).length,
    movimientos_conciliados: reconciliation.movimientos_conciliados.length,
  };
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!hasRoutePermission(claims, "/conciliacion-bancaria", 1)) {
    return NextResponse.json({ error: "No tienes permiso para consultar conciliaciones." }, { status: 403 });
  }
  if (isMockAuthEnabled()) {
    const companyId = getMockCompanyId(claims.empresaId);
    return NextResponse.json({
      data: getMockTreasuryState().reconciliations
        .filter((item) => item.empresa_id === companyId)
        .map(mockView),
    });
  }

  const result = await getDatabasePool().query(
    `SELECT conciliacion.id::text, conciliacion.empresa_id::text,
            conciliacion.cuenta_bancaria_id::text, conciliacion.periodo,
            to_char(conciliacion.fecha_desde, 'YYYY-MM-DD') AS fecha_desde,
            to_char(conciliacion.fecha_hasta, 'YYYY-MM-DD') AS fecha_hasta,
            to_char(conciliacion.fecha_conciliacion, 'YYYY-MM-DD') AS fecha_conciliacion,
            conciliacion.saldo_libros, conciliacion.saldo_banco, conciliacion.diferencia,
            COALESCE(conciliacion.motivo_diferencia, '') AS motivo_diferencia,
            conciliacion.responsable_id::text, responsable.nombre AS responsable,
            conciliacion.estado, banco.nombre AS banco, cuenta.moneda,
            banco.nombre || ' · ' || cuenta.codigo || ' · ' ||
              CASE WHEN LENGTH(cuenta.numero_cuenta) > 4
                   THEN '**** ' || RIGHT(cuenta.numero_cuenta, 4)
                   ELSE '****' END AS cuenta,
            COUNT(detalle.id)::integer AS movimientos_total,
            COUNT(detalle.id) FILTER (WHERE detalle.conciliado)::integer AS movimientos_conciliados
     FROM conciliaciones_bancarias AS conciliacion
     JOIN cuentas_bancarias AS cuenta
       ON cuenta.id = conciliacion.cuenta_bancaria_id AND cuenta.empresa_id = conciliacion.empresa_id
     JOIN bancos AS banco ON banco.id = cuenta.banco_id
     LEFT JOIN usuarios AS responsable
       ON responsable.id = conciliacion.responsable_id AND responsable.empresa_id = conciliacion.empresa_id
     LEFT JOIN conciliaciones_bancarias_detalles AS detalle
       ON detalle.conciliacion_id = conciliacion.id AND detalle.empresa_id = conciliacion.empresa_id
     WHERE conciliacion.empresa_id = $1
     GROUP BY conciliacion.id, cuenta.id, banco.nombre, responsable.nombre
     ORDER BY conciliacion.fecha_hasta DESC, conciliacion.id DESC`,
    [claims.empresaId],
  );
  return NextResponse.json({
    data: result.rows.map((row) => ({
      ...row,
      id: Number(row.id),
      empresa_id: Number(row.empresa_id),
      cuenta_bancaria_id: Number(row.cuenta_bancaria_id),
      responsable_id: row.responsable_id === null ? null : Number(row.responsable_id),
      saldo_libros: Number(row.saldo_libros),
      saldo_banco: Number(row.saldo_banco),
      diferencia: Number(row.diferencia),
      movimientos_total: Number(row.movimientos_total),
      movimientos_conciliados: Number(row.movimientos_conciliados),
    })),
  });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!hasRoutePermission(claims, "/conciliacion-bancaria", 2)) {
    return NextResponse.json({ error: "No tienes permiso para registrar conciliaciones." }, { status: 403 });
  }
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  const input = parseReconciliation(body);
  if (!input) return NextResponse.json({ error: "Revisa la cuenta, el período, el saldo bancario y los movimientos seleccionados." }, { status: 400 });
  const responsibleId = actorId(claims);
  const companyId = isMockAuthEnabled() ? getMockCompanyId(claims.empresaId) : claims.empresaId;
  if (!responsibleId) return NextResponse.json({ error: "No se pudo identificar al responsable activo." }, { status: 400 });
  const dates = periodDates(input.periodo);

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const account = state.bankAccounts.find((item) =>
      item.id === input.cuenta_bancaria_id && item.empresa_id === companyId && item.estado === "ACTIVA");
    const bank = account && state.banks.find((item) => item.id === account.banco_id);
    if (!account || bank?.estado !== "ACTIVO") {
      return NextResponse.json({ error: "Selecciona una cuenta bancaria activa de tu empresa." }, { status: 400 });
    }
    if (dates.hasta < account.fecha_saldo_inicial) {
      return NextResponse.json({ error: "El período termina antes de la fecha del saldo inicial de la cuenta." }, { status: 400 });
    }
    if (state.reconciliations.some((item) =>
      item.cuenta_bancaria_id === account.id && item.periodo === input.periodo)) {
      return NextResponse.json({ error: "Ya existe una conciliación para esta cuenta y período." }, { status: 409 });
    }
    const periodMovements = state.bankMovements.filter((movement) =>
      movement.cuenta_bancaria_id === account.id &&
      movement.fecha >= dates.desde && movement.fecha <= dates.hasta);
    const movementIds = new Set(periodMovements.map((movement, index) => movement.id ?? index + 1));
    if (input.movimientos_conciliados.some((id) => !movementIds.has(id))) {
      return NextResponse.json({ error: "La lista contiene movimientos fuera de la cuenta o del período." }, { status: 400 });
    }
    const bookMovements = state.bankMovements.filter((movement) =>
      movement.cuenta_bancaria_id === account.id && movement.fecha <= dates.hasta);
    const bookBalance = Math.round(getExpectedBankBalance(account, bookMovements) * 100) / 100;
    const difference = Math.round((bookBalance - input.saldo_banco) * 100) / 100;
    if (Math.abs(difference) >= 0.01 && !input.motivo_diferencia) {
      return NextResponse.json({ error: "Indica el motivo para cerrar una conciliación con diferencia." }, { status: 400 });
    }
    const created: TreasuryReconciliation = {
      id: nextMockId(state.reconciliations),
      empresa_id: companyId,
      cuenta_bancaria_id: account.id,
      periodo: input.periodo,
      fecha_desde: dates.desde,
      fecha_hasta: dates.hasta,
      fecha_conciliacion: dates.hasta,
      saldo_libros: bookBalance,
      saldo_banco: input.saldo_banco,
      diferencia: difference,
      motivo_diferencia: input.motivo_diferencia,
      responsable_id: responsibleId,
      estado: Math.abs(difference) < 0.01 ? "CONCILIADA" : "CONCILIADA_CON_DIFERENCIA",
      movimientos_conciliados: input.movimientos_conciliados,
    };
    state.reconciliations.push(created);
    return NextResponse.json({ data: mockView(created) }, { status: 201 });
  }

  const client = await getDatabasePool().connect();
  let transactionOpen = false;
  try {
    await client.query("BEGIN");
    transactionOpen = true;
    const account = await client.query<{ id: string; moneda: string; fecha_saldo_inicial: string }>(
      `SELECT cuenta.id::text, cuenta.moneda, cuenta.fecha_saldo_inicial::text
       FROM cuentas_bancarias AS cuenta
       JOIN bancos AS banco ON banco.id = cuenta.banco_id AND banco.estado = 'ACTIVO'
       WHERE cuenta.id = $1 AND cuenta.empresa_id = $2 AND cuenta.estado = 'ACTIVA'
       FOR UPDATE OF cuenta`,
      [input.cuenta_bancaria_id, claims.empresaId],
    );
    if (!account.rows[0]) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Selecciona una cuenta bancaria activa de tu empresa." }, { status: 400 });
    }
    if (dates.hasta < account.rows[0].fecha_saldo_inicial) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "El período termina antes de la fecha del saldo inicial de la cuenta." }, { status: 400 });
    }
    const user = await client.query(
      "SELECT id FROM usuarios WHERE id = $1 AND empresa_id = $2 AND estado = 'ACTIVO'",
      [responsibleId, claims.empresaId],
    );
    if (!user.rows[0]) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "El responsable debe estar activo y pertenecer a la empresa." }, { status: 400 });
    }
    const bookBalanceResult = await client.query<{ saldo: string }>(
      `SELECT cuenta.saldo_inicial + COALESCE(SUM(
                CASE WHEN movimiento.tipo IN ('INGRESO', 'DEPOSITO', 'ABONO') THEN movimiento.importe
                     WHEN movimiento.tipo IN ('EGRESO', 'CHEQUE', 'PAGO') THEN -movimiento.importe
                     ELSE 0 END
              ), 0)::numeric(18, 2)::text AS saldo
       FROM cuentas_bancarias AS cuenta
       LEFT JOIN movimientos_tesoreria AS movimiento
         ON movimiento.cuenta_bancaria_id = cuenta.id
        AND movimiento.fecha::date >= cuenta.fecha_saldo_inicial
        AND movimiento.fecha::date <= $3::date
       WHERE cuenta.id = $1 AND cuenta.empresa_id = $2
       GROUP BY cuenta.id`,
      [input.cuenta_bancaria_id, claims.empresaId, dates.hasta],
    );
    const bookBalance = Number(bookBalanceResult.rows[0].saldo);
    const difference = Math.round((bookBalance - input.saldo_banco) * 100) / 100;
    if (Math.abs(difference) >= 0.01 && !input.motivo_diferencia) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Indica el motivo para cerrar una conciliación con diferencia." }, { status: 400 });
    }
    const periodMovements = await client.query<{ id: string }>(
      `SELECT id::text FROM movimientos_tesoreria
       WHERE empresa_id = $1 AND cuenta_bancaria_id = $2
         AND fecha::date BETWEEN $3::date AND $4::date
       ORDER BY fecha, id`,
      [claims.empresaId, input.cuenta_bancaria_id, dates.desde, dates.hasta],
    );
    const periodIds = new Set(periodMovements.rows.map((row) => Number(row.id)));
    if (input.movimientos_conciliados.some((id) => !periodIds.has(id))) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "La lista contiene movimientos fuera de la cuenta o del período." }, { status: 400 });
    }
    const duplicate = await client.query(
      `SELECT 1 FROM conciliaciones_bancarias
       WHERE cuenta_bancaria_id = $1 AND periodo = $2`,
      [input.cuenta_bancaria_id, input.periodo],
    );
    if (duplicate.rows[0]) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Ya existe una conciliación para esta cuenta y período." }, { status: 409 });
    }
    const inserted = await client.query<{ id: string }>(
      `INSERT INTO conciliaciones_bancarias
         (empresa_id, cuenta_bancaria_id, periodo, fecha_desde, fecha_hasta,
          fecha_conciliacion, saldo_libros, saldo_banco, diferencia,
          motivo_diferencia, responsable_id, estado)
       VALUES ($1, $2, $3, $4, $5, $5, $6, $7, $8, NULLIF($9, ''),
               $10, $11)
       RETURNING id::text`,
      [claims.empresaId, input.cuenta_bancaria_id, input.periodo, dates.desde, dates.hasta,
        bookBalance, input.saldo_banco, difference, input.motivo_diferencia,
        responsibleId, Math.abs(difference) < 0.01 ? "CONCILIADA" : "CONCILIADA_CON_DIFERENCIA"],
    );
    if (periodMovements.rows.length) {
      await client.query(
        `INSERT INTO conciliaciones_bancarias_detalles
           (empresa_id, conciliacion_id, movimiento_tesoreria_id, conciliado)
         SELECT $1, $2, movimiento.id, movimiento.id = ANY($3::bigint[])
         FROM movimientos_tesoreria AS movimiento
         WHERE movimiento.empresa_id = $1 AND movimiento.cuenta_bancaria_id = $4
           AND movimiento.fecha::date BETWEEN $5::date AND $6::date`,
        [claims.empresaId, inserted.rows[0].id, input.movimientos_conciliados,
          input.cuenta_bancaria_id, dates.desde, dates.hasta],
      );
    }
    await client.query("COMMIT");
    transactionOpen = false;
    return NextResponse.json({
      data: {
        id: Number(inserted.rows[0].id),
        cuenta_bancaria_id: input.cuenta_bancaria_id,
        periodo: input.periodo,
        fecha_desde: dates.desde,
        fecha_hasta: dates.hasta,
        fecha_conciliacion: dates.hasta,
        saldo_libros: bookBalance,
        saldo_banco: input.saldo_banco,
        diferencia: difference,
        motivo_diferencia: input.motivo_diferencia,
        responsable_id: responsibleId,
        moneda: account.rows[0].moneda,
        estado: Math.abs(difference) < 0.01 ? "CONCILIADA" : "CONCILIADA_CON_DIFERENCIA",
        movimientos_total: periodMovements.rows.length,
        movimientos_conciliados: input.movimientos_conciliados.length,
      },
    }, { status: 201 });
  } catch (error) {
    if (transactionOpen) await client.query("ROLLBACK");
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "Ya existe una conciliación para esta cuenta y período." }, { status: 409 });
    }
    throw error;
  } finally {
    client.release();
  }
}
