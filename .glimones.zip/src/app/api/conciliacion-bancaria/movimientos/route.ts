import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool } from "@/lib/db";
import { getExpectedBankBalance, getMockCompanyId, getMockTreasuryState } from "@/lib/mock-treasury";
import { hasRoutePermission } from "@/lib/route-permissions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function periodDates(period: string) {
  const [year, month] = period.split("-").map(Number);
  const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
  return { desde: `${period}-01`, hasta: `${period}-${String(lastDay).padStart(2, "0")}` };
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!hasRoutePermission(claims, "/conciliacion-bancaria", 1)) {
    return NextResponse.json({ error: "No tienes permiso para consultar conciliaciones." }, { status: 403 });
  }
  const accountId = Number(request.nextUrl.searchParams.get("cuenta_bancaria_id"));
  const period = request.nextUrl.searchParams.get("periodo") ?? "";
  if (!Number.isSafeInteger(accountId) || accountId <= 0 || !/^\d{4}-(0[1-9]|1[0-2])$/.test(period)) {
    return NextResponse.json({ error: "Indica una cuenta y un período válidos." }, { status: 400 });
  }
  const dates = periodDates(period);

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const companyId = getMockCompanyId(claims.empresaId);
    const account = state.bankAccounts.find((item) =>
      item.id === accountId && item.empresa_id === companyId && item.estado === "ACTIVA");
    if (!account) return NextResponse.json({ error: "La cuenta bancaria no está disponible." }, { status: 404 });
    if (dates.hasta < account.fecha_saldo_inicial) {
      return NextResponse.json({ error: "El período termina antes de la fecha del saldo inicial de la cuenta." }, { status: 400 });
    }
    const data = state.bankMovements
      .filter((movement) => movement.cuenta_bancaria_id === accountId &&
        movement.fecha >= dates.desde && movement.fecha <= dates.hasta)
      .map((movement, index) => ({
        id: movement.id ?? index + 1,
        fecha: movement.fecha,
        concepto: movement.concepto || movement.tipo,
        referencia: movement.referencia ?? "",
        tipo: movement.tipo,
        importe: movement.importe,
      }));
    const bookMovements = state.bankMovements.filter((movement) =>
      movement.cuenta_bancaria_id === accountId && movement.fecha <= dates.hasta);
    const saldo_libros = Math.round(getExpectedBankBalance(account, bookMovements) * 100) / 100;
    return NextResponse.json({ data, saldo_libros });
  }

  const pool = getDatabasePool();
  const [result, balance] = await Promise.all([
    pool.query(
    `SELECT id::text, to_char(fecha, 'YYYY-MM-DD') AS fecha, concepto,
            COALESCE(referencia, '') AS referencia, tipo, importe
     FROM movimientos_tesoreria
     WHERE empresa_id = $1 AND cuenta_bancaria_id = $2
       AND fecha::date BETWEEN $3::date AND $4::date
     ORDER BY fecha, id`,
    [claims.empresaId, accountId, dates.desde, dates.hasta],
    ),
    pool.query<{ saldo_libros: string }>(
      `SELECT cuenta.saldo_inicial + COALESCE(SUM(
                CASE WHEN movimiento.tipo IN ('INGRESO', 'DEPOSITO', 'ABONO') THEN movimiento.importe
                     WHEN movimiento.tipo IN ('EGRESO', 'CHEQUE', 'PAGO') THEN -movimiento.importe
                     ELSE 0 END
              ), 0)::numeric(18, 2)::text AS saldo_libros
       FROM cuentas_bancarias AS cuenta
       LEFT JOIN movimientos_tesoreria AS movimiento
         ON movimiento.cuenta_bancaria_id = cuenta.id
        AND movimiento.fecha::date >= cuenta.fecha_saldo_inicial
        AND movimiento.fecha::date <= $3::date
       WHERE cuenta.id = $1 AND cuenta.empresa_id = $2 AND cuenta.estado = 'ACTIVA'
       GROUP BY cuenta.id`,
      [accountId, claims.empresaId, dates.hasta],
    ),
  ]);
  if (!balance.rows[0]) return NextResponse.json({ error: "La cuenta bancaria no está disponible." }, { status: 404 });
  const accountDate = await pool.query<{ fecha_saldo_inicial: string }>(
    `SELECT fecha_saldo_inicial::text FROM cuentas_bancarias
     WHERE id = $1 AND empresa_id = $2 AND estado = 'ACTIVA'`,
    [accountId, claims.empresaId],
  );
  if (!accountDate.rows[0]) return NextResponse.json({ error: "La cuenta bancaria no está disponible." }, { status: 404 });
  if (dates.hasta < accountDate.rows[0].fecha_saldo_inicial) {
    return NextResponse.json({ error: "El período termina antes de la fecha del saldo inicial de la cuenta." }, { status: 400 });
  }
  return NextResponse.json({
    data: result.rows.map((row) => ({
      ...row,
      id: Number(row.id),
      importe: Number(row.importe),
    })),
    saldo_libros: Number(balance.rows[0].saldo_libros),
  });
}
