import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool } from "@/lib/db";
import { getMockTreasuryState, nextMockId, type TreasuryBank } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type BankInput = Omit<TreasuryBank, "id">;

function isUniqueViolation(error: unknown) {
  return typeof error === "object" && error !== null && "code" in error && error.code === "23505";
}

function parseBank(body: unknown): BankInput | null {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  const input = body as Record<string, unknown>;
  const codigo = typeof input.codigo === "string" ? input.codigo.trim().toUpperCase() : "";
  const nombre = typeof input.nombre === "string" ? input.nombre.trim() : "";
  const pais = typeof input.pais === "string" ? input.pais.trim() : "";
  const swift = typeof input.swift_bic === "string" ? input.swift_bic.trim().toUpperCase() : "";
  const estado = String(input.estado ?? "ACTIVO").toUpperCase() === "INACTIVO" ? "INACTIVO" : "ACTIVO";
  if (!codigo || codigo.length > 30 || !nombre || nombre.length > 120 || !pais || pais.length > 80 ||
      swift.length > 11 || (swift && !/^[A-Z0-9]{8}([A-Z0-9]{3})?$/.test(swift))) return null;
  return { codigo, nombre, pais, swift_bic: swift, estado };
}

export async function GET(request: NextRequest) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (isMockAuthEnabled()) {
    const data = getMockTreasuryState().banks;
    return NextResponse.json({
      data,
      counts: { total: data.length, active: data.filter((bank) => bank.estado === "ACTIVO").length, inactive: data.filter((bank) => bank.estado === "INACTIVO").length },
    });
  }
  const result = await getDatabasePool().query(
    `SELECT id::text, codigo, nombre, pais, COALESCE(swift_bic, '') AS swift_bic, estado
     FROM bancos ORDER BY nombre`,
  );
  const data = result.rows.map((row) => ({ ...row, id: Number(row.id) }));
  return NextResponse.json({
    data,
    counts: { total: data.length, active: data.filter((bank) => bank.estado === "ACTIVO").length, inactive: data.filter((bank) => bank.estado === "INACTIVO").length },
  });
}

export async function POST(request: NextRequest) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  const bank = parseBank(body);
  if (!bank) return NextResponse.json({ error: "Revisa el código, nombre, país y formato SWIFT/BIC." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    if (state.banks.some((item) => item.codigo.toLocaleLowerCase() === bank.codigo.toLocaleLowerCase() || item.nombre.toLocaleLowerCase() === bank.nombre.toLocaleLowerCase())) {
      return NextResponse.json({ error: "Ya existe un banco con ese código o nombre." }, { status: 409 });
    }
    const data = { id: nextMockId(state.banks), ...bank };
    state.banks.push(data);
    return NextResponse.json({ data }, { status: 201 });
  }
  try {
    const result = await getDatabasePool().query(
      `INSERT INTO bancos (codigo, nombre, pais, swift_bic, estado)
       VALUES ($1, $2, $3, NULLIF($4, ''), $5)
       RETURNING id::text, codigo, nombre, pais, COALESCE(swift_bic, '') AS swift_bic, estado`,
      [bank.codigo, bank.nombre, bank.pais, bank.swift_bic, bank.estado],
    );
    return NextResponse.json({ data: { ...result.rows[0], id: Number(result.rows[0].id) } }, { status: 201 });
  } catch (error) {
    if (isUniqueViolation(error)) return NextResponse.json({ error: "Ya existe un banco con ese código o nombre." }, { status: 409 });
    throw error;
  }
}
