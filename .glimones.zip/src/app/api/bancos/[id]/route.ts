import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool } from "@/lib/db";
import { getMockTreasuryState, type TreasuryBank } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

function isUniqueViolation(error: unknown) {
  return typeof error === "object" && error !== null && "code" in error && error.code === "23505";
}

function validId(value: string) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

function parseBank(body: unknown) {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  const input = body as Record<string, unknown>;
  const codigo = typeof input.codigo === "string" ? input.codigo.trim().toUpperCase() : "";
  const nombre = typeof input.nombre === "string" ? input.nombre.trim() : "";
  const pais = typeof input.pais === "string" ? input.pais.trim() : "";
  const swift = typeof input.swift_bic === "string" ? input.swift_bic.trim().toUpperCase() : "";
  const estado: TreasuryBank["estado"] = String(input.estado ?? "ACTIVO").toUpperCase() === "INACTIVO" ? "INACTIVO" : "ACTIVO";
  if (!codigo || codigo.length > 30 || !nombre || nombre.length > 120 || !pais || pais.length > 80 ||
      swift.length > 11 || (swift && !/^[A-Z0-9]{8}([A-Z0-9]{3})?$/.test(swift))) return null;
  return { codigo, nombre, pais, swift_bic: swift, estado };
}

export async function PUT(request: NextRequest, context: RouteContext) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = validId((await context.params).id);
  if (id === null) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  const bank = parseBank(body);
  if (!bank) return NextResponse.json({ error: "Revisa el código, nombre, país y formato SWIFT/BIC." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const index = state.banks.findIndex((item) => item.id === id);
    if (index < 0) return NextResponse.json({ error: "Banco no encontrado." }, { status: 404 });
    if (state.banks.some((item) => item.id !== id && (item.codigo.toLocaleLowerCase() === bank.codigo.toLocaleLowerCase() || item.nombre.toLocaleLowerCase() === bank.nombre.toLocaleLowerCase()))) {
      return NextResponse.json({ error: "Ya existe un banco con ese código o nombre." }, { status: 409 });
    }
    if (bank.estado === "INACTIVO" && state.bankAccounts.some((account) => account.banco_id === id && account.estado === "ACTIVA")) {
      return NextResponse.json({ error: "No se puede inactivar un banco con cuentas activas." }, { status: 409 });
    }
    state.banks[index] = { id, ...bank };
    return NextResponse.json({ data: state.banks[index] });
  }
  const pool = getDatabasePool();
  if (bank.estado === "INACTIVO") {
    const activeAccounts = await pool.query(
      "SELECT 1 FROM cuentas_bancarias WHERE banco_id = $1 AND estado = 'ACTIVA' LIMIT 1",
      [id],
    );
    if (activeAccounts.rowCount) return NextResponse.json({ error: "No se puede inactivar un banco con cuentas activas." }, { status: 409 });
  }
  try {
    const result = await pool.query(
      `UPDATE bancos SET codigo = $2, nombre = $3, pais = $4, swift_bic = NULLIF($5, ''), estado = $6
       WHERE id = $1
       RETURNING id::text, codigo, nombre, pais, COALESCE(swift_bic, '') AS swift_bic, estado`,
      [id, bank.codigo, bank.nombre, bank.pais, bank.swift_bic, bank.estado],
    );
    return result.rowCount
      ? NextResponse.json({ data: { ...result.rows[0], id: Number(result.rows[0].id) } })
      : NextResponse.json({ error: "Banco no encontrado." }, { status: 404 });
  } catch (error) {
    if (isUniqueViolation(error)) return NextResponse.json({ error: "Ya existe un banco con ese código o nombre." }, { status: 409 });
    throw error;
  }
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = validId((await context.params).id);
  if (id === null) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const bank = state.banks.find((item) => item.id === id);
    if (!bank) return NextResponse.json({ error: "Banco no encontrado." }, { status: 404 });
    if (state.bankAccounts.some((account) => account.banco_id === id && account.estado === "ACTIVA")) {
      return NextResponse.json({ error: "No se puede inactivar un banco con cuentas activas." }, { status: 409 });
    }
    bank.estado = "INACTIVO";
    return NextResponse.json({ data: bank });
  }
  const pool = getDatabasePool();
  const activeAccounts = await pool.query(
    "SELECT 1 FROM cuentas_bancarias WHERE banco_id = $1 AND estado = 'ACTIVA' LIMIT 1",
    [id],
  );
  if (activeAccounts.rowCount) return NextResponse.json({ error: "No se puede inactivar un banco con cuentas activas." }, { status: 409 });
  const result = await pool.query(
    "UPDATE bancos SET estado = 'INACTIVO' WHERE id = $1 RETURNING id::text, codigo, nombre, pais, COALESCE(swift_bic, '') AS swift_bic, estado",
    [id],
  );
  return result.rowCount
    ? NextResponse.json({ data: { ...result.rows[0], id: Number(result.rows[0].id) } })
    : NextResponse.json({ error: "Banco no encontrado." }, { status: 404 });
}
