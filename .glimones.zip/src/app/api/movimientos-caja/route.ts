import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getMockTreasuryState, nextMockId } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function databaseUnavailable() {
  return NextResponse.json(
    { error: "Los movimientos de caja todavía están disponibles solo en modo demostración sin base de datos." },
    { status: 501 },
  );
}

function movementView(movement: ReturnType<typeof getMockTreasuryState>["cashMovements"][number]) {
  const state = getMockTreasuryState();
  const box = state.boxes.find((item) => item.id === movement.caja_id);
  const session = state.sessions.find((item) => item.id === movement.sesion_id);
  const user = state.users.find((item) => item.id === movement.responsable_id);
  return {
    ...movement,
    caja: box?.nombre ?? "Caja no disponible",
    codigo_caja: box?.codigo ?? "",
    sesion: session?.codigo ?? "",
    responsable: user?.nombre ?? "Responsable no disponible",
  };
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!isMockAuthEnabled()) return databaseUnavailable();

  const state = getMockTreasuryState();
  const openSessions = state.sessions
    .filter((session) => session.estado === "ABIERTA")
    .map((session) => {
      const box = state.boxes.find((item) => item.id === session.caja_id);
      return {
        id: session.id,
        codigo: session.codigo,
        caja: box?.nombre ?? "Caja no disponible",
        empresa_id: box?.empresa_id ?? 0,
        responsable_id: session.responsable_id,
      };
    });
  return NextResponse.json({
    data: state.cashMovements.map(movementView).sort((left, right) => right.fecha.localeCompare(left.fecha)),
    openSessions,
    users: state.users,
    capabilities: { create: true },
  });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!isMockAuthEnabled()) return databaseUnavailable();

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
  }
  const input = body as Record<string, unknown>;
  const sessionId = Number(input.sesion_id);
  const responsibleId = Number(input.responsable_id);
  const type = typeof input.tipo === "string" ? input.tipo.toUpperCase() : "";
  const concept = typeof input.concepto === "string" ? input.concepto.trim() : "";
  const amount = Number(input.importe);
  if (!Number.isSafeInteger(sessionId) || sessionId <= 0 ||
      !Number.isSafeInteger(responsibleId) || responsibleId <= 0 ||
      (type !== "INGRESO" && type !== "EGRESO") ||
      !concept || concept.length > 250 ||
      !Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Completa la sesión, el responsable, el tipo, el concepto y un importe mayor que cero." }, { status: 400 });
  }

  const state = getMockTreasuryState();
  const session = state.sessions.find((item) => item.id === sessionId && item.estado === "ABIERTA");
  if (!session) return NextResponse.json({ error: "Solo se pueden registrar movimientos en una sesión abierta." }, { status: 409 });
  const box = state.boxes.find((item) => item.id === session.caja_id);
  if (!box || !state.users.some((user) => user.id === responsibleId && user.empresa_id === box.empresa_id)) {
    return NextResponse.json({ error: "El responsable debe pertenecer a la empresa de la caja." }, { status: 400 });
  }

  const id = nextMockId(state.cashMovements);
  const movement = {
    id,
    codigo: `MC-${String(id).padStart(6, "0")}`,
    sesion_id: session.id,
    caja_id: session.caja_id,
    tipo: type as "INGRESO" | "EGRESO",
    concepto: concept,
    fecha: new Date().toISOString(),
    importe: Number(amount.toFixed(2)),
    responsable_id: responsibleId,
  };
  state.cashMovements.push(movement);
  return NextResponse.json({ data: movementView(movement) }, { status: 201 });
}
