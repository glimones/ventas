import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getExpectedCashBalance, getMockTreasuryState, nextMockId } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function sessionView(session: ReturnType<typeof getMockTreasuryState>["sessions"][number]) {
  const state = getMockTreasuryState();
  const box = state.boxes.find((item) => item.id === session.caja_id);
  const branch = state.branches.find((item) => item.id === box?.sucursal_id);
  const responsible = state.users.find((item) => item.id === session.responsable_id);
  return {
    ...session,
    caja: box?.nombre ?? "Caja no disponible",
    codigo_caja: box?.codigo ?? "",
    empresa: state.companies.find((item) => item.id === box?.empresa_id)?.nombre_comercial ?? "",
    sucursal: branch?.nombre ?? "",
    responsable: responsible?.nombre ?? "Responsable no disponible",
    saldo_esperado: getExpectedCashBalance(session, state.cashMovements),
  };
}

function databaseUnavailable() {
  return NextResponse.json(
    { error: "Aperturas y cierres todavía están disponibles solo en modo demostración sin base de datos." },
    { status: 501 },
  );
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!isMockAuthEnabled()) return databaseUnavailable();

  const state = getMockTreasuryState();
  const openBoxIds = new Set(
    state.sessions.filter((session) => session.estado === "ABIERTA").map((session) => session.caja_id),
  );
  const data = state.sessions
    .map(sessionView)
    .sort((left, right) => right.fecha_apertura.localeCompare(left.fecha_apertura));
  return NextResponse.json({
    data,
    catalogs: {
      availableBoxes: state.boxes
        .filter((box) => box.estado === "ACTIVA" && !openBoxIds.has(box.id))
        .map((box) => ({
          id: box.id,
          empresa_id: box.empresa_id,
          responsable_id: box.responsable_id,
          nombre: box.nombre,
          codigo: box.codigo,
          empresa: state.companies.find((company) => company.id === box.empresa_id)?.nombre_comercial ?? "",
          sucursal: state.branches.find((branch) => branch.id === box.sucursal_id)?.nombre ?? "",
        })),
      boxes: state.boxes.map((box) => ({
        id: box.id,
        nombre: box.nombre,
        codigo: box.codigo,
      })),
      users: state.users,
    },
    capabilities: { create: true, close: true },
  });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!isMockAuthEnabled()) return databaseUnavailable();

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
  }

  const input = body as Record<string, unknown>;
  const cajaId = Number(input.caja_id);
  const responsableId = Number(input.responsable_id);
  const saldoInicial = Number(input.saldo_inicial);
  if (!Number.isSafeInteger(cajaId) || cajaId <= 0 ||
      !Number.isSafeInteger(responsableId) || responsableId <= 0 ||
      !Number.isFinite(saldoInicial) || saldoInicial < 0) {
    return NextResponse.json({ error: "Selecciona la caja y el responsable e ingresa un saldo inicial válido." }, { status: 400 });
  }

  const state = getMockTreasuryState();
  const box = state.boxes.find((item) => item.id === cajaId && item.estado === "ACTIVA");
  if (!box) return NextResponse.json({ error: "La caja seleccionada no está activa." }, { status: 400 });
  if (state.sessions.some((session) => session.caja_id === cajaId && session.estado === "ABIERTA")) {
    return NextResponse.json({ error: "La caja ya tiene una sesión abierta." }, { status: 409 });
  }
  if (!state.users.some((user) => user.id === responsableId && user.empresa_id === box.empresa_id)) {
    return NextResponse.json({ error: "El responsable debe pertenecer a la empresa de la caja." }, { status: 400 });
  }

  const id = nextMockId(state.sessions);
  const session = {
    id,
    codigo: `APC-${String(id).padStart(6, "0")}`,
    caja_id: cajaId,
    responsable_id: responsableId,
    fecha_apertura: new Date().toISOString(),
    saldo_inicial: saldoInicial,
    fecha_cierre: null,
    cerrado_por: null,
    efectivo_contado: null,
    diferencia: null,
    observacion: "",
    estado: "ABIERTA" as const,
  };
  state.sessions.push(session);
  return NextResponse.json({ data: sessionView(session) }, { status: 201 });
}
