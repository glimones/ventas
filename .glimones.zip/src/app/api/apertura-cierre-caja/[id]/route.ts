import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getExpectedCashBalance, getMockTreasuryState } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

function parseId(value: string) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

export async function PATCH(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!isMockAuthEnabled()) {
    return NextResponse.json(
      { error: "Aperturas y cierres todavía están disponibles solo en modo demostración sin base de datos." },
      { status: 501 },
    );
  }

  const id = parseId((await context.params).id);
  if (!id) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
  }
  const input = body as Record<string, unknown>;
  const contado = Number(input.efectivo_contado);
  const observacion = typeof input.observacion === "string" ? input.observacion.trim() : "";
  if (!Number.isFinite(contado) || contado < 0 || observacion.length > 500) {
    return NextResponse.json({ error: "Ingresa un efectivo contado válido y una observación de hasta 500 caracteres." }, { status: 400 });
  }

  const state = getMockTreasuryState();
  const session = state.sessions.find((item) => item.id === id);
  if (!session) return NextResponse.json({ error: "Sesión de caja no encontrada." }, { status: 404 });
  if (session.estado !== "ABIERTA") {
    return NextResponse.json({ error: "La sesión ya está cerrada y no puede modificarse." }, { status: 409 });
  }

  const expected = getExpectedCashBalance(session, state.cashMovements);
  session.fecha_cierre = new Date().toISOString();
  session.cerrado_por = claims.name;
  session.efectivo_contado = contado;
  session.diferencia = Number((contado - expected).toFixed(2));
  session.observacion = observacion;
  session.estado = "CERRADA";

  const box = state.boxes.find((item) => item.id === session.caja_id);
  const responsible = state.users.find((item) => item.id === session.responsable_id);
  return NextResponse.json({
    data: {
      ...session,
      caja: box?.nombre ?? "Caja no disponible",
      saldo_esperado: expected,
      responsable: responsible?.nombre ?? "Responsable no disponible",
    },
  });
}
