import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool } from "@/lib/db";
import { getExpectedBankBalance, getMockCompanyId, getMockTreasuryState } from "@/lib/mock-treasury";
import { hasAnyRoutePermission } from "@/lib/route-permissions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function maskAccountNumber(value: string) {
  return value.length > 4 ? `**** ${value.slice(-4)}` : "****";
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!hasAnyRoutePermission(claims, ["/cheques", "/depositos", "/conciliacion-bancaria"], 1)) {
    return NextResponse.json({ error: "No tienes permiso para consultar opciones de tesorería." }, { status: 403 });
  }

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const companyId = getMockCompanyId(claims.empresaId);
    return NextResponse.json({
      data: {
        accounts: state.bankAccounts
          .filter((account) => account.empresa_id === companyId &&
            account.estado === "ACTIVA" &&
            state.banks.some((bank) => bank.id === account.banco_id && bank.estado === "ACTIVO"))
          .map((account) => ({
            id: account.id,
            empresa_id: account.empresa_id,
            codigo: account.codigo,
            banco: state.banks.find((bank) => bank.id === account.banco_id)?.nombre ?? "",
            cuenta: `${state.banks.find((bank) => bank.id === account.banco_id)?.nombre ?? ""} · ${account.codigo} · ${maskAccountNumber(account.numero_cuenta)}`,
            numero_cuenta: maskAccountNumber(account.numero_cuenta),
            moneda: account.moneda,
            saldo_actual: getExpectedBankBalance(account, state.bankMovements),
          })),
      },
    });
  }

  const result = await getDatabasePool().query(
    `SELECT cuenta.id::text, cuenta.empresa_id::text, cuenta.codigo, banco.nombre AS banco,
            banco.nombre || ' · ' || cuenta.codigo || ' · ' ||
              CASE WHEN LENGTH(cuenta.numero_cuenta) > 4
                   THEN '**** ' || RIGHT(cuenta.numero_cuenta, 4)
                   ELSE '****' END AS cuenta,
            CASE WHEN LENGTH(cuenta.numero_cuenta) > 4
                 THEN '**** ' || RIGHT(cuenta.numero_cuenta, 4)
                 ELSE '****' END AS numero_cuenta,
            cuenta.moneda,
            cuenta.saldo_inicial + COALESCE(SUM(
              CASE WHEN movimiento.tipo IN ('INGRESO', 'DEPOSITO', 'ABONO') THEN movimiento.importe
                   WHEN movimiento.tipo IN ('EGRESO', 'CHEQUE', 'PAGO') THEN -movimiento.importe
                   ELSE 0 END
            ), 0) AS saldo_actual
     FROM cuentas_bancarias AS cuenta
     JOIN bancos AS banco ON banco.id = cuenta.banco_id AND banco.estado = 'ACTIVO'
     LEFT JOIN movimientos_tesoreria AS movimiento
       ON movimiento.cuenta_bancaria_id = cuenta.id
      AND movimiento.fecha::date >= cuenta.fecha_saldo_inicial
     WHERE cuenta.empresa_id = $1 AND cuenta.estado = 'ACTIVA'
     GROUP BY cuenta.id, banco.nombre
     ORDER BY cuenta.codigo`,
    [claims.empresaId],
  );
  return NextResponse.json({
    data: {
      accounts: result.rows.map((row) => ({
        ...row,
        id: Number(row.id),
        empresa_id: Number(row.empresa_id),
        saldo_actual: Number(row.saldo_actual),
      })),
    },
  });
}
