import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import { getExpectedBankBalance, getMockTreasuryState, nextMockId, type TreasuryBankAccount } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type AccountInput = Omit<TreasuryBankAccount, "id">;

function isUniqueViolation(error: unknown) {
  return typeof error === "object" && error !== null && "code" in error && error.code === "23505";
}

function parseAccount(body: unknown): AccountInput | null {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  const input = body as Record<string, unknown>;
  const empresaId = Number(input.empresa_id);
  const bancoId = Number(input.banco_id);
  const chartId = input.cuenta_contable_id === "" || input.cuenta_contable_id === null || input.cuenta_contable_id === undefined
    ? null : Number(input.cuenta_contable_id);
  const codigo = typeof input.codigo === "string" ? input.codigo.trim().toUpperCase() : "";
  const numero = typeof input.numero_cuenta === "string" ? input.numero_cuenta.trim() : "";
  const titular = typeof input.titular === "string" ? input.titular.trim() : "";
  const tipo = typeof input.tipo_cuenta === "string" ? input.tipo_cuenta.trim().toUpperCase() : "";
  const branch = typeof input.sucursal_bancaria === "string" ? input.sucursal_bancaria.trim() : "";
  const moneda = typeof input.moneda === "string" ? input.moneda.trim().toUpperCase() : "";
  const fecha = typeof input.fecha_saldo_inicial === "string" ? input.fecha_saldo_inicial.trim() : "";
  const saldo = Number(input.saldo_inicial);
  const estado = String(input.estado ?? "ACTIVA").toUpperCase() === "INACTIVA" ? "INACTIVA" : "ACTIVA";
  if (!Number.isSafeInteger(empresaId) || empresaId <= 0 || !Number.isSafeInteger(bancoId) || bancoId <= 0 ||
      (chartId !== null && (!Number.isSafeInteger(chartId) || chartId <= 0)) ||
      !codigo || codigo.length > 30 || !numero || numero.length > 80 || !titular || titular.length > 160 ||
      !["CORRIENTE", "AHORROS", "OTRA"].includes(tipo) || branch.length > 120 || !/^[A-Z]{3}$/.test(moneda) ||
      !/^\d{4}-\d{2}-\d{2}$/.test(fecha) || !Number.isFinite(saldo) || saldo < 0) return null;
  return {
    empresa_id: empresaId,
    banco_id: bancoId,
    codigo,
    numero_cuenta: numero,
    titular,
    tipo_cuenta: tipo,
    sucursal_bancaria: branch,
    moneda,
    fecha_saldo_inicial: fecha,
    saldo_inicial: saldo,
    cuenta_contable_id: chartId,
    estado,
  };
}

function mask(number: string) {
  return `**** ${number.slice(-4)}`;
}

function safeAccount(row: Record<string, unknown>): Record<string, unknown> & {
  id: number;
  empresa_id: number;
  banco_id: number;
  cuenta_contable_id: number | null;
  saldo_inicial: number;
  saldo_actual: number;
  numero_cuenta: string;
  estado: string;
} {
  const number = String(row.numero_cuenta ?? "");
  return {
    ...row,
    numero_cuenta: mask(number),
    id: Number(row.id),
    empresa_id: Number(row.empresa_id),
    banco_id: Number(row.banco_id),
    cuenta_contable_id: row.cuenta_contable_id === null ? null : Number(row.cuenta_contable_id),
    saldo_inicial: Number(row.saldo_inicial ?? 0),
    saldo_actual: Number(row.saldo_actual ?? row.saldo_inicial ?? 0),
    estado: String(row.estado ?? ""),
  };
}

const ACCOUNT_SELECT = `
  SELECT cuenta.id::text, cuenta.empresa_id::text, cuenta.banco_id::text, cuenta.codigo,
         cuenta.numero_cuenta, cuenta.titular, cuenta.tipo_cuenta, cuenta.sucursal_bancaria,
         cuenta.moneda, to_char(cuenta.fecha_saldo_inicial, 'YYYY-MM-DD') AS fecha_saldo_inicial,
         cuenta.saldo_inicial, cuenta.cuenta_contable_id::text, cuenta.estado,
         banco.nombre AS banco, empresa.nombre_comercial AS empresa,
         plan.codigo || ' - ' || plan.nombre AS cuenta_contable,
         cuenta.saldo_inicial + COALESCE(SUM(
           CASE WHEN movimiento.tipo IN ('INGRESO', 'DEPOSITO', 'ABONO') THEN movimiento.importe
                WHEN movimiento.tipo IN ('EGRESO', 'CHEQUE', 'PAGO') THEN -movimiento.importe
                ELSE 0 END
         ), 0) AS saldo_actual
  FROM cuentas_bancarias AS cuenta
  JOIN bancos AS banco ON banco.id = cuenta.banco_id
  JOIN empresas AS empresa ON empresa.id = cuenta.empresa_id
  LEFT JOIN cuentas_contables AS plan
    ON plan.id = cuenta.cuenta_contable_id AND plan.empresa_id = cuenta.empresa_id
  LEFT JOIN movimientos_tesoreria AS movimiento
    ON movimiento.cuenta_bancaria_id = cuenta.id
   AND movimiento.fecha::date >= cuenta.fecha_saldo_inicial
`;

export async function GET(request: NextRequest) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const data = state.bankAccounts.map((account) => ({
      ...account,
      banco: state.banks.find((bank) => bank.id === account.banco_id)?.nombre ?? "",
      empresa: state.companies.find((company) => company.id === account.empresa_id)?.nombre_comercial ?? "",
      cuenta_contable: state.chartAccounts.find((chart) => chart.id === account.cuenta_contable_id)?.codigo ?? "",
      saldo_actual: getExpectedBankBalance(account, state.bankMovements),
      numero_cuenta: mask(account.numero_cuenta),
    }));
    return NextResponse.json({
      data,
      counts: { total: data.length, active: data.filter((account) => account.estado === "ACTIVA").length, inactive: data.filter((account) => account.estado === "INACTIVA").length },
    });
  }
  const result = await getDatabasePool().query(
    `${ACCOUNT_SELECT}
     WHERE cuenta.empresa_id = $1
     GROUP BY cuenta.id, banco.nombre, empresa.nombre_comercial, plan.codigo, plan.nombre
     ORDER BY cuenta.codigo`,
    [getEmpresaId()],
  );
  const data = result.rows.map((row) => safeAccount(row));
  return NextResponse.json({
    data,
    counts: { total: data.length, active: data.filter((account) => account.estado === "ACTIVA").length, inactive: data.filter((account) => account.estado === "INACTIVA").length },
  });
}

export async function POST(request: NextRequest) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  const account = parseAccount(body);
  if (!account) return NextResponse.json({ error: "Revisa empresa, banco, código, cuenta, titular, moneda, fecha y saldo inicial." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    if (!state.companies.some((company) => company.id === account.empresa_id) ||
        !state.banks.some((bank) => bank.id === account.banco_id && bank.estado === "ACTIVO") ||
        (account.cuenta_contable_id !== null && !state.chartAccounts.some((chart) => chart.id === account.cuenta_contable_id && chart.empresa_id === account.empresa_id && chart.estado === "ACTIVA"))) {
      return NextResponse.json({ error: "Selecciona una empresa, banco y cuenta contable activos." }, { status: 400 });
    }
    if (state.bankAccounts.some((item) => item.empresa_id === account.empresa_id && item.codigo.toLocaleLowerCase() === account.codigo.toLocaleLowerCase())) {
      return NextResponse.json({ error: "Ya existe una cuenta con ese código en la empresa." }, { status: 409 });
    }
    const data = { id: nextMockId(state.bankAccounts), ...account };
    state.bankAccounts.push(data);
    return NextResponse.json({
      data: {
        ...data,
        banco: state.banks.find((bank) => bank.id === data.banco_id)?.nombre ?? "",
        empresa: state.companies.find((company) => company.id === data.empresa_id)?.nombre_comercial ?? "",
        cuenta_contable: state.chartAccounts.find((chart) => chart.id === data.cuenta_contable_id)?.codigo ?? "",
        saldo_actual: getExpectedBankBalance(data, state.bankMovements),
        numero_cuenta: mask(data.numero_cuenta),
      },
    }, { status: 201 });
  }
  const companyId = getEmpresaId();
  if (account.empresa_id !== companyId) return NextResponse.json({ error: "La empresa seleccionada no coincide con la empresa configurada." }, { status: 400 });
  const pool = getDatabasePool();
  const references = await pool.query(
    `SELECT EXISTS (SELECT 1 FROM empresas WHERE id = $1 AND estado = 'ACTIVA') AS empresa_activa,
            EXISTS (SELECT 1 FROM bancos WHERE id = $2 AND estado = 'ACTIVO') AS banco_activo,
            EXISTS (SELECT 1 FROM monedas WHERE codigo = $4 AND estado = 'ACTIVA') AS moneda_valida,
            ($3::bigint IS NULL OR EXISTS (
              SELECT 1 FROM cuentas_contables
              WHERE id = $3 AND empresa_id = $1 AND estado = 'ACTIVA' AND acepta_movimientos = TRUE
            )) AS cuenta_contable_valida`,
    [companyId, account.banco_id, account.cuenta_contable_id, account.moneda],
  );
  const reference = references.rows[0];
  if (!reference.empresa_activa || !reference.banco_activo || !reference.moneda_valida || !reference.cuenta_contable_valida) {
    return NextResponse.json({ error: "Selecciona una empresa, banco y cuenta contable activos." }, { status: 400 });
  }
  try {
    const result = await pool.query(
      `INSERT INTO cuentas_bancarias
         (empresa_id, codigo, banco_id, banco, numero_cuenta, titular, tipo_cuenta, sucursal_bancaria,
          moneda, saldo_inicial, fecha_saldo_inicial, cuenta_contable_id, estado)
       SELECT $1, $2, banco.id, banco.nombre, $4, $5, $6, NULLIF($7, ''), $8, $9, $10, $11, $12
       FROM bancos AS banco
       WHERE banco.id = $3 AND banco.estado = 'ACTIVO'
       RETURNING id::text`,
      [companyId, account.codigo, account.banco_id, account.numero_cuenta, account.titular, account.tipo_cuenta,
        account.sucursal_bancaria, account.moneda, account.saldo_inicial, account.fecha_saldo_inicial,
        account.cuenta_contable_id, account.estado],
    );
    const created = await pool.query(`${ACCOUNT_SELECT}
      WHERE cuenta.id = $1 AND cuenta.empresa_id = $2
      GROUP BY cuenta.id, banco.nombre, empresa.nombre_comercial, plan.codigo, plan.nombre`,
      [Number(result.rows[0].id), companyId]);
    return NextResponse.json({ data: safeAccount(created.rows[0]) }, { status: 201 });
  } catch (error) {
    if (isUniqueViolation(error)) return NextResponse.json({ error: "Ya existe una cuenta con ese código en la empresa." }, { status: 409 });
    throw error;
  }
}
