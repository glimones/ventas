import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import { getMockTreasuryState } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    return NextResponse.json({
      data: {
        companies: state.companies,
        banks: state.banks.filter((bank) => bank.estado === "ACTIVO"),
        currencies: [...new Set(state.companies.map((company) => company.moneda_base))].map((codigo) => ({ codigo, nombre: codigo })),
        chartAccounts: state.chartAccounts.filter((account) => account.estado === "ACTIVA"),
      },
    });
  }
  const companyId = getEmpresaId();
  const pool = getDatabasePool();
  const [companies, banks, currencies, chartAccounts] = await Promise.all([
    pool.query(
      "SELECT id::text, nombre_comercial, moneda_base FROM empresas WHERE id = $1 AND estado = 'ACTIVA'",
      [companyId],
    ),
    pool.query("SELECT id::text, nombre, codigo FROM bancos WHERE estado = 'ACTIVO' ORDER BY nombre"),
    pool.query("SELECT codigo, nombre FROM monedas WHERE estado = 'ACTIVA' ORDER BY nombre"),
    pool.query(
      `SELECT id::text, empresa_id::text, codigo, nombre FROM cuentas_contables
       WHERE empresa_id = $1 AND estado = 'ACTIVA' AND acepta_movimientos = TRUE ORDER BY codigo`,
      [companyId],
    ),
  ]);
  return NextResponse.json({
    data: {
      companies: companies.rows.map((row) => ({ ...row, id: Number(row.id) })),
      banks: banks.rows.map((row) => ({ ...row, id: Number(row.id) })),
      currencies: currencies.rows,
      chartAccounts: chartAccounts.rows.map((row) => ({ ...row, id: Number(row.id), empresa_id: Number(row.empresa_id) })),
    },
  });
}
