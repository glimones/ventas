import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import { getExpectedBankBalance, getMockTreasuryState, type TreasuryBankAccount } from "@/lib/mock-treasury";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };
type AccountInput = Omit<TreasuryBankAccount, "id">;

function isUniqueViolation(error: unknown) {
  return typeof error === "object" && error !== null && "code" in error && error.code === "23505";
}

function validId(value: string) {
  const id = Number(value);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

function parseAccount(body: unknown): AccountInput | null {
  if (!body || typeof body !== "object" || Array.isArray(body)) return null;
  const input = body as Record<string, unknown>;
  const empresaId = Number(input.empresa_id);
  const bancoId = Number(input.banco_id);
  const chartId = input.cuenta_contable_id === "" || input.cuenta_contable_id === null || input.cuenta_contable_id === undefined
    ? null : Number(input.cuenta_contable_id);
  const codigo = typeof input.codigo === "string" ? input.codigo.trim().toUpperCase() : "";
  const numero = typeof input.numero_cuenta === "string" ? input.numero_cuenta.trim() : "";
  const titular = typeof input.titular === "string" ? input.titular.trim() : "";
  const tipo = typeof input.tipo_cuenta === "string" ? input.tipo_cuenta.trim().toUpperCase() : "";
  const branch = typeof input.sucursal_bancaria === "string" ? input.sucursal_bancaria.trim() : "";
  const moneda = typeof input.moneda === "string" ? input.moneda.trim().toUpperCase() : "";
  const fecha = typeof input.fecha_saldo_inicial === "string" ? input.fecha_saldo_inicial.trim() : "";
  const saldo = Number(input.saldo_inicial);
  const estado = String(input.estado ?? "ACTIVA").toUpperCase() === "INACTIVA" ? "INACTIVA" : "ACTIVA";
  if (!Number.isSafeInteger(empresaId) || empresaId <= 0 || !Number.isSafeInteger(bancoId) || bancoId <= 0 ||
      (chartId !== null && (!Number.isSafeInteger(chartId) || chartId <= 0)) ||
      !codigo || codigo.length > 30 || numero.length > 80 || !titular || titular.length > 160 ||
      !["CORRIENTE", "AHORROS", "OTRA"].includes(tipo) || branch.length > 120 || !/^[A-Z]{3}$/.test(moneda) ||
      !/^\d{4}-\d{2}-\d{2}$/.test(fecha) || !Number.isFinite(saldo) || saldo < 0) return null;
  return {
    empresa_id: empresaId, banco_id: bancoId, codigo, numero_cuenta: numero, titular,
    tipo_cuenta: tipo, sucursal_bancaria: branch, moneda, fecha_saldo_inicial: fecha,
    saldo_inicial: saldo, cuenta_contable_id: chartId, estado,
  };
}

function mask(number: string) {
  return `**** ${number.slice(-4)}`;
}

function safeAccount(row: Record<string, unknown>) {
  return {
    ...row,
    numero_cuenta: mask(String(row.numero_cuenta ?? "")),
    id: Number(row.id),
    empresa_id: Number(row.empresa_id),
    banco_id: Number(row.banco_id),
    cuenta_contable_id: row.cuenta_contable_id === null ? null : Number(row.cuenta_contable_id),
    saldo_inicial: Number(row.saldo_inicial ?? 0),
    saldo_actual: Number(row.saldo_actual ?? row.saldo_inicial ?? 0),
    estado: String(row.estado ?? ""),
  };
}

const ACCOUNT_SELECT = `
  SELECT cuenta.id::text, cuenta.empresa_id::text, cuenta.banco_id::text, cuenta.codigo,
         cuenta.numero_cuenta, cuenta.titular, cuenta.tipo_cuenta, cuenta.sucursal_bancaria,
         cuenta.moneda, to_char(cuenta.fecha_saldo_inicial, 'YYYY-MM-DD') AS fecha_saldo_inicial,
         cuenta.saldo_inicial, cuenta.cuenta_contable_id::text, cuenta.estado,
         banco.nombre AS banco, empresa.nombre_comercial AS empresa,
         plan.codigo || ' - ' || plan.nombre AS cuenta_contable,
         cuenta.saldo_inicial + COALESCE(SUM(
           CASE WHEN movimiento.tipo IN ('INGRESO', 'DEPOSITO', 'ABONO') THEN movimiento.importe
                WHEN movimiento.tipo IN ('EGRESO', 'CHEQUE', 'PAGO') THEN -movimiento.importe
                ELSE 0 END
         ), 0) AS saldo_actual
  FROM cuentas_bancarias AS cuenta
  JOIN bancos AS banco ON banco.id = cuenta.banco_id
  JOIN empresas AS empresa ON empresa.id = cuenta.empresa_id
  LEFT JOIN cuentas_contables AS plan
    ON plan.id = cuenta.cuenta_contable_id AND plan.empresa_id = cuenta.empresa_id
  LEFT JOIN movimientos_tesoreria AS movimiento
    ON movimiento.cuenta_bancaria_id = cuenta.id
   AND movimiento.fecha::date >= cuenta.fecha_saldo_inicial
`;

export async function PUT(request: NextRequest, context: RouteContext) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = validId((await context.params).id);
  if (id === null) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  const account = parseAccount(body);
  if (!account) return NextResponse.json({ error: "Revisa empresa, banco, código, titular, moneda, fecha y saldo inicial." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const index = state.bankAccounts.findIndex((item) => item.id === id);
    if (index < 0) return NextResponse.json({ error: "Cuenta bancaria no encontrada." }, { status: 404 });
    const current = state.bankAccounts[index];
    if (!account.numero_cuenta) account.numero_cuenta = current.numero_cuenta;
    if (!state.companies.some((company) => company.id === account.empresa_id) ||
        !state.banks.some((bank) => bank.id === account.banco_id && bank.estado === "ACTIVO") ||
        (account.cuenta_contable_id !== null && !state.chartAccounts.some((chart) => chart.id === account.cuenta_contable_id && chart.empresa_id === account.empresa_id && chart.estado === "ACTIVA"))) {
      return NextResponse.json({ error: "Selecciona una empresa, banco y cuenta contable activos." }, { status: 400 });
    }
    if (state.bankAccounts.some((item) => item.id !== id && item.empresa_id === account.empresa_id && item.codigo.toLocaleLowerCase() === account.codigo.toLocaleLowerCase())) {
      return NextResponse.json({ error: "Ya existe una cuenta con ese código en la empresa." }, { status: 409 });
    }
    state.bankAccounts[index] = { id, ...account };
    return NextResponse.json({
      data: {
        ...state.bankAccounts[index],
        banco: state.banks.find((bank) => bank.id === account.banco_id)?.nombre ?? "",
        empresa: state.companies.find((company) => company.id === account.empresa_id)?.nombre_comercial ?? "",
        saldo_actual: getExpectedBankBalance(state.bankAccounts[index], state.bankMovements),
        numero_cuenta: mask(state.bankAccounts[index].numero_cuenta),
      },
    });
  }
  const companyId = getEmpresaId();
  if (account.empresa_id !== companyId) return NextResponse.json({ error: "La empresa seleccionada no coincide con la empresa configurada." }, { status: 400 });
  const pool = getDatabasePool();
  const references = await pool.query(
    `SELECT EXISTS (SELECT 1 FROM bancos WHERE id = $1 AND estado = 'ACTIVO') AS banco_activo,
            EXISTS (SELECT 1 FROM monedas WHERE codigo = $3 AND estado = 'ACTIVA') AS moneda_valida,
            ($2::bigint IS NULL OR EXISTS (
              SELECT 1 FROM cuentas_contables
              WHERE id = $2 AND empresa_id = $4 AND estado = 'ACTIVA' AND acepta_movimientos = TRUE
            )) AS cuenta_contable_valida`,
    [account.banco_id, account.cuenta_contable_id, account.moneda, companyId],
  );
  if (!references.rows[0].banco_activo || !references.rows[0].moneda_valida || !references.rows[0].cuenta_contable_valida) {
    return NextResponse.json({ error: "Selecciona un banco, moneda y cuenta contable activos." }, { status: 400 });
  }
  try {
    const result = await pool.query(
      `UPDATE cuentas_bancarias AS cuenta
       SET codigo = $3, banco_id = $4, banco = banco_catalogo.nombre,
           numero_cuenta = CASE WHEN $5 = '' THEN cuenta.numero_cuenta ELSE $5 END,
           titular = $6, tipo_cuenta = $7, sucursal_bancaria = NULLIF($8, ''),
           moneda = $9, saldo_inicial = $10, fecha_saldo_inicial = $11,
           cuenta_contable_id = $12, estado = $13
       FROM bancos AS banco_catalogo
       WHERE cuenta.id = $1 AND cuenta.empresa_id = $2
         AND banco_catalogo.id = $4 AND banco_catalogo.estado = 'ACTIVO'
       RETURNING cuenta.id`,
      [id, companyId, account.codigo, account.banco_id, account.numero_cuenta, account.titular,
        account.tipo_cuenta, account.sucursal_bancaria, account.moneda, account.saldo_inicial,
        account.fecha_saldo_inicial, account.cuenta_contable_id, account.estado],
    );
    if (!result.rowCount) return NextResponse.json({ error: "Cuenta bancaria no encontrada." }, { status: 404 });
    const updated = await pool.query(`${ACCOUNT_SELECT}
      WHERE cuenta.id = $1 AND cuenta.empresa_id = $2
      GROUP BY cuenta.id, banco.nombre, empresa.nombre_comercial, plan.codigo, plan.nombre`,
      [id, companyId]);
    return NextResponse.json({ data: safeAccount(updated.rows[0]) });
  } catch (error) {
    if (isUniqueViolation(error)) return NextResponse.json({ error: "Ya existe una cuenta con ese código en la empresa." }, { status: 409 });
    throw error;
  }
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  if (!await getActiveAccessClaims(request)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const id = validId((await context.params).id);
  if (id === null) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  if (isMockAuthEnabled()) {
    const account = getMockTreasuryState().bankAccounts.find((item) => item.id === id);
    if (!account) return NextResponse.json({ error: "Cuenta bancaria no encontrada." }, { status: 404 });
    account.estado = "INACTIVA";
    return NextResponse.json({ data: { id: account.id, codigo: account.codigo, estado: account.estado } });
  }
  const result = await getDatabasePool().query(
    `UPDATE cuentas_bancarias SET estado = 'INACTIVA'
     WHERE id = $1 AND empresa_id = $2
     RETURNING id::text, codigo, estado`,
    [id, getEmpresaId()],
  );
  return result.rowCount
    ? NextResponse.json({ data: { ...result.rows[0], id: Number(result.rows[0].id) } })
    : NextResponse.json({ error: "Cuenta bancaria no encontrada." }, { status: 404 });
}
