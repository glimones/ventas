import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getDatabasePool } from "@/lib/db";
import { getMockCompanyId, getMockTreasuryState, nextMockId, type TreasuryCheck } from "@/lib/mock-treasury";
import { parseCheck } from "@/lib/tesoreria-documentos";
import { hasRoutePermission } from "@/lib/route-permissions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function actorId(claims: { sub: string; empresaId: number }) {
  const parsed = Number(claims.sub);
  if (Number.isSafeInteger(parsed) && parsed > 0) return parsed;
  if (isMockAuthEnabled()) {
    const companyId = getMockCompanyId(claims.empresaId);
    return getMockTreasuryState().users.find((user) => user.empresa_id === companyId)?.id ?? null;
  }
  return null;
}

function mockView(check: TreasuryCheck) {
  const state = getMockTreasuryState();
  const account = state.bankAccounts.find((item) => item.id === check.cuenta_bancaria_id);
  const bank = account && state.banks.find((item) => item.id === account.banco_id);
  return {
    ...check,
    cuenta: account ? `${bank?.nombre ?? ""} · ${account.codigo} · **** ${account.numero_cuenta.slice(-4)}` : "",
    responsable: state.users.find((item) => item.id === check.responsable_id)?.nombre ?? "",
    moneda: account?.moneda ?? "USD",
  };
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!hasRoutePermission(claims, "/cheques", 1)) return NextResponse.json({ error: "No tienes permiso para consultar cheques." }, { status: 403 });
  if (isMockAuthEnabled()) {
    const companyId = getMockCompanyId(claims.empresaId);
    return NextResponse.json({
      data: getMockTreasuryState().checks
        .filter((check) => check.empresa_id === companyId)
        .map(mockView),
    });
  }

  const result = await getDatabasePool().query(
    `SELECT cheque.id::text, cheque.empresa_id::text, cheque.numero_cheque,
            cheque.cuenta_bancaria_id::text, cheque.beneficiario,
            to_char(cheque.fecha_emision, 'YYYY-MM-DD') AS fecha_emision,
            COALESCE(to_char(cheque.fecha_cobro, 'YYYY-MM-DD'), '') AS fecha_cobro,
            cheque.importe, cheque.concepto, COALESCE(cheque.referencia, '') AS referencia,
            cheque.comprobante_base64, cheque.comprobante_mime_type,
            cheque.cheque_base64, cheque.cheque_mime_type, cheque.responsable_id::text,
            responsable.nombre AS responsable, cheque.estado,
            banco.nombre || ' · ' || cuenta.codigo || ' · ' ||
              CASE WHEN LENGTH(cuenta.numero_cuenta) > 4
                   THEN '**** ' || RIGHT(cuenta.numero_cuenta, 4)
                   ELSE '****' END AS cuenta,
            cuenta.moneda
     FROM cheques_emitidos AS cheque
     JOIN cuentas_bancarias AS cuenta
       ON cuenta.id = cheque.cuenta_bancaria_id AND cuenta.empresa_id = cheque.empresa_id
     JOIN bancos AS banco ON banco.id = cuenta.banco_id
     LEFT JOIN usuarios AS responsable
       ON responsable.id = cheque.responsable_id AND responsable.empresa_id = cheque.empresa_id
     WHERE cheque.empresa_id = $1
     ORDER BY cheque.fecha_emision DESC, cheque.id DESC`,
    [claims.empresaId],
  );
  return NextResponse.json({
    data: result.rows.map((row) => ({
      ...row,
      id: Number(row.id),
      empresa_id: Number(row.empresa_id),
      cuenta_bancaria_id: Number(row.cuenta_bancaria_id),
      responsable_id: Number(row.responsable_id),
      importe: Number(row.importe),
      comprobante_base64: String(row.comprobante_base64 ?? ""),
      cheque_base64: String(row.cheque_base64 ?? ""),
    })),
  });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  if (!hasRoutePermission(claims, "/cheques", 2)) return NextResponse.json({ error: "No tienes permiso para registrar cheques." }, { status: 403 });
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  const input = parseCheck(body);
  if (!input) {
    return NextResponse.json({
      error: "Revisa los datos del cheque. Adjunta el cheque y su comprobante en PNG, JPG o WebP de hasta 5 MB cada uno.",
    }, { status: 400 });
  }
  const responsibleId = actorId(claims);
  const companyId = isMockAuthEnabled() ? getMockCompanyId(claims.empresaId) : claims.empresaId;
  if (!responsibleId) return NextResponse.json({ error: "No se pudo identificar al responsable activo." }, { status: 400 });

  if (isMockAuthEnabled()) {
    const state = getMockTreasuryState();
    const account = state.bankAccounts.find((item) =>
      item.id === input.cuenta_bancaria_id && item.empresa_id === companyId && item.estado === "ACTIVA");
    const bank = account && state.banks.find((item) => item.id === account.banco_id);
    if (!account || bank?.estado !== "ACTIVO" || !state.users.some((item) =>
      item.id === responsibleId && item.empresa_id === companyId)) {
      return NextResponse.json({ error: "Selecciona una cuenta bancaria activa de tu empresa." }, { status: 400 });
    }
    if (state.checks.some((item) =>
      item.cuenta_bancaria_id === account.id && item.numero_cheque === input.numero_cheque)) {
      return NextResponse.json({ error: "Ese número de cheque ya está registrado para la cuenta." }, { status: 409 });
    }
    const created: TreasuryCheck = {
      id: nextMockId(state.checks),
      empresa_id: companyId,
      ...input,
      fecha_cobro: input.fecha_cobro ?? "",
      responsable_id: responsibleId,
      estado: "PENDIENTE",
    };
    state.checks.push(created);
    state.bankMovements.push({
      id: nextMockId(state.bankMovements),
      cuenta_bancaria_id: account.id,
      tipo: "CHEQUE",
      importe: input.importe,
      fecha: input.fecha_emision,
      concepto: input.concepto,
      referencia: input.numero_cheque,
    });
    return NextResponse.json({ data: mockView(created) }, { status: 201 });
  }

  const client = await getDatabasePool().connect();
  let transactionOpen = false;
  try {
    await client.query("BEGIN");
    transactionOpen = true;
    const account = await client.query<{ id: string }>(
      `SELECT cuenta.id::text
       FROM cuentas_bancarias AS cuenta
       JOIN bancos AS banco ON banco.id = cuenta.banco_id AND banco.estado = 'ACTIVO'
       WHERE cuenta.id = $1 AND cuenta.empresa_id = $2 AND cuenta.estado = 'ACTIVA'
       FOR UPDATE OF cuenta`,
      [input.cuenta_bancaria_id, claims.empresaId],
    );
    if (!account.rows[0]) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "Selecciona una cuenta bancaria activa de tu empresa." }, { status: 400 });
    }
    const user = await client.query(
      "SELECT id FROM usuarios WHERE id = $1 AND empresa_id = $2 AND estado = 'ACTIVO'",
      [responsibleId, claims.empresaId],
    );
    if (!user.rows[0]) {
      await client.query("ROLLBACK");
      transactionOpen = false;
      return NextResponse.json({ error: "El responsable debe estar activo y pertenecer a la empresa." }, { status: 400 });
    }
    const inserted = await client.query<{ id: string }>(
      `INSERT INTO cheques_emitidos
         (empresa_id, numero_cheque, cuenta_bancaria_id, beneficiario, fecha_emision,
          fecha_cobro, importe, concepto, referencia, comprobante_base64,
          comprobante_mime_type, cheque_base64, cheque_mime_type, responsable_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NULLIF($9, ''),
               $10, $11, $12, $13, $14)
       RETURNING id::text`,
      [companyId, input.numero_cheque, input.cuenta_bancaria_id, input.beneficiario,
        input.fecha_emision, input.fecha_cobro, input.importe, input.concepto, input.referencia,
        input.comprobante_base64, input.comprobante_mime_type, input.cheque_base64,
        input.cheque_mime_type, responsibleId],
    );
    await client.query(
      `INSERT INTO movimientos_tesoreria
         (empresa_id, cuenta_bancaria_id, tipo, fecha, concepto, referencia,
          importe, documento_tipo, documento_id, usuario_id)
       VALUES ($1, $2, 'CHEQUE', $3::date, $4, $5, $6, 'CHEQUE', $7, $8)`,
      [companyId, input.cuenta_bancaria_id, input.fecha_emision, input.concepto,
        input.numero_cheque, input.importe, inserted.rows[0].id, responsibleId],
    );
    await client.query("COMMIT");
    transactionOpen = false;
    const saved = await getDatabasePool().query(
      `SELECT cheque.id::text, cheque.empresa_id::text, cheque.numero_cheque,
              cheque.cuenta_bancaria_id::text, cheque.beneficiario,
              to_char(cheque.fecha_emision, 'YYYY-MM-DD') AS fecha_emision,
              COALESCE(to_char(cheque.fecha_cobro, 'YYYY-MM-DD'), '') AS fecha_cobro,
              cheque.importe, cheque.concepto, COALESCE(cheque.referencia, '') AS referencia,
              cheque.comprobante_base64, cheque.comprobante_mime_type,
              cheque.cheque_base64, cheque.cheque_mime_type,
              cheque.responsable_id::text, responsable.nombre AS responsable, cheque.estado,
              banco.nombre || ' · ' || cuenta.codigo || ' · ' ||
                CASE WHEN LENGTH(cuenta.numero_cuenta) > 4
                     THEN '**** ' || RIGHT(cuenta.numero_cuenta, 4)
                     ELSE '****' END AS cuenta,
              cuenta.moneda
       FROM cheques_emitidos AS cheque
       JOIN cuentas_bancarias AS cuenta ON cuenta.id = cheque.cuenta_bancaria_id
       JOIN bancos AS banco ON banco.id = cuenta.banco_id
       LEFT JOIN usuarios AS responsable ON responsable.id = cheque.responsable_id
       WHERE cheque.id = $1 AND cheque.empresa_id = $2`,
      [inserted.rows[0].id, companyId],
    );
    const row = saved.rows[0];
    return NextResponse.json({
      data: {
        ...row,
        id: Number(row.id),
        empresa_id: Number(row.empresa_id),
        cuenta_bancaria_id: Number(row.cuenta_bancaria_id),
        responsable_id: Number(row.responsable_id),
        importe: Number(row.importe),
      },
    }, { status: 201 });
  } catch (error) {
    if (transactionOpen) await client.query("ROLLBACK");
    if (typeof error === "object" && error !== null && "code" in error && error.code === "23505") {
      return NextResponse.json({ error: "Ese número de cheque ya está registrado para la cuenta." }, { status: 409 });
    }
    throw error;
  } finally {
    client.release();
  }
}
