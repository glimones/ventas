(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["chunks/[root-of-the-server]__0ebc0521._.js",
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[project]/src/lib/auth-mode.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getAuthSecret",
    ()=>getAuthSecret,
    "isMockAuthEnabled",
    ()=>isMockAuthEnabled
]);
const LOCAL_MOCK_AUTH_SECRET = "glm-local-mock-auth-secret-only-for-development";
function isMockAuthEnabled() {
    return ("TURBOPACK compile-time value", "development") !== "production" && !process.env.DATABASE_URL;
}
function getAuthSecret() {
    const configuredSecret = process.env.AUTH_SECRET;
    if (configuredSecret) return configuredSecret.length >= 32 ? configuredSecret : null;
    return isMockAuthEnabled() ? LOCAL_MOCK_AUTH_SECRET : null;
}
}),
"[project]/middleware.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "config",
    ()=>config,
    "middleware",
    ()=>middleware
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$mode$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-mode.ts [middleware-edge] (ecmascript)");
;
;
function decodeBase64Url(value) {
    const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
    const binary = atob(base64.padEnd(Math.ceil(base64.length / 4) * 4, "="));
    return Uint8Array.from(binary, (character)=>character.charCodeAt(0));
}
async function readClaims(request) {
    const token = request.cookies.get("ventas_session")?.value;
    const secret = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$mode$2e$ts__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["getAuthSecret"])();
    if (!token || !secret) return null;
    const [payload, signature, extra] = token.split(".");
    if (!payload || !signature || extra) return null;
    try {
        const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), {
            name: "HMAC",
            hash: "SHA-256"
        }, false, [
            "verify"
        ]);
        const valid = await crypto.subtle.verify("HMAC", key, decodeBase64Url(signature), new TextEncoder().encode(payload));
        if (!valid) return null;
        const claims = JSON.parse(new TextDecoder().decode(decodeBase64Url(payload)));
        return Number.isSafeInteger(claims.exp) && claims.exp > Math.floor(Date.now() / 1000) && claims.permissions !== null && typeof claims.permissions === "object" ? claims : null;
    } catch  {
        return null;
    }
}
function getPermissionRoute(pathname) {
    if (pathname.startsWith("/api/")) {
        let route = pathname.slice(4);
        if (route === "/clientes" || route.startsWith("/clientes/")) route = `/cliente${route.slice("/clientes".length)}`;
        if (route === "/empresas" || route.startsWith("/empresas/")) route = `/empresa${route.slice("/empresas".length)}`;
        if (route.startsWith("/seguridad/roles/")) route = "/seguridad/permisos-usuarios";
        if (route.startsWith("/seguridad/usuarios/")) route = "/seguridad/usuarios";
        if (route.startsWith("/compras/")) route = "/solicitudes-compra";
        return route;
    }
    return pathname;
}
function getAction(method) {
    if (method === "GET" || method === "HEAD") return 1;
    if (method === "DELETE") return 4;
    return 2;
}
function hasPermission(claims, route, action) {
    if (((claims.permissions["*"] ?? 0) & action) === action) return true;
    let bestMatch = "";
    for (const candidate of Object.keys(claims.permissions)){
        if ((route === candidate || route.startsWith(`${candidate}/`)) && candidate.length > bestMatch.length) {
            bestMatch = candidate;
        }
    }
    return bestMatch.length > 0 && (claims.permissions[bestMatch] & action) === action;
}
async function middleware(request) {
    const { pathname } = request.nextUrl;
    if (pathname === "/login" || pathname.startsWith("/sitio/") || pathname.startsWith("/api/clientes-web/") || pathname === "/api/auth/login" || pathname === "/api/auth/logout" || pathname === "/api/auth/session" || pathname === "/api/auth/mode" || pathname === "/api/menu") return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    const claims = await readClaims(request);
    if (!claims) {
        if (pathname.startsWith("/api/")) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Se requiere iniciar sesión."
            }, {
                status: 401
            });
        }
        const login = new URL("/login", request.url);
        login.searchParams.set("next", pathname);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].redirect(login);
    }
    if (pathname === "/") return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    if (pathname === "/seguridad" && (claims.permissions["*"] !== undefined || Object.keys(claims.permissions).some((route)=>route.startsWith("/seguridad/")))) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    }
    const route = getPermissionRoute(pathname);
    if (!hasPermission(claims, route, getAction(request.method))) {
        if (pathname.startsWith("/api/")) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "No tienes permiso para realizar esta acción."
            }, {
                status: 403
            });
        }
        return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"]("No tienes permiso para acceder a esta opción.", {
            status: 403
        });
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
}
const config = {
    matcher: [
        "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:png|jpg|jpeg|gif|svg|ico|css|js)$).*)"
    ]
};
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__0ebc0521._.js.map