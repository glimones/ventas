(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_693366d6._.js",
  "static/chunks/node_modules_976fa8f2._.js"
],
    source: "dynamic"
});
