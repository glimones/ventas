(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_890fc129._.js",
  "static/chunks/src_a4d05e0a._.js",
  "static/chunks/src_app_login_login_33d5c297.css"
],
    source: "dynamic"
});
