// Servicio universal para integración con SRI Ecuador - Todos los comprobantes electrónicos
export interface ComprobanteElectronico {
  id: number;
  tipo_comprobante: '01' | '03' | '04' | '05' | '06' | '07'; // 01=Factura, 03=Liquidación, 04=Nota Crédito, 05=Nota Débito, 06=Guía Remisión, 07=Comprobante Retención
  info_tributaria: InfoTributaria;
  estado_sri: 'PENDIENTE' | 'AUTORIZADA' | 'RECHAZADA' | 'DEVUELTA';
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  xml_generado?: string;
  observaciones_sri?: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
}

export interface InfoTributaria {
  ambiente: string; // 1 = Pruebas, 2 = Producción
  tipo_emision: string; // 1 = Emisión normal
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  clave_acceso: string;
  cod_doc: string; // Código del documento
  estab: string; // Establecimiento
  ptoEmi: string; // Punto de emisión
  secuencial: string;
  direccion_matriz: string;
}

export interface RespuestaSRI {
  success: boolean;
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  estado: 'AUTORIZADA' | 'RECHAZADA' | 'DEVUELTA';
  xml_autorizado?: string;
  observaciones?: string;
  codigo_error?: string;
  mensaje_error?: string;
}

export interface CertificadoP12 {
  archivo: string; // Base64 del archivo P12
  password: string;
  propietario: string;
  vigencia_desde: string;
  vigencia_hasta: string;
  numero_serie: string;
}

export class SRIUniversalService {
  private static instance: SRIUniversalService;
  private readonly URL_SRI_RECEPCION = 'https://celcer.sri.gob.ec/comprobantes-electronicos-ws/RecepcionComprobantesOffline?wsdl';
  private readonly URL_SRI_AUTORIZACION = 'https://celcer.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline?wsdl';

  // Certificado P12 simulado para desarrollo
  private readonly certificadoP12Simulado: CertificadoP12 = {
    archivo: "MIIKoQIBAzCCCmcGCSqGSIb3DQEHAaCCClgEggpUMIIKUDCCBW...", // Base64 simulado
    password: "password123",
    propietario: "EMPRESA DEMO S.A.",
    vigencia_desde: "2024-01-01",
    vigencia_hasta: "2026-12-31",
    numero_serie: "1234567890123456789"
  };

  public static getInstance(): SRIUniversalService {
    if (!SRIUniversalService.instance) {
      SRIUniversalService.instance = new SRIUniversalService();
    }
    return SRIUniversalService.instance;
  }

  /**
   * Genera una clave de acceso de 49 dígitos según las especificaciones del SRI
   */
  private generarClaveAcceso(fecha: string, tipoComprobante: string, ruc: string, ambiente: string, establecimiento: string, puntoEmision: string, secuencial: string): string {
    // Formato: ddmmaaaa + tipo_comprobante + ruc + ambiente + serie + numero_comprobante + codigo_numerico + tipo_emision
    const fechaFormateada = fecha.split('/').reverse().join(''); // DDMMAAAA
    const codigoNumerico = Math.floor(Math.random() * 99999999).toString().padStart(8, '0');
    const tipoEmision = '1'; // Emisión normal
    
    const claveBase = fechaFormateada + tipoComprobante + ruc + ambiente + establecimiento + puntoEmision + secuencial.padStart(9, '0') + codigoNumerico + tipoEmision;
    
    // Calcular dígito verificador usando módulo 11
    const digitoVerificador = this.calcularDigitoVerificador(claveBase);
    
    return claveBase + digitoVerificador;
  }

  /**
   * Calcula el dígito verificador usando módulo 11
   */
  private calcularDigitoVerificador(clave: string): string {
    const factores = [2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7];
    let suma = 0;
    
    for (let i = 0; i < clave.length; i++) {
      suma += parseInt(clave[i]) * factores[i];
    }
    
    const residuo = suma % 11;
    const digitoVerificador = residuo < 2 ? residuo : 11 - residuo;
    
    return digitoVerificador.toString();
  }

  /**
   * Simula la firma electrónica con certificado P12
   */
  private async firmarXMLConP12(xml: string, tipoComprobante: string): Promise<string> {
    // Simular validación del certificado P12
    console.log('🔐 Validando certificado P12...');
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const ahora = new Date();
    const vigenciaDesde = new Date(this.certificadoP12Simulado.vigencia_desde);
    const vigenciaHasta = new Date(this.certificadoP12Simulado.vigencia_hasta);
    
    if (ahora < vigenciaDesde || ahora > vigenciaHasta) {
      throw new Error('Certificado P12 expirado o no válido');
    }

    console.log(`📋 Firmando ${this.getNombreComprobante(tipoComprobante)} con certificado P12...`);
    console.log(`👤 Propietario: ${this.certificadoP12Simulado.propietario}`);
    console.log(`🔢 Serie: ${this.certificadoP12Simulado.numero_serie}`);
    
    // Simular tiempo de firma
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Agregar firma digital simulada al XML
    const xmlFirmado = xml.replace(
      `</${this.getTagComprobante(tipoComprobante)}>`,
      `  <!-- Firma electrónica P12 -->\n  <ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Id="Signature">\n    <ds:SignedInfo>\n      <ds:CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>\n      <ds:SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>\n      <ds:Reference URI="">\n        <ds:Transforms>\n          <ds:Transform Algorithm="http://www.w3.org/2000/09/xmldsig#enveloped-signature"/>\n        </ds:Transforms>\n        <ds:DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>\n        <ds:DigestValue>SIMULADO_DIGEST_VALUE</ds:DigestValue>\n      </ds:Reference>\n    </ds:SignedInfo>\n    <ds:SignatureValue>SIMULADO_SIGNATURE_VALUE_P12_${this.certificadoP12Simulado.numero_serie}</ds:SignatureValue>\n    <ds:KeyInfo>\n      <ds:X509Data>\n        <ds:X509Certificate>SIMULADO_CERTIFICATE_VALUE</ds:X509Certificate>\n      </ds:X509Data>\n    </ds:KeyInfo>\n  </ds:Signature>\n</${this.getTagComprobante(tipoComprobante)}>`
    );
    
    return xmlFirmado;
  }

  /**
   * Obtiene el tag raíz del XML según el tipo de comprobante
   */
  private getTagComprobante(tipoComprobante: string): string {
    switch (tipoComprobante) {
      case '01': return 'factura';
      case '03': return 'liquidacionCompra';
      case '04': return 'notaCredito';
      case '05': return 'notaDebito';
      case '06': return 'guiaRemision';
      case '07': return 'comprobanteRetencion';
      default: return 'comprobante';
    }
  }

  /**
   * Obtiene el nombre del comprobante según el tipo
   */
  private getNombreComprobante(tipoComprobante: string): string {
    switch (tipoComprobante) {
      case '01': return 'Factura';
      case '03': return 'Liquidación de Compra';
      case '04': return 'Nota de Crédito';
      case '05': return 'Nota de Débito';
      case '06': return 'Guía de Remisión';
      case '07': return 'Comprobante de Retención';
      default: return 'Comprobante';
    }
  }

  /**
   * Genera XML base para cualquier tipo de comprobante
   */
  public generarXMLComprobante(comprobante: ComprobanteElectronico, datosEspecificos: string, fecha: string): string {
    const claveAcceso = this.generarClaveAcceso(
      fecha,
      comprobante.tipo_comprobante,
      comprobante.info_tributaria.ruc,
      comprobante.info_tributaria.ambiente,
      comprobante.info_tributaria.estab,
      comprobante.info_tributaria.ptoEmi,
      comprobante.info_tributaria.secuencial
    );

    // Actualizar la clave de acceso en el comprobante
    comprobante.info_tributaria.clave_acceso = claveAcceso;

    const tagComprobante = this.getTagComprobante(comprobante.tipo_comprobante);
    
    return `<?xml version="1.0" encoding="UTF-8"?>
<${tagComprobante} id="comprobante" version="1.1.0">
  <infoTributaria>
    <ambiente>${comprobante.info_tributaria.ambiente}</ambiente>
    <tipoEmision>${comprobante.info_tributaria.tipo_emision}</tipoEmision>
    <razonSocial><![CDATA[${comprobante.info_tributaria.razon_social}]]></razonSocial>
    <nombreComercial><![CDATA[${comprobante.info_tributaria.nombre_comercial}]]></nombreComercial>
    <ruc>${comprobante.info_tributaria.ruc}</ruc>
    <claveAcceso>${claveAcceso}</claveAcceso>
    <codDoc>${comprobante.info_tributaria.cod_doc}</codDoc>
    <estab>${comprobante.info_tributaria.estab}</estab>
    <ptoEmi>${comprobante.info_tributaria.ptoEmi}</ptoEmi>
    <secuencial>${comprobante.info_tributaria.secuencial}</secuencial>
    <dirMatriz><![CDATA[${comprobante.info_tributaria.direccion_matriz}]]></dirMatriz>
  </infoTributaria>
  ${datosEspecificos}
</${tagComprobante}>`;
  }

  /**
   * Envía cualquier comprobante electrónico al SRI
   */
  public async enviarComprobanteSRI(comprobante: ComprobanteElectronico, datosEspecificos: string, fecha: string): Promise<RespuestaSRI> {
    try {
      const nombreComprobante = this.getNombreComprobante(comprobante.tipo_comprobante);
      console.log(`🚀 Iniciando proceso de envío ${nombreComprobante} al SRI...`);
      
      // Paso 1: Generar XML
      console.log(`📄 Generando XML del ${nombreComprobante}...`);
      const xml = this.generarXMLComprobante(comprobante, datosEspecificos, fecha);
      
      // Paso 2: Firmar XML con P12
      console.log(`✍️ Firmando electrónicamente el XML con certificado P12...`);
      const xmlFirmado = await this.firmarXMLConP12(xml, comprobante.tipo_comprobante);
      
      // Paso 3: Validaciones básicas
      console.log(`🔍 Validando estructura del ${nombreComprobante}...`);
      const validacion = this.validarComprobante(comprobante);
      if (!validacion.valida) {
        return {
          success: false,
          estado: 'RECHAZADA',
          codigo_error: '70',
          mensaje_error: validacion.errores.join(', '),
          observaciones: `${nombreComprobante} rechazado por errores de validación`
        };
      }
      
      // Paso 4: Simular envío a SRI (recepción)
      console.log(`📤 Enviando ${nombreComprobante} al SRI...`);
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Paso 5: Simular proceso de autorización
      console.log(`⏳ Procesando autorización...`);
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simular diferentes escenarios de respuesta
      const probabilidadExito = 0.85; // 85% de probabilidad de éxito
      const random = Math.random();
      
      if (random < probabilidadExito) {
        // Autorizada
        const numeroAutorizacion = this.generarNumeroAutorizacion();
        const fechaAutorizacion = new Date().toISOString();
        
        console.log(`✅ ${nombreComprobante} autorizado exitosamente`);
        
        return {
          success: true,
          numero_autorizacion: numeroAutorizacion,
          fecha_autorizacion: fechaAutorizacion,
          estado: 'AUTORIZADA',
          xml_autorizado: xmlFirmado,
          observaciones: `${nombreComprobante} autorizado correctamente`
        };
      } else if (random < 0.95) {
        // Devuelta (errores menores)
        console.log(`⚠️ ${nombreComprobante} devuelto por observaciones`);
        
        return {
          success: false,
          estado: 'DEVUELTA',
          codigo_error: '43',
          mensaje_error: 'CLAVE DE ACCESO REGISTRADA',
          observaciones: `El ${nombreComprobante} fue devuelto. Corrija los errores y reenvíe.`
        };
      } else {
        // Rechazada (errores graves)
        console.log(`❌ ${nombreComprobante} rechazado`);
        
        return {
          success: false,
          estado: 'RECHAZADA',
          codigo_error: '70',
          mensaje_error: 'ESTRUCTURA DEL COMPROBANTE ERRONEA',
          observaciones: `El ${nombreComprobante} contiene errores estructurales graves.`
        };
      }
      
    } catch (error) {
      console.error('💥 Error en el proceso de envío al SRI:', error);
      
      return {
        success: false,
        estado: 'RECHAZADA',
        codigo_error: '999',
        mensaje_error: error instanceof Error ? error.message : 'Error interno del sistema',
        observaciones: 'Ocurrió un error inesperado durante el procesamiento.'
      };
    }
  }

  /**
   * Genera un número de autorización simulado
   */
  private generarNumeroAutorizacion(): string {
    const timestamp = Date.now().toString();
    const random = Math.floor(Math.random() * 999999).toString().padStart(6, '0');
    return timestamp + random;
  }

  /**
   * Valida la estructura básica del comprobante
   */
  private validarComprobante(comprobante: ComprobanteElectronico): { valida: boolean; errores: string[] } {
    const errores: string[] = [];
    
    // Validar RUC
    if (!comprobante.info_tributaria.ruc || comprobante.info_tributaria.ruc.length !== 13) {
      errores.push('RUC debe tener 13 dígitos');
    }
    
    // Validar secuencial
    if (!comprobante.info_tributaria.secuencial || isNaN(parseInt(comprobante.info_tributaria.secuencial))) {
      errores.push('Secuencial debe ser numérico');
    }
    
    // Validar establecimiento y punto de emisión
    if (!comprobante.info_tributaria.estab || comprobante.info_tributaria.estab.length !== 3) {
      errores.push('Establecimiento debe tener 3 dígitos');
    }
    
    if (!comprobante.info_tributaria.ptoEmi || comprobante.info_tributaria.ptoEmi.length !== 3) {
      errores.push('Punto de emisión debe tener 3 dígitos');
    }
    
    return {
      valida: errores.length === 0,
      errores
    };
  }

  /**
   * Consulta el estado de autorización de un comprobante
   */
  public async consultarAutorizacion(claveAcceso: string): Promise<RespuestaSRI> {
    console.log(`🔍 Consultando autorización para clave: ${claveAcceso}`);
    
    // Simular consulta
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Por simplicidad, siempre retornamos autorizada en las consultas
    return {
      success: true,
      numero_autorizacion: this.generarNumeroAutorizacion(),
      fecha_autorizacion: new Date().toISOString(),
      estado: 'AUTORIZADA',
      observaciones: 'Comprobante autorizado correctamente'
    };
  }

  /**
   * Obtiene información del certificado P12 actual
   */
  public getCertificadoP12Info(): CertificadoP12 {
    return { ...this.certificadoP12Simulado };
  }
}
