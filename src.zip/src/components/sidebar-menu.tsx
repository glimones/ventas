"use client"
import { BrickWallShield, Building2, CircleUserRound, FolderPlus, NotebookText, PackageSearch, Receipt } from "lucide-react"
import { usePathname } from "next/navigation"
import React, { useState } from "react"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,  
  SidebarProvider,
} from "@/components/ui/sidebar"
import { NavMain } from "./nav-main"

// Tipos para los items del menú
import { type LucideIcon } from "lucide-react"

interface SubMenuItem {
  title: string;
  url: string;
}

interface MenuItem {
  title: string;
  url: string;
  icon?: LucideIcon;
  isActive: boolean;
  items?: SubMenuItem[];
}

// Menu items.
const normalizeUrl = (url: string) => (url === "#" ? url : url.startsWith("/") ? url : `/${url}`);

const items: MenuItem[] = [
  {
    title: "Empresas",
    url: "/empresa",
    icon: Building2,
    isActive: false,
  },
  {
    title: "Clientes",
    url: "/cliente",
    icon: CircleUserRound,
    isActive: false,
  },
  {
    title: "Inventario",
    url: "#",
    icon: PackageSearch,
    isActive: false,
    items: [
      {
        title: "Productos",
        url: "/productos",
      },     
      {
        title: "Movimientos",
        url: "#",
      }, 
      {
        title: "Bodegas",
        url: "#",
      },
    ],
  },
  {
    title: "Comprobantes Electrónicos",
    url: "#",
    icon: Receipt,
    isActive: false,
    items: [
      {
        title: "Facturas",
        url: "/facturas",
      },
      {
        title: "Notas de Crédito",
        url: "/notas-credito",
      },
      {
        title: "Notas de Débito",
        url: "/notas-debito",
      },
      {
        title: "Comprobantes de Retención",
        url: "/comprobantes-retencion",
      },
      {
        title: "Guías de Remisión",
        url: "/guias-remision",
      },
      {
        title: "Liquidaciones de Compra",
        url: "/liquidaciones-compra",
      },      
    ],
  },
  {
    title: "Pedidos",
    url: "#",
    icon: FolderPlus,
    isActive: false,
    items: [
      {
        title: "Solicitudes de pedido",
        url: "/solicitudes-pedido",
      },
      {
        title: "Solicitudes de compra",
        url: "/solicitudes-compra",
      },
      {
        title: "Cotizaciones",
        url: "/cotizaciones",
      },
      {
        title: "Ordenes",
        url: "/ordenes-compra",
      },      
    ],
  },
  {
    title: "Reportes",
    url: "#",
    icon: NotebookText,
    isActive: false,
    items: [
      {
        title: "General",
        url: "#",
      },
      {
        title: "Team",
        url: "#",
      },
      {
        title: "Billing",
        url: "#",
      },
      {
        title: "Limits",
        url: "#",
      },
    ],
  },
  {
    title: "Seguridad",
    url: "#",
    icon: BrickWallShield,
    isActive: false,
    items: [
      {
        title: "Usuarios",
        url: "/seguridad/usuarios",
      },
      {
        title: "Roles",
        url: "/seguridad/roles",
      },
      {
        title: "Permisos Usuarios",
        url: "/seguridad/permisos-usuarios",
      }            
    ],
  },
]



export function AppSidebarMenu() {
  const pathname = usePathname();
  const [openGroup, setOpenGroup] = useState<string | null>(null);
  
  // Función para determinar si un item está activo
  const isItemActive = (item: MenuItem) => {
    // Si tiene subitems, verificar si algún subitem está activo
    if (item.items) {
      return item.items.some((subItem: SubMenuItem) => {
        if (subItem.url === "#") return false;
        return pathname.includes(normalizeUrl(subItem.url));
      });
    }
    // Si es un item directo, verificar si la URL coincide
    if (item.url === "#") return false;
    return pathname.includes(normalizeUrl(item.url));
  };
  
  // Crear items dinámicos con isActive actualizado
  const dynamicItems = items.map(item => ({
    ...item,
    isActive: isItemActive(item)
  }));

  // Establecer el grupo abierto basado en el item activo al cargar
  React.useEffect(() => {
    const activeGroup = items.find(item => {
      if (!item.items) return false;
      return item.items.some(subItem => {
        if (subItem.url === "#") return false;
        return pathname.includes(normalizeUrl(subItem.url));
      });
    });
    if (activeGroup) {
      setOpenGroup(activeGroup.title);
    }
  }, [pathname]);

  // Función para manejar el toggle de grupos
  const handleGroupToggle = (groupTitle: string, hasItems: boolean) => {
    if (!hasItems) return;
    
    setOpenGroup(prevOpen => 
      prevOpen === groupTitle ? null : groupTitle
    );
  };

  return (
      <SidebarProvider>
        <Sidebar collapsible="none" className="h-full border-r border-black/10 bg-white">
          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupContent>
                <NavMain 
                  items={dynamicItems} 
                  openGroup={openGroup}
                  onGroupToggle={handleGroupToggle}
                />           
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>
      </SidebarProvider>
  )
}