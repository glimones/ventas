import { Quantum } from 'ldrs/react'
import 'ldrs/react/Quantum.css'

// Default values shown
export default function Loading() {
    return (<div style={{
        position: 'absolute', left: '50%', top: '50%',
        transform: 'translate(-50%, -50%)'
      }}>      
        <Quantum
        size="45"
        speed="1.75"
        color="black" 
      />
      </div>
    );
  }
