"use client"

import { ChevronRight, type LucideIcon } from "lucide-react"
import Link from "next/link"

import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible"
import {
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "@/components/ui/sidebar"

export function NavMain({
  items,
  openGroup,
  onGroupToggle,
}: {
  items: {
    title: string
    url: string
    icon?: LucideIcon
    isActive?: boolean
    items?: {
      title: string
      url: string
    }[]
  }[]
  openGroup?: string | null
  onGroupToggle?: (groupTitle: string, hasItems: boolean) => void
}) {
  return (
    <SidebarMenu>
      {items.map((item) => {
        // Verificar si el elemento tiene subelementos
        const hasSubItems = item.items && item.items.length > 0;
        
        // Si no hay subelementos, solo mostramos un botón simple sin flecha ni colapsable
        if (!hasSubItems) {
          return (
            <SidebarMenuItem key={item.title}>
              <SidebarMenuButton 
                tooltip={item.title}
                isActive={item.isActive}
                asChild
              >
                <Link href={item.url}>
                  {item.icon && <item.icon className="h-4 w-4 mr-2" />} 
                  <span>{item.title}</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          );
        }
        
        // Si hay subelementos, mostramos el comportamiento colapsable con flecha
        const isOpen = openGroup === item.title;
        
        return (
          <Collapsible
            key={item.title}
            asChild
            open={isOpen}
            onOpenChange={(open) => {
              if (onGroupToggle) {
                onGroupToggle(item.title, true);
              }
            }}
            className="group/collapsible"
          >
            <SidebarMenuItem>
              <CollapsibleTrigger asChild>
                <SidebarMenuButton tooltip={item.title}>
                  {item.icon && <item.icon className="h-4 w-4 mr-2" />}
                  <span>{item.title}</span>
                  <ChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                </SidebarMenuButton>
              </CollapsibleTrigger>
              <CollapsibleContent>                
                <SidebarMenuSub>
                  {item.items?.map((subItem) => (
                    <SidebarMenuSubItem key={subItem.title}>
                      <SidebarMenuSubButton asChild>
                        <Link href={subItem.url}>
                          <span>{subItem.title}</span>
                        </Link>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                  ))}
                </SidebarMenuSub>
              </CollapsibleContent>
            </SidebarMenuItem>
          </Collapsible>
        );
      })}
    </SidebarMenu>
  )
}