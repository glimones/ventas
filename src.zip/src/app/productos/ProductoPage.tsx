"use client";

import React, { useState, useCallback } from "react";
import { Producto, ProductoFormValues, MovimientoInventario } from "./types";
import ProductoModal from "./ProductoModal";
import MovimientoModal from "./MovimientoModal";
import "./bootstrap-producto.css";
import { CirclePlus, Package, Loader, ArrowUpDown, SquarePen, Trash2 } from 'lucide-react';

const initialForm: ProductoFormValues = {
  codigo: "",
  nombre: "",
  descripcion: "",
  categoria: "",
  precio_compra: 0,
  precio_venta: 0,
  stock_actual: 0,
  stock_minimo: 0,
  unidad_medida: "",
  marca: "",
  proveedor: "",
  ubicacion: "",
  imagen_url: "",
  estado: "Activo",
};

const initialProductos: Producto[] = [
  {
    id: 1,
    codigo: "PROD001",
    nombre: "Laptop HP Pavilion",
    descripcion: "Laptop HP Pavilion 15 pulgadas, 8GB RAM, 256GB SSD",
    categoria: "Electrónica",
    precio_compra: 450,
    precio_venta: 599.99,
    stock_actual: 5,
    stock_minimo: 5,
    unidad_medida: "unidad",
    marca: "HP",
    proveedor: "Distribuidor HP",
    ubicacion: "Estante A-1",
    imagen_url: "laptop.jpg",
    estado: "Activo",
  },
  {
    id: 2,
    codigo: "PROD002",
    nombre: "Mouse Inalámbrico",
    descripcion: "Mouse inalámbrico ergonómico",
    categoria: "Electrónica",
    precio_compra: 8.5,
    precio_venta: 14.99,
    stock_actual: 30,
    stock_minimo: 10,
    unidad_medida: "unidad",
    marca: "Logitech",
    proveedor: "Distribuidora ABC",
    imagen_url: "mouse.jpg",
    ubicacion: "Estante B-3",
    estado: "Activo",
  },
];

export default function ProductosPage() {
  const [productos, setProductos] = useState<Producto[]>(initialProductos);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [showMovimientoModal, setShowMovimientoModal] = useState<boolean>(false);
  const [selectedProducto, setSelectedProducto] = useState<Producto | null>(null);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ProductoFormValues>(initialForm);
  
  // Movimientos de inventario
  const [movimientos, setMovimientos] = useState<MovimientoInventario[]>([]);

  const limpiarForm = useCallback(() => {
    setForm(initialForm);
    setEditandoId(null);
  }, []);

  const abrirModalNuevo = useCallback(() => {
    limpiarForm();
    setTimeout(() => {
      setShowModal(true);
      console.log("Modal abierto para nuevo producto");
    }, 0);
  }, [limpiarForm]);
  
  const abrirModalEditar = useCallback((producto: Producto) => {
    // Crear un nuevo objeto para evitar referencias
    setForm({
      codigo: producto.codigo || "",
      nombre: producto.nombre || "",
      descripcion: producto.descripcion || "",
      categoria: producto.categoria || "",
      precio_compra: producto.precio_compra || 0,
      precio_venta: producto.precio_venta || 0,
      stock_actual: producto.stock_actual || 0,
      stock_minimo: producto.stock_minimo || 0,
      unidad_medida: producto.unidad_medida || "",
      marca: producto.marca || "",
      proveedor: producto.proveedor || "",
      ubicacion: producto.ubicacion || "",
      imagen_url: producto.imagen_url || "",
      estado: producto.estado || "Activo",
    });
    setEditandoId(producto.id);
    
    setTimeout(() => {
      setShowModal(true);
      console.log("Modal abierto para editar producto:", producto.id);
    }, 0);
  }, []);
  
  const abrirModalMovimiento = useCallback((producto: Producto) => {
    setSelectedProducto(producto);
    setTimeout(() => {
      setShowMovimientoModal(true);
      console.log("Modal de movimiento abierto para producto:", producto.id);
    }, 0);
  }, []);

  const cerrarModal = useCallback(() => {
    console.log("Cerrando modal");
    setShowModal(false);
    // Limpiar el formulario después de que el modal se haya cerrado
    setTimeout(limpiarForm, 300);
  }, [limpiarForm]);
  
  const cerrarModalMovimiento = useCallback(() => {
    console.log("Cerrando modal de movimiento");
    setShowMovimientoModal(false);
    setTimeout(() => setSelectedProducto(null), 300);
  }, []);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    console.log(`Campo ${name} cambiado a:`, value);
    
    setForm(prev => ({
      ...prev,
      [name]: value,
    }));
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    console.log("Formulario enviado:", form, "Editando ID:", editandoId);
    
    if (editandoId) {
      setProductos(prev =>
        prev.map(producto =>
          producto.id === editandoId ? { ...producto, ...form, id: editandoId } : producto
        )
      );
      console.log("Producto actualizado");
    } else {
      const nuevoId = Date.now();
      setProductos(prev => [
        ...prev,
        { ...form, id: nuevoId } as Producto,
      ]);
      console.log("Nuevo producto añadido con ID:", nuevoId);
    }
    
    cerrarModal();
  }, [form, editandoId, cerrarModal]);
  
  const handleMovimientoSubmit = useCallback((movimiento: Partial<MovimientoInventario>) => {
    if (!selectedProducto) return;
    
    const nuevoId = Date.now();
    const nuevoMovimiento: MovimientoInventario = {
      ...movimiento as MovimientoInventario,
      id: nuevoId,
      producto_id: selectedProducto.id,
    };
    
    // Actualizar el stock del producto
    setProductos(prev =>
      prev.map(producto => {
        if (producto.id === selectedProducto.id) {
          const nuevoStock = movimiento.tipo === 'Entrada'
            ? producto.stock_actual + (movimiento.cantidad || 0)
            : producto.stock_actual - (movimiento.cantidad || 0);
          
          return {
            ...producto,
            stock_actual: Math.max(0, nuevoStock), // Evitar stock negativo
          };
        }
        return producto;
      })
    );
    
    // Guardar el movimiento
    setMovimientos(prev => [...prev, nuevoMovimiento]);
    
    console.log("Nuevo movimiento registrado:", nuevoMovimiento);
    cerrarModalMovimiento();
  }, [selectedProducto, cerrarModalMovimiento]);

  const eliminarProducto = useCallback((id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar este producto?")) {
      setProductos(prev => prev.filter(producto => producto.id !== id));
      console.log("Producto eliminado:", id);
    }
  }, []);

  const productosFiltrados = productos.filter(producto =>
    Object.values(producto)
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-0">Stock de Productos</h1>
        
        <div className="d-flex justify-content-between align-items-center mb-4">          
          <p className="text-muted mb-0">Registro de productos y movimientos</p>
          <div className="ms-auto">
            <button 
              className="btn btn-primary d-flex align-items-center" 
              onClick={abrirModalNuevo}
              type="button"
            >
              <CirclePlus className="me-2" size={16} />
              <span>Añadir Producto</span>
            </button>
          </div>
        </div>
        
        <div className="card mb-4">
          <div className="card-body">
            <div className="row align-items-center">
              <div className="col-md-6">
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="bi bi-search"></i>
                  </span>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Buscar por código, nombre, categoría..."
                    value={filtro}
                    onChange={(e) => setFiltro(e.target.value)}
                  />
                </div>
              </div>
              <div className="col-md-6 text-md-end mt-3 mt-md-0">
                <span className="badge bg-info me-2">
                  <Package size={14} className="me-1" />
                  Total de productos: {productos.length}
                </span>
                <span className="badge bg-warning me-2">
                  <Loader size={14} className="me-1" />
                  Stock bajo: {productos.filter(p => p.stock_actual <= p.stock_minimo).length}
                </span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Categoría</th>
                <th>Precio Compra</th>
                <th>Precio Venta</th>
                <th>Stock</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {productosFiltrados.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center">
                    <div className="alert alert-info mb-0">
                      No se encontraron productos
                    </div>
                  </td>
                </tr>
              )}
              {productosFiltrados.map((producto) => (
                <tr key={producto.id}>
                  <td>{producto.codigo}</td>
                  <td>
                    <div className="d-flex align-items-center">
                      <img
                        src={ `/img/${producto.imagen_url}`}
                        alt={producto.nombre}
                        className="me-2"
                        style={{ width: '30px', height: '30px', objectFit: 'cover' }}
                        onError={e => {
                          (e.target as HTMLImageElement).src = "/img/placeholder.png";
                        }}
                      />
                      <div>
                        <div>{producto.nombre}</div>
                        <small className="text-muted">{producto.marca}</small>
                      </div>
                    </div>
                  </td>
                  <td>{producto.categoria}</td>
                  <td>${producto.precio_compra.toFixed(2)}</td>
                  <td>${producto.precio_venta.toFixed(2)}</td>
                  <td>
                    <span className={
                      producto.stock_actual <= producto.stock_minimo / 2 ? "stock-danger" :
                      producto.stock_actual <= producto.stock_minimo ? "stock-warning" : "stock-ok"
                    }>
                      {producto.stock_actual} {producto.unidad_medida}
                      {producto.stock_actual <= producto.stock_minimo && (
                        <span className="ms-2 badge bg-warning">¡Bajo!</span>
                      )}
                    </span>
                  </td>
                  <td>
                    <span
                      className={`badge bg-${
                        producto.estado === "Activo"
                          ? "success"
                          : producto.estado === "Inactivo"
                          ? "secondary"
                          : "danger"
                      }`}
                    >
                      {producto.estado}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group btn-group-sm opciones-btn-group">
                      <button
                        className="btn btn-primary"
                        onClick={() => abrirModalMovimiento(producto)}
                        title="Registrar movimiento"
                        type="button"
                      >
                        <ArrowUpDown size={16} />
                      </button>
                      <button
                        className="btn btn-warning"
                        onClick={() => abrirModalEditar(producto)}
                        title="Editar producto"
                        type="button"
                      >
                        <SquarePen size={16} />
                      </button>
                      <button
                        className="btn btn-danger"
                        onClick={() => eliminarProducto(producto.id)}
                        title="Eliminar producto"
                        type="button"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <ProductoModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
        
        <MovimientoModal
          show={showMovimientoModal}
          producto={selectedProducto}
          onClose={cerrarModalMovimiento}
          onSubmit={handleMovimientoSubmit}
        />
      </div>
    </div>
  );
}