import { AppShell } from '@/components/app-shell';
import ProductosPage from './ProductoPage';
// Removemos la importación del CSS aquí, ya que está importado en EmpresaPage 

export default function Page() {
  return (
    <AppShell>
        <ProductosPage />
    </AppShell>
  );
}