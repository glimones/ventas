import React from "react";
import { ProductoFormValues } from "./types";

interface Props {
  values: ProductoFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const categoriasOptions = [
  { value: "", label: "Seleccione una categoría" },
  { value: "Electrónica", label: "Electrónica" },
  { value: "Ropa", label: "Ropa" },
  { value: "Hogar", label: "Hogar" },
  { value: "Alimentos", label: "Alimentos" },
  { value: "Bebidas", label: "Bebidas" },
  { value: "Oficina", label: "Oficina" },
  { value: "Herramientas", label: "Herramientas" },
  { value: "Salud", label: "Salud" },
  { value: "Belleza", label: "Belleza" },
  { value: "Otros", label: "Otros" },
];

const unidadesMedida = [
  { value: "", label: "Seleccione unidad" },
  { value: "unidad", label: "Unidad" },
  { value: "kg", label: "Kilogramo" },
  { value: "g", label: "Gramo" },
  { value: "l", label: "Litro" },
  { value: "ml", label: "Mililitro" },
  { value: "m", label: "Metro" },
  { value: "cm", label: "Centímetro" },
  { value: "m2", label: "Metro cuadrado" },
  { value: "m3", label: "Metro cúbico" },
  { value: "docena", label: "Docena" },
  { value: "caja", label: "Caja" },
  { value: "paquete", label: "Paquete" },
];

const ProductoForm: React.FC<Props> = ({ values, onChange }) => {
  // Manejador de eventos para asegurar que los cambios se registren
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  // Manejador especial para campos numéricos
  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    const numericValue = value === '' ? 0 : parseFloat(value);
    
    // Crear un evento sintético para mantener la coherencia con la interfaz
    const syntheticEvent = {
      ...e,
      target: {
        ...e.target,
        name,
        value: numericValue,
      },
    } as unknown as React.ChangeEvent<HTMLInputElement>;
    
    handleInputChange(syntheticEvent);
  };

  // Manejador para la subida de imágenes
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name } = e.target;
    const file = e.target.files?.[0];
    
    if (file) {
      // En una aplicación real, aquí subirías el archivo y obtendrías una URL
      // Para este ejemplo, simplemente creamos una URL local temporal
      const url = URL.createObjectURL(file);
      
      // Crear un evento sintético
      const syntheticEvent = {
        ...e,
        target: {
          ...e.target,
          name,
          value: url,
        },
      } as React.ChangeEvent<HTMLInputElement>;
      
      handleInputChange(syntheticEvent);
    }
  };

  return (
    <div className="row g-3">
      {/* Primera columna */}
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="codigo" className="form-label">
            Código *
          </label>
          <input
            type="text"
            className="form-control"
            id="codigo"
            name="codigo"
            value={values.codigo || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label">
            Nombre *
          </label>
          <input
            type="text"
            className="form-control"
            id="nombre"
            name="nombre"
            value={values.nombre || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="descripcion" className="form-label">
            Descripción
          </label>
          <textarea
            className="form-control"
            id="descripcion"
            name="descripcion"
            value={values.descripcion || ""}
            onChange={handleInputChange}
            rows={3}
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="categoria" className="form-label">
            Categoría *
          </label>
          <select
            className="form-select"
            id="categoria"
            name="categoria"
            value={values.categoria || ""}
            onChange={handleInputChange}
            required
          >
            {categoriasOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="marca" className="form-label">
            Marca
          </label>
          <input
            type="text"
            className="form-control"
            id="marca"
            name="marca"
            value={values.marca || ""}
            onChange={handleInputChange}
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="proveedor" className="form-label">
            Proveedor
          </label>
          <input
            type="text"
            className="form-control"
            id="proveedor"
            name="proveedor"
            value={values.proveedor || ""}
            onChange={handleInputChange}
            autoComplete="off"
          />
        </div>
      </div>
      
      {/* Segunda columna */}
      <div className="col-md-6">
        <div className="row">
          <div className="col-md-6">
            <div className="mb-3">
              <label htmlFor="precio_compra" className="form-label">
                Precio de compra *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-control"
                id="precio_compra"
                name="precio_compra"
                value={values.precio_compra || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="mb-3">
              <label htmlFor="precio_venta" className="form-label">
                Precio de venta *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-control"
                id="precio_venta"
                name="precio_venta"
                value={values.precio_venta || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
        </div>
        
        <div className="row">
          <div className="col-md-6">
            <div className="mb-3">
              <label htmlFor="stock_actual" className="form-label">
                Stock actual *
              </label>
              <input
                type="number"
                step="1"
                min="0"
                className="form-control"
                id="stock_actual"
                name="stock_actual"
                value={values.stock_actual || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="mb-3">
              <label htmlFor="stock_minimo" className="form-label">
                Stock mínimo *
              </label>
              <input
                type="number"
                step="1"
                min="0"
                className="form-control"
                id="stock_minimo"
                name="stock_minimo"
                value={values.stock_minimo || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
        </div>
        
        <div className="mb-3">
          <label htmlFor="unidad_medida" className="form-label">
            Unidad de medida *
          </label>
          <select
            className="form-select"
            id="unidad_medida"
            name="unidad_medida"
            value={values.unidad_medida || ""}
            onChange={handleInputChange}
            required
          >
            {unidadesMedida.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="ubicacion" className="form-label">
            Ubicación en almacén
          </label>
          <input
            type="text"
            className="form-control"
            id="ubicacion"
            name="ubicacion"
            value={values.ubicacion || ""}
            onChange={handleInputChange}
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="estado" className="form-label">
            Estado
          </label>
          <select
            className="form-select"
            id="estado"
            name="estado"
            value={values.estado || "Activo"}
            onChange={handleInputChange}
          >
            <option value="Activo">Activo</option>
            <option value="Inactivo">Inactivo</option>
            <option value="Descontinuado">Descontinuado</option>
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="imagen_url" className="form-label">
            Imagen del producto
          </label>
          <input
            type="file"
            className="form-control"
            id="imagen_url"
            name="imagen_url"
            onChange={handleImageChange}
            accept="image/*"
          />
          {values.imagen_url && (
            <div className="mt-2">
              <img 
                src={values.imagen_url} 
                alt="Vista previa" 
                className="product-img-preview" 
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductoForm;