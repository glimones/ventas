export interface Producto {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  categoria: string;
  precio_compra: number;
  precio_venta: number;
  stock_actual: number;
  stock_minimo: number;
  unidad_medida: string;
  marca?: string;
  proveedor?: string;
  ubicacion?: string;
  imagen_url?: string;
  estado: string;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface ProductoFormValues {
  codigo: string;
  nombre: string;
  descripcion: string;
  categoria: string;
  precio_compra: number;
  precio_venta: number;
  stock_actual: number;
  stock_minimo: number;
  unidad_medida: string;
  marca?: string;
  proveedor?: string;
  ubicacion?: string;
  imagen_url?: string;
  estado: string;
}

export interface MovimientoInventario {
  id: number;
  producto_id: number;
  tipo: 'Entrada' | 'Salida';
  cantidad: number;
  fecha: string;
  motivo: string;
  usuario: string;
  documento_referencia?: string;
}