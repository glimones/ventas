import React, { useEffect, useState } from "react";
import { Producto, MovimientoInventario } from "./types";
import "./producto.css";

interface Props {
  show: boolean;
  producto: Producto | null;
  onClose: () => void;
  onSubmit: (movimiento: Partial<MovimientoInventario>) => void;
}

const MovimientoModal: React.FC<Props> = ({
  show,
  producto,
  onClose,
  onSubmit,
}) => {
  const [movimiento, setMovimiento] = useState<Partial<MovimientoInventario>>({
    tipo: 'Entrada',
    cantidad: 1,
    motivo: '',
    documento_referencia: '',
    usuario: 'Usuario Actual', // En una app real esto vendría de la autenticación
  });
  
  // Reiniciar el formulario cuando se abre el modal con un nuevo producto
  useEffect(() => {
    if (show && producto) {
      setMovimiento({
        producto_id: producto.id,
        tipo: 'Entrada',
        cantidad: 1,
        motivo: '',
        documento_referencia: '',
        usuario: 'Usuario Actual',
        fecha: new Date().toISOString().split('T')[0],
      });
    }
  }, [show, producto]);

  // Manejar cambios en los campos del formulario
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    if (name === 'cantidad') {
      setMovimiento({
        ...movimiento,
        [name]: parseInt(value, 10) || 0,
      });
    } else {
      setMovimiento({
        ...movimiento,
        [name]: value,
      });
    }
  };

  // Manejar el envío del formulario
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(movimiento);
  };
  
  // Manejar el clic en el backdrop
  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };
  
  if (!show || !producto) return null;

  return (
    <>
      <div 
        className="modal fade show d-block" 
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        style={{ zIndex: 1050 }}
      >
        <div 
          className="modal-dialog" 
          role="document"
          style={{ zIndex: 1060 }}
        >
          <div className="modal-content">
            <form onSubmit={handleSubmit}>
              <div className="modal-header bg-primary text-white">
                <h5 className="modal-title">
                  Registrar movimiento de inventario
                </h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={onClose}
                  aria-label="Cerrar"
                />
              </div>
              <div className="modal-body">
                <div className="alert alert-info">
                  <strong>Producto:</strong> {producto.nombre} (Código: {producto.codigo})
                  <br />
                  <strong>Stock actual:</strong> {producto.stock_actual} {producto.unidad_medida}
                </div>
                
                <div className="mb-3">
                  <label htmlFor="tipo" className="form-label">Tipo de movimiento *</label>
                  <select
                    className="form-select"
                    id="tipo"
                    name="tipo"
                    value={movimiento.tipo}
                    onChange={handleChange}
                    required
                  >
                    <option value="entrada">Entrada</option>
                    <option value="salida">Salida</option>
                  </select>
                </div>
                
                <div className="mb-3">
                  <label htmlFor="cantidad" className="form-label">Cantidad *</label>
                  <input
                    type="number"
                    className="form-control"
                    id="cantidad"
                    name="cantidad"
                    value={movimiento.cantidad}
                    onChange={handleChange}
                    min="1"
                    required
                  />
                </div>
                
                <div className="mb-3">
                  <label htmlFor="motivo" className="form-label">Motivo *</label>
                  <select
                    className="form-select"
                    id="motivo"
                    name="motivo"
                    value={movimiento.motivo}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Seleccione un motivo</option>
                    {movimiento.tipo === 'Entrada' ? (
                      <>
                        <option value="Compra">Compra</option>
                        <option value="Devolución de cliente">Devolución de cliente</option>
                        <option value="Ajuste de inventario">Ajuste de inventario</option>
                        <option value="Transferencia de otra sucursal">Transferencia de otra sucursal</option>
                      </>
                    ) : (
                      <>
                        <option value="Venta">Venta</option>
                        <option value="Devolución a proveedor">Devolución a proveedor</option>
                        <option value="Ajuste de inventario">Ajuste de inventario</option>
                        <option value="Transferencia a otra sucursal">Transferencia a otra sucursal</option>
                        <option value="Producto dañado">Producto dañado</option>
                        <option value="Producto vencido">Producto vencido</option>
                      </>
                    )}
                  </select>
                </div>
                
                <div className="mb-3">
                  <label htmlFor="documento_referencia" className="form-label">Documento de referencia</label>
                  <input
                    type="text"
                    className="form-control"
                    id="documento_referencia"
                    name="documento_referencia"
                    value={movimiento.documento_referencia}
                    onChange={handleChange}
                    placeholder="Ej: Factura #12345"
                  />
                </div>
                
                <div className="mb-3">
                  <label htmlFor="fecha" className="form-label">Fecha *</label>
                  <input
                    type="date"
                    className="form-control"
                    id="fecha"
                    name="fecha"
                    value={movimiento.fecha}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={onClose}
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="btn btn-success"
                >
                  Registrar movimiento
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div 
        className="modal-backdrop fade show" 
        onClick={handleBackdropClick}
        style={{ zIndex: 1040 }}
      ></div>
    </>
  );
};

export default MovimientoModal;