import { AppShell } from '@/components/app-shell';
import ClientesPage from './ClientePage';
// Removemos la importación del CSS aquí, ya que está importado en EmpresaPage 

export default function Page() {
  return (
    <AppShell>
        <ClientesPage />
    </AppShell>
  );
}