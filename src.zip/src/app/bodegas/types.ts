export interface Cliente {
  id: number;
  nombre: string;
  apellido: string;
  empresa?: string;
  tipo_documento: string;
  documento: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  codigo_postal?: string;
  email: string;
  telefono: string;
  celular?: string;
  notas?: string;
  estado: string;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface ClienteFormValues {
  nombre: string;
  apellido: string;
  empresa?: string;
  tipo_documento: string;
  documento: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  codigo_postal?: string;
  email: string;
  telefono: string;
  celular?: string;
  notas?: string;
  estado: string;
}