import React from "react";
import { ClienteFormValues } from "./types";

interface Props {
  values: ClienteFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const tiposDocumento = [
  { value: "", label: "Seleccione tipo de documento" },
  { value: "DNI", label: "DNI" },
  { value: "RUC", label: "RUC/NIT" },
  { value: "PASAPORTE", label: "Pasaporte" },
  { value: "CEDULA", label: "Cédula de Identidad" },
];

const paisesOptions = [
  { value: "", label: "Seleccione un país" },
  { value: "es", label: "España" },
  { value: "mx", label: "México" },
  { value: "co", label: "Colombia" },
  { value: "ar", label: "Argentina" },
  { value: "cl", label: "Chile" },
  { value: "pe", label: "Perú" },
  { value: "ec", label: "Ecuador" },
  { value: "ve", label: "Venezuela" },
  { value: "us", label: "Estados Unidos" },
  { value: "ca", label: "Canadá" },
];

const ClienteForm: React.FC<Props> = ({ values, onChange }) => {
  // Manejador de eventos para asegurar que los cambios se registren
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className="row g-3">
      {/* Primera columna */}
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label">
            Nombre *
          </label>
          <input
            type="text"
            className="form-control"
            id="nombre"
            name="nombre"
            value={values.nombre || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="apellido" className="form-label">
            Apellido *
          </label>
          <input
            type="text"
            className="form-control"
            id="apellido"
            name="apellido"
            value={values.apellido || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>        
        
        <div className="mb-3">
          <label htmlFor="tipo_documento" className="form-label">
            Tipo de Documento *
          </label>
          <select
            className="form-select"
            id="tipo_documento"
            name="tipo_documento"
            value={values.tipo_documento || ""}
            onChange={handleInputChange}
            required
          >
            {tiposDocumento.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="documento" className="form-label">
            Número de Documento *
          </label>
          <input
            type="text"
            className="form-control"
            id="documento"
            name="documento"
            value={values.documento || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="direccion" className="form-label">
            Dirección *
          </label>
          <textarea
            className="form-control"
            id="direccion"
            name="direccion"
            value={values.direccion || ""}
            onChange={handleInputChange}
            rows={2}
            required
          />
        </div>
      </div>
      
      {/* Segunda columna */}
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="ciudad" className="form-label">
            Ciudad *
          </label>
          <input
            type="text"
            className="form-control"
            id="ciudad"
            name="ciudad"
            value={values.ciudad || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="provincia" className="form-label">
            Provincia/Estado
          </label>
          <input
            type="text"
            className="form-control"
            id="provincia"
            name="provincia"
            value={values.provincia || ""}
            onChange={handleInputChange}
            autoComplete="off"
          />
        </div>
                       
        <div className="mb-3">
          <label htmlFor="email" className="form-label">
            Correo electrónico *
          </label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            value={values.email || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="row">
          <div className="col-md-6">
            <div className="mb-3">
              <label htmlFor="telefono" className="form-label">
                Teléfono *
              </label>
              <input
                type="text"
                className="form-control"
                id="telefono"
                name="telefono"
                value={values.telefono || ""}
                onChange={handleInputChange}
                required
                autoComplete="off"
              />
            </div>
          </div>
          <div className="col-md-6">
            <div className="mb-3">
              <label htmlFor="celular" className="form-label">
                Celular
              </label>
              <input
                type="tel"
                className="form-control"
                id="celular"
                name="celular"
                value={values.celular || ""}
                onChange={handleInputChange}
                autoComplete="off"
              />
            </div>
          </div>
        </div>
        
        <div className="mb-3">
          <label htmlFor="estado" className="form-label">
            Estado
          </label>
          <select
            className="form-select"
            id="estado"
            name="estado"
            value={values.estado || "Activo"}
            onChange={handleInputChange}
          >
            <option value="Activo">Activo</option>
            <option value="Inactivo">Inactivo</option>
          </select>
        </div>
      </div>     
    </div>
  );
};

export default ClienteForm;