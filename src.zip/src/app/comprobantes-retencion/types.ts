// Tipos para Comprobantes de Retención SRI Ecuador

export interface InfoTributaria {
  ambiente: string;
  tipo_emision: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  clave_acceso: string;
  cod_doc: string; // "07" para comprobantes de retención
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
}

export interface InfoComprobanteRetencion {
  fecha_emision: string;
  direccion_establecimiento: string;
  contribuyente_especial?: string;
  obligado_contabilidad: string;
  tipo_identificacion_sujeto_retenido: string;
  partido_politico?: string;
  razon_social_sujeto_retenido: string;
  identificacion_sujeto_retenido: string;
  periodo_fiscal: string;
}

export interface DetalleImpuesto {
  codigo: string;
  codigo_retencion: string;
  base_imponible: number;
  porcentaje_retener: number;
  valor_retenido: number;
  cod_doc_sustento: string;
  num_doc_sustento: string;
  fecha_emision_doc_sustento: string;
}

export interface Impuesto {
  codigo: string;
  codigo_retencion: string;
  tarifa: number;
  valor: number;
}

export interface ComprobanteRetencion {
  id: number;
  info_tributaria: InfoTributaria;
  info_comprobante_retencion: InfoComprobanteRetencion;
  impuestos: DetalleImpuesto[];
  estado_sri: 'PENDIENTE' | 'AUTORIZADA' | 'RECHAZADA' | 'DEVUELTA';
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  xml_generado?: string;
  observaciones_sri?: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
}

export interface ComprobanteRetencionFormValues {
  // Info tributaria básica
  ambiente: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
  
  // Info del comprobante
  fecha_emision: string;
  direccion_establecimiento: string;
  contribuyente_especial: string;
  obligado_contabilidad: string;
  tipo_identificacion_sujeto_retenido: string;
  razon_social_sujeto_retenido: string;
  identificacion_sujeto_retenido: string;
  periodo_fiscal: string;
  
  // Detalles de impuestos
  cod_doc_sustento: string;
  num_doc_sustento: string;
  fecha_emision_doc_sustento: string;
  codigo_impuesto: string;
  codigo_retencion: string;
  base_imponible: number;
  porcentaje_retener: number;
  valor_retenido: number;
}

// Tipos de identificación del sujeto retenido
export const tiposIdentificacion = [
  { codigo: "04", descripcion: "RUC" },
  { codigo: "05", descripcion: "Cédula" },
  { codigo: "06", descripcion: "Pasaporte" },
  { codigo: "07", descripcion: "Venta a consumidor final" },
  { codigo: "08", descripcion: "Identificación del exterior" }
];

// Códigos de documentos de sustento
export const documentosSustento = [
  { codigo: "01", descripcion: "Factura" },
  { codigo: "02", descripcion: "Nota de Venta" },
  { codigo: "03", descripcion: "Liquidación de compra de bienes y servicios" },
  { codigo: "04", descripcion: "Nota de Crédito" },
  { codigo: "05", descripcion: "Nota de Débito" },
  { codigo: "41", descripcion: "Comprobante de venta emitido en el exterior" },
  { codigo: "42", descripcion: "Documento aduanero único de importación" },
  { codigo: "43", descripcion: "Documento aduanero único de exportación" },
  { codigo: "44", descripcion: "Documento de transporte aéreo" },
  { codigo: "45", descripcion: "Documento de transporte terrestre" }
];

// Tipos de impuestos
export const tiposImpuestos = [
  { 
    codigo: "1", 
    descripcion: "Renta",
    retenciones: [
      { codigo: "303", descripcion: "Honorarios profesionales", porcentaje: 10 },
      { codigo: "304", descripcion: "Predomina el intelecto", porcentaje: 8 },
      { codigo: "307", descripcion: "Arrendamiento inmuebles", porcentaje: 8 },
      { codigo: "308", descripcion: "Arrendamiento muebles", porcentaje: 1 },
      { codigo: "309", descripcion: "Intereses y comisiones", porcentaje: 2 },
      { codigo: "310", descripcion: "Seguros y reaseguros", porcentaje: 1 },
      { codigo: "312", descripcion: "Predomina la mano de obra", porcentaje: 2 },
      { codigo: "320", descripcion: "Transporte privado", porcentaje: 1 },
      { codigo: "322", descripcion: "Pagos notarios y registradores", porcentaje: 8 },
      { codigo: "323", descripcion: "Pagos comerciantes", porcentaje: 1 },
      { codigo: "324", descripcion: "Transferencia de acciones", porcentaje: 1 },
      { codigo: "325", descripcion: "Medicamentos", porcentaje: 1 },
      { codigo: "327", descripcion: "Servicios de medios de comunicación", porcentaje: 1 },
      { codigo: "328", descripcion: "Molinos", porcentaje: 1 },
      { codigo: "332", descripcion: "Energía eléctrica", porcentaje: 1 },
      { codigo: "340", descripcion: "Servicios públicos", porcentaje: 2.75 }
    ]
  },
  { 
    codigo: "2", 
    descripcion: "IVA",
    retenciones: [
      { codigo: "725", descripcion: "Retención 30% IVA", porcentaje: 30 },
      { codigo: "727", descripcion: "Retención 70% IVA", porcentaje: 70 },
      { codigo: "729", descripcion: "Retención 100% IVA", porcentaje: 100 }
    ]
  },
  { 
    codigo: "6", 
    descripcion: "ICE",
    retenciones: [
      { codigo: "731", descripcion: "Retención ICE", porcentaje: 0 }
    ]
  }
];

// Ambientes
export const ambientes = [
  { codigo: "1", descripcion: "Pruebas" },
  { codigo: "2", descripcion: "Producción" }
];

// Obligado a llevar contabilidad
export const obligadoContabilidad = [
  { codigo: "SI", descripcion: "Sí" },
  { codigo: "NO", descripcion: "No" }
];
