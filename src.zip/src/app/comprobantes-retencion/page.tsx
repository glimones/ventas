import { AppShell } from "@/components/app-shell";
import ComprobantesRetencionPage from "./ComprobantesRetencionPage";

export default function Page() {
  return <AppShell><ComprobantesRetencionPage /></AppShell>;
}
