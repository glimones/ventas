import { AppShell } from "@/components/app-shell";
import CotizacionesPage from "./CotizacionesPage";

export default function Page() {
  return <AppShell><CotizacionesPage /></AppShell>;
}
