"use client";

import React, { useState } from "react";
import { Cotizacion, CotizacionFormValues, InfoProveedorCotizacion, DetalleCotizacion, CondicionesCotizacion } from "./types";
import "./cotizaciones.css";
import { CirclePlus, SquarePen, Trash2, Eye, Package, Plus, Minus, FileText, Calendar, DollarSign, Clock, CheckCircle, XCircle } from 'lucide-react';

const initialForm: CotizacionFormValues = {
  fecha_cotizacion: new Date().toISOString().split('T')[0],
  fecha_vencimiento: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // +30 días
  tipo_cotizacion: "SOLICITUD_DIRECTA",
  id_solicitud_compra: "",
  tipo_identificacion: "",
  identificacion: "",
  razon_social: "",
  nombre_comercial: "",
  direccion: "",
  telefono: "",
  email: "",
  contacto_principal: "",
  telefono_contacto: "",
  email_contacto: "",
  codigo_producto: "",
  descripcion: "",
  especificaciones_tecnicas: "",
  unidad_medida: "UND",
  cantidad_solicitada: 1,
  cantidad_cotizada: 1,
  precio_unitario: 0,
  descuento_porcentaje: 0,
  tiempo_entrega_dias: 15,
  observaciones_proveedor: "",
  observaciones_internas: "",
  forma_pago: "CREDITO_30",
  tiempo_entrega_general: 15,
  lugar_entrega: "",
  garantia_meses: 12,
  incluye_instalacion: false,
  incluye_capacitacion: false,
  incluye_soporte: false,
  vigencia_precio_dias: 30,
  observaciones_comerciales: "",
  moneda: "USD",
  observaciones_generales: "",
  responsable_negociacion: "admin",
  requiere_aprobacion: true,
};

const initialCotizaciones: Cotizacion[] = [
  {
    id: 1,
    numero_cotizacion: "COT-2024-001",
    fecha_cotizacion: "21/09/2024",
    fecha_vencimiento: "21/10/2024",
    estado: "APROBADA",
    tipo_cotizacion: "SOLICITUD_DIRECTA",
    id_solicitud_compra: 1,
    numero_solicitud_compra: "SC-2024-001",
    info_proveedor: {
      tipo_identificacion: "04",
      identificacion: "1234567890001",
      razon_social: "PROVEEDORA TECH S.A.",
      nombre_comercial: "TechStore",
      direccion: "Av. Tecnología 123, Quito",
      telefono: "02-2345678",
      email: "ventas@techstore.com",
      contacto_principal: "María González",
      telefono_contacto: "0987654321",
      email_contacto: "maria.gonzalez@techstore.com"
    },
    detalles: [
      {
        id: "1",
        codigo_producto: "SRV001",
        descripcion: "Servidores Dell PowerEdge R740",
        especificaciones_tecnicas: "Intel Xeon Silver 4214R, 32GB RAM DDR4, 2x1TB SSD, Garantía 3 años",
        unidad_medida: "UND",
        cantidad_solicitada: 2,
        cantidad_cotizada: 2,
        precio_unitario: 3200.00,
        descuento_porcentaje: 5,
        precio_neto: 3040.00,
        subtotal: 6080.00,
        tiempo_entrega_dias: 10,
        observaciones_proveedor: "Incluye instalación y configuración básica",
        estado_item: "APROBADO"
      },
      {
        id: "2",
        codigo_producto: "LIC001",
        descripcion: "Licencias Windows Server 2022 Standard",
        especificaciones_tecnicas: "Standard Edition - 50 CAL usuarios",
        unidad_medida: "LIC",
        cantidad_solicitada: 50,
        cantidad_cotizada: 50,
        precio_unitario: 42.00,
        descuento_porcentaje: 0,
        precio_neto: 42.00,
        subtotal: 2100.00,
        tiempo_entrega_dias: 5,
        observaciones_proveedor: "Licencias digitales, entrega inmediata",
        estado_item: "APROBADO"
      }
    ],
    condiciones: {
      forma_pago: "CREDITO_30",
      tiempo_entrega_dias: 10,
      lugar_entrega: "Oficina principal - Sistemas",
      garantia_meses: 36,
      incluye_instalacion: true,
      incluye_capacitacion: true,
      incluye_soporte: false,
      vigencia_precio_dias: 30,
      observaciones_comerciales: "Precio válido por 30 días. Instalación incluida sin costo adicional."
    },
    subtotal: 8180.00,
    descuento_total: 160.00,
    subtotal_neto: 8180.00,
    iva: 981.60,
    total: 9161.60,
    moneda: "USD",
    observaciones_generales: "Cotización competitiva con buen tiempo de entrega",
    solicitado_por: "admin",
    centro_costo: "SIS",
    responsable_negociacion: "admin",
    fecha_creacion: "2024-09-21T08:00:00.000Z",
    fecha_actualizacion: "2024-09-21T16:00:00.000Z",
    requiere_aprobacion: true,
    aprobado_por: "jefe_sistemas",
    fecha_aprobacion: "2024-09-21T17:00:00.000Z",
    observaciones_aprobacion: "Aprobada por precio competitivo y buenas condiciones",
    orden_compra_generada: "OC-2024-001",
    fecha_orden_compra: "2024-09-22T08:00:00.000Z"
  },
  {
    id: 2,
    numero_cotizacion: "COT-2024-002",
    fecha_cotizacion: "22/09/2024",
    fecha_vencimiento: "22/10/2024",
    estado: "EN_REVISION",
    tipo_cotizacion: "SOLICITUD_DIRECTA",
    id_solicitud_compra: 2,
    numero_solicitud_compra: "SC-2024-002",
    info_proveedor: {
      tipo_identificacion: "04",
      identificacion: "9876543210001",
      razon_social: "MANTENIMIENTO INDUSTRIAL S.A.",
      direccion: "Zona Industrial Norte, Quito",
      telefono: "02-3456789",
      email: "servicios@manind.com",
      contacto_principal: "Carlos Ruiz",
      telefono_contacto: "0998765432",
      email_contacto: "carlos.ruiz@manind.com"
    },
    detalles: [
      {
        id: "1",
        descripcion: "Mantenimiento preventivo equipos industriales",
        especificaciones_tecnicas: "Revisión completa sistemas hidráulicos, cambio filtros, lubricación, calibración sensores",
        unidad_medida: "SERV",
        cantidad_solicitada: 1,
        cantidad_cotizada: 1,
        precio_unitario: 2300.00,
        descuento_porcentaje: 0,
        precio_neto: 2300.00,
        subtotal: 2300.00,
        tiempo_entrega_dias: 5,
        observaciones_proveedor: "Incluye repuestos básicos y certificado de mantenimiento",
        estado_item: "COTIZADO"
      }
    ],
    condiciones: {
      forma_pago: "CREDITO_15",
      tiempo_entrega_dias: 5,
      lugar_entrega: "Planta industrial - Sector B",
      garantia_meses: 6,
      incluye_instalacion: false,
      incluye_capacitacion: false,
      incluye_soporte: true,
      vigencia_precio_dias: 15,
      observaciones_comerciales: "Precio incluye mano de obra y repuestos básicos"
    },
    subtotal: 2300.00,
    descuento_total: 0.00,
    subtotal_neto: 2300.00,
    iva: 276.00,
    total: 2576.00,
    moneda: "USD",
    observaciones_generales: "Cotización en revisión por área de mantenimiento",
    solicitado_por: "admin",
    centro_costo: "MAN",
    responsable_negociacion: "jefe_mantenimiento",
    fecha_creacion: "2024-09-22T10:00:00.000Z",
    fecha_actualizacion: "2024-09-22T11:00:00.000Z",
    requiere_aprobacion: true
  }
];

export default function CotizacionesPage() {
  const [cotizaciones, setCotizaciones] = useState<Cotizacion[]>(initialCotizaciones);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [showApprovalModal, setShowApprovalModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [cotizacionAprobacion, setCotizacionAprobacion] = useState<Cotizacion | null>(null);
  const [form, setForm] = useState<CotizacionFormValues>(initialForm);
  const [detallesTemp, setDetallesTemp] = useState<DetalleCotizacion[]>([]);
  const [procesando, setProcesando] = useState<boolean>(false);

  const limpiarForm = () => {
    setForm(initialForm);
    setDetallesTemp([]);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (cotizacion: Cotizacion) => {
    setForm({
      fecha_cotizacion: cotizacion.fecha_cotizacion.split('/').reverse().join('-'),
      fecha_vencimiento: cotizacion.fecha_vencimiento.split('/').reverse().join('-'),
      tipo_cotizacion: cotizacion.tipo_cotizacion,
      id_solicitud_compra: cotizacion.id_solicitud_compra?.toString() || "",
      tipo_identificacion: cotizacion.info_proveedor.tipo_identificacion,
      identificacion: cotizacion.info_proveedor.identificacion,
      razon_social: cotizacion.info_proveedor.razon_social,
      nombre_comercial: cotizacion.info_proveedor.nombre_comercial || "",
      direccion: cotizacion.info_proveedor.direccion,
      telefono: cotizacion.info_proveedor.telefono || "",
      email: cotizacion.info_proveedor.email || "",
      contacto_principal: cotizacion.info_proveedor.contacto_principal || "",
      telefono_contacto: cotizacion.info_proveedor.telefono_contacto || "",
      email_contacto: cotizacion.info_proveedor.email_contacto || "",
      codigo_producto: "",
      descripcion: "",
      especificaciones_tecnicas: "",
      unidad_medida: "UND",
      cantidad_solicitada: 1,
      cantidad_cotizada: 1,
      precio_unitario: 0,
      descuento_porcentaje: 0,
      tiempo_entrega_dias: 15,
      observaciones_proveedor: "",
      observaciones_internas: "",
      forma_pago: cotizacion.condiciones.forma_pago,
      tiempo_entrega_general: cotizacion.condiciones.tiempo_entrega_dias,
      lugar_entrega: cotizacion.condiciones.lugar_entrega,
      garantia_meses: cotizacion.condiciones.garantia_meses || 12,
      incluye_instalacion: cotizacion.condiciones.incluye_instalacion,
      incluye_capacitacion: cotizacion.condiciones.incluye_capacitacion,
      incluye_soporte: cotizacion.condiciones.incluye_soporte,
      vigencia_precio_dias: cotizacion.condiciones.vigencia_precio_dias,
      observaciones_comerciales: cotizacion.condiciones.observaciones_comerciales || "",
      moneda: cotizacion.moneda,
      observaciones_generales: cotizacion.observaciones_generales || "",
      responsable_negociacion: cotizacion.responsable_negociacion,
      requiere_aprobacion: cotizacion.requiere_aprobacion,
    });
    
    setDetallesTemp([...cotizacion.detalles]);
    setEditandoId(cotizacion.id);
    setShowModal(true);
  };

  const abrirModalAprobacion = (cotizacion: Cotizacion) => {
    setCotizacionAprobacion(cotizacion);
    setShowApprovalModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    setShowApprovalModal(false);
    setCotizacionAprobacion(null);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    
    if (type === 'checkbox') {
      const checkbox = e.target as HTMLInputElement;
      setForm((prev) => ({
        ...prev,
        [name]: checkbox.checked,
      }));
    } else {
      setForm((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const agregarDetalle = () => {
    if (!form.descripcion || form.cantidad_cotizada <= 0) {
      alert("Por favor complete la descripción y cantidad cotizada");
      return;
    }

    const precioNeto = form.precio_unitario * (1 - form.descuento_porcentaje / 100);
    const subtotal = form.cantidad_cotizada * precioNeto;
    
    const nuevoDetalle: DetalleCotizacion = {
      id: Date.now().toString(),
      codigo_producto: form.codigo_producto,
      descripcion: form.descripcion,
      especificaciones_tecnicas: form.especificaciones_tecnicas,
      unidad_medida: form.unidad_medida,
      cantidad_solicitada: form.cantidad_solicitada,
      cantidad_cotizada: form.cantidad_cotizada,
      precio_unitario: form.precio_unitario,
      descuento_porcentaje: form.descuento_porcentaje,
      precio_neto: precioNeto,
      subtotal: subtotal,
      tiempo_entrega_dias: form.tiempo_entrega_dias,
      observaciones_proveedor: form.observaciones_proveedor,
      observaciones_internas: form.observaciones_internas,
      estado_item: "COTIZADO",
    };

    setDetallesTemp(prev => [...prev, nuevoDetalle]);
    
    // Limpiar campos del producto
    setForm(prev => ({
      ...prev,
      codigo_producto: "",
      descripcion: "",
      especificaciones_tecnicas: "",
      cantidad_solicitada: 1,
      cantidad_cotizada: 1,
      precio_unitario: 0,
      descuento_porcentaje: 0,
      observaciones_proveedor: "",
      observaciones_internas: "",
    }));
  };

  const eliminarDetalle = (id: string) => {
    setDetallesTemp(prev => prev.filter(detalle => detalle.id !== id));
  };

  const calcularTotales = () => {
    const subtotal = detallesTemp.reduce((sum, detalle) => sum + detalle.subtotal, 0);
    const descuentoTotal = detallesTemp.reduce((sum, detalle) => 
      sum + (detalle.cantidad_cotizada * detalle.precio_unitario * detalle.descuento_porcentaje / 100), 0);
    const iva = subtotal * 0.12; // 12% IVA
    const total = subtotal + iva;
    
    return { subtotal, descuentoTotal, iva, total };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (detallesTemp.length === 0) {
      alert("Debe agregar al menos un producto o servicio cotizado");
      return;
    }

    setProcesando(true);
    
    try {
      const totales = calcularTotales();
      
      const infoProveedor: InfoProveedorCotizacion = {
        tipo_identificacion: form.tipo_identificacion,
        identificacion: form.identificacion,
        razon_social: form.razon_social,
        nombre_comercial: form.nombre_comercial,
        direccion: form.direccion,
        telefono: form.telefono,
        email: form.email,
        contacto_principal: form.contacto_principal,
        telefono_contacto: form.telefono_contacto,
        email_contacto: form.email_contacto,
      };

      const condiciones: CondicionesCotizacion = {
        forma_pago: form.forma_pago,
        tiempo_entrega_dias: form.tiempo_entrega_general,
        lugar_entrega: form.lugar_entrega,
        garantia_meses: form.garantia_meses,
        incluye_instalacion: form.incluye_instalacion,
        incluye_capacitacion: form.incluye_capacitacion,
        incluye_soporte: form.incluye_soporte,
        vigencia_precio_dias: form.vigencia_precio_dias,
        observaciones_comerciales: form.observaciones_comerciales,
      };

      const nuevaCotizacion: Cotizacion = {
        id: editandoId || Date.now(),
        numero_cotizacion: editandoId ? 
          cotizaciones.find(c => c.id === editandoId)?.numero_cotizacion || "" :
          `COT-${new Date().getFullYear()}-${String(cotizaciones.length + 1).padStart(3, '0')}`,
        fecha_cotizacion: form.fecha_cotizacion.split('-').reverse().join('/'),
        fecha_vencimiento: form.fecha_vencimiento.split('-').reverse().join('/'),
        estado: editandoId ? 
          cotizaciones.find(c => c.id === editandoId)?.estado || 'BORRADOR' : 
          'BORRADOR',
        tipo_cotizacion: form.tipo_cotizacion as "SOLICITUD_DIRECTA" | "COTIZACION_LIBRE" | "RENOVACION",
        id_solicitud_compra: form.id_solicitud_compra ? parseInt(form.id_solicitud_compra) : undefined,
        numero_solicitud_compra: form.id_solicitud_compra ? `SC-2024-${form.id_solicitud_compra.padStart(3, '0')}` : undefined,
        info_proveedor: infoProveedor,
        detalles: detallesTemp,
        condiciones: condiciones,
        subtotal: totales.subtotal,
        descuento_total: totales.descuentoTotal,
        subtotal_neto: totales.subtotal,
        iva: totales.iva,
        total: totales.total,
        moneda: form.moneda as "USD" | "EUR",
        observaciones_generales: form.observaciones_generales,
        solicitado_por: "admin",
        centro_costo: "ADM",
        responsable_negociacion: form.responsable_negociacion,
        fecha_creacion: editandoId ? 
          cotizaciones.find(c => c.id === editandoId)?.fecha_creacion || new Date().toISOString() :
          new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString(),
        requiere_aprobacion: form.requiere_aprobacion,
      };

      console.log('💾 Guardando cotización...', nuevaCotizacion);

      if (editandoId) {
        setCotizaciones((prev) =>
          prev.map((cot) =>
            cot.id === editandoId ? nuevaCotizacion : cot
          )
        );
        alert(`✅ Cotización ${nuevaCotizacion.numero_cotizacion} actualizada exitosamente.`);
      } else {
        setCotizaciones((prev) => [...prev, nuevaCotizacion]);
        alert(`✅ Cotización ${nuevaCotizacion.numero_cotizacion} creada exitosamente.`);
      }

      cerrarModal();

    } catch (error) {
      console.error('Error procesando cotización:', error);
      alert('Error inesperado al procesar la cotización');
    } finally {
      setProcesando(false);
    }
  };

  const eliminarCotizacion = (id: number) => {
    const cotizacion = cotizaciones.find(c => c.id === id);
    if (cotizacion && cotizacion.estado !== 'BORRADOR') {
      alert("Solo se pueden eliminar cotizaciones en estado BORRADOR");
      return;
    }
    
    if (window.confirm("¿Seguro que deseas eliminar esta cotización?")) {
      setCotizaciones((prev) => prev.filter((cot) => cot.id !== id));
    }
  };

  const cambiarEstado = (id: number, nuevoEstado: string) => {
    setCotizaciones(prev => 
      prev.map(cot => 
        cot.id === id 
          ? { ...cot, estado: nuevoEstado as "BORRADOR" | "ENVIADA_PROVEEDOR" | "RECIBIDA" | "EN_REVISION" | "APROBADA" | "RECHAZADA" | "ORDEN_GENERADA" | "VENCIDA" | "CANCELADA", fecha_actualizacion: new Date().toISOString() }
          : cot
      )
    );
  };

  const procesarAprobacion = (aprobado: boolean, observaciones: string) => {
    if (!cotizacionAprobacion) return;

    const nuevoEstado = aprobado ? 'APROBADA' : 'RECHAZADA';
    
    setCotizaciones(prev => 
      prev.map(cot => 
        cot.id === cotizacionAprobacion.id 
          ? { 
              ...cot, 
              estado: nuevoEstado as "BORRADOR" | "ENVIADA_PROVEEDOR" | "RECIBIDA" | "EN_REVISION" | "APROBADA" | "RECHAZADA" | "ORDEN_GENERADA" | "VENCIDA" | "CANCELADA", 
              aprobado_por: "admin",
              fecha_aprobacion: new Date().toISOString(),
              observaciones_aprobacion: observaciones,
              fecha_actualizacion: new Date().toISOString()
            }
          : cot
      )
    );

    alert(`✅ Cotización ${aprobado ? 'aprobada' : 'rechazada'} exitosamente.`);
    cerrarModal();
  };

  const generarOrdenCompra = (cotizacionId: number) => {
    const cotizacion = cotizaciones.find(c => c.id === cotizacionId);
    if (!cotizacion || cotizacion.estado !== 'APROBADA') {
      alert("Solo se pueden generar órdenes de compra para cotizaciones aprobadas");
      return;
    }

    if (window.confirm("¿Confirma que desea generar la orden de compra para esta cotización?")) {
      const numeroOrden = `OC-${new Date().getFullYear()}-${String(cotizaciones.length + 1).padStart(3, '0')}`;
      
      setCotizaciones(prev => 
        prev.map(cot => 
          cot.id === cotizacionId 
            ? { 
                ...cot, 
                estado: 'ORDEN_GENERADA' as "BORRADOR" | "ENVIADA_PROVEEDOR" | "RECIBIDA" | "EN_REVISION" | "APROBADA" | "RECHAZADA" | "ORDEN_GENERADA" | "VENCIDA" | "CANCELADA",
                orden_compra_generada: numeroOrden,
                fecha_orden_compra: new Date().toISOString(),
                fecha_actualizacion: new Date().toISOString()
              }
            : cot
        )
      );

      alert(`✅ Orden de compra ${numeroOrden} generada exitosamente.`);
    }
  };

  const cotizacionesFiltradas = cotizaciones.filter((cot) =>
    Object.values(cot.info_proveedor)
      .concat([cot.numero_cotizacion, cot.estado, cot.numero_solicitud_compra || ""])
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'BORRADOR': return 'bg-secondary';
      case 'ENVIADA_PROVEEDOR': return 'bg-primary';
      case 'RECIBIDA': return 'bg-info';
      case 'EN_REVISION': return 'bg-warning text-dark';
      case 'APROBADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'ORDEN_GENERADA': return 'bg-dark';
      case 'VENCIDA': return 'bg-danger';
      case 'CANCELADA': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  const totalesCalculados = calcularTotales();

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Cotizaciones</h1>
            <p className="text-muted mb-0">Gestión de cotizaciones de proveedores</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-info">Sistema: Activo</span>
            <span className="badge bg-primary text-white">{cotizaciones.length} cotizaciones</span>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar por proveedor, número, estado..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-info d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Cotización</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Número</th>
                <th>Proveedor</th>
                <th>Solicitud</th>
                <th>Ítems</th>
                <th>Total</th>
                <th>Vencimiento</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {cotizacionesFiltradas.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-4">
                    <div className="text-muted">
                      No se encontraron cotizaciones
                    </div>
                  </td>
                </tr>
              )}
              {cotizacionesFiltradas.map((cot) => (
                <tr key={cot.id}>
                  <td>
                    <strong>{cot.numero_cotizacion}</strong>
                    <br />
                    <small className="text-muted">
                      <Calendar size={12} className="me-1" />
                      {cot.fecha_cotizacion}
                    </small>
                  </td>
                  <td>
                    <div>
                      <strong>{cot.info_proveedor.razon_social}</strong>
                      {cot.info_proveedor.nombre_comercial && (
                        <div className="small text-muted">{cot.info_proveedor.nombre_comercial}</div>
                      )}
                    </div>
                  </td>
                  <td>
                    {cot.numero_solicitud_compra ? (
                      <span className="badge bg-light text-dark">{cot.numero_solicitud_compra}</span>
                    ) : (
                      <span className="text-muted">-</span>
                    )}
                  </td>
                  <td>
                    <small className="text-muted">
                      <Package size={14} className="me-1" />
                      {cot.detalles.length} ítem{cot.detalles.length !== 1 ? 's' : ''}
                    </small>
                  </td>
                  <td className="text-end">
                    <strong>
                      <DollarSign size={14} className="me-1" />
                      {cot.total.toFixed(2)}
                    </strong>
                    <div className="small text-muted">{cot.moneda}</div>
                  </td>
                  <td>
                    <small className="text-muted">
                      <Clock size={12} className="me-1" />
                      {cot.fecha_vencimiento}
                    </small>
                  </td>
                  <td>
                    <div className="dropdown">
                      <span 
                        className={`badge ${getEstadoBadgeClass(cot.estado)} dropdown-toggle`}
                        data-bs-toggle="dropdown"
                        style={{ cursor: 'pointer' }}
                      >
                        {cot.estado.replace('_', ' ')}
                      </span>
                      <ul className="dropdown-menu">
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(cot.id, 'BORRADOR')}>Borrador</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(cot.id, 'ENVIADA_PROVEEDOR')}>Enviada a Proveedor</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(cot.id, 'RECIBIDA')}>Recibida</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(cot.id, 'EN_REVISION')}>En Revisión</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(cot.id, 'VENCIDA')}>Vencida</button></li>
                        <li><button className="dropdown-item" onClick={() => cambiarEstado(cot.id, 'CANCELADA')}>Cancelada</button></li>
                      </ul>
                    </div>
                  </td>
                  <td>
                    <div className="btn-group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => abrirModalEditar(cot)}
                        title="Ver detalles"
                      >
                        <Eye size={14} />
                      </button>
                      
                      {cot.estado === 'EN_REVISION' && cot.requiere_aprobacion && (
                        <button
                          className="btn btn-outline-success btn-sm"
                          onClick={() => abrirModalAprobacion(cot)}
                          title="Aprobar/Rechazar"
                        >
                          <CheckCircle size={14} />
                        </button>
                      )}
                      
                      {cot.estado === 'APROBADA' && !cot.orden_compra_generada && (
                        <button
                          className="btn btn-outline-primary btn-sm"
                          onClick={() => generarOrdenCompra(cot.id)}
                          title="Generar Orden"
                        >
                          <FileText size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(cot)}
                        title="Editar"
                        disabled={cot.estado === 'APROBADA' || cot.estado === 'ORDEN_GENERADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarCotizacion(cot.id)}
                        title="Eliminar"
                        disabled={cot.estado !== 'BORRADOR'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Modal para cotizaciones */}
        {showModal && (
          <div className="modal fade show d-block" style={{ zIndex: 1050 }}>
            <div className="modal-dialog modal-xl">
              <div className="modal-content">
                <form onSubmit={handleSubmit}>
                  <div className="modal-header bg-info text-white">
                    <h5 className="modal-title">
                      <FileText className="me-2" size={20} />
                      {editandoId ? "Editar Cotización" : "Nueva Cotización"}
                    </h5>
                    <button
                      type="button"
                      className="btn-close btn-close-white"
                      onClick={cerrarModal}
                      disabled={procesando}
                    />
                  </div>
                  
                  <div className="modal-body" style={{ maxHeight: '80vh', overflowY: 'auto' }}>
                    <div className="row g-3">
                      {/* Información general */}
                      <div className="col-12">
                        <h6 className="text-info border-bottom pb-2">
                          <FileText className="me-2" size={16} />
                          Información General
                        </h6>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="fecha_cotizacion" className="form-label">Fecha Cotización *</label>
                        <input
                          type="date"
                          className="form-control"
                          id="fecha_cotizacion"
                          name="fecha_cotizacion"
                          value={form.fecha_cotizacion}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="fecha_vencimiento" className="form-label">Fecha Vencimiento *</label>
                        <input
                          type="date"
                          className="form-control"
                          id="fecha_vencimiento"
                          name="fecha_vencimiento"
                          value={form.fecha_vencimiento}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="tipo_cotizacion" className="form-label">Tipo *</label>
                        <select
                          className="form-select"
                          id="tipo_cotizacion"
                          name="tipo_cotizacion"
                          value={form.tipo_cotizacion}
                          onChange={handleChange}
                          required
                        >
                          <option value="SOLICITUD_DIRECTA">Desde solicitud de compra</option>
                          <option value="COTIZACION_LIBRE">Cotización libre</option>
                          <option value="RENOVACION">Renovación de contrato</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="id_solicitud_compra" className="form-label">ID Solicitud Compra</label>
                        <input
                          type="number"
                          className="form-control"
                          id="id_solicitud_compra"
                          name="id_solicitud_compra"
                          value={form.id_solicitud_compra}
                          onChange={handleChange}
                          placeholder="Opcional"
                        />
                      </div>

                      {/* Información del proveedor */}
                      <div className="col-12">
                        <h6 className="text-info border-bottom pb-2 mt-3">Información del Proveedor</h6>
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="razon_social" className="form-label">Proveedor/Razón Social *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="razon_social"
                          name="razon_social"
                          value={form.razon_social}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="identificacion" className="form-label">RUC/Cédula *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="identificacion"
                          name="identificacion"
                          value={form.identificacion}
                          onChange={handleChange}
                          required
                        />
                      </div>

                      {/* Agregar productos/servicios */}
                      <div className="col-12">
                        <h6 className="text-info border-bottom pb-2 mt-3">
                          <Package className="me-2" size={16} />
                          Agregar Producto/Servicio Cotizado
                        </h6>
                      </div>
                      <div className="col-md-2">
                        <label htmlFor="codigo_producto" className="form-label">Código</label>
                        <input
                          type="text"
                          className="form-control"
                          id="codigo_producto"
                          name="codigo_producto"
                          value={form.codigo_producto}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="descripcion" className="form-label">Descripción *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="descripcion"
                          name="descripcion"
                          value={form.descripcion}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-md-2">
                        <label htmlFor="cantidad_cotizada" className="form-label">Cant. Cotizada</label>
                        <input
                          type="number"
                          className="form-control"
                          id="cantidad_cotizada"
                          name="cantidad_cotizada"
                          value={form.cantidad_cotizada}
                          onChange={handleChange}
                          min="1"
                        />
                      </div>
                      <div className="col-md-2">
                        <label htmlFor="precio_unitario" className="form-label">Precio Unit.</label>
                        <input
                          type="number"
                          className="form-control"
                          id="precio_unitario"
                          name="precio_unitario"
                          value={form.precio_unitario}
                          onChange={handleChange}
                          min="0"
                          step="0.01"
                        />
                      </div>
                      <div className="col-md-2">
                        <label htmlFor="tiempo_entrega_dias" className="form-label">Días Entrega</label>
                        <input
                          type="number"
                          className="form-control"
                          id="tiempo_entrega_dias"
                          name="tiempo_entrega_dias"
                          value={form.tiempo_entrega_dias}
                          onChange={handleChange}
                          min="1"
                        />
                      </div>
                      <div className="col-md-1">
                        <label htmlFor="agregar_producto_cotizacion" className="form-label">Agregar</label>
                        <button
                          type="button"
                          className="btn btn-info w-100"
                          onClick={agregarDetalle}
                          id="agregar_producto_cotizacion"
                        >
                          <Plus size={16} />
                        </button>
                      </div>

                      {/* Lista de productos cotizados */}
                      {detallesTemp.length > 0 && (
                        <>
                          <div className="col-12">
                            <h6 className="text-info border-bottom pb-2 mt-3">Productos/Servicios Cotizados</h6>
                          </div>
                          <div className="col-12">
                            <div className="table-responsive">
                              <table className="table table-sm">
                                <thead className="table-light">
                                  <tr>
                                    <th>Descripción</th>
                                    <th>Cantidad</th>
                                    <th>Precio Unit.</th>
                                    <th>Subtotal</th>
                                    <th>Días Entrega</th>
                                    <th>Acción</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {detallesTemp.map((detalle) => (
                                    <tr key={detalle.id}>
                                      <td>{detalle.descripcion}</td>
                                      <td>{detalle.cantidad_cotizada}</td>
                                      <td>${detalle.precio_unitario.toFixed(2)}</td>
                                      <td>${detalle.subtotal.toFixed(2)}</td>
                                      <td>{detalle.tiempo_entrega_dias}d</td>
                                      <td>
                                        <button
                                          type="button"
                                          className="btn btn-outline-danger btn-sm"
                                          onClick={() => eliminarDetalle(detalle.id)}
                                        >
                                          <Minus size={14} />
                                        </button>
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                                <tfoot className="table-light">
                                  <tr>
                                    <td colSpan={3} className="text-end fw-bold">Total:</td>
                                    <td className="fw-bold">${totalesCalculados.total.toFixed(2)}</td>
                                    <td colSpan={2}></td>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>
                          </div>
                        </>
                      )}

                      {/* Condiciones comerciales */}
                      <div className="col-12">
                        <h6 className="text-info border-bottom pb-2 mt-3">Condiciones Comerciales</h6>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="forma_pago" className="form-label">Forma de Pago</label>
                        <select
                          className="form-select"
                          id="forma_pago"
                          name="forma_pago"
                          value={form.forma_pago}
                          onChange={handleChange}
                        >
                          <option value="CONTADO">Contado</option>
                          <option value="CREDITO_15">Crédito 15 días</option>
                          <option value="CREDITO_30">Crédito 30 días</option>
                          <option value="CREDITO_45">Crédito 45 días</option>
                          <option value="CREDITO_60">Crédito 60 días</option>
                          <option value="CREDITO_90">Crédito 90 días</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="garantia_meses" className="form-label">Garantía (meses)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="garantia_meses"
                          name="garantia_meses"
                          value={form.garantia_meses}
                          onChange={handleChange}
                          min="0"
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="vigencia_precio_dias" className="form-label">Vigencia Precio (días)</label>
                        <input
                          type="number"
                          className="form-control"
                          id="vigencia_precio_dias"
                          name="vigencia_precio_dias"
                          value={form.vigencia_precio_dias}
                          onChange={handleChange}
                          min="1"
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="moneda" className="form-label">Moneda</label>
                        <select
                          className="form-select"
                          id="moneda"
                          name="moneda"
                          value={form.moneda}
                          onChange={handleChange}
                        >
                          <option value="USD">USD - Dólares</option>
                          <option value="EUR">EUR - Euros</option>
                        </select>
                      </div>

                      {/* Servicios incluidos */}
                      <div className="col-12">
                        <div className="row">
                          <div className="col-md-4">
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="incluye_instalacion"
                                name="incluye_instalacion"
                                checked={form.incluye_instalacion}
                                onChange={handleChange}
                              />
                              <label className="form-check-label" htmlFor="incluye_instalacion">
                                Incluye instalación
                              </label>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="incluye_capacitacion"
                                name="incluye_capacitacion"
                                checked={form.incluye_capacitacion}
                                onChange={handleChange}
                              />
                              <label className="form-check-label" htmlFor="incluye_capacitacion">
                                Incluye capacitación
                              </label>
                            </div>
                          </div>
                          <div className="col-md-4">
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="incluye_soporte"
                                name="incluye_soporte"
                                checked={form.incluye_soporte}
                                onChange={handleChange}
                              />
                              <label className="form-check-label" htmlFor="incluye_soporte">
                                Incluye soporte técnico
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Observaciones */}
                      <div className="col-12">
                        <label htmlFor="observaciones_generales" className="form-label">Observaciones Generales</label>
                        <textarea
                          className="form-control"
                          id="observaciones_generales"
                          name="observaciones_generales"
                          rows={3}
                          value={form.observaciones_generales}
                          onChange={handleChange}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={cerrarModal}
                      disabled={procesando}
                    >
                      Cancelar
                    </button>
                    <button 
                      type="submit" 
                      className="btn btn-info"
                      disabled={procesando}
                    >
                      {(() => {
                        if (procesando) return 'Guardando...';
                        if (editandoId) return 'Actualizar Cotización';
                        return 'Crear Cotización';
                      })()}
                    </button>
                  </div>
                </form>
              </div>
            </div>
            <div className="modal-backdrop fade show"></div>
          </div>
        )}

        {/* Modal de aprobación */}
        {showApprovalModal && cotizacionAprobacion && (
          <div className="modal fade show d-block" style={{ zIndex: 1051 }}>
            <div className="modal-dialog">
              <div className="modal-content">
                <div className="modal-header bg-warning text-dark">
                  <h5 className="modal-title">
                    <CheckCircle className="me-2" size={20} />
                    Aprobación de Cotización
                  </h5>
                  <button
                    type="button"
                    className="btn-close"
                    onClick={cerrarModal}
                  />
                </div>
                
                <div className="modal-body">
                  <div className="mb-3">
                    <h6>Cotización: {cotizacionAprobacion.numero_cotizacion}</h6>
                    <p className="text-muted">Proveedor: {cotizacionAprobacion.info_proveedor.razon_social}</p>
                    <p className="text-muted">Total: ${cotizacionAprobacion.total.toFixed(2)}</p>
                  </div>
                  
                  <div className="mb-3">
                    <label htmlFor="observaciones_aprobacion" className="form-label">Observaciones</label>
                    <textarea
                      className="form-control"
                      id="observaciones_aprobacion"
                      rows={3}
                      placeholder="Ingrese observaciones sobre la aprobación/rechazo..."
                    />
                  </div>
                </div>
                
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={cerrarModal}
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => {
                      const observaciones = (document.getElementById('observaciones_aprobacion') as HTMLTextAreaElement)?.value || '';
                      procesarAprobacion(false, observaciones);
                    }}
                  >
                    <XCircle className="me-1" size={16} />
                    Rechazar
                  </button>
                  <button
                    type="button"
                    className="btn btn-success"
                    onClick={() => {
                      const observaciones = (document.getElementById('observaciones_aprobacion') as HTMLTextAreaElement)?.value || '';
                      procesarAprobacion(true, observaciones);
                    }}
                  >
                    <CheckCircle className="me-1" size={16} />
                    Aprobar
                  </button>
                </div>
              </div>
            </div>
            <div className="modal-backdrop fade show"></div>
          </div>
        )}
      </div>
    </div>
  );
}
