// Estados de las cotizaciones
export const estadosCotizacion = {
  "BORRADOR": "Borrador",
  "ENVIADA_PROVEEDOR": "Enviada al proveedor",
  "RECIBIDA": "Recibida del proveedor",
  "EN_REVISION": "En revisión",
  "APROBADA": "Aprobada",
  "RECHAZADA": "Rechazada",
  "ORDEN_GENERADA": "Orden de compra generada",
  "VENCIDA": "Vencida",
  "CANCELADA": "Cancelada"
} as const;

// Tipos de cotización
export const tiposCotizacion = {
  "SOLICITUD_DIRECTA": "Desde solicitud de compra",
  "COTIZACION_LIBRE": "Cotización libre",
  "RENOVACION": "Renovación de contrato"
} as const;

// Validez de cotizaciones
export const validezCotizacion = {
  "7": "7 días",
  "15": "15 días",
  "30": "30 días",
  "45": "45 días",
  "60": "60 días",
  "90": "90 días"
} as const;

// Tipos de moneda
export const tiposMoneda = {
  "USD": "Dólares americanos",
  "EUR": "Euros"
} as const;

// Interface para información del proveedor en cotización
export interface InfoProveedorCotizacion {
  id_proveedor?: string;
  tipo_identificacion: string;
  identificacion: string;
  razon_social: string;
  nombre_comercial?: string;
  direccion: string;
  telefono?: string;
  email?: string;
  contacto_principal?: string;
  telefono_contacto?: string;
  email_contacto?: string;
}

// Interface para el detalle de productos cotizados
export interface DetalleCotizacion {
  id: string;
  id_detalle_solicitud?: string; // Referencia al detalle de solicitud original
  codigo_producto?: string;
  descripcion: string;
  especificaciones_tecnicas?: string;
  unidad_medida: string;
  cantidad_solicitada: number;
  cantidad_cotizada: number;
  precio_unitario: number;
  descuento_porcentaje: number;
  precio_neto: number;
  subtotal: number;
  tiempo_entrega_dias: number;
  observaciones_proveedor?: string;
  observaciones_internas?: string;
  estado_item: "PENDIENTE" | "COTIZADO" | "APROBADO" | "RECHAZADO";
  alternativo?: boolean; // Si es producto alternativo propuesto por proveedor
}

// Interface para condiciones comerciales
export interface CondicionesCotizacion {
  forma_pago: string;
  tiempo_entrega_dias: number;
  lugar_entrega: string;
  garantia_meses?: number;
  incluye_instalacion: boolean;
  incluye_capacitacion: boolean;
  incluye_soporte: boolean;
  vigencia_precio_dias: number;
  observaciones_comerciales?: string;
}

// Interface principal para cotización
export interface Cotizacion {
  id: number;
  numero_cotizacion: string;
  fecha_cotizacion: string;
  fecha_vencimiento: string;
  estado: keyof typeof estadosCotizacion;
  tipo_cotizacion: keyof typeof tiposCotizacion;
  
  // Referencia a solicitud de compra
  id_solicitud_compra?: number;
  numero_solicitud_compra?: string;
  
  // Información del proveedor
  info_proveedor: InfoProveedorCotizacion;
  
  // Detalles de productos/servicios
  detalles: DetalleCotizacion[];
  
  // Condiciones comerciales
  condiciones: CondicionesCotizacion;
  
  // Totales
  subtotal: number;
  descuento_total: number;
  subtotal_neto: number;
  iva: number;
  total: number;
  
  // Información de gestión
  moneda: keyof typeof tiposMoneda;
  observaciones_generales?: string;
  archivo_cotizacion?: string; // PDF de cotización del proveedor
  
  // Información de seguimiento
  solicitado_por: string;
  centro_costo: string;
  responsable_negociacion: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
  
  // Aprobación
  requiere_aprobacion: boolean;
  aprobado_por?: string;
  fecha_aprobacion?: string;
  observaciones_aprobacion?: string;
  
  // Referencia a orden de compra
  orden_compra_generada?: string;
  fecha_orden_compra?: string;
}

// Interface para el formulario de cotización
export interface CotizacionFormValues {
  fecha_cotizacion: string;
  fecha_vencimiento: string;
  tipo_cotizacion: string;
  id_solicitud_compra: string;
  
  // Proveedor
  tipo_identificacion: string;
  identificacion: string;
  razon_social: string;
  nombre_comercial: string;
  direccion: string;
  telefono: string;
  email: string;
  contacto_principal: string;
  telefono_contacto: string;
  email_contacto: string;
  
  // Producto/servicio temporal
  codigo_producto: string;
  descripcion: string;
  especificaciones_tecnicas: string;
  unidad_medida: string;
  cantidad_solicitada: number;
  cantidad_cotizada: number;
  precio_unitario: number;
  descuento_porcentaje: number;
  tiempo_entrega_dias: number;
  observaciones_proveedor: string;
  observaciones_internas: string;
  
  // Condiciones comerciales
  forma_pago: string;
  tiempo_entrega_general: number;
  lugar_entrega: string;
  garantia_meses: number;
  incluye_instalacion: boolean;
  incluye_capacitacion: boolean;
  incluye_soporte: boolean;
  vigencia_precio_dias: number;
  observaciones_comerciales: string;
  
  // Información adicional
  moneda: string;
  observaciones_generales: string;
  responsable_negociacion: string;
  requiere_aprobacion: boolean;
}

// Interface para la aprobación de cotizaciones
export interface AprobacionCotizacion {
  id_cotizacion: number;
  aprobado: boolean;
  observaciones: string;
  aprobado_por: string;
  fecha_aprobacion: string;
}

// Interface para comparación de cotizaciones
export interface ComparacionCotizaciones {
  solicitud_compra: string;
  cotizaciones: Cotizacion[];
  criterios_evaluacion: {
    precio: number; // peso porcentual
    tiempo_entrega: number;
    calidad_proveedor: number;
    condiciones_pago: number;
    garantia: number;
  };
  recomendacion?: number; // ID de cotización recomendada
}

// Tipos derivados
export type EstadoCotizacion = keyof typeof estadosCotizacion;
export type TipoCotizacion = keyof typeof tiposCotizacion;
export type ValidezCotizacion = keyof typeof validezCotizacion;
export type TipoMoneda = keyof typeof tiposMoneda;
