// Tipos de identificación para proveedores
export const tiposIdentificacionProveedor = {
  "04": "RUC",
  "05": "Cédula",
  "06": "Pasaporte",
  "07": "Venta a consumidor final",
  "08": "Identificación del exterior"
} as const;

// Estados de las solicitudes de compra
export const estadosSolicitudCompra = {
  "BORRADOR": "Borrador",
  "ENVIADA": "Enviada al proveedor",
  "EN_NEGOCIACION": "En negociación",
  "COTIZADA": "Cotizada",
  "APROBADA": "Aprobada",
  "RECHAZADA": "Rechazada",
  "ORDEN_GENERADA": "Orden de compra generada",
  "CANCELADA": "Cancelada"
} as const;

// Prioridades de las solicitudes
export const prioridadesCompra = {
  "BAJA": "Baja",
  "NORMAL": "Normal", 
  "ALTA": "Alta",
  "URGENTE": "Urgente"
} as const;

// Tipos de solicitud de compra
export const tiposSolicitudCompra = {
  "PRODUCTOS": "Solo productos",
  "SERVICIOS": "Solo servicios", 
  "MIXTA": "Productos y servicios"
} as const;

// Centros de costo o departamentos
export const centrosCosto = {
  "ADM": "Administración",
  "VEN": "Ventas",
  "PRO": "Producción", 
  "LOG": "Logística",
  "SIS": "Sistemas",
  "MAN": "Mantenimiento"
} as const;

// Formas de pago preferidas
export const formasPago = {
  "CONTADO": "Contado",
  "CREDITO_15": "Crédito 15 días",
  "CREDITO_30": "Crédito 30 días",
  "CREDITO_45": "Crédito 45 días",
  "CREDITO_60": "Crédito 60 días",
  "CREDITO_90": "Crédito 90 días"
} as const;

// Tipos de entrega
export const tiposEntrega = {
  "RETIRO_PROVEEDOR": "Retiro en proveedor",
  "ENTREGA_EMPRESA": "Entrega en empresa",
  "OBRA_PROYECTO": "Entrega en obra/proyecto"
} as const;

// Interface para información del proveedor
export interface InfoProveedor {
  tipo_identificacion: keyof typeof tiposIdentificacionProveedor;
  identificacion: string;
  razon_social: string;
  nombre_comercial?: string;
  direccion: string;
  telefono?: string;
  email?: string;
  contacto_principal?: string;
  telefono_contacto?: string;
  email_contacto?: string;
}

// Interface para el detalle de productos/servicios solicitados
export interface DetalleCompra {
  id: string;
  codigo_producto?: string;
  descripcion: string;
  especificaciones_tecnicas?: string;
  unidad_medida: string;
  cantidad_solicitada: number;
  precio_referencial?: number;
  precio_cotizado?: number;
  descuento_porcentaje: number;
  subtotal_referencial: number;
  subtotal_cotizado?: number;
  fecha_entrega_requerida?: string;
  observaciones?: string;
  estado_item: "PENDIENTE" | "COTIZADO" | "APROBADO" | "RECHAZADO";
}

// Interface principal para solicitud de compra
export interface SolicitudCompra {
  id: number;
  numero_solicitud: string;
  fecha_solicitud: string;
  fecha_entrega_requerida: string;
  estado: keyof typeof estadosSolicitudCompra;
  prioridad: keyof typeof prioridadesCompra;
  tipo_solicitud: keyof typeof tiposSolicitudCompra;
  centro_costo: keyof typeof centrosCosto;
  forma_pago_preferida: keyof typeof formasPago;
  tipo_entrega: keyof typeof tiposEntrega;
  lugar_entrega?: string;
  
  // Información del proveedor
  info_proveedor: InfoProveedor;
  
  // Detalles de productos/servicios
  detalles: DetalleCompra[];
  
  // Totales
  subtotal_referencial: number;
  descuento_total: number;
  iva: number;
  total_referencial: number;
  subtotal_cotizado?: number;
  total_cotizado?: number;
  
  // Información adicional
  justificacion_compra: string;
  observaciones_generales?: string;
  archivo_especificaciones?: string;
  
  // Información de seguimiento
  solicitado_por: string;
  departamento_solicitante: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
  aprobado_por?: string;
  fecha_aprobacion?: string;
  
  // Referencia a orden de compra
  orden_compra_generada?: string;
  fecha_orden_compra?: string;
}

// Interface para el formulario
export interface SolicitudCompraFormValues {
  fecha_solicitud: string;
  fecha_entrega_requerida: string;
  prioridad: string;
  tipo_solicitud: string;
  centro_costo: string;
  forma_pago_preferida: string;
  tipo_entrega: string;
  lugar_entrega: string;
  
  // Proveedor
  tipo_identificacion: string;
  identificacion: string;
  razon_social: string;
  nombre_comercial: string;
  direccion: string;
  telefono: string;
  email: string;
  contacto_principal: string;
  telefono_contacto: string;
  email_contacto: string;
  
  // Producto/servicio temporal
  codigo_producto: string;
  descripcion: string;
  especificaciones_tecnicas: string;
  unidad_medida: string;
  cantidad_solicitada: number;
  precio_referencial: number;
  descuento_porcentaje: number;
  fecha_entrega_requerida_item: string;
  observaciones_producto: string;
  
  // Información adicional
  justificacion_compra: string;
  observaciones_generales: string;
  solicitado_por: string;
  departamento_solicitante: string;
}

// Interface para filtros de búsqueda
export interface FiltrosSolicitudCompra {
  texto: string;
  estado?: keyof typeof estadosSolicitudCompra;
  prioridad?: keyof typeof prioridadesCompra;
  centro_costo?: keyof typeof centrosCosto;
  fecha_desde?: string;
  fecha_hasta?: string;
  proveedor?: string;
}

// Interface para resumen/estadísticas
export interface ResumenSolicitudesCompra {
  total_solicitudes: number;
  por_estado: Record<keyof typeof estadosSolicitudCompra, number>;
  por_prioridad: Record<keyof typeof prioridadesCompra, number>;
  total_valor_referencial: number;
  total_valor_cotizado: number;
  promedio_dias_aprobacion: number;
}

// Tipos derivados para mayor seguridad de tipos
export type EstadoSolicitudCompra = keyof typeof estadosSolicitudCompra;
export type PrioridadSolicitudCompra = keyof typeof prioridadesCompra;
export type TipoSolicitudCompra = keyof typeof tiposSolicitudCompra;
export type CentroCosto = keyof typeof centrosCosto;
export type FormaPago = keyof typeof formasPago;
export type TipoEntrega = keyof typeof tiposEntrega;
