import { AppShell } from "@/components/app-shell";
import SolicitudesCompraPage from "./SolicitudesCompraPage";

export default function Page() {
  return <AppShell><SolicitudesCompraPage /></AppShell>;
}
