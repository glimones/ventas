// Estados de las órdenes de compra
export const estadosOrdenCompra = {
  "BORRADOR": "Borrador",
  "EMITIDA": "Emitida",
  "ENVIADA": "Enviada al proveedor",
  "CONFIRMADA": "Confirmada por proveedor",
  "EN_PROCESO": "En proceso de entrega",
  "RECIBIDA_PARCIAL": "Recibida parcial",
  "RECIBIDA_TOTAL": "Recibida total",
  "FACTURADA": "Facturada",
  "PAGADA": "Pagada",
  "CANCELADA": "Cancelada",
  "ANULADA": "Anulada"
} as const;

// Tipos de orden de compra
export const tiposOrdenCompra = {
  "DESDE_COTIZACION": "Desde cotización aprobada",
  "ORDEN_DIRECTA": "Orden directa",
  "ORDEN_URGENTE": "Orden urgente",
  "CONTRATO_MARCO": "Desde contrato marco"
} as const;

// Prioridades de la orden
export const prioridadesOrden = {
  "BAJA": "Baja",
  "NORMAL": "Normal",
  "ALTA": "Alta",
  "URGENTE": "Urgente"
} as const;

// Términos de entrega (Incoterms)
export const terminosEntrega = {
  "EXW": "Ex Works (En fábrica)",
  "FCA": "Free Carrier (Franco transportista)",
  "CPT": "Carriage Paid To (Transporte pagado hasta)",
  "CIP": "Carriage and Insurance Paid (Transporte y seguro pagados hasta)",
  "DAP": "Delivered at Place (Entregado en lugar)",
  "DPU": "Delivered at Place Unloaded (Entregado en lugar descargado)",
  "DDP": "Delivered Duty Paid (Entregado derechos pagados)"
} as const;

// Estados de recepción por ítem
export const estadosRecepcion = {
  "PENDIENTE": "Pendiente de recepción",
  "PARCIAL": "Recibido parcial",
  "COMPLETO": "Recibido completo",
  "DEVUELTO": "Devuelto",
  "DEFECTUOSO": "Defectuoso"
} as const;

// Interface para información del proveedor en orden
export interface InfoProveedorOrden {
  id_proveedor?: string;
  tipo_identificacion: string;
  identificacion: string;
  razon_social: string;
  nombre_comercial?: string;
  direccion: string;
  direccion_entrega?: string;
  telefono?: string;
  email?: string;
  contacto_principal?: string;
  telefono_contacto?: string;
  email_contacto?: string;
}

// Interface para el detalle de productos en orden
export interface DetalleOrdenCompra {
  id: string;
  id_detalle_cotizacion?: string; // Referencia al detalle de cotización
  codigo_producto?: string;
  descripcion: string;
  especificaciones_tecnicas?: string;
  unidad_medida: string;
  cantidad_ordenada: number;
  cantidad_recibida: number;
  cantidad_pendiente: number;
  precio_unitario: number;
  descuento_porcentaje: number;
  precio_neto: number;
  subtotal: number;
  fecha_entrega_programada: string;
  fecha_entrega_real?: string;
  estado_recepcion: keyof typeof estadosRecepcion;
  observaciones_recepcion?: string;
  numero_lote?: string;
  numero_serie?: string;
  observaciones?: string;
}

// Interface para términos y condiciones
export interface TerminosOrdenCompra {
  forma_pago: string;
  plazo_pago_dias: number;
  terminos_entrega: keyof typeof terminosEntrega;
  lugar_entrega: string;
  fecha_entrega_requerida: string;
  garantia_meses: number;
  penalizacion_retraso_porcentaje?: number;
  observaciones_especiales?: string;
  requiere_orden_firmada: boolean;
  requiere_factura_original: boolean;
  requiere_certificados: boolean;
  descuentos_pronto_pago?: string;
}

// Interface para seguimiento de recepción
export interface SeguimientoRecepcion {
  id: string;
  fecha_recepcion: string;
  cantidad_recibida: number;
  estado_mercancia: "CONFORME" | "NO_CONFORME" | "DEFECTUOSA";
  recibido_por: string;
  observaciones: string;
  numero_albaran?: string;
  numero_factura?: string;
}

// Interface principal para orden de compra
export interface OrdenCompra {
  id: number;
  numero_orden: string;
  fecha_orden: string;
  fecha_entrega_requerida: string;
  estado: keyof typeof estadosOrdenCompra;
  tipo_orden: keyof typeof tiposOrdenCompra;
  prioridad: keyof typeof prioridadesOrden;
  
  // Referencias
  id_cotizacion?: number;
  numero_cotizacion?: string;
  id_solicitud_compra?: number;
  numero_solicitud_compra?: string;
  
  // Información del proveedor
  info_proveedor: InfoProveedorOrden;
  
  // Detalles de productos/servicios
  detalles: DetalleOrdenCompra[];
  
  // Términos y condiciones
  terminos: TerminosOrdenCompra;
  
  // Totales
  subtotal: number;
  descuento_total: number;
  subtotal_neto: number;
  iva: number;
  total: number;
  
  // Información adicional
  moneda: "USD" | "EUR";
  observaciones_generales?: string;
  archivo_orden_firmada?: string;
  
  // Seguimiento de recepción
  recepciones: SeguimientoRecepcion[];
  porcentaje_recibido: number;
  
  // Información de gestión
  generado_por: string;
  autorizado_por?: string;
  fecha_autorizacion?: string;
  centro_costo: string;
  proyecto?: string;
  
  // Fechas de seguimiento
  fecha_creacion: string;
  fecha_actualizacion: string;
  fecha_envio_proveedor?: string;
  fecha_confirmacion_proveedor?: string;
  fecha_entrega_real?: string;
  
  // Información financiera
  numero_factura_proveedor?: string;
  fecha_factura?: string;
  monto_facturado?: number;
  fecha_pago?: string;
  numero_cheque_transferencia?: string;
}

// Interface para el formulario de orden de compra
export interface OrdenCompraFormValues {
  fecha_orden: string;
  fecha_entrega_requerida: string;
  tipo_orden: string;
  prioridad: string;
  id_cotizacion: string;
  
  // Proveedor
  tipo_identificacion: string;
  identificacion: string;
  razon_social: string;
  nombre_comercial: string;
  direccion: string;
  direccion_entrega: string;
  telefono: string;
  email: string;
  contacto_principal: string;
  telefono_contacto: string;
  email_contacto: string;
  
  // Producto/servicio temporal
  codigo_producto: string;
  descripcion: string;
  especificaciones_tecnicas: string;
  unidad_medida: string;
  cantidad_ordenada: number;
  precio_unitario: number;
  descuento_porcentaje: number;
  fecha_entrega_programada: string;
  observaciones: string;
  
  // Términos y condiciones
  forma_pago: string;
  plazo_pago_dias: number;
  terminos_entrega: string;
  lugar_entrega: string;
  garantia_meses: number;
  penalizacion_retraso_porcentaje: number;
  observaciones_especiales: string;
  requiere_orden_firmada: boolean;
  requiere_factura_original: boolean;
  requiere_certificados: boolean;
  descuentos_pronto_pago: string;
  
  // Información adicional
  moneda: string;
  observaciones_generales: string;
  centro_costo: string;
  proyecto: string;
}

// Interface para recepción de mercancías
export interface RecepcionMercancia {
  id_orden_compra: number;
  detalles_recepcion: {
    id_detalle: string;
    cantidad_recibida: number;
    estado_mercancia: "CONFORME" | "NO_CONFORME" | "DEFECTUOSA";
    observaciones: string;
    numero_lote?: string;
    numero_serie?: string;
  }[];
  recibido_por: string;
  fecha_recepcion: string;
  numero_albaran?: string;
  observaciones_generales: string;
}

// Interface para autorización de orden
export interface AutorizacionOrden {
  id_orden_compra: number;
  autorizado: boolean;
  observaciones: string;
  autorizado_por: string;
  fecha_autorizacion: string;
}

// Interface para seguimiento financiero
export interface SeguimientoFinanciero {
  id_orden_compra: number;
  numero_factura_proveedor: string;
  fecha_factura: string;
  monto_facturado: number;
  fecha_vencimiento_pago: string;
  fecha_pago?: string;
  numero_cheque_transferencia?: string;
  observaciones_pago?: string;
}

// Tipos derivados
export type EstadoOrdenCompra = keyof typeof estadosOrdenCompra;
export type TipoOrdenCompra = keyof typeof tiposOrdenCompra;
export type PrioridadOrden = keyof typeof prioridadesOrden;
export type TerminoEntrega = keyof typeof terminosEntrega;
export type EstadoRecepcion = keyof typeof estadosRecepcion;
