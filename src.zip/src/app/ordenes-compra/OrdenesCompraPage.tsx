"use client";

import React, { useState } from "react";
import { OrdenCompra, OrdenCompraFormValues, DetalleOrdenCompra } from "./types";
import "./ordenes-compra.css";
import "./bootstrap-ordenes-compra.css";
import { CirclePlus, SquarePen, Trash2, Eye, Package, DollarSign, Clock, CheckCircle, Truck, CreditCard, AlertTriangle } from 'lucide-react';

const OrdenesCompraPage: React.FC = () => {
  const [ordenes, setOrdenes] = useState<OrdenCompra[]>([
    {
      id: 1,
      numero_orden: "OC-2024-001",
      fecha_orden: "2024-01-15",
      fecha_entrega_requerida: "2024-02-15",
      estado: "CONFIRMADA",
      tipo_orden: "DESDE_COTIZACION",
      prioridad: "NORMAL",
      id_cotizacion: 1,
      numero_cotizacion: "COT-2024-001",
      id_solicitud_compra: 1,
      numero_solicitud_compra: "SC-2024-001",
      info_proveedor: {
        tipo_identificacion: "RUC",
        identificacion: "20123456789",
        razon_social: "Proveedores SA",
        nombre_comercial: "Proveedores",
        direccion: "Av. Industrial 123",
        telefono: "01-234-5678",
        email: "ventas@proveedores.com",
        contacto_principal: "Juan Pérez"
      },
      detalles: [
        {
          id: "1",
          codigo_producto: "PROD-001",
          descripcion: "Laptop Dell Inspiron",
          unidad_medida: "UND",
          cantidad_ordenada: 5,
          cantidad_recibida: 0,
          cantidad_pendiente: 5,
          precio_unitario: 2500.00,
          descuento_porcentaje: 0,
          precio_neto: 2500.00,
          subtotal: 12500.00,
          especificaciones_tecnicas: "Core i7, 16GB RAM, 512GB SSD",
          fecha_entrega_programada: "2024-02-10",
          estado_recepcion: "PENDIENTE"
        }
      ],
      terminos: {
        forma_pago: "CREDITO",
        plazo_pago_dias: 30,
        terminos_entrega: "DDP",
        lugar_entrega: "Oficinas Lima",
        fecha_entrega_requerida: "2024-02-15",
        garantia_meses: 24,
        penalizacion_retraso_porcentaje: 0.5,
        observaciones_especiales: "Entrega en horario de oficina",
        requiere_orden_firmada: true,
        requiere_factura_original: true,
        requiere_certificados: false
      },
      subtotal: 12500.00,
      descuento_total: 0,
      subtotal_neto: 12500.00,
      iva: 2250.00,
      total: 14750.00,
      moneda: "USD",
      recepciones: [],
      porcentaje_recibido: 0,
      generado_por: "admin",
      centro_costo: "TI-001",
      fecha_creacion: "2024-01-15T10:00:00Z",
      fecha_actualizacion: "2024-01-15T10:00:00Z"
    }
  ]);

  // Estados para modales y formularios - se utilizarán en futuras implementaciones
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [showModal, setShowModal] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [modalType, setModalType] = useState<'create' | 'edit' | 'view' | 'approve' | 'receive' | 'finance'>('create');
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [selectedOrden, setSelectedOrden] = useState<OrdenCompra | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [showRecepcionModal, setShowRecepcionModal] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [showFinanceModal, setShowFinanceModal] = useState(false);

  const defaultFormValues: OrdenCompraFormValues = {
    fecha_orden: new Date().toISOString().split('T')[0],
    fecha_entrega_requerida: "",
    tipo_orden: "ORDEN_DIRECTA",
    prioridad: "NORMAL",
    id_cotizacion: "",
    
    // Proveedor
    tipo_identificacion: "RUC",
    identificacion: "",
    razon_social: "",
    nombre_comercial: "",
    direccion: "",
    direccion_entrega: "",
    telefono: "",
    email: "",
    contacto_principal: "",
    telefono_contacto: "",
    email_contacto: "",
    
    // Producto/servicio temporal
    codigo_producto: "",
    descripcion: "",
    especificaciones_tecnicas: "",
    unidad_medida: "",
    cantidad_ordenada: 0,
    precio_unitario: 0,
    descuento_porcentaje: 0,
    fecha_entrega_programada: "",
    observaciones: "",
    
    // Términos y condiciones
    forma_pago: "CONTADO",
    plazo_pago_dias: 0,
    terminos_entrega: "EXW",
    lugar_entrega: "",
    garantia_meses: 0,
    penalizacion_retraso_porcentaje: 0,
    observaciones_especiales: "",
    requiere_orden_firmada: false,
    requiere_factura_original: false,
    requiere_certificados: false,
    descuentos_pronto_pago: "",
    
    // Información adicional
    moneda: "USD",
    observaciones_generales: "",
    centro_costo: "",
    proyecto: ""
  };

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [formValues, setFormValues] = useState<OrdenCompraFormValues>(defaultFormValues);

  const handleCreate = () => {
    setModalType('create');
    setFormValues(defaultFormValues);
    setSelectedOrden(null);
    setShowModal(true);
  };

  const handleEdit = (orden: OrdenCompra) => {
    setModalType('edit');
    // Convertir OrdenCompra a OrdenCompraFormValues
    const formData: OrdenCompraFormValues = {
      fecha_orden: orden.fecha_orden,
      fecha_entrega_requerida: orden.fecha_entrega_requerida,
      tipo_orden: orden.tipo_orden,
      prioridad: orden.prioridad,
      id_cotizacion: orden.id_cotizacion?.toString() || "",
      
      // Proveedor
      tipo_identificacion: orden.info_proveedor.tipo_identificacion,
      identificacion: orden.info_proveedor.identificacion,
      razon_social: orden.info_proveedor.razon_social,
      nombre_comercial: orden.info_proveedor.nombre_comercial || "",
      direccion: orden.info_proveedor.direccion,
      direccion_entrega: orden.info_proveedor.direccion_entrega || "",
      telefono: orden.info_proveedor.telefono || "",
      email: orden.info_proveedor.email || "",
      contacto_principal: orden.info_proveedor.contacto_principal || "",
      telefono_contacto: orden.info_proveedor.telefono_contacto || "",
      email_contacto: orden.info_proveedor.email_contacto || "",
      
      // Producto/servicio temporal (usar el primer detalle como ejemplo)
      codigo_producto: orden.detalles[0]?.codigo_producto || "",
      descripcion: orden.detalles[0]?.descripcion || "",
      especificaciones_tecnicas: orden.detalles[0]?.especificaciones_tecnicas || "",
      unidad_medida: orden.detalles[0]?.unidad_medida || "",
      cantidad_ordenada: orden.detalles[0]?.cantidad_ordenada || 0,
      precio_unitario: orden.detalles[0]?.precio_unitario || 0,
      descuento_porcentaje: orden.detalles[0]?.descuento_porcentaje || 0,
      fecha_entrega_programada: orden.detalles[0]?.fecha_entrega_programada || "",
      observaciones: orden.detalles[0]?.observaciones || "",
      
      // Términos y condiciones
      forma_pago: orden.terminos.forma_pago,
      plazo_pago_dias: orden.terminos.plazo_pago_dias,
      terminos_entrega: orden.terminos.terminos_entrega,
      lugar_entrega: orden.terminos.lugar_entrega,
      garantia_meses: orden.terminos.garantia_meses,
      penalizacion_retraso_porcentaje: orden.terminos.penalizacion_retraso_porcentaje || 0,
      observaciones_especiales: orden.terminos.observaciones_especiales || "",
      requiere_orden_firmada: orden.terminos.requiere_orden_firmada,
      requiere_factura_original: orden.terminos.requiere_factura_original,
      requiere_certificados: orden.terminos.requiere_certificados,
      descuentos_pronto_pago: orden.terminos.descuentos_pronto_pago || "",
      
      // Información adicional
      moneda: orden.moneda,
      observaciones_generales: orden.observaciones_generales || "",
      centro_costo: orden.centro_costo,
      proyecto: orden.proyecto || ""
    };
    setFormValues(formData);
    setSelectedOrden(orden);
    setShowModal(true);
  };

  const handleView = (orden: OrdenCompra) => {
    setModalType('view');
    setSelectedOrden(orden);
    setShowModal(true);
  };

  const handleApprove = (orden: OrdenCompra) => {
    setModalType('approve');
    setSelectedOrden(orden);
    setShowModal(true);
  };

  const handleReceive = (orden: OrdenCompra) => {
    setSelectedOrden(orden);
    setShowRecepcionModal(true);
  };

  const handleFinance = (orden: OrdenCompra) => {
    setSelectedOrden(orden);
    setShowFinanceModal(true);
  };

  const handleDelete = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar esta orden de compra?')) {
      setOrdenes(ordenes.filter(orden => orden.id !== id));
    }
  };

  const calculateItemTotal = (detalle: DetalleOrdenCompra): number => {
    const subtotal = detalle.cantidad_ordenada * detalle.precio_unitario;
    const descuento = subtotal * (detalle.descuento_porcentaje / 100);
    const base = subtotal - descuento;
    return base;
  };

  // Función para calcular total de un item - se utilizará en formularios
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const calculateTotal = (detalles: DetalleOrdenCompra[]): number => {
    return detalles.reduce((total, detalle) => total + calculateItemTotal(detalle), 0);
  };

  const getEstadoBadge = (estado: string) => {
    const badges = {
      BORRADOR: 'badge bg-secondary',
      PENDIENTE_CONFIRMACION: 'badge bg-warning text-dark',
      CONFIRMADA: 'badge bg-primary',
      EN_PROCESO: 'badge bg-info',
      PARCIALMENTE_RECIBIDA: 'badge bg-warning text-dark',
      COMPLETAMENTE_RECIBIDA: 'badge bg-success',
      CANCELADA: 'badge bg-danger',
      CERRADA: 'badge bg-dark'
    };
    return badges[estado as keyof typeof badges] || 'badge bg-secondary';
  };

  const getPrioridadBadge = (prioridad: string) => {
    const badges = {
      BAJA: 'badge bg-light text-dark',
      NORMAL: 'badge bg-info',
      ALTA: 'badge bg-warning text-dark',
      URGENTE: 'badge bg-danger'
    };
    return badges[prioridad as keyof typeof badges] || 'badge bg-info';
  };

  return (
    <div className="ordenes-compra-container">
      <div className="ordenes-compra-header">
        <div className="header-content">
          <div className="header-text">
            <h1 className="page-title">
              <Package className="title-icon" />
              Órdenes de Compra
            </h1>
            <p className="page-subtitle">
              Gestión completa de órdenes de compra, seguimiento de recepciones y control financiero
            </p>
          </div>
          <button className="btn-primary" onClick={handleCreate}>
            <CirclePlus size={20} />
            Nueva Orden
          </button>
        </div>
      </div>

      <div className="ordenes-stats">
        <div className="stat-card">
          <div className="stat-icon confirmadas">
            <CheckCircle size={24} />
          </div>
          <div className="stat-content">
            <h3>{ordenes.filter(o => o.estado === 'CONFIRMADA').length}</h3>
            <p>Confirmadas</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon proceso">
            <Clock size={24} />
          </div>
          <div className="stat-content">
            <h3>{ordenes.filter(o => o.estado === 'EN_PROCESO').length}</h3>
            <p>En Proceso</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon recibidas">
            <Truck size={24} />
          </div>
          <div className="stat-content">
            <h3>{ordenes.filter(o => o.estado === 'RECIBIDA_TOTAL').length}</h3>
            <p>Recibidas</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon total">
            <DollarSign size={24} />
          </div>
          <div className="stat-content">
            <h3> {ordenes.reduce((total, o) => total + o.total, 0).toLocaleString()}</h3>
            <p>Total Órdenes</p>
          </div>
        </div>
      </div>

      <div className="ordenes-table-container">
        <div className="table-responsive">
          <table className="table ordenes-table">
            <thead>
              <tr>
                <th>Número</th>
                <th>Fecha</th>
                <th>Proveedor</th>
                <th>Estado</th>
                <th>Prioridad</th>
                <th>Monto Total</th>
                <th>Entrega</th>
                <th>Recepción</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {ordenes.map((orden) => (
                <tr key={orden.id}>
                  <td>
                    <strong>{orden.numero_orden}</strong>
                    <br />
                    <small className="text-muted">COT: {orden.numero_cotizacion}</small>
                  </td>
                  <td>
                    <div>{new Date(orden.fecha_orden).toLocaleDateString()}</div>
                    <small className="text-muted">
                      {orden.generado_por}
                    </small>
                  </td>
                  <td>
                    <strong>{orden.info_proveedor.razon_social}</strong>
                    <br />
                    <small className="text-muted">{orden.info_proveedor.identificacion}</small>
                  </td>
                  <td>
                    <span className={getEstadoBadge(orden.estado)}>
                      {orden.estado.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td>
                    <span className={getPrioridadBadge(orden.prioridad)}>
                      {orden.prioridad}
                    </span>
                  </td>
                  <td>
                    <strong>S/ {orden.total.toLocaleString()}</strong>
                    <br />
                    <small className="text-muted">
                      Subtotal: S/ {orden.subtotal.toLocaleString()}
                    </small>
                  </td>
                  <td>
                    <div>{new Date(orden.fecha_entrega_requerida).toLocaleDateString()}</div>
                    {new Date(orden.fecha_entrega_requerida) < new Date() && orden.estado !== 'RECIBIDA_TOTAL' && (
                      <small className="text-danger">
                        <AlertTriangle size={12} /> Vencida
                      </small>
                    )}
                  </td>
                  <td>
                    {(() => {
                      let badgeClass = 'bg-secondary';
                      let status = 'PENDIENTE';
                      
                      if (orden.porcentaje_recibido === 100) {
                        badgeClass = 'bg-success';
                        status = 'COMPLETO';
                      } else if (orden.porcentaje_recibido > 0) {
                        badgeClass = 'bg-warning text-dark';
                        status = 'PARCIAL';
                      }
                      
                      return <span className={`badge ${badgeClass}`}>{status}</span>;
                    })()}
                  </td>
                  <td>
                    <div className="btn-group">
                      <button
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => handleView(orden)}
                        title="Ver detalles"
                      >
                        <Eye size={16} />
                      </button>
                      {orden.estado === 'BORRADOR' && (
                        <button
                          className="btn btn-sm btn-outline-warning"
                          onClick={() => handleEdit(orden)}
                          title="Editar"
                        >
                          <SquarePen size={16} />
                        </button>
                      )}
                      {(orden.estado === 'EMITIDA' || orden.estado === 'CONFIRMADA') && (
                        <button
                          className="btn btn-sm btn-outline-success"
                          onClick={() => handleApprove(orden)}
                          title="Aprobar"
                        >
                          <CheckCircle size={16} />
                        </button>
                      )}
                      {(orden.estado === 'CONFIRMADA' || orden.estado === 'EN_PROCESO') && (
                        <button
                          className="btn btn-sm btn-outline-info"
                          onClick={() => handleReceive(orden)}
                          title="Registrar recepción"
                        >
                          <Truck size={16} />
                        </button>
                      )}
                      <button
                        className="btn btn-sm btn-outline-secondary"
                        onClick={() => handleFinance(orden)}
                        title="Seguimiento financiero"
                      >
                        <CreditCard size={16} />
                      </button>
                      {orden.estado === 'BORRADOR' && (
                        <button
                          className="btn btn-sm btn-outline-danger"
                          onClick={() => handleDelete(orden.id)}
                          title="Eliminar"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {ordenes.length === 0 && (
        <div className="empty-state">
          <Package size={64} className="empty-icon" />
          <h3>No hay órdenes de compra</h3>
          <p>Comience creando su primera orden de compra</p>
          <button className="btn-primary" onClick={handleCreate}>
            <CirclePlus size={20} />
            Crear Primera Orden
          </button>
        </div>
      )}
    </div>
  );
};

export default OrdenesCompraPage;
