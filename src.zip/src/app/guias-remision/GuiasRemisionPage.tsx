"use client";

import React, { useState } from "react";
import { GuiaRemision, GuiaRemisionFormValues, InfoGuiaRemision, Destinatario, DetalleItem } from "./types";
import { SRIUniversalService } from "../../services/sri-universal.service";
import "./guias-remision.css";
import { CirclePlus, SquarePen, Trash2, Eye, Download } from 'lucide-react';

const initialForm: GuiaRemisionFormValues = {
  ambiente: "1",
  razon_social: "EMPRESA DEMO S.A.",
  nombre_comercial: "Demo",
  ruc: "1234567890001",
  estab: "001",
  ptoEmi: "001",
  secuencial: "1",
  direccion_matriz: "Av. Principal 123, Ciudad Demo",
  dir_establecimiento: "Av. Principal 123, Ciudad Demo",
  dir_partida: "Av. Principal 123, Ciudad Demo",
  razon_social_transportista: "",
  tipo_identificacion_transportista: "",
  ruc_transportista: "",
  obligado_contabilidad: "SI",
  contribuyente_especial: "",
  fecha_ini_transporte: new Date().toISOString().split('T')[0],
  fecha_fin_transporte: new Date().toISOString().split('T')[0],
  placa_vehiculo: "",
  identificacion_destinatario: "",
  razon_social_destinatario: "",
  dir_destinatario: "",
  motivo_traslado: "",
  ruta: "",
  cod_doc_sustento: "",
  num_doc_sustento: "",
  num_autorizacion_doc_sustento: "",
  fecha_emision_doc_sustento: "",
  cod_interno: "",
  descripcion: "",
  cantidad: 0,
};

const initialGuias: GuiaRemision[] = [
  {
    id: 1,
    info_tributaria: {
      ambiente: "1",
      tipo_emision: "1",
      razon_social: "EMPRESA DEMO S.A.",
      nombre_comercial: "Demo",
      ruc: "1234567890001",
      clave_acceso: "2309202406123456789000110010010000000011234567893",
      cod_doc: "06",
      estab: "001",
      ptoEmi: "001",
      secuencial: "000000001",
      direccion_matriz: "Av. Principal 123, Ciudad Demo"
    },
    info_guia_remision: {
      dir_establecimiento: "Av. Principal 123, Ciudad Demo",
      dir_partida: "Av. Principal 123, Ciudad Demo",
      razon_social_transportista: "TRANSPORTES DEMO S.A.",
      tipo_identificacion_transportista: "04",
      ruc_transportista: "1234567890001",
      obligado_contabilidad: "SI",
      fecha_ini_transporte: "23/09/2024",
      fecha_fin_transporte: "23/09/2024",
      placa_vehiculo: "ABC-1234"
    },
    destinatarios: [
      {
        identificacion_destinatario: "1234567890",
        razon_social_destinatario: "CLIENTE DEMO",
        dir_destinatario: "Av. Secundaria 456, Ciudad Demo",
        motivo_traslado: "01",
        ruta: "Ciudad Demo - Ciudad Destino",
        cod_doc_sustento: "01",
        num_doc_sustento: "001-001-000000001",
        num_autorizacion_doc_sustento: "2309202412345678901234567890",
        fecha_emision_doc_sustento: "20/09/2024"
      }
    ],
    detalles: [
      {
        cod_interno: "PROD001",
        descripcion: "Producto Demo 1",
        cantidad: 10
      },
      {
        cod_interno: "PROD002",
        descripcion: "Producto Demo 2",
        cantidad: 5
      }
    ],
    estado_sri: 'AUTORIZADA',
    numero_autorizacion: "2309202412345678901234567890123456",
    fecha_autorizacion: "2024-09-23T10:30:00.000Z",
    fecha_creacion: "2024-09-23T10:00:00.000Z",
    fecha_actualizacion: "2024-09-23T10:30:00.000Z"
  }
];

export default function GuiasRemisionPage() {
  const [guias, setGuias] = useState<GuiaRemision[]>(initialGuias);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<GuiaRemisionFormValues>(initialForm);
  const [enviandoSRI, setEnviandoSRI] = useState<boolean>(false);

  const sriService = SRIUniversalService.getInstance();

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    const ultimoSecuencial = Math.max(...guias.map(g => parseInt(g.info_tributaria.secuencial) || 0), 0);
    setForm(prev => ({
      ...prev,
      secuencial: (ultimoSecuencial + 1).toString()
    }));
    setShowModal(true);
  };

  const abrirModalEditar = (guia: GuiaRemision) => {
    const primerDestinatario = guia.destinatarios[0] || {};
    const primerDetalle = guia.detalles[0] || {};
    
    setForm({
      ambiente: guia.info_tributaria.ambiente,
      razon_social: guia.info_tributaria.razon_social,
      nombre_comercial: guia.info_tributaria.nombre_comercial,
      ruc: guia.info_tributaria.ruc,
      estab: guia.info_tributaria.estab,
      ptoEmi: guia.info_tributaria.ptoEmi,
      secuencial: guia.info_tributaria.secuencial,
      direccion_matriz: guia.info_tributaria.direccion_matriz,
      dir_establecimiento: guia.info_guia_remision.dir_establecimiento,
      dir_partida: guia.info_guia_remision.dir_partida,
      razon_social_transportista: guia.info_guia_remision.razon_social_transportista,
      tipo_identificacion_transportista: guia.info_guia_remision.tipo_identificacion_transportista,
      ruc_transportista: guia.info_guia_remision.ruc_transportista,
      obligado_contabilidad: guia.info_guia_remision.obligado_contabilidad,
      contribuyente_especial: guia.info_guia_remision.contribuyente_especial || "",
      fecha_ini_transporte: guia.info_guia_remision.fecha_ini_transporte.split('/').reverse().join('-'),
      fecha_fin_transporte: guia.info_guia_remision.fecha_fin_transporte.split('/').reverse().join('-'),
      placa_vehiculo: guia.info_guia_remision.placa_vehiculo,
      identificacion_destinatario: primerDestinatario.identificacion_destinatario || "",
      razon_social_destinatario: primerDestinatario.razon_social_destinatario || "",
      dir_destinatario: primerDestinatario.dir_destinatario || "",
      motivo_traslado: primerDestinatario.motivo_traslado || "",
      ruta: primerDestinatario.ruta || "",
      cod_doc_sustento: primerDestinatario.cod_doc_sustento || "",
      num_doc_sustento: primerDestinatario.num_doc_sustento || "",
      num_autorizacion_doc_sustento: primerDestinatario.num_autorizacion_doc_sustento || "",
      fecha_emision_doc_sustento: primerDestinatario.fecha_emision_doc_sustento ? primerDestinatario.fecha_emision_doc_sustento.split('/').reverse().join('-') : "",
      cod_interno: primerDetalle.cod_interno || "",
      descripcion: primerDetalle.descripcion || "",
      cantidad: primerDetalle.cantidad || 0,
    });
    
    setEditandoId(guia.id);
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setEnviandoSRI(true);
    
    try {
      const infoGuia: InfoGuiaRemision = {
        dir_establecimiento: form.dir_establecimiento,
        dir_partida: form.dir_partida,
        razon_social_transportista: form.razon_social_transportista,
        tipo_identificacion_transportista: form.tipo_identificacion_transportista,
        ruc_transportista: form.ruc_transportista,
        obligado_contabilidad: form.obligado_contabilidad,
        contribuyente_especial: form.contribuyente_especial,
        fecha_ini_transporte: form.fecha_ini_transporte.split('-').reverse().join('/'),
        fecha_fin_transporte: form.fecha_fin_transporte.split('-').reverse().join('/'),
        placa_vehiculo: form.placa_vehiculo,
      };

      const destinatario: Destinatario = {
        identificacion_destinatario: form.identificacion_destinatario,
        razon_social_destinatario: form.razon_social_destinatario,
        dir_destinatario: form.dir_destinatario,
        motivo_traslado: form.motivo_traslado,
        ruta: form.ruta,
        cod_doc_sustento: form.cod_doc_sustento,
        num_doc_sustento: form.num_doc_sustento,
        num_autorizacion_doc_sustento: form.num_autorizacion_doc_sustento,
        fecha_emision_doc_sustento: form.fecha_emision_doc_sustento.split('-').reverse().join('/'),
      };

      const detalle: DetalleItem = {
        cod_interno: form.cod_interno,
        descripcion: form.descripcion,
        cantidad: form.cantidad,
      };

      const nuevaGuia: GuiaRemision = {
        id: editandoId || Date.now(),
        info_tributaria: {
          ambiente: form.ambiente,
          tipo_emision: "1",
          razon_social: form.razon_social,
          nombre_comercial: form.nombre_comercial,
          ruc: form.ruc,
          clave_acceso: "",
          cod_doc: "06",
          estab: form.estab,
          ptoEmi: form.ptoEmi,
          secuencial: form.secuencial,
          direccion_matriz: form.direccion_matriz,
        },
        info_guia_remision: infoGuia,
        destinatarios: [destinatario],
        detalles: [detalle],
        estado_sri: 'PENDIENTE',
        fecha_creacion: new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString()
      };

      const comprobanteParaSRI = {
        id: nuevaGuia.id,
        tipo_comprobante: '06' as const,
        info_tributaria: nuevaGuia.info_tributaria,
        estado_sri: nuevaGuia.estado_sri,
        fecha_creacion: nuevaGuia.fecha_creacion,
        fecha_actualizacion: nuevaGuia.fecha_actualizacion
      };

      const datosEspecificos = `
  <infoGuiaRemision>
    <dirEstablecimiento><![CDATA[${infoGuia.dir_establecimiento}]]></dirEstablecimiento>
    <dirPartida><![CDATA[${infoGuia.dir_partida}]]></dirPartida>
    <razonSocialTransportista><![CDATA[${infoGuia.razon_social_transportista}]]></razonSocialTransportista>
    <tipoIdentificacionTransportista>${infoGuia.tipo_identificacion_transportista}</tipoIdentificacionTransportista>
    <rucTransportista>${infoGuia.ruc_transportista}</rucTransportista>
    <obligadoContabilidad>${infoGuia.obligado_contabilidad}</obligadoContabilidad>
    <fechaIniTransporte>${infoGuia.fecha_ini_transporte}</fechaIniTransporte>
    <fechaFinTransporte>${infoGuia.fecha_fin_transporte}</fechaFinTransporte>
    <placaVehiculo>${infoGuia.placa_vehiculo}</placaVehiculo>
  </infoGuiaRemision>
  <destinatarios>
    <destinatario>
      <identificacionDestinatario>${destinatario.identificacion_destinatario}</identificacionDestinatario>
      <razonSocialDestinatario><![CDATA[${destinatario.razon_social_destinatario}]]></razonSocialDestinatario>
      <dirDestinatario><![CDATA[${destinatario.dir_destinatario}]]></dirDestinatario>
      <motivoTraslado>${destinatario.motivo_traslado}</motivoTraslado>
      <ruta><![CDATA[${destinatario.ruta}]]></ruta>
      <codDocSustento>${destinatario.cod_doc_sustento}</codDocSustento>
      <numDocSustento>${destinatario.num_doc_sustento}</numDocSustento>
      <numAutDocSustento>${destinatario.num_autorizacion_doc_sustento}</numAutDocSustento>
      <fechaEmisionDocSustento>${destinatario.fecha_emision_doc_sustento}</fechaEmisionDocSustento>
      <detalles>
        <detalle>
          <codigoInterno>${detalle.cod_interno}</codigoInterno>
          <descripcion><![CDATA[${detalle.descripcion}]]></descripcion>
          <cantidad>${detalle.cantidad}</cantidad>
        </detalle>
      </detalles>
    </destinatario>
  </destinatarios>`;

      console.log('🚀 Enviando guía de remisión al SRI...', nuevaGuia);
      const respuestaSRI = await sriService.enviarComprobanteSRI(comprobanteParaSRI, datosEspecificos, infoGuia.fecha_ini_transporte);

      nuevaGuia.estado_sri = respuestaSRI.estado;
      if (respuestaSRI.success) {
        nuevaGuia.numero_autorizacion = respuestaSRI.numero_autorizacion;
        nuevaGuia.fecha_autorizacion = respuestaSRI.fecha_autorizacion;
        nuevaGuia.xml_generado = respuestaSRI.xml_autorizado;
      }
      nuevaGuia.observaciones_sri = respuestaSRI.observaciones;

      if (editandoId) {
        setGuias((prev) =>
          prev.map((guia) =>
            guia.id === editandoId ? nuevaGuia : guia
          )
        );
      } else {
        setGuias((prev) => [...prev, nuevaGuia]);
      }

      if (respuestaSRI.success) {
        alert(`✅ Guía de Remisión ${respuestaSRI.estado.toLowerCase()} exitosamente.\nNúmero de autorización: ${respuestaSRI.numero_autorizacion}`);
        cerrarModal();
      } else {
        alert(`❌ Error del SRI: ${respuestaSRI.mensaje_error}\n\nObservaciones: ${respuestaSRI.observaciones}`);
      }

    } catch (error) {
      console.error('Error procesando guía de remisión:', error);
      alert('Error inesperado al procesar la guía de remisión');
    } finally {
      setEnviandoSRI(false);
    }
  };

  const eliminarGuia = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta guía de remisión?")) {
      setGuias((prev) => prev.filter((guia) => guia.id !== id));
    }
  };

  const guiasFiltradas = guias.filter((guia) =>
    Object.values(guia.info_guia_remision)
      .concat(Object.values(guia.info_tributaria))
      .concat(guia.destinatarios.map(d => Object.values(d)).flat())
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'AUTORIZADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'DEVUELTA': return 'bg-warning text-dark';
      case 'PENDIENTE': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Guías de Remisión Electrónicas</h1>
            <p className="text-muted mb-0">Gestión de transporte SRI Ecuador</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-info">Ambiente: Pruebas</span>
            <span className="badge bg-success text-white">{guias.length} guías</span>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar por destinatario, transportista, placa..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-success d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Guía de Remisión</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Secuencial</th>
                <th>Fecha Transporte</th>
                <th>Destinatario</th>
                <th>Transportista</th>
                <th>Placa</th>
                <th>Productos</th>
                <th>Estado SRI</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {guiasFiltradas.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-4">
                    <div className="text-muted">
                      No se encontraron guías de remisión
                    </div>
                  </td>
                </tr>
              )}
              {guiasFiltradas.map((guia) => (
                <tr key={guia.id}>
                  <td>
                    <strong>{guia.info_tributaria.estab}-{guia.info_tributaria.ptoEmi}-{guia.info_tributaria.secuencial.padStart(9, '0')}</strong>
                  </td>
                  <td>{guia.info_guia_remision.fecha_ini_transporte}</td>
                  <td>{guia.destinatarios[0]?.razon_social_destinatario || 'N/A'}</td>
                  <td>
                    <small className="text-muted">
                      {guia.info_guia_remision.razon_social_transportista}
                    </small>
                  </td>
                  <td>
                    <span className="badge bg-secondary">{guia.info_guia_remision.placa_vehiculo}</span>
                  </td>
                  <td>
                    <small>
                      {guia.detalles.length} producto{guia.detalles.length !== 1 ? 's' : ''}
                    </small>
                  </td>
                  <td>
                    <span className={`badge ${getEstadoBadgeClass(guia.estado_sri)}`}>
                      {guia.estado_sri}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => abrirModalEditar(guia)}
                        title="Ver detalles"
                      >
                        <Eye size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(guia)}
                        title="Editar"
                        disabled={guia.estado_sri === 'AUTORIZADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      {guia.xml_generado && (
                        <button
                          className="btn btn-outline-success btn-sm"
                          title="Descargar XML"
                          onClick={() => {
                            const blob = new Blob([guia.xml_generado!], { type: 'application/xml' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `guia_remision_${guia.info_tributaria.secuencial}.xml`;
                            a.click();
                          }}
                        >
                          <Download size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarGuia(guia.id)}
                        title="Eliminar"
                        disabled={guia.estado_sri === 'AUTORIZADA'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Modal simplificado para guías de remisión */}
        {showModal && (
          <div className="modal fade show d-block" style={{ zIndex: 1050 }}>
            <div className="modal-dialog modal-xl">
              <div className="modal-content">
                <form onSubmit={handleSubmit}>
                  <div className="modal-header bg-success text-white">
                    <h5 className="modal-title">
                      {editandoId ? "Editar Guía de Remisión" : "Nueva Guía de Remisión"}
                    </h5>
                    <button
                      type="button"
                      className="btn-close btn-close-white"
                      onClick={cerrarModal}
                      disabled={enviandoSRI}
                    />
                  </div>
                  
                  <div className="modal-body" style={{ maxHeight: '70vh', overflowY: 'auto' }}>
                    <div className="row g-3">
                      {/* Datos del transporte */}
                      <div className="col-12">
                        <h6 className="text-success border-bottom pb-2">Información de Transporte</h6>
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="fecha_ini_transporte" className="form-label">Fecha Inicio Transporte *</label>
                        <input
                          type="date"
                          className="form-control"
                          id="fecha_ini_transporte"
                          name="fecha_ini_transporte"
                          value={form.fecha_ini_transporte}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="fecha_fin_transporte" className="form-label">Fecha Fin Transporte *</label>
                        <input
                          type="date"
                          className="form-control"
                          id="fecha_fin_transporte"
                          name="fecha_fin_transporte"
                          value={form.fecha_fin_transporte}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="razon_social_transportista" className="form-label">Transportista *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="razon_social_transportista"
                          name="razon_social_transportista"
                          value={form.razon_social_transportista}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="ruc_transportista" className="form-label">RUC Transportista *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="ruc_transportista"
                          name="ruc_transportista"
                          value={form.ruc_transportista}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="placa_vehiculo" className="form-label">Placa Vehículo *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="placa_vehiculo"
                          name="placa_vehiculo"
                          value={form.placa_vehiculo}
                          onChange={handleChange}
                          placeholder="ABC-1234"
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="ruta" className="form-label">Ruta *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="ruta"
                          name="ruta"
                          value={form.ruta}
                          onChange={handleChange}
                          placeholder="Ciudad Origen - Ciudad Destino"
                          required
                        />
                      </div>
                      
                      {/* Datos del destinatario */}
                      <div className="col-12">
                        <h6 className="text-success border-bottom pb-2 mt-3">Información del Destinatario</h6>
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="razon_social_destinatario" className="form-label">Destinatario *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="razon_social_destinatario"
                          name="razon_social_destinatario"
                          value={form.razon_social_destinatario}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="identificacion_destinatario" className="form-label">Identificación *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="identificacion_destinatario"
                          name="identificacion_destinatario"
                          value={form.identificacion_destinatario}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="dir_destinatario" className="form-label">Dirección Destinatario *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="dir_destinatario"
                          name="dir_destinatario"
                          value={form.dir_destinatario}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="motivo_traslado" className="form-label">Motivo Traslado *</label>
                        <select
                          className="form-select"
                          id="motivo_traslado"
                          name="motivo_traslado"
                          value={form.motivo_traslado}
                          onChange={handleChange}
                          required
                        >
                          <option value="">Seleccione...</option>
                          <option value="01">Venta</option>
                          <option value="02">Compra</option>
                          <option value="03">Transformación</option>
                          <option value="04">Consignación</option>
                          <option value="05">Devolución</option>
                          <option value="08">Traslado entre establecimientos</option>
                          <option value="09">Otros</option>
                        </select>
                      </div>
                      
                      {/* Documento sustento */}
                      <div className="col-12">
                        <h6 className="text-success border-bottom pb-2 mt-3">Documento de Sustento</h6>
                      </div>
                      <div className="col-md-4">
                        <label htmlFor="cod_doc_sustento" className="form-label">Tipo Documento *</label>
                        <select
                          className="form-select"
                          id="cod_doc_sustento"
                          name="cod_doc_sustento"
                          value={form.cod_doc_sustento}
                          onChange={handleChange}
                          required
                        >
                          <option value="">Seleccione...</option>
                          <option value="01">Factura</option>
                          <option value="04">Nota de Crédito</option>
                          <option value="05">Nota de Débito</option>
                          <option value="06">Guía de Remisión</option>
                        </select>
                      </div>
                      <div className="col-md-4">
                        <label htmlFor="num_doc_sustento" className="form-label">Número Documento *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="num_doc_sustento"
                          name="num_doc_sustento"
                          value={form.num_doc_sustento}
                          onChange={handleChange}
                          placeholder="001-001-000000001"
                          required
                        />
                      </div>
                      <div className="col-md-4">
                        <label htmlFor="fecha_emision_doc_sustento" className="form-label">Fecha Documento *</label>
                        <input
                          type="date"
                          className="form-control"
                          id="fecha_emision_doc_sustento"
                          name="fecha_emision_doc_sustento"
                          value={form.fecha_emision_doc_sustento}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      
                      {/* Producto */}
                      <div className="col-12">
                        <h6 className="text-success border-bottom pb-2 mt-3">Detalle de Productos</h6>
                      </div>
                      <div className="col-md-4">
                        <label htmlFor="cod_interno" className="form-label">Código Producto *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="cod_interno"
                          name="cod_interno"
                          value={form.cod_interno}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-5">
                        <label htmlFor="descripcion" className="form-label">Descripción *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="descripcion"
                          name="descripcion"
                          value={form.descripcion}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="cantidad" className="form-label">Cantidad *</label>
                        <input
                          type="number"
                          className="form-control"
                          id="cantidad"
                          name="cantidad"
                          value={form.cantidad}
                          onChange={handleChange}
                          min="1"
                          required
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={cerrarModal}
                      disabled={enviandoSRI}
                    >
                      Cancelar
                    </button>
                    <button 
                      type="submit" 
                      className="btn btn-success"
                      disabled={enviandoSRI}
                    >
                      {enviandoSRI ? 'Enviando...' : 'Crear y Enviar al SRI'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
            <div className="modal-backdrop fade show"></div>
          </div>
        )}
      </div>
    </div>
  );
}
