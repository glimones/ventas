// Tipos para Guías de Remisión SRI Ecuador

export interface InfoTributaria {
  ambiente: string;
  tipo_emision: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  clave_acceso: string;
  cod_doc: string; // "06" para guías de remisión
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
}

export interface InfoGuiaRemision {
  dir_establecimiento: string;
  dir_partida: string;
  razon_social_transportista: string;
  tipo_identificacion_transportista: string;
  ruc_transportista: string;
  rise?: string;
  obligado_contabilidad: string;
  contribuyente_especial?: string;
  fecha_ini_transporte: string;
  fecha_fin_transporte: string;
  placa_vehiculo: string;
}

export interface Destinatario {
  identificacion_destinatario: string;
  razon_social_destinatario: string;
  dir_destinatario: string;
  motivo_traslado: string;
  doc_aduanero_unico?: string;
  cod_establecimiento_destino?: string;
  ruta: string;
  cod_doc_sustento: string;
  num_doc_sustento: string;
  num_autorizacion_doc_sustento: string;
  fecha_emision_doc_sustento: string;
}

export interface DetalleItem {
  cod_interno: string;
  cod_auxiliar?: string;
  descripcion: string;
  cantidad: number;
}

export interface GuiaRemision {
  id: number;
  info_tributaria: InfoTributaria;
  info_guia_remision: InfoGuiaRemision;
  destinatarios: Destinatario[];
  detalles: DetalleItem[];
  estado_sri: 'PENDIENTE' | 'AUTORIZADA' | 'RECHAZADA' | 'DEVUELTA';
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  xml_generado?: string;
  observaciones_sri?: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
}

export interface GuiaRemisionFormValues {
  // Info tributaria básica
  ambiente: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
  
  // Info de la guía
  dir_establecimiento: string;
  dir_partida: string;
  razon_social_transportista: string;
  tipo_identificacion_transportista: string;
  ruc_transportista: string;
  obligado_contabilidad: string;
  contribuyente_especial: string;
  fecha_ini_transporte: string;
  fecha_fin_transporte: string;
  placa_vehiculo: string;
  
  // Destinatario
  identificacion_destinatario: string;
  razon_social_destinatario: string;
  dir_destinatario: string;
  motivo_traslado: string;
  ruta: string;
  cod_doc_sustento: string;
  num_doc_sustento: string;
  num_autorizacion_doc_sustento: string;
  fecha_emision_doc_sustento: string;
  
  // Detalle de productos
  cod_interno: string;
  descripcion: string;
  cantidad: number;
}

// Tipos de identificación del transportista
export const tiposIdentificacion = [
  { codigo: "04", descripcion: "RUC" },
  { codigo: "05", descripcion: "Cédula" },
  { codigo: "06", descripcion: "Pasaporte" },
  { codigo: "08", descripcion: "Identificación del exterior" }
];

// Motivos de traslado
export const motivosTraslado = [
  { codigo: "01", descripcion: "Venta" },
  { codigo: "02", descripcion: "Compra" },
  { codigo: "03", descripcion: "Transformación" },
  { codigo: "04", descripcion: "Consignación" },
  { codigo: "05", descripcion: "Devolución" },
  { codigo: "06", descripcion: "Importación" },
  { codigo: "07", descripcion: "Exportación" },
  { codigo: "08", descripcion: "Traslado entre establecimientos de la misma empresa" },
  { codigo: "09", descripcion: "Otros" }
];

// Códigos de documentos de sustento
export const documentosSustento = [
  { codigo: "01", descripcion: "Factura" },
  { codigo: "04", descripcion: "Nota de Crédito" },
  { codigo: "05", descripcion: "Nota de Débito" },
  { codigo: "06", descripcion: "Guía de Remisión" },
  { codigo: "07", descripcion: "Comprobante de Retención" },
  { codigo: "15", descripcion: "Comprobante de venta emitido en el exterior" },
  { codigo: "16", descripcion: "Formulario Único de Exportación (FUE)" }
];

// Ambientes
export const ambientes = [
  { codigo: "1", descripcion: "Pruebas" },
  { codigo: "2", descripcion: "Producción" }
];

// Obligado a llevar contabilidad
export const obligadoContabilidad = [
  { codigo: "SI", descripcion: "Sí" },
  { codigo: "NO", descripcion: "No" }
];
