import { AppShell } from "@/components/app-shell";
import GuiasRemisionPage from "./GuiasRemisionPage";

export default function Page() {
  return <AppShell><GuiasRemisionPage /></AppShell>;
}
