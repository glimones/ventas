// Tipos de datos para Notas de Crédito electrónicas Ecuador SRI

export interface DetalleNotaCredito {
  id: number;
  codigo_principal: string;
  codigo_auxiliar?: string;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  descuento: number;
  precio_total_sin_impuesto: number;
  codigo_porcentaje_iva: string; // 0, 2, 3 (0%, 12%, 14%)
  tarifa_iva: number;
  valor_iva: number;
  precio_total_con_impuesto: number;
}

export interface InfoNotaCredito {
  fecha_emision: string; // DD/MM/YYYY
  direccion_establecimiento: string;
  tipo_identificacion_sujeto_retenido: string; // 04 = RUC, 05 = Cédula, 06 = Pasaporte, 07 = Venta consumidor final, 08 = Identificación exterior
  razon_social_sujeto_retenido: string;
  identificacion_sujeto_retenido: string;
  contribuyente_especial?: string;
  obligado_contabilidad: string; // SI o NO
  rise?: string;
  cod_doc_modificado: string; // 01 = Factura, 03 = Liquidación de compra
  num_doc_modificado: string; // Número del documento que se modifica
  fecha_emision_doc_modificado: string;
  total_sin_impuestos: number;
  valor_modificacion: number;
  moneda: string; // DOLAR
  motivo: string; // Razón de la nota de crédito
}

export interface TotalConImpuesto {
  codigo: string; // 2 = IVA
  codigo_porcentaje: string; // 0, 2, 3
  descuento_adicional: number;
  base_imponible: number;
  tarifa: number;
  valor: number;
}

export interface NotaCredito {
  id: number;
  info_tributaria: {
    ambiente: string;
    tipo_emision: string;
    razon_social: string;
    nombre_comercial: string;
    ruc: string;
    clave_acceso: string;
    cod_doc: string; // 04 para Nota de Crédito
    estab: string;
    ptoEmi: string;
    secuencial: string;
    direccion_matriz: string;
  };
  info_nota_credito: InfoNotaCredito;
  detalles: DetalleNotaCredito[];
  total_con_impuestos: TotalConImpuesto[];
  estado_sri: 'PENDIENTE' | 'AUTORIZADA' | 'RECHAZADA' | 'DEVUELTA';
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  xml_generado?: string;
  observaciones_sri?: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
}

export interface NotaCreditoFormValues {
  // Info Tributaria
  ambiente: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
  
  // Info Nota Crédito
  fecha_emision: string;
  direccion_establecimiento: string;
  tipo_identificacion_sujeto_retenido: string;
  razon_social_sujeto_retenido: string;
  identificacion_sujeto_retenido: string;
  contribuyente_especial: string;
  obligado_contabilidad: string;
  rise: string;
  cod_doc_modificado: string;
  num_doc_modificado: string;
  fecha_emision_doc_modificado: string;
  valor_modificacion: number;
  moneda: string;
  motivo: string;
}

export interface DetalleNotaCreditoFormValues {
  codigo_principal: string;
  codigo_auxiliar: string;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  descuento: number;
  codigo_porcentaje_iva: string;
}

// Opciones para los selectores
export const TIPO_IDENTIFICACION_OPTIONS = [
  { value: '04', label: 'RUC' },
  { value: '05', label: 'Cédula' },
  { value: '06', label: 'Pasaporte' },
  { value: '07', label: 'Venta a consumidor final' },
  { value: '08', label: 'Identificación del exterior' },
];

export const CODIGO_IVA_OPTIONS = [
  { value: '0', label: '0% IVA' },
  { value: '2', label: '12% IVA' },
  { value: '3', label: '14% IVA' },
];

export const COD_DOC_MODIFICADO_OPTIONS = [
  { value: '01', label: 'Factura' },
  { value: '03', label: 'Liquidación de compra' },
];

export const AMBIENTE_OPTIONS = [
  { value: '1', label: 'Pruebas' },
  { value: '2', label: 'Producción' },
];

export const MOTIVOS_COMUNES = [
  'Devolución de mercadería',
  'Descuento por pronto pago',
  'Descuento por volumen',
  'Corrección de precio',
  'Anulación de operación',
  'Bonificación',
  'Otros',
];
