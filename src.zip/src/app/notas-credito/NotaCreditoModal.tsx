import React, { useEffect } from "react";
import { NotaCreditoFormValues, DetalleNotaCreditoFormValues } from "./types";
import NotaCreditoForm from "./NotaCreditoForm";

interface Props {
  show: boolean;
  editando: boolean;
  values: NotaCreditoFormValues;
  detalles: DetalleNotaCreditoFormValues[];
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onDetallesChange: (detalles: DetalleNotaCreditoFormValues[]) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  enviandoSRI?: boolean;
}

const NotaCreditoModal: React.FC<Props> = ({
  show,
  editando,
  values,
  detalles,
  onChange,
  onDetallesChange,
  onClose,
  onSubmit,
  enviandoSRI = false,
}) => {
  // Bloquear el scroll del body cuando el modal está abierto
  useEffect(() => {
    if (show) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [show]);

  if (!show) return null;

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Solo cerrar si se hace clic directamente en el backdrop, no en el contenido
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <>
      <div 
        className="modal fade show d-block" 
        tabIndex={-1}
        style={{ zIndex: 1050 }}
      >
        <div 
          className="modal-dialog modal-xl" 
          style={{ zIndex: 1060, maxWidth: '95%' }}
        >
          <div className="modal-content">
            <form onSubmit={onSubmit}>
              <div className="modal-header bg-danger text-white">
                <h5 className="modal-title d-flex align-items-center">
                  <i className="fas fa-file-minus me-2"></i>
                  {editando ? "Editar Nota de Crédito" : "Nueva Nota de Crédito"}
                  {editando && (
                    <span className="badge bg-light text-dark ms-2">
                      {values.estab.padStart(3, '0')}-{values.ptoEmi.padStart(3, '0')}-{values.secuencial.padStart(9, '0')}
                    </span>
                  )}
                </h5>
                <button
                  type="button"
                  className="btn-close btn-close-white"
                  onClick={onClose}
                  aria-label="Cerrar"
                  disabled={enviandoSRI}
                />
              </div>
              
              <div className="modal-body" style={{ maxHeight: '75vh', overflowY: 'auto' }}>
                <div className="alert alert-warning d-flex align-items-center mb-3">
                  <i className="fas fa-exclamation-triangle me-2"></i>
                  <div>
                    <strong>Nota de Crédito:</strong> Este comprobante reduce el valor de una factura o liquidación previamente emitida. 
                    Verifique que todos los datos coincidan con el documento original.
                  </div>
                </div>
                
                <NotaCreditoForm 
                  values={values} 
                  onChange={onChange}
                  detalles={detalles}
                  onDetallesChange={onDetallesChange}
                />
              </div>
              
              <div className="modal-footer">
                <div className="d-flex justify-content-between w-100 align-items-center">
                  <div className="text-muted small">
                    {detalles.length > 0 && (
                      <>
                        <i className="fas fa-box me-1"></i>
                        {detalles.length} producto{detalles.length !== 1 ? 's' : ''} en la nota
                      </>
                    )}
                  </div>
                  
                  <div className="d-flex gap-2">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={onClose}
                      disabled={enviandoSRI}
                    >
                      <i className="fas fa-times me-1"></i>
                      Cancelar
                    </button>
                    
                    <button 
                      type="submit" 
                      className="btn btn-danger"
                      disabled={enviandoSRI || detalles.length === 0}
                    >
                      {enviandoSRI ? (
                        <>
                          <span className="spinner-border spinner-border-sm me-2"></span>
                          Enviando al SRI...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-paper-plane me-1"></i>
                          {editando ? "Actualizar" : "Crear"} y Enviar al SRI
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      
      <div 
        className="modal-backdrop fade show" 
        onClick={handleBackdropClick}
        style={{ zIndex: 1040 }}
      ></div>
    </>
  );
};

export default NotaCreditoModal;
