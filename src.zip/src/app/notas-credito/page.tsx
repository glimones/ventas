import { AppShell } from "@/components/app-shell";
import NotasCreditoPage from "./NotasCreditoPage";

export default function Page() {
  return <AppShell><NotasCreditoPage /></AppShell>;
}
