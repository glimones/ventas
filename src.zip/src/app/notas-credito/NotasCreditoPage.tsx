"use client";

import React, { useState } from "react";
import { NotaCredito, NotaCreditoFormValues, DetalleNotaCreditoFormValues, InfoNotaCredito, TotalConImpuesto } from "./types";
import NotaCreditoModal from "./NotaCreditoModal";
import { SRIUniversalService } from "../../services/sri-universal.service";
import "./notas-credito.css";
import { CirclePlus, SquarePen, Trash2, Eye, Send, Download } from 'lucide-react';

const initialForm: NotaCreditoFormValues = {
  ambiente: "1", // Pruebas por defecto
  razon_social: "",
  nombre_comercial: "",
  ruc: "",
  estab: "001",
  ptoEmi: "001",
  secuencial: "1",
  direccion_matriz: "",
  fecha_emision: new Date().toISOString().split('T')[0],
  direccion_establecimiento: "",
  tipo_identificacion_sujeto_retenido: "",
  razon_social_sujeto_retenido: "",
  identificacion_sujeto_retenido: "",
  contribuyente_especial: "",
  obligado_contabilidad: "NO",
  rise: "",
  cod_doc_modificado: "",
  num_doc_modificado: "",
  fecha_emision_doc_modificado: "",
  valor_modificacion: 0,
  moneda: "DOLAR",
  motivo: "",
};

const initialNotasCredito: NotaCredito[] = [
  {
    id: 1,
    info_tributaria: {
      ambiente: "1",
      tipo_emision: "1",
      razon_social: "EMPRESA DEMO S.A.",
      nombre_comercial: "Demo",
      ruc: "1234567890001",
      clave_acceso: "2309202404123456789000110010010000000011234567894",
      cod_doc: "04",
      estab: "001",
      ptoEmi: "001",
      secuencial: "000000001",
      direccion_matriz: "Av. Principal 123, Ciudad Demo"
    },
    info_nota_credito: {
      fecha_emision: "23/09/2024",
      direccion_establecimiento: "Av. Principal 123, Ciudad Demo",
      tipo_identificacion_sujeto_retenido: "05",
      razon_social_sujeto_retenido: "CLIENTE DEMO",
      identificacion_sujeto_retenido: "1234567890",
      contribuyente_especial: "",
      obligado_contabilidad: "SI",
      rise: "",
      cod_doc_modificado: "01",
      num_doc_modificado: "001-001-000000001",
      fecha_emision_doc_modificado: "20/09/2024",
      total_sin_impuestos: 50.00,
      valor_modificacion: 56.00,
      moneda: "DOLAR",
      motivo: "Devolución de mercadería"
    },
    detalles: [
      {
        id: 1,
        codigo_principal: "PROD001",
        descripcion: "Producto Demo - Devolución",
        cantidad: 1,
        precio_unitario: 50.00,
        descuento: 0.00,
        precio_total_sin_impuesto: 50.00,
        codigo_porcentaje_iva: "2",
        tarifa_iva: 0.12,
        valor_iva: 6.00,
        precio_total_con_impuesto: 56.00
      }
    ],
    total_con_impuestos: [
      {
        codigo: "2",
        codigo_porcentaje: "2",
        descuento_adicional: 0.00,
        base_imponible: 50.00,
        tarifa: 0.12,
        valor: 6.00
      }
    ],
    estado_sri: 'AUTORIZADA',
    numero_autorizacion: "2309202412345678901234567890123456",
    fecha_autorizacion: "2024-09-23T10:30:00.000Z",
    fecha_creacion: "2024-09-23T10:00:00.000Z",
    fecha_actualizacion: "2024-09-23T10:30:00.000Z"
  }
];

export default function NotasCreditoPage() {
  const [notasCredito, setNotasCredito] = useState<NotaCredito[]>(initialNotasCredito);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<NotaCreditoFormValues>(initialForm);
  const [detalles, setDetalles] = useState<DetalleNotaCreditoFormValues[]>([]);
  const [enviandoSRI, setEnviandoSRI] = useState<boolean>(false);

  const sriService = SRIUniversalService.getInstance();

  const limpiarForm = () => {
    setForm(initialForm);
    setDetalles([]);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    // Auto-incrementar secuencial
    const ultimoSecuencial = Math.max(...notasCredito.map(nc => parseInt(nc.info_tributaria.secuencial) || 0), 0);
    setForm(prev => ({
      ...prev,
      secuencial: (ultimoSecuencial + 1).toString()
    }));
    setShowModal(true);
  };
  
  const abrirModalEditar = (notaCredito: NotaCredito) => {
    setForm({
      ambiente: notaCredito.info_tributaria.ambiente,
      razon_social: notaCredito.info_tributaria.razon_social,
      nombre_comercial: notaCredito.info_tributaria.nombre_comercial,
      ruc: notaCredito.info_tributaria.ruc,
      estab: notaCredito.info_tributaria.estab,
      ptoEmi: notaCredito.info_tributaria.ptoEmi,
      secuencial: notaCredito.info_tributaria.secuencial,
      direccion_matriz: notaCredito.info_tributaria.direccion_matriz,
      fecha_emision: notaCredito.info_nota_credito.fecha_emision.split('/').reverse().join('-'),
      direccion_establecimiento: notaCredito.info_nota_credito.direccion_establecimiento,
      tipo_identificacion_sujeto_retenido: notaCredito.info_nota_credito.tipo_identificacion_sujeto_retenido,
      razon_social_sujeto_retenido: notaCredito.info_nota_credito.razon_social_sujeto_retenido,
      identificacion_sujeto_retenido: notaCredito.info_nota_credito.identificacion_sujeto_retenido,
      contribuyente_especial: notaCredito.info_nota_credito.contribuyente_especial || "",
      obligado_contabilidad: notaCredito.info_nota_credito.obligado_contabilidad,
      rise: notaCredito.info_nota_credito.rise || "",
      cod_doc_modificado: notaCredito.info_nota_credito.cod_doc_modificado,
      num_doc_modificado: notaCredito.info_nota_credito.num_doc_modificado,
      fecha_emision_doc_modificado: notaCredito.info_nota_credito.fecha_emision_doc_modificado.split('/').reverse().join('-'),
      valor_modificacion: notaCredito.info_nota_credito.valor_modificacion,
      moneda: notaCredito.info_nota_credito.moneda,
      motivo: notaCredito.info_nota_credito.motivo,
    });
    
    setDetalles(notaCredito.detalles.map(det => ({
      codigo_principal: det.codigo_principal,
      codigo_auxiliar: det.codigo_auxiliar || "",
      descripcion: det.descripcion,
      cantidad: det.cantidad,
      precio_unitario: det.precio_unitario,
      descuento: det.descuento,
      codigo_porcentaje_iva: det.codigo_porcentaje_iva,
    })));
    
    setEditandoId(notaCredito.id);
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const calcularTotalesNotaCredito = (detallesNota: DetalleNotaCreditoFormValues[]) => {
    let totalSinImpuestos = 0;
    let totalDescuentos = 0;
    let totalIva = 0;
    const totalesConImpuestos: TotalConImpuesto[] = [];

    detallesNota.forEach(detalle => {
      const subtotal = (detalle.cantidad * detalle.precio_unitario) - detalle.descuento;
      totalSinImpuestos += subtotal;
      totalDescuentos += detalle.descuento;

      let tarifaIva = 0;
      if (detalle.codigo_porcentaje_iva === "2") {
        tarifaIva = 0.12;
      } else if (detalle.codigo_porcentaje_iva === "3") {
        tarifaIva = 0.14;
      }

      const valorIva = subtotal * tarifaIva;
      totalIva += valorIva;

      // Agrupar por código de porcentaje
      const existente = totalesConImpuestos.find(t => t.codigo_porcentaje === detalle.codigo_porcentaje_iva);
      if (existente) {
        existente.base_imponible += subtotal;
        existente.valor += valorIva;
      } else {
        totalesConImpuestos.push({
          codigo: "2",
          codigo_porcentaje: detalle.codigo_porcentaje_iva,
          descuento_adicional: 0,
          base_imponible: subtotal,
          tarifa: tarifaIva,
          valor: valorIva
        });
      }
    });

    return {
      totalSinImpuestos,
      totalDescuentos,
      totalIva,
      totalesConImpuestos,
      valorModificacion: totalSinImpuestos + totalIva
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (detalles.length === 0) {
      alert('Debe agregar al menos un detalle a la nota de crédito');
      return;
    }

    setEnviandoSRI(true);
    
    try {
      const totales = calcularTotalesNotaCredito(detalles);
      
      // Crear estructura completa de la nota de crédito
      const infoNotaCredito: InfoNotaCredito = {
        fecha_emision: form.fecha_emision.split('-').reverse().join('/'),
        direccion_establecimiento: form.direccion_establecimiento,
        tipo_identificacion_sujeto_retenido: form.tipo_identificacion_sujeto_retenido,
        razon_social_sujeto_retenido: form.razon_social_sujeto_retenido,
        identificacion_sujeto_retenido: form.identificacion_sujeto_retenido,
        contribuyente_especial: form.contribuyente_especial,
        obligado_contabilidad: form.obligado_contabilidad,
        rise: form.rise,
        cod_doc_modificado: form.cod_doc_modificado,
        num_doc_modificado: form.num_doc_modificado,
        fecha_emision_doc_modificado: form.fecha_emision_doc_modificado.split('-').reverse().join('/'),
        total_sin_impuestos: totales.totalSinImpuestos,
        valor_modificacion: form.valor_modificacion || totales.valorModificacion,
        moneda: form.moneda,
        motivo: form.motivo,
      };

      const detallesCompletos = detalles.map((det, index) => {
        const subtotal = (det.cantidad * det.precio_unitario) - det.descuento;
        let tarifaIva = 0;
        if (det.codigo_porcentaje_iva === "2") {
          tarifaIva = 0.12;
        } else if (det.codigo_porcentaje_iva === "3") {
          tarifaIva = 0.14;
        }
        const valorIva = subtotal * tarifaIva;

        return {
          id: index + 1,
          codigo_principal: det.codigo_principal,
          codigo_auxiliar: det.codigo_auxiliar,
          descripcion: det.descripcion,
          cantidad: det.cantidad,
          precio_unitario: det.precio_unitario,
          descuento: det.descuento,
          precio_total_sin_impuesto: subtotal,
          codigo_porcentaje_iva: det.codigo_porcentaje_iva,
          tarifa_iva: tarifaIva,
          valor_iva: valorIva,
          precio_total_con_impuesto: subtotal + valorIva
        };
      });

      const nuevaNotaCredito: NotaCredito = {
        id: editandoId || Date.now(),
        info_tributaria: {
          ambiente: form.ambiente,
          tipo_emision: "1",
          razon_social: form.razon_social,
          nombre_comercial: form.nombre_comercial,
          ruc: form.ruc,
          clave_acceso: "",
          cod_doc: "04",
          estab: form.estab,
          ptoEmi: form.ptoEmi,
          secuencial: form.secuencial,
          direccion_matriz: form.direccion_matriz,
        },
        info_nota_credito: infoNotaCredito,
        detalles: detallesCompletos,
        total_con_impuestos: totales.totalesConImpuestos,
        estado_sri: 'PENDIENTE',
        fecha_creacion: new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString()
      };

      // Crear estructura para el servicio SRI
      const comprobanteParaSRI = {
        id: nuevaNotaCredito.id,
        tipo_comprobante: '04' as const,
        info_tributaria: nuevaNotaCredito.info_tributaria,
        estado_sri: nuevaNotaCredito.estado_sri,
        fecha_creacion: nuevaNotaCredito.fecha_creacion,
        fecha_actualizacion: nuevaNotaCredito.fecha_actualizacion
      };

      // Generar XML específico para nota de crédito
      const datosEspecificos = `
  <infoNotaCredito>
    <fechaEmision>${infoNotaCredito.fecha_emision}</fechaEmision>
    <dirEstablecimiento><![CDATA[${infoNotaCredito.direccion_establecimiento}]]></dirEstablecimiento>
    <tipoIdentificacionSujetoRetenido>${infoNotaCredito.tipo_identificacion_sujeto_retenido}</tipoIdentificacionSujetoRetenido>
    <razonSocialSujetoRetenido><![CDATA[${infoNotaCredito.razon_social_sujeto_retenido}]]></razonSocialSujetoRetenido>
    <identificacionSujetoRetenido>${infoNotaCredito.identificacion_sujeto_retenido}</identificacionSujetoRetenido>
    <obligadoContabilidad>${infoNotaCredito.obligado_contabilidad}</obligadoContabilidad>
    <codDocModificado>${infoNotaCredito.cod_doc_modificado}</codDocModificado>
    <numDocModificado>${infoNotaCredito.num_doc_modificado}</numDocModificado>
    <fechaEmisionDocSustento>${infoNotaCredito.fecha_emision_doc_modificado}</fechaEmisionDocSustento>
    <totalSinImpuestos>${infoNotaCredito.total_sin_impuestos.toFixed(2)}</totalSinImpuestos>
    <valorModificacion>${infoNotaCredito.valor_modificacion.toFixed(2)}</valorModificacion>
    <moneda>${infoNotaCredito.moneda}</moneda>
    <totalConImpuestos>
      ${totales.totalesConImpuestos.map(impuesto => `
      <totalImpuesto>
        <codigo>${impuesto.codigo}</codigo>
        <codigoPorcentaje>${impuesto.codigo_porcentaje}</codigoPorcentaje>
        <baseImponible>${impuesto.base_imponible.toFixed(2)}</baseImponible>
        <tarifa>${impuesto.tarifa.toFixed(2)}</tarifa>
        <valor>${impuesto.valor.toFixed(2)}</valor>
      </totalImpuesto>`).join('')}
    </totalConImpuestos>
    <motivo><![CDATA[${infoNotaCredito.motivo}]]></motivo>
  </infoNotaCredito>
  <detalles>
    ${detallesCompletos.map(detalle => `
    <detalle>
      <codigoPrincipal><![CDATA[${detalle.codigo_principal}]]></codigoPrincipal>
      <descripcion><![CDATA[${detalle.descripcion}]]></descripcion>
      <cantidad>${detalle.cantidad}</cantidad>
      <precioUnitario>${detalle.precio_unitario.toFixed(6)}</precioUnitario>
      <descuento>${detalle.descuento.toFixed(2)}</descuento>
      <precioTotalSinImpuesto>${detalle.precio_total_sin_impuesto.toFixed(2)}</precioTotalSinImpuesto>
      <impuestos>
        <impuesto>
          <codigo>2</codigo>
          <codigoPorcentaje>${detalle.codigo_porcentaje_iva}</codigoPorcentaje>
          <tarifa>${detalle.tarifa_iva.toFixed(2)}</tarifa>
          <baseImponible>${detalle.precio_total_sin_impuesto.toFixed(2)}</baseImponible>
          <valor>${detalle.valor_iva.toFixed(2)}</valor>
        </impuesto>
      </impuestos>
    </detalle>`).join('')}
  </detalles>`;

      // Enviar al SRI
      console.log('🚀 Enviando nota de crédito al SRI...', nuevaNotaCredito);
      const respuestaSRI = await sriService.enviarComprobanteSRI(comprobanteParaSRI, datosEspecificos, infoNotaCredito.fecha_emision);

      // Actualizar nota de crédito con respuesta del SRI
      nuevaNotaCredito.estado_sri = respuestaSRI.estado;
      if (respuestaSRI.success) {
        nuevaNotaCredito.numero_autorizacion = respuestaSRI.numero_autorizacion;
        nuevaNotaCredito.fecha_autorizacion = respuestaSRI.fecha_autorizacion;
        nuevaNotaCredito.xml_generado = respuestaSRI.xml_autorizado;
      }
      nuevaNotaCredito.observaciones_sri = respuestaSRI.observaciones;

      // Actualizar lista de notas de crédito
      if (editandoId) {
        setNotasCredito((prev) =>
          prev.map((nota) =>
            nota.id === editandoId ? nuevaNotaCredito : nota
          )
        );
      } else {
        setNotasCredito((prev) => [...prev, nuevaNotaCredito]);
      }

      // Mostrar resultado
      if (respuestaSRI.success) {
        alert(`✅ Nota de Crédito ${respuestaSRI.estado.toLowerCase()} exitosamente.\nNúmero de autorización: ${respuestaSRI.numero_autorizacion}`);
        cerrarModal();
      } else {
        alert(`❌ Error del SRI: ${respuestaSRI.mensaje_error}\n\nObservaciones: ${respuestaSRI.observaciones}`);
      }

    } catch (error) {
      console.error('Error procesando nota de crédito:', error);
      alert('Error inesperado al procesar la nota de crédito');
    } finally {
      setEnviandoSRI(false);
    }
  };

  const eliminarNotaCredito = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta nota de crédito?")) {
      setNotasCredito((prev) => prev.filter((nota) => nota.id !== id));
    }
  };

  const reenviarSRI = async (notaCredito: NotaCredito) => {
    if (window.confirm("¿Desea reenviar esta nota de crédito al SRI?")) {
      setEnviandoSRI(true);
      try {
        const comprobanteParaSRI = {
          id: notaCredito.id,
          tipo_comprobante: '04' as const,
          info_tributaria: notaCredito.info_tributaria,
          estado_sri: notaCredito.estado_sri,
          fecha_creacion: notaCredito.fecha_creacion,
          fecha_actualizacion: notaCredito.fecha_actualizacion
        };

        const respuestaSRI = await sriService.enviarComprobanteSRI(comprobanteParaSRI, "", notaCredito.info_nota_credito.fecha_emision);
        
        // Actualizar nota de crédito
        const notaActualizada = {
          ...notaCredito,
          estado_sri: respuestaSRI.estado,
          numero_autorizacion: respuestaSRI.numero_autorizacion,
          fecha_autorizacion: respuestaSRI.fecha_autorizacion,
          xml_generado: respuestaSRI.xml_autorizado,
          observaciones_sri: respuestaSRI.observaciones,
          fecha_actualizacion: new Date().toISOString()
        };

        setNotasCredito(prev => prev.map(nc => nc.id === notaCredito.id ? notaActualizada : nc));

        if (respuestaSRI.success) {
          alert(`✅ Nota de Crédito ${respuestaSRI.estado.toLowerCase()} exitosamente.`);
        } else {
          alert(`❌ Error del SRI: ${respuestaSRI.mensaje_error}`);
        }
      } catch (error) {
        console.error('Error al reenviar:', error);
        alert('Error al reenviar nota de crédito al SRI');
      } finally {
        setEnviandoSRI(false);
      }
    }
  };

  const notasCreditoFiltradas = notasCredito.filter((nota) =>
    Object.values(nota.info_nota_credito)
      .concat(Object.values(nota.info_tributaria))
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'AUTORIZADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'DEVUELTA': return 'bg-warning text-dark';
      case 'PENDIENTE': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Notas de Crédito Electrónicas</h1>
            <p className="text-muted mb-0">Gestión de notas de crédito SRI Ecuador</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-info">Ambiente: Pruebas</span>
            <span className="badge bg-danger">{notasCredito.length} notas</span>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar por cliente, RUC, secuencial..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-danger d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Nota de Crédito</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Secuencial</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>Doc. Modificado</th>
                <th>Motivo</th>
                <th>Valor</th>
                <th>Estado SRI</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {notasCreditoFiltradas.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-4">
                    <div className="text-muted">
                      <i className="fas fa-file-minus fa-3x mb-3 d-block"></i>
                      No se encontraron notas de crédito
                    </div>
                  </td>
                </tr>
              )}
              {notasCreditoFiltradas.map((nota) => (
                <tr key={nota.id}>
                  <td>
                    <strong>{nota.info_tributaria.estab}-{nota.info_tributaria.ptoEmi}-{nota.info_tributaria.secuencial.padStart(9, '0')}</strong>
                  </td>
                  <td>{nota.info_nota_credito.fecha_emision}</td>
                  <td>{nota.info_nota_credito.razon_social_sujeto_retenido}</td>
                  <td>
                    <small className="text-muted">
                      {nota.info_nota_credito.cod_doc_modificado === '01' ? 'Factura' : 'Liquidación'}: {nota.info_nota_credito.num_doc_modificado}
                    </small>
                  </td>
                  <td>
                    <small title={nota.info_nota_credito.motivo}>
                      {nota.info_nota_credito.motivo.substring(0, 20)}
                      {nota.info_nota_credito.motivo.length > 20 ? '...' : ''}
                    </small>
                  </td>
                  <td className="text-end">
                    <strong>${nota.info_nota_credito.valor_modificacion.toFixed(2)}</strong>
                  </td>
                  <td>
                    <span className={`badge ${getEstadoBadgeClass(nota.estado_sri)}`}>
                      {nota.estado_sri}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => abrirModalEditar(nota)}
                        title="Ver detalles"
                      >
                        <Eye size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(nota)}
                        title="Editar"
                        disabled={nota.estado_sri === 'AUTORIZADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      {(nota.estado_sri === 'RECHAZADA' || nota.estado_sri === 'DEVUELTA' || nota.estado_sri === 'PENDIENTE') && (
                        <button
                          className="btn btn-outline-primary btn-sm"
                          onClick={() => reenviarSRI(nota)}
                          title="Reenviar al SRI"
                          disabled={enviandoSRI}
                        >
                          <Send size={14} />
                        </button>
                      )}
                      
                      {nota.xml_generado && (
                        <button
                          className="btn btn-outline-success btn-sm"
                          title="Descargar XML"
                          onClick={() => {
                            const blob = new Blob([nota.xml_generado!], { type: 'application/xml' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `nota_credito_${nota.info_tributaria.secuencial}.xml`;
                            a.click();
                          }}
                        >
                          <Download size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarNotaCredito(nota.id)}
                        title="Eliminar"
                        disabled={nota.estado_sri === 'AUTORIZADA'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <NotaCreditoModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          detalles={detalles}
          onChange={handleChange}
          onDetallesChange={setDetalles}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          enviandoSRI={enviandoSRI}
        />
      </div>
    </div>
  );
}
