"use client";

import React, { useState, useCallback } from "react";
import { Cliente, ClienteFormValues } from "./types";
import ClienteModal from "./MovimientoModal";
import "./bootstrap-cliente.css";
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: ClienteFormValues = {
  nombre: "",
  apellido: "",
  empresa: "",
  tipo_documento: "",
  documento: "",
  direccion: "",
  ciudad: "",
  provincia: "",
  pais: "",
  codigo_postal: "",
  email: "",
  telefono: "",
  celular: "",
  notas: "",
  estado: "Activo",
};

const initialClientes: Cliente[] = [
  {
    id: 1,
    nombre: "Juan",
    apellido: "Pérez",
    empresa: "Empresa Ejemplo S.A.",
    tipo_documento: "DNI",
    documento: "12345678",
    direccion: "Av. Principal 123",
    ciudad: "Madrid",
    provincia: "Madrid",
    pais: "es",
    codigo_postal: "28001",
    email: "juan.perez@ejemplo.com",
    telefono: "912345678",
    celular: "612345678",
    notas: "Cliente preferente",
    estado: "Activo",
  },
  {
    id: 2,
    nombre: "María",
    apellido: "González",
    tipo_documento: "PASAPORTE",
    documento: "AB123456",
    direccion: "Calle Secundaria 456",
    ciudad: "Barcelona",
    provincia: "Barcelona",
    pais: "es",
    email: "maria.gonzalez@ejemplo.com",
    telefono: "934567890",
    estado: "Activo",
  },
];

export default function ClientesPage() {
  const [clientes, setClientes] = useState<Cliente[]>(initialClientes);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ClienteFormValues>(initialForm);

  const limpiarForm = useCallback(() => {
    setForm(initialForm);
    setEditandoId(null);
  }, []);

  const abrirModalNueva = useCallback(() => {
    limpiarForm();
    // Asegurarse de que el formulario esté limpio antes de mostrar el modal
    setTimeout(() => {
      setShowModal(true);
      console.log("Modal abierto para nuevo cliente");
    }, 0);
  }, [limpiarForm]);
  
  const abrirModalEditar = useCallback((cliente: Cliente) => {
    // Crear un nuevo objeto para evitar referencias
    setForm({
      nombre: cliente.nombre || "",
      apellido: cliente.apellido || "",
      empresa: cliente.empresa || "",
      tipo_documento: cliente.tipo_documento || "",
      documento: cliente.documento || "",
      direccion: cliente.direccion || "",
      ciudad: cliente.ciudad || "",
      provincia: cliente.provincia || "",
      pais: cliente.pais || "",
      codigo_postal: cliente.codigo_postal || "",
      email: cliente.email || "",
      telefono: cliente.telefono || "",
      celular: cliente.celular || "",
      notas: cliente.notas || "",
      estado: cliente.estado || "Activo",
    });
    setEditandoId(cliente.id);
    
    // Asegurarse de que el formulario esté actualizado antes de mostrar el modal
    setTimeout(() => {
      setShowModal(true);
      console.log("Modal abierto para editar cliente:", cliente.id);
    }, 0);
  }, []);

  const cerrarModal = useCallback(() => {
    console.log("Cerrando modal");
    setShowModal(false);
    // Limpiar el formulario después de que el modal se haya cerrado
    setTimeout(limpiarForm, 300);
  }, [limpiarForm]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    console.log(`Campo ${name} cambiado a: ${value}`);
    
    setForm(prev => ({
      ...prev,
      [name]: value,
    }));
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    console.log("Formulario enviado:", form, "Editando ID:", editandoId);
    
    if (editandoId) {
      setClientes(prev =>
        prev.map(cliente =>
          cliente.id === editandoId ? { ...cliente, ...form, id: editandoId } : cliente
        )
      );
      console.log("Cliente actualizado");
    } else {
      const nuevoId = Date.now();
      setClientes(prev => [
        ...prev,
        { ...form, id: nuevoId } as Cliente,
      ]);
      console.log("Nuevo cliente añadido con ID:", nuevoId);
    }
    
    cerrarModal();
  }, [form, editandoId, cerrarModal]);

  const eliminarCliente = useCallback((id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar este cliente?")) {
      setClientes(prev => prev.filter(cliente => cliente.id !== id));
      console.log("Cliente eliminado:", id);
    }
  }, []);

  const clientesFiltrados = clientes.filter(cliente =>
    Object.values(cliente)
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">Clientes</h1>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar cliente..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button 
            className="btn btn-primary d-flex align-items-center" 
            onClick={abrirModalNueva}
            type="button"
          >
            <CirclePlus className="me-2" size={16} />
            <span>Añadir Cliente</span>
          </button>
        </div>
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-light">
              <tr>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Documento</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {clientesFiltrados.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center">
                    No se encontraron clientes
                  </td>
                </tr>
              )}
              {clientesFiltrados.map((cliente) => (
                <tr key={cliente.id}>
                  <td>{cliente.nombre}</td>
                  <td>{cliente.apellido}</td>
                  <td>{cliente.tipo_documento}: {cliente.documento}</td>
                  <td>{cliente.email}</td>
                  <td>{cliente.telefono}</td>
                  <td>
                    <span
                      className={`badge bg-${
                        cliente.estado === "Activo"
                          ? "success"
                          : "secondary"
                      }`}
                    >
                      {cliente.estado}
                    </span>
                  </td>
                  <td>
                    <button
                      className="btn btn-warning btn-sm me-1"
                      onClick={() => abrirModalEditar(cliente)}
                      type="button"
                    >
                      <SquarePen size={16} className="me-1" />
                      Editar
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => eliminarCliente(cliente.id)}
                      type="button"
                    >
                      <Trash2 size={16} className="me-1" />
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <ClienteModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}