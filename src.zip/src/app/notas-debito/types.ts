// Tipos de datos para Notas de Débito electrónicas Ecuador SRI

export interface InfoNotaDebito {
  fecha_emision: string; // DD/MM/YYYY
  direccion_establecimiento: string;
  tipo_identificacion_sujeto_retenido: string;
  razon_social_sujeto_retenido: string;
  identificacion_sujeto_retenido: string;
  contribuyente_especial?: string;
  obligado_contabilidad: string; // SI o NO
  rise?: string;
  cod_doc_modificado: string; // 01 = Factura, 03 = Liquidación de compra
  num_doc_modificado: string;
  fecha_emision_doc_modificado: string;
  total_sin_impuestos: number;
  valor_total: number;
  valor_modificacion: number;
  moneda: string; // DOLAR
  motivo: string; // Razón de la nota de débito
}

export interface NotaDebito {
  id: number;
  info_tributaria: {
    ambiente: string;
    tipo_emision: string;
    razon_social: string;
    nombre_comercial: string;
    ruc: string;
    clave_acceso: string;
    cod_doc: string; // 05 para Nota de Débito
    estab: string;
    ptoEmi: string;
    secuencial: string;
    direccion_matriz: string;
  };
  info_nota_debito: InfoNotaDebito;
  estado_sri: 'PENDIENTE' | 'AUTORIZADA' | 'RECHAZADA' | 'DEVUELTA';
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  xml_generado?: string;
  observaciones_sri?: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
}

export interface NotaDebitoFormValues {
  ambiente: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
  fecha_emision: string;
  direccion_establecimiento: string;
  tipo_identificacion_sujeto_retenido: string;
  razon_social_sujeto_retenido: string;
  identificacion_sujeto_retenido: string;
  contribuyente_especial: string;
  obligado_contabilidad: string;
  rise: string;
  cod_doc_modificado: string;
  num_doc_modificado: string;
  fecha_emision_doc_modificado: string;
  valor_modificacion: number;
  moneda: string;
  motivo: string;
}

export const MOTIVOS_DEBITO_COMUNES = [
  'Intereses por mora',
  'Gastos de cobranza',
  'Diferencia de precio',
  'Corrección de facturación',
  'Penalizaciones',
  'Gastos adicionales',
  'Otros',
];

export const TIPO_IDENTIFICACION_OPTIONS = [
  { value: '04', label: 'RUC' },
  { value: '05', label: 'Cédula' },
  { value: '06', label: 'Pasaporte' },
  { value: '07', label: 'Venta a consumidor final' },
  { value: '08', label: 'Identificación del exterior' },
];

export const COD_DOC_MODIFICADO_OPTIONS = [
  { value: '01', label: 'Factura' },
  { value: '03', label: 'Liquidación de compra' },
];

export const AMBIENTE_OPTIONS = [
  { value: '1', label: 'Pruebas' },
  { value: '2', label: 'Producción' },
];
