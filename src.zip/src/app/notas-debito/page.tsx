import { AppShell } from "@/components/app-shell";
import NotasDebitoPage from "./NotasDebitoPage";

export default function Page() {
  return <AppShell><NotasDebitoPage /></AppShell>;
}
