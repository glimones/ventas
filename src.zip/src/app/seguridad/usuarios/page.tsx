import { AppShell } from "@/components/app-shell";
import { SecurityModule } from "../_components/security-module";

export default function UsuariosPage() {
  return (
    <AppShell>
      <SecurityModule mode="usuarios" />
    </AppShell>
  );
}