"use client";

import React, { useMemo, useState } from "react";
import { CirclePlus, KeyRound, PenSquare, ShieldCheck, Trash2, Users } from "lucide-react";

type SecurityMode = "usuarios" | "roles" | "permisos";

type UserItem = {
  id: number;
  nombres: string;
  usuario: string;
  correo: string;
  telefono: string;
  cargo: string;
  area: string;
  rol: string;
  sucursal: string;
  estado: string;
};

type RoleItem = {
  id: number;
  nombre: string;
  codigo: string;
  descripcion: string;
  alcance: string;
  nivel: string;
  estado: string;
};

type PermissionItem = {
  id: number;
  usuario: string;
  rol: string;
  modulo: string;
  puedeVer: boolean;
  puedeCrear: boolean;
  puedeEditar: boolean;
  puedeEliminar: boolean;
  puedeAprobar: boolean;
  vigencia: string;
  estado: string;
};

type UserFormValues = {
  nombres: string;
  usuario: string;
  correo: string;
  telefono: string;
  cargo: string;
  area: string;
  rol: string;
  sucursal: string;
  estado: string;
};

type RoleFormValues = {
  nombre: string;
  codigo: string;
  descripcion: string;
  alcance: string;
  nivel: string;
  estado: string;
};

type PermissionFormValues = {
  usuario: string;
  rol: string;
  modulo: string;
  puedeVer: boolean;
  puedeCrear: boolean;
  puedeEditar: boolean;
  puedeEliminar: boolean;
  puedeAprobar: boolean;
  vigencia: string;
  estado: string;
};

const initialUsers: UserItem[] = [
  {
    id: 1,
    nombres: "Ana Torres",
    usuario: "atorres",
    correo: "ana.torres@glimones.com",
    telefono: "0991112233",
    cargo: "Jefe de Operaciones",
    area: "Operaciones",
    rol: "Administrador",
    sucursal: "Matriz",
    estado: "Activo",
  },
  {
    id: 2,
    nombres: "Luis Mendoza",
    usuario: "lmendoza",
    correo: "luis.mendoza@glimones.com",
    telefono: "0987654321",
    cargo: "Analista de Ventas",
    area: "Comercial",
    rol: "Vendedor",
    sucursal: "Sucursal Norte",
    estado: "Activo",
  },
];

const initialRoles: RoleItem[] = [
  {
    id: 1,
    nombre: "Administrador",
    codigo: "ADM",
    descripcion: "Control total del sistema y parametrización general.",
    alcance: "Corporativo",
    nivel: "Alto",
    estado: "Activo",
  },
  {
    id: 2,
    nombre: "Vendedor",
    codigo: "VEN",
    descripcion: "Gestión comercial, clientes y cotizaciones.",
    alcance: "Operativo",
    nivel: "Medio",
    estado: "Activo",
  },
];

const initialPermissions: PermissionItem[] = [
  {
    id: 1,
    usuario: "atorres",
    rol: "Administrador",
    modulo: "Facturas",
    puedeVer: true,
    puedeCrear: true,
    puedeEditar: true,
    puedeEliminar: true,
    puedeAprobar: true,
    vigencia: "Permanente",
    estado: "Activo",
  },
  {
    id: 2,
    usuario: "lmendoza",
    rol: "Vendedor",
    modulo: "Cotizaciones",
    puedeVer: true,
    puedeCrear: true,
    puedeEditar: true,
    puedeEliminar: false,
    puedeAprobar: false,
    vigencia: "Permanente",
    estado: "Activo",
  },
];

function PageShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">{children}</div>
    </div>
  );
}

function Badge({ children, tone = "secondary" }: { children: React.ReactNode; tone?: "secondary" | "primary" | "success" | "warning" | "danger" | "dark" }) {
  return <span className={`badge bg-${tone}`}>{children}</span>;
}

function SectionTitle({ title, description, countText, icon }: { title: string; description: string; countText: string; icon: React.ReactNode }) {
  return (
    <div className="d-flex justify-content-between align-items-center mb-4">
      <div>
        <h1 className="mb-2">{title}</h1>
        <p className="text-muted mb-0">{description}</p>
      </div>
      <div className="d-flex align-items-center gap-2">
        <span className="badge bg-dark">Sistema: Activo</span>
        <span className="badge bg-primary text-white">{countText}</span>
        <span className="badge bg-success text-white d-inline-flex align-items-center gap-1">
          {icon}
        </span>
      </div>
    </div>
  );
}

function Toolbar({
  value,
  onChange,
  onCreate,
  placeholder,
  buttonLabel,
}: {
  value: string;
  onChange: (value: string) => void;
  onCreate: () => void;
  placeholder: string;
  buttonLabel: string;
}) {
  return (
    <div className="d-flex justify-content-between align-items-center mb-3 gap-3">
      <input
        type="text"
        className="form-control w-50"
        placeholder={placeholder}
        value={value}
        onChange={(event) => onChange(event.target.value)}
      />
      <button className="btn btn-primary d-flex align-items-center" onClick={onCreate} type="button">
        <CirclePlus className="me-2" size={16} />
        <span>{buttonLabel}</span>
      </button>
    </div>
  );
}

function ModalShell({
  open,
  title,
  onClose,
  children,
}: {
  open: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  if (!open) return null;

  return (
    <div className="modal fade show d-block" style={{ zIndex: 1050 }}>
      <div className="modal-dialog modal-xl">
        <div className="modal-content">
          <div className="modal-header bg-success text-white">
            <h5 className="modal-title">{title}</h5>
            <button type="button" className="btn-close btn-close-white" onClick={onClose} />
          </div>
          {children}
        </div>
      </div>
    </div>
  );
}

function Label({ children, htmlFor }: { children: React.ReactNode; htmlFor: string }) {
  return (
    <label htmlFor={htmlFor} className="form-label">
      {children}
    </label>
  );
}

export function SecurityModule({ mode }: { mode: SecurityMode }) {
  if (mode === "roles") return <RolesScreen />;
  if (mode === "permisos") return <PermissionsScreen />;
  return <UsersScreen />;
}

function UsersScreen() {
  const [items, setItems] = useState<UserItem[]>(initialUsers);
  const [filtro, setFiltro] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<UserFormValues>({
    nombres: "",
    usuario: "",
    correo: "",
    telefono: "",
    cargo: "",
    area: "",
    rol: "Administrador",
    sucursal: "Matriz",
    estado: "Activo",
  });

  const filtrados = useMemo(() => {
    const term = filtro.toLowerCase();
    return items.filter((item) => [item.nombres, item.usuario, item.correo, item.cargo, item.area, item.rol, item.sucursal, item.estado].join(" ").toLowerCase().includes(term));
  }, [filtro, items]);

  const abrirNuevo = () => {
    setForm({ nombres: "", usuario: "", correo: "", telefono: "", cargo: "", area: "", rol: "Administrador", sucursal: "Matriz", estado: "Activo" });
    setEditandoId(null);
    setShowModal(true);
  };

  const abrirEditar = (item: UserItem) => {
    setForm({
      nombres: item.nombres,
      usuario: item.usuario,
      correo: item.correo,
      telefono: item.telefono,
      cargo: item.cargo,
      area: item.area,
      rol: item.rol,
      sucursal: item.sucursal,
      estado: item.estado,
    });
    setEditandoId(item.id);
    setShowModal(true);
  };

  const guardar = (event: React.FormEvent) => {
    event.preventDefault();
    if (editandoId) {
      setItems((current) => current.map((item) => (item.id === editandoId ? { ...item, ...form } : item)));
    } else {
      setItems((current) => [...current, { id: Date.now(), ...form }]);
    }
    setShowModal(false);
  };

  const eliminar = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar este usuario?")) {
      setItems((current) => current.filter((item) => item.id !== id));
    }
  };

  return (
    <PageShell>
      <SectionTitle
        title="Usuarios"
        description="Gestión de cuentas, accesos, cargos y estado de usuarios del sistema"
        countText={`${items.length} usuarios`}
        icon={<Users size={14} />}
      />

      <Toolbar
        value={filtro}
        onChange={setFiltro}
        onCreate={abrirNuevo}
        placeholder="Buscar usuario, correo, cargo, área, rol o sucursal..."
        buttonLabel="Nuevo Usuario"
      />

      <div className="table-responsive">
        <table className="table table-striped table-hover">
          <thead className="table-dark">
            <tr>
              <th>Nombre</th>
              <th>Usuario</th>
              <th>Correo</th>
              <th>Cargo</th>
              <th>Área</th>
              <th>Rol</th>
              <th>Sucursal</th>
              <th>Estado</th>
              <th>Opciones</th>
            </tr>
          </thead>
          <tbody>
            {filtrados.length === 0 ? (
              <tr>
                <td colSpan={9} className="text-center py-4 text-muted">
                  No se encontraron usuarios
                </td>
              </tr>
            ) : (
              filtrados.map((item) => (
                <tr key={item.id}>
                  <td><strong>{item.nombres}</strong></td>
                  <td>{item.usuario}</td>
                  <td>{item.correo}</td>
                  <td>{item.cargo}</td>
                  <td>{item.area}</td>
                  <td>{item.rol}</td>
                  <td>{item.sucursal}</td>
                  <td><Badge tone={item.estado === "Activo" ? "success" : "secondary"}>{item.estado}</Badge></td>
                  <td>
                    <div className="btn-group">
                      <button className="btn btn-outline-warning btn-sm" type="button" onClick={() => abrirEditar(item)} title="Editar">
                        <PenSquare size={14} />
                      </button>
                      <button className="btn btn-outline-danger btn-sm" type="button" onClick={() => eliminar(item.id)} title="Eliminar">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <ModalShell open={showModal} title={editandoId ? "Editar Usuario" : "Nuevo Usuario"} onClose={() => setShowModal(false)}>
        <form onSubmit={guardar}>
          <div className="modal-body">
            <div className="row g-3">
              <div className="col-md-6">
                <Label htmlFor="nombres">Nombres completos *</Label>
                <input id="nombres" className="form-control" value={form.nombres} onChange={(event) => setForm((current) => ({ ...current, nombres: event.target.value }))} required />
              </div>
              <div className="col-md-6">
                <Label htmlFor="usuario">Usuario *</Label>
                <input id="usuario" className="form-control" value={form.usuario} onChange={(event) => setForm((current) => ({ ...current, usuario: event.target.value }))} required />
              </div>
              <div className="col-md-6">
                <Label htmlFor="correo">Correo electrónico *</Label>
                <input id="correo" type="email" className="form-control" value={form.correo} onChange={(event) => setForm((current) => ({ ...current, correo: event.target.value }))} required />
              </div>
              <div className="col-md-6">
                <Label htmlFor="telefono">Teléfono</Label>
                <input id="telefono" className="form-control" value={form.telefono} onChange={(event) => setForm((current) => ({ ...current, telefono: event.target.value }))} />
              </div>
              <div className="col-md-6">
                <Label htmlFor="cargo">Cargo</Label>
                <input id="cargo" className="form-control" value={form.cargo} onChange={(event) => setForm((current) => ({ ...current, cargo: event.target.value }))} />
              </div>
              <div className="col-md-6">
                <Label htmlFor="area">Área</Label>
                <input id="area" className="form-control" value={form.area} onChange={(event) => setForm((current) => ({ ...current, area: event.target.value }))} />
              </div>
              <div className="col-md-6">
                <Label htmlFor="rol">Rol</Label>
                <select id="rol" className="form-select" value={form.rol} onChange={(event) => setForm((current) => ({ ...current, rol: event.target.value }))}>
                  <option value="Administrador">Administrador</option>
                  <option value="Supervisor">Supervisor</option>
                  <option value="Vendedor">Vendedor</option>
                  <option value="Consulta">Consulta</option>
                </select>
              </div>
              <div className="col-md-6">
                <Label htmlFor="sucursal">Sucursal</Label>
                <input id="sucursal" className="form-control" value={form.sucursal} onChange={(event) => setForm((current) => ({ ...current, sucursal: event.target.value }))} />
              </div>
              <div className="col-md-6">
                <Label htmlFor="estado">Estado</Label>
                <select id="estado" className="form-select" value={form.estado} onChange={(event) => setForm((current) => ({ ...current, estado: event.target.value }))}>
                  <option value="Activo">Activo</option>
                  <option value="Bloqueado">Bloqueado</option>
                </select>
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancelar
            </button>
            <button type="submit" className="btn btn-success">
              Guardar
            </button>
          </div>
        </form>
      </ModalShell>
    </PageShell>
  );
}

function RolesScreen() {
  const [items, setItems] = useState<RoleItem[]>(initialRoles);
  const [filtro, setFiltro] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<RoleFormValues>({
    nombre: "",
    codigo: "",
    descripcion: "",
    alcance: "Corporativo",
    nivel: "Medio",
    estado: "Activo",
  });

  const filtrados = useMemo(() => {
    const term = filtro.toLowerCase();
    return items.filter((item) => [item.nombre, item.codigo, item.descripcion, item.alcance, item.nivel, item.estado].join(" ").toLowerCase().includes(term));
  }, [filtro, items]);

  const abrirNuevo = () => {
    setForm({ nombre: "", codigo: "", descripcion: "", alcance: "Corporativo", nivel: "Medio", estado: "Activo" });
    setEditandoId(null);
    setShowModal(true);
  };

  const abrirEditar = (item: RoleItem) => {
    setForm({
      nombre: item.nombre,
      codigo: item.codigo,
      descripcion: item.descripcion,
      alcance: item.alcance,
      nivel: item.nivel,
      estado: item.estado,
    });
    setEditandoId(item.id);
    setShowModal(true);
  };

  const guardar = (event: React.FormEvent) => {
    event.preventDefault();
    if (editandoId) {
      setItems((current) => current.map((item) => (item.id === editandoId ? { ...item, ...form } : item)));
    } else {
      setItems((current) => [...current, { id: Date.now(), ...form }]);
    }
    setShowModal(false);
  };

  const eliminar = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar este rol?")) {
      setItems((current) => current.filter((item) => item.id !== id));
    }
  };

  return (
    <PageShell>
      <SectionTitle
        title="Roles"
        description="Administración de perfiles, alcance y nivel de acceso"
        countText={`${items.length} roles`}
        icon={<KeyRound size={14} />}
      />

      <Toolbar
        value={filtro}
        onChange={setFiltro}
        onCreate={abrirNuevo}
        placeholder="Buscar rol, código, nivel o alcance..."
        buttonLabel="Nuevo Rol"
      />

      <div className="table-responsive">
        <table className="table table-striped table-hover">
          <thead className="table-dark">
            <tr>
              <th>Nombre</th>
              <th>Código</th>
              <th>Descripción</th>
              <th>Alcance</th>
              <th>Nivel</th>
              <th>Estado</th>
              <th>Opciones</th>
            </tr>
          </thead>
          <tbody>
            {filtrados.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center py-4 text-muted">
                  No se encontraron roles
                </td>
              </tr>
            ) : (
              filtrados.map((item) => (
                <tr key={item.id}>
                  <td><strong>{item.nombre}</strong></td>
                  <td>{item.codigo}</td>
                  <td>{item.descripcion}</td>
                  <td>{item.alcance}</td>
                  <td>{item.nivel}</td>
                  <td><Badge tone={item.estado === "Activo" ? "success" : "secondary"}>{item.estado}</Badge></td>
                  <td>
                    <div className="btn-group">
                      <button className="btn btn-outline-warning btn-sm" type="button" onClick={() => abrirEditar(item)} title="Editar">
                        <PenSquare size={14} />
                      </button>
                      <button className="btn btn-outline-danger btn-sm" type="button" onClick={() => eliminar(item.id)} title="Eliminar">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <ModalShell open={showModal} title={editandoId ? "Editar Rol" : "Nuevo Rol"} onClose={() => setShowModal(false)}>
        <form onSubmit={guardar}>
          <div className="modal-body">
            <div className="row g-3">
              <div className="col-md-6">
                <Label htmlFor="nombre">Nombre del rol *</Label>
                <input id="nombre" className="form-control" value={form.nombre} onChange={(event) => setForm((current) => ({ ...current, nombre: event.target.value }))} required />
              </div>
              <div className="col-md-6">
                <Label htmlFor="codigo">Código *</Label>
                <input id="codigo" className="form-control" value={form.codigo} onChange={(event) => setForm((current) => ({ ...current, codigo: event.target.value }))} required />
              </div>
              <div className="col-12">
                <Label htmlFor="descripcion">Descripción</Label>
                <textarea id="descripcion" className="form-control" rows={3} value={form.descripcion} onChange={(event) => setForm((current) => ({ ...current, descripcion: event.target.value }))} />
              </div>
              <div className="col-md-4">
                <Label htmlFor="alcance">Alcance</Label>
                <select id="alcance" className="form-select" value={form.alcance} onChange={(event) => setForm((current) => ({ ...current, alcance: event.target.value }))}>
                  <option value="Corporativo">Corporativo</option>
                  <option value="Operativo">Operativo</option>
                  <option value="Sucursal">Sucursal</option>
                </select>
              </div>
              <div className="col-md-4">
                <Label htmlFor="nivel">Nivel</Label>
                <select id="nivel" className="form-select" value={form.nivel} onChange={(event) => setForm((current) => ({ ...current, nivel: event.target.value }))}>
                  <option value="Bajo">Bajo</option>
                  <option value="Medio">Medio</option>
                  <option value="Alto">Alto</option>
                </select>
              </div>
              <div className="col-md-4">
                <Label htmlFor="estado-rol">Estado</Label>
                <select id="estado-rol" className="form-select" value={form.estado} onChange={(event) => setForm((current) => ({ ...current, estado: event.target.value }))}>
                  <option value="Activo">Activo</option>
                  <option value="Inactivo">Inactivo</option>
                </select>
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancelar
            </button>
            <button type="submit" className="btn btn-success">
              Guardar
            </button>
          </div>
        </form>
      </ModalShell>
    </PageShell>
  );
}

function PermissionsScreen() {
  const [items, setItems] = useState<PermissionItem[]>(initialPermissions);
  const [filtro, setFiltro] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<PermissionFormValues>({
    usuario: "",
    rol: "Administrador",
    modulo: "Ventas",
    puedeVer: true,
    puedeCrear: false,
    puedeEditar: false,
    puedeEliminar: false,
    puedeAprobar: false,
    vigencia: "Permanente",
    estado: "Activo",
  });

  const filtrados = useMemo(() => {
    const term = filtro.toLowerCase();
    return items.filter((item) => [item.usuario, item.rol, item.modulo, item.vigencia, item.estado].join(" ").toLowerCase().includes(term));
  }, [filtro, items]);

  const abrirNuevo = () => {
    setForm({ usuario: "", rol: "Administrador", modulo: "Ventas", puedeVer: true, puedeCrear: false, puedeEditar: false, puedeEliminar: false, puedeAprobar: false, vigencia: "Permanente", estado: "Activo" });
    setEditandoId(null);
    setShowModal(true);
  };

  const abrirEditar = (item: PermissionItem) => {
    setForm({
      usuario: item.usuario,
      rol: item.rol,
      modulo: item.modulo,
      puedeVer: item.puedeVer,
      puedeCrear: item.puedeCrear,
      puedeEditar: item.puedeEditar,
      puedeEliminar: item.puedeEliminar,
      puedeAprobar: item.puedeAprobar,
      vigencia: item.vigencia,
      estado: item.estado,
    });
    setEditandoId(item.id);
    setShowModal(true);
  };

  const guardar = (event: React.FormEvent) => {
    event.preventDefault();
    if (editandoId) {
      setItems((current) => current.map((item) => (item.id === editandoId ? { ...item, ...form } : item)));
    } else {
      setItems((current) => [...current, { id: Date.now(), ...form }]);
    }
    setShowModal(false);
  };

  const eliminar = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar este permiso?")) {
      setItems((current) => current.filter((item) => item.id !== id));
    }
  };

  return (
    <PageShell>
      <SectionTitle
        title="Permisos de Usuarios"
        description="Asignación de módulos, acciones permitidas y vigencia de accesos"
        countText={`${items.length} permisos`}
        icon={<ShieldCheck size={14} />}
      />

      <Toolbar
        value={filtro}
        onChange={setFiltro}
        onCreate={abrirNuevo}
        placeholder="Buscar usuario, rol, módulo o vigencia..."
        buttonLabel="Nuevo Permiso"
      />

      <div className="table-responsive">
        <table className="table table-striped table-hover">
          <thead className="table-dark">
            <tr>
              <th>Usuario</th>
              <th>Rol</th>
              <th>Módulo</th>
              <th>Ver</th>
              <th>Crear</th>
              <th>Editar</th>
              <th>Eliminar</th>
              <th>Aprobar</th>
              <th>Vigencia</th>
              <th>Estado</th>
              <th>Opciones</th>
            </tr>
          </thead>
          <tbody>
            {filtrados.length === 0 ? (
              <tr>
                <td colSpan={11} className="text-center py-4 text-muted">
                  No se encontraron permisos de usuarios
                </td>
              </tr>
            ) : (
              filtrados.map((item) => (
                <tr key={item.id}>
                  <td><strong>{item.usuario}</strong></td>
                  <td>{item.rol}</td>
                  <td>{item.modulo}</td>
                  <td>{item.puedeVer ? <Badge tone="success">Sí</Badge> : <Badge tone="secondary">No</Badge>}</td>
                  <td>{item.puedeCrear ? <Badge tone="success">Sí</Badge> : <Badge tone="secondary">No</Badge>}</td>
                  <td>{item.puedeEditar ? <Badge tone="success">Sí</Badge> : <Badge tone="secondary">No</Badge>}</td>
                  <td>{item.puedeEliminar ? <Badge tone="danger">Sí</Badge> : <Badge tone="secondary">No</Badge>}</td>
                  <td>{item.puedeAprobar ? <Badge tone="warning">Sí</Badge> : <Badge tone="secondary">No</Badge>}</td>
                  <td>{item.vigencia}</td>
                  <td><Badge tone={item.estado === "Activo" ? "success" : "secondary"}>{item.estado}</Badge></td>
                  <td>
                    <div className="btn-group">
                      <button className="btn btn-outline-warning btn-sm" type="button" onClick={() => abrirEditar(item)} title="Editar">
                        <PenSquare size={14} />
                      </button>
                      <button className="btn btn-outline-danger btn-sm" type="button" onClick={() => eliminar(item.id)} title="Eliminar">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <ModalShell open={showModal} title={editandoId ? "Editar Permiso de Usuario" : "Nuevo Permiso de Usuario"} onClose={() => setShowModal(false)}>
        <form onSubmit={guardar}>
          <div className="modal-body">
            <div className="row g-3">
              <div className="col-md-6">
                <Label htmlFor="usuario-permiso">Usuario *</Label>
                <select id="usuario-permiso" className="form-select" value={form.usuario} onChange={(event) => setForm((current) => ({ ...current, usuario: event.target.value }))} required>
                  <option value="">Seleccione</option>
                  <option value="atorres">atorres</option>
                  <option value="lmendoza">lmendoza</option>
                  <option value="jlopez">jlopez</option>
                </select>
              </div>
              <div className="col-md-6">
                <Label htmlFor="rol-permiso">Rol *</Label>
                <select id="rol-permiso" className="form-select" value={form.rol} onChange={(event) => setForm((current) => ({ ...current, rol: event.target.value }))} required>
                  <option value="Administrador">Administrador</option>
                  <option value="Supervisor">Supervisor</option>
                  <option value="Vendedor">Vendedor</option>
                </select>
              </div>
              <div className="col-md-6">
                <Label htmlFor="modulo-permiso">Módulo *</Label>
                <select id="modulo-permiso" className="form-select" value={form.modulo} onChange={(event) => setForm((current) => ({ ...current, modulo: event.target.value }))}>
                  <option value="Ventas">Ventas</option>
                  <option value="Compras">Compras</option>
                  <option value="Facturas">Facturas</option>
                  <option value="Usuarios">Usuarios</option>
                  <option value="Reportes">Reportes</option>
                </select>
              </div>
              <div className="col-md-6">
                <Label htmlFor="vigencia-permiso">Vigencia</Label>
                <select id="vigencia-permiso" className="form-select" value={form.vigencia} onChange={(event) => setForm((current) => ({ ...current, vigencia: event.target.value }))}>
                  <option value="Permanente">Permanente</option>
                  <option value="Temporal">Temporal</option>
                  <option value="Por aprobación">Por aprobación</option>
                </select>
              </div>
              <div className="col-12">
                <div className="row g-2">
                  {[
                    ["puedeVer", "Puede ver"],
                    ["puedeCrear", "Puede crear"],
                    ["puedeEditar", "Puede editar"],
                    ["puedeEliminar", "Puede eliminar"],
                    ["puedeAprobar", "Puede aprobar"],
                  ].map(([field, label]) => (
                    <div className="col-md-4" key={field}>
                      <div className="form-check border rounded p-3">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id={field}
                          checked={Boolean((form as Record<string, boolean>)[field])}
                          onChange={(event) => setForm((current) => ({ ...current, [field]: event.target.checked }))}
                        />
                        <label className="form-check-label ms-2" htmlFor={field}>
                          {label}
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="col-md-6">
                <Label htmlFor="estado-permiso">Estado</Label>
                <select id="estado-permiso" className="form-select" value={form.estado} onChange={(event) => setForm((current) => ({ ...current, estado: event.target.value }))}>
                  <option value="Activo">Activo</option>
                  <option value="Suspendido">Suspendido</option>
                </select>
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={() => setShowModal(false)}>
              Cancelar
            </button>
            <button type="submit" className="btn btn-success">
              Guardar
            </button>
          </div>
        </form>
      </ModalShell>
    </PageShell>
  );
}
