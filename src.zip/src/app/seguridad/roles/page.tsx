import { AppShell } from "@/components/app-shell";
import { SecurityModule } from "../_components/security-module";

export default function RolesPage() {
  return (
    <AppShell>
      <SecurityModule mode="roles" />
    </AppShell>
  );
}