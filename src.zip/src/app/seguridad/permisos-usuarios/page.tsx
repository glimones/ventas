import { AppShell } from "@/components/app-shell";
import { SecurityModule } from "../_components/security-module";

export default function PermisosUsuariosPage() {
  return (
    <AppShell>
      <SecurityModule mode="permisos" />
    </AppShell>
  );
}