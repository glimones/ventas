import Link from "next/link";
import { AppShell } from "@/components/app-shell";
import { ShieldCheck, Users, KeyRound, LayoutGrid } from "lucide-react";

const cards = [
  {
    title: "Usuarios",
    description: "Gestiona cuentas, accesos, 2FA y estado.",
    href: "/seguridad/usuarios",
    icon: Users,
  },
  {
    title: "Roles",
    description: "Define perfiles y alcance funcional.",
    href: "/seguridad/roles",
    icon: KeyRound,
  },
  {
    title: "Permisos de usuarios",
    description: "Controla acciones por módulo y vigencia.",
    href: "/seguridad/permisos-usuarios",
    icon: LayoutGrid,
  },
];

export default function SeguridadHome() {
  return (
    <AppShell showFooter={false}>
      <div className="space-y-6 p-6">
        <div className="rounded-3xl bg-gradient-to-r from-black to-neutral-800 px-6 py-6 text-white shadow-sm">
          <p className="text-xs font-semibold uppercase tracking-[0.28em] text-white/60">Seguridad</p>
          <div className="mt-2 flex items-end justify-between gap-4">
            <div>
              <h1 className="text-3xl font-semibold">Módulo de seguridad</h1>
              <p className="mt-2 max-w-2xl text-sm text-white/70">Selecciona una pantalla para administrar usuarios, roles o permisos.</p>
            </div>
            <ShieldCheck className="h-10 w-10 text-white/80" />
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <Link key={card.href} href={card.href} className="group rounded-2xl border border-black/10 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-black/20 hover:shadow-md">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-black text-white transition group-hover:bg-neutral-800">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h2 className="text-xl font-semibold text-neutral-900">{card.title}</h2>
                    <p className="mt-2 text-sm text-neutral-500">{card.description}</p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </AppShell>
  );
}