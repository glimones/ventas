'use client';

import React, { useState, useEffect } from 'react';
import { Search, Plus, Edit2, Trash2, Eye, FileText, User, Package, DollarSign, Truck, X } from 'lucide-react';
import './solicitudes-pedido.css';

// Tipos
interface Cliente {
  id: number;
  nombre: string;
  email: string;
  telefono: string;
  direccion: string;
}

interface Producto {
  id: number;
  nombre: string;
  precio: number;
  stock: number;
  categoria: string;
}

interface ProductoSolicitud {
  productoId: number;
  nombreProducto: string;
  cantidad: number;
  precio: number;
  total: number;
}

interface SolicitudPedido {
  id: number;
  numeroSolicitud: string;
  cliente: Cliente;
  fechaSolicitud: string;
  fechaEntregaDeseada: string;
  estado: 'pendiente' | 'aprobada' | 'rechazada' | 'en_proceso' | 'completada';
  prioridad: 'baja' | 'media' | 'alta' | 'urgente';
  productos: ProductoSolicitud[];
  subtotal: number;
  impuestos: number;
  total: number;
  observaciones: string;
  direccionEntrega: string;
  tipoEntrega: 'domicilio' | 'recoger' | 'express';
}

// Datos de ejemplo
const clientesEjemplo: Cliente[] = [
  {
    id: 1,
    nombre: "María García",
    email: "maria.garcia@email.com",
    telefono: "555-0001",
    direccion: "Av. Principal 123, Ciudad"
  },
  {
    id: 2,
    nombre: "Carlos López",
    email: "carlos.lopez@email.com",
    telefono: "555-0002",
    direccion: "Calle Segunda 456, Ciudad"
  },
  {
    id: 3,
    nombre: "Ana Martínez",
    email: "ana.martinez@email.com",
    telefono: "555-0003",
    direccion: "Plaza Central 789, Ciudad"
  }
];

const productosEjemplo: Producto[] = [
  {
    id: 1,
    nombre: "Laptop Dell Inspiron",
    precio: 899.99,
    stock: 15,
    categoria: "Electrónicos"
  },
  {
    id: 2,
    nombre: "Mouse Inalámbrico",
    precio: 25.99,
    stock: 50,
    categoria: "Accesorios"
  },
  {
    id: 3,
    nombre: "Teclado Mecánico",
    precio: 89.99,
    stock: 30,
    categoria: "Accesorios"
  },
  {
    id: 4,
    nombre: "Monitor 24 pulgadas",
    precio: 199.99,
    stock: 20,
    categoria: "Electrónicos"
  },
  {
    id: 5,
    nombre: "Webcam HD",
    precio: 79.99,
    stock: 25,
    categoria: "Accesorios"
  }
];

const solicitudesEjemplo: SolicitudPedido[] = [
  {
    id: 1,
    numeroSolicitud: "SOL-2024-001",
    cliente: clientesEjemplo[0],
    fechaSolicitud: "2024-01-15",
    fechaEntregaDeseada: "2024-01-20",
    estado: "pendiente",
    prioridad: "alta",
    productos: [
      {
        productoId: 1,
        nombreProducto: "Laptop Dell Inspiron",
        cantidad: 2,
        precio: 899.99,
        total: 1799.98
      },
      {
        productoId: 2,
        nombreProducto: "Mouse Inalámbrico",
        cantidad: 2,
        precio: 25.99,
        total: 51.98
      }
    ],
    subtotal: 1851.96,
    impuestos: 185.20,
    total: 2037.16,
    observaciones: "Entrega urgente para proyecto empresarial",
    direccionEntrega: "Av. Principal 123, Ciudad",
    tipoEntrega: "domicilio"
  },
  {
    id: 2,
    numeroSolicitud: "SOL-2024-002",
    cliente: clientesEjemplo[1],
    fechaSolicitud: "2024-01-16",
    fechaEntregaDeseada: "2024-01-25",
    estado: "aprobada",
    prioridad: "media",
    productos: [
      {
        productoId: 4,
        nombreProducto: "Monitor 24 pulgadas",
        cantidad: 1,
        precio: 199.99,
        total: 199.99
      },
      {
        productoId: 3,
        nombreProducto: "Teclado Mecánico",
        cantidad: 1,
        precio: 89.99,
        total: 89.99
      }
    ],
    subtotal: 289.98,
    impuestos: 29.00,
    total: 318.98,
    observaciones: "Setup para oficina en casa",
    direccionEntrega: "Calle Segunda 456, Ciudad",
    tipoEntrega: "recoger"
  },
  {
    id: 3,
    numeroSolicitud: "SOL-2024-003",
    cliente: clientesEjemplo[2],
    fechaSolicitud: "2024-01-17",
    fechaEntregaDeseada: "2024-01-22",
    estado: "en_proceso",
    prioridad: "urgente",
    productos: [
      {
        productoId: 5,
        nombreProducto: "Webcam HD",
        cantidad: 3,
        precio: 79.99,
        total: 239.97
      }
    ],
    subtotal: 239.97,
    impuestos: 24.00,
    total: 263.97,
    observaciones: "Para conferencias virtuales",
    direccionEntrega: "Plaza Central 789, Ciudad",
    tipoEntrega: "express"
  }
];

export default function SolicitudesPedidoPage() {
  const [solicitudes, setSolicitudes] = useState<SolicitudPedido[]>(solicitudesEjemplo);
  const [filtroTexto, setFiltroTexto] = useState('');
  const [filtroEstado, setFiltroEstado] = useState('');
  const [filtroPrioridad, setFiltroPrioridad] = useState('');
  const [mostrarModal, setMostrarModal] = useState(false);
  const [solicitudEditando, setSolicitudEditando] = useState<SolicitudPedido | null>(null);
  const [modoVista, setModoVista] = useState<'crear' | 'editar' | 'ver'>('crear');

  // Formulario
  const [formData, setFormData] = useState<Partial<SolicitudPedido>>({
    numeroSolicitud: '',
    cliente: undefined,
    fechaSolicitud: new Date().toISOString().split('T')[0],
    fechaEntregaDeseada: '',
    estado: 'pendiente',
    prioridad: 'media',
    productos: [],
    observaciones: '',
    direccionEntrega: '',
    tipoEntrega: 'domicilio'
  });

  const [clienteSeleccionado, setClienteSeleccionado] = useState<Cliente | null>(null);
  const [productosSeleccionados, setProductosSeleccionados] = useState<ProductoSolicitud[]>([]);

  // Generar número de solicitud automático
  useEffect(() => {
    if (mostrarModal && modoVista === 'crear') {
      const ultimoNumero = solicitudes.length + 1;
      const nuevoNumero = `SOL-2024-${ultimoNumero.toString().padStart(3, '0')}`;
      setFormData(prev => ({ ...prev, numeroSolicitud: nuevoNumero }));
    }
  }, [mostrarModal, modoVista, solicitudes.length]);

  // Filtrar solicitudes
  const solicitudesFiltradas = solicitudes.filter(solicitud => {
    const coincideTexto = !filtroTexto || 
      solicitud.numeroSolicitud.toLowerCase().includes(filtroTexto.toLowerCase()) ||
      solicitud.cliente.nombre.toLowerCase().includes(filtroTexto.toLowerCase());
    
    const coincideEstado = !filtroEstado || solicitud.estado === filtroEstado;
    const coincidePrioridad = !filtroPrioridad || solicitud.prioridad === filtroPrioridad;
    
    return coincideTexto && coincideEstado && coincidePrioridad;
  });

  // Funciones de estado
  const getEstadoBadge = (estado: string) => {
    const clases = {
      pendiente: 'bg-warning text-dark',
      aprobada: 'bg-success',
      rechazada: 'bg-danger',
      en_proceso: 'bg-info',
      completada: 'bg-dark'
    };
    return clases[estado as keyof typeof clases] || 'bg-secondary';
  };

  const getPrioridadBadge = (prioridad: string) => {
    const clases = {
      baja: 'bg-secondary',
      media: 'bg-primary',
      alta: 'bg-warning text-dark',
      urgente: 'bg-danger'
    };
    return clases[prioridad as keyof typeof clases] || 'bg-secondary';
  };

  const getEstadoTexto = (estado: string) => {
    const textos = {
      pendiente: 'Pendiente',
      aprobada: 'Aprobada',
      rechazada: 'Rechazada',
      en_proceso: 'En Proceso',
      completada: 'Completada'
    };
    return textos[estado as keyof typeof textos] || estado;
  };

  const getPrioridadTexto = (prioridad: string) => {
    const textos = {
      baja: 'Baja',
      media: 'Media',
      alta: 'Alta',
      urgente: 'Urgente'
    };
    return textos[prioridad as keyof typeof textos] || prioridad;
  };

  // Funciones del modal
  const abrirModal = (modo: 'crear' | 'editar' | 'ver', solicitud?: SolicitudPedido) => {
    setModoVista(modo);
    if (solicitud) {
      setSolicitudEditando(solicitud);
      setFormData(solicitud);
      setClienteSeleccionado(solicitud.cliente);
      setProductosSeleccionados(solicitud.productos);
    } else {
      resetFormulario();
    }
    setMostrarModal(true);
  };

  const cerrarModal = () => {
    setMostrarModal(false);
    setSolicitudEditando(null);
    resetFormulario();
  };

  const resetFormulario = () => {
    setFormData({
      numeroSolicitud: '',
      cliente: undefined,
      fechaSolicitud: new Date().toISOString().split('T')[0],
      fechaEntregaDeseada: '',
      estado: 'pendiente',
      prioridad: 'media',
      productos: [],
      observaciones: '',
      direccionEntrega: '',
      tipoEntrega: 'domicilio'
    });
    setClienteSeleccionado(null);
    setProductosSeleccionados([]);
  };

  // Funciones de productos
  const agregarProducto = (producto: Producto) => {
    const productoExistente = productosSeleccionados.find(p => p.productoId === producto.id);
    
    if (productoExistente) {
      setProductosSeleccionados(prev =>
        prev.map(p =>
          p.productoId === producto.id
            ? { ...p, cantidad: p.cantidad + 1, total: (p.cantidad + 1) * p.precio }
            : p
        )
      );
    } else {
      const nuevoProducto: ProductoSolicitud = {
        productoId: producto.id,
        nombreProducto: producto.nombre,
        cantidad: 1,
        precio: producto.precio,
        total: producto.precio
      };
      setProductosSeleccionados(prev => [...prev, nuevoProducto]);
    }
  };

  const actualizarCantidadProducto = (productoId: number, nuevaCantidad: number) => {
    if (nuevaCantidad <= 0) {
      setProductosSeleccionados(prev => prev.filter(p => p.productoId !== productoId));
    } else {
      setProductosSeleccionados(prev =>
        prev.map(p =>
          p.productoId === productoId
            ? { ...p, cantidad: nuevaCantidad, total: nuevaCantidad * p.precio }
            : p
        )
      );
    }
  };

  const removerProducto = (productoId: number) => {
    setProductosSeleccionados(prev => prev.filter(p => p.productoId !== productoId));
  };

  // Calcular totales
  const calcularTotales = () => {
    const subtotal = productosSeleccionados.reduce((sum, producto) => sum + producto.total, 0);
    const impuestos = subtotal * 0.1; // 10% de impuestos
    const total = subtotal + impuestos;
    
    return { subtotal, impuestos, total };
  };

  // Guardar solicitud
  const guardarSolicitud = () => {
    if (!clienteSeleccionado || productosSeleccionados.length === 0) {
      alert('Por favor selecciona un cliente y al menos un producto');
      return;
    }

    const { subtotal, impuestos, total } = calcularTotales();

    const nuevaSolicitud: SolicitudPedido = {
      id: solicitudEditando ? solicitudEditando.id : Date.now(),
      numeroSolicitud: formData.numeroSolicitud || '',
      cliente: clienteSeleccionado,
      fechaSolicitud: formData.fechaSolicitud || '',
      fechaEntregaDeseada: formData.fechaEntregaDeseada || '',
      estado: formData.estado as SolicitudPedido['estado'] || 'pendiente',
      prioridad: formData.prioridad as SolicitudPedido['prioridad'] || 'media',
      productos: productosSeleccionados,
      subtotal,
      impuestos,
      total,
      observaciones: formData.observaciones || '',
      direccionEntrega: formData.direccionEntrega || clienteSeleccionado.direccion,
      tipoEntrega: formData.tipoEntrega as SolicitudPedido['tipoEntrega'] || 'domicilio'
    };

    if (solicitudEditando) {
      setSolicitudes(prev => prev.map(s => s.id === solicitudEditando.id ? nuevaSolicitud : s));
    } else {
      setSolicitudes(prev => [...prev, nuevaSolicitud]);
    }

    cerrarModal();
  };

  // Eliminar solicitud
  const eliminarSolicitud = (id: number) => {
    if (confirm('¿Estás seguro de que deseas eliminar esta solicitud?')) {
      setSolicitudes(prev => prev.filter(s => s.id !== id));
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1>Solicitudes de Pedido</h1>
            <h6 className="text-primary">
              Gestión y seguimiento de solicitudes de clientes
            </h6>
          </div>
          <button
            className="btn btn-primary"
            onClick={() => abrirModal('crear')}
          >
            <Plus size={20} className="me-2" />
            Nueva Solicitud
          </button>
        </div>

        {/* Filtros */}
        <div className="row mb-4">
          <div className="col-md-4">
            <div className="position-relative">
              <input
                type="text"
                className="form-control"
                placeholder="Buscar por número o cliente..."
                value={filtroTexto}
                onChange={(e) => setFiltroTexto(e.target.value)}
              />
              <Search className="position-absolute top-50 end-0 translate-middle-y me-3" size={16} />
            </div>
          </div>
          <div className="col-md-3">
            <select
              className="form-select"
              value={filtroEstado}
              onChange={(e) => setFiltroEstado(e.target.value)}
            >
              <option value="">Todos los estados</option>
              <option value="pendiente">Pendiente</option>
              <option value="aprobada">Aprobada</option>
              <option value="rechazada">Rechazada</option>
              <option value="en_proceso">En Proceso</option>
              <option value="completada">Completada</option>
            </select>
          </div>
          <div className="col-md-3">
            <select
              className="form-select"
              value={filtroPrioridad}
              onChange={(e) => setFiltroPrioridad(e.target.value)}
            >
              <option value="">Todas las prioridades</option>
              <option value="baja">Baja</option>
              <option value="media">Media</option>
              <option value="alta">Alta</option>
              <option value="urgente">Urgente</option>
            </select>
          </div>
          <div className="col-md-2">
            <button 
              className="btn btn-outline-secondary w-100"
              onClick={() => {
                setFiltroTexto('');
                setFiltroEstado('');
                setFiltroPrioridad('');
              }}
            >
              Limpiar
            </button>
          </div>
        </div>

        {/* Tabla */}
        <div className="table-responsive">
          <table className="table table-hover">
            <thead className="table-dark">
              <tr>
                <th>Número</th>
                <th>Cliente</th>
                <th>Fecha Solicitud</th>
                <th>Fecha Entrega</th>
                <th>Estado</th>
                <th>Prioridad</th>
                <th>Total</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {solicitudesFiltradas.map((solicitud) => (
                <tr key={solicitud.id}>
                  <td className="fw-bold">{solicitud.numeroSolicitud}</td>
                  <td>
                    <div>
                      <div className="fw-medium">{solicitud.cliente.nombre}</div>
                      <small className="text-muted">{solicitud.cliente.email}</small>
                    </div>
                  </td>
                  <td>{new Date(solicitud.fechaSolicitud).toLocaleDateString()}</td>
                  <td>{new Date(solicitud.fechaEntregaDeseada).toLocaleDateString()}</td>
                  <td>
                    <span className={`badge ${getEstadoBadge(solicitud.estado)}`}>
                      {getEstadoTexto(solicitud.estado)}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${getPrioridadBadge(solicitud.prioridad)}`}>
                      {getPrioridadTexto(solicitud.prioridad)}
                    </span>
                  </td>
                  <td className="fw-bold">${solicitud.total.toFixed(2)}</td>
                  <td>
                    <div className="btn-group" role="group">
                      <button
                        className="btn btn-sm btn-outline-info"
                        onClick={() => abrirModal('ver', solicitud)}
                        title="Ver detalles"
                      >
                        <Eye size={16} />
                      </button>
                      <button
                        className="btn btn-sm btn-outline-primary"
                        onClick={() => abrirModal('editar', solicitud)}
                        title="Editar"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => eliminarSolicitud(solicitud.id)}
                        title="Eliminar"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {solicitudesFiltradas.length === 0 && (
            <div className="text-center py-4">
              <FileText size={48} className="text-muted mb-3" />
              <p className="text-muted">No se encontraron solicitudes que coincidan con los filtros aplicados.</p>
            </div>
          )}
        </div>

        {/* Modal */}
        {mostrarModal && (
          <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && cerrarModal()}>
            <div className="modal-container">
              <div className="modal-header">
                <h5 className="modal-title">
                  {modoVista === 'crear' && 'Nueva Solicitud de Pedido'}
                  {modoVista === 'editar' && 'Editar Solicitud de Pedido'}
                  {modoVista === 'ver' && 'Detalles de Solicitud'}
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={cerrarModal}
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="modal-body">
                <form>
                  {/* Información básica */}
                  <div className="border-bottom pb-3 mb-4">
                    <h6 className="text-primary mb-3">
                      <FileText size={20} className="me-2" />
                      Información Básica
                    </h6>
                    <div className="row">
                      <div className="col-md-6">
                        <label className="form-label">Número de Solicitud</label>
                        <input
                          type="text"
                          className="form-control"
                          value={formData.numeroSolicitud}
                          disabled={modoVista !== 'crear'}
                          onChange={(e) => setFormData(prev => ({ ...prev, numeroSolicitud: e.target.value }))}
                        />
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Fecha de Solicitud</label>
                        <input
                          type="date"
                          className="form-control"
                          value={formData.fechaSolicitud}
                          disabled={modoVista === 'ver'}
                          onChange={(e) => setFormData(prev => ({ ...prev, fechaSolicitud: e.target.value }))}
                        />
                      </div>
                    </div>
                    <div className="row mt-3">
                      <div className="col-md-6">
                        <label className="form-label">Fecha de Entrega Deseada</label>
                        <input
                          type="date"
                          className="form-control"
                          value={formData.fechaEntregaDeseada}
                          disabled={modoVista === 'ver'}
                          onChange={(e) => setFormData(prev => ({ ...prev, fechaEntregaDeseada: e.target.value }))}
                        />
                      </div>
                      <div className="col-md-3">
                        <label className="form-label">Estado</label>
                        <select
                          className="form-select"
                          value={formData.estado}
                          disabled={modoVista === 'ver'}
                          onChange={(e) => setFormData(prev => ({ ...prev, estado: e.target.value as SolicitudPedido['estado'] }))}
                        >
                          <option value="pendiente">Pendiente</option>
                          <option value="aprobada">Aprobada</option>
                          <option value="rechazada">Rechazada</option>
                          <option value="en_proceso">En Proceso</option>
                          <option value="completada">Completada</option>
                        </select>
                      </div>
                      <div className="col-md-3">
                        <label className="form-label">Prioridad</label>
                        <select
                          className="form-select"
                          value={formData.prioridad}
                          disabled={modoVista === 'ver'}
                          onChange={(e) => setFormData(prev => ({ ...prev, prioridad: e.target.value as SolicitudPedido['prioridad'] }))}
                        >
                          <option value="baja">Baja</option>
                          <option value="media">Media</option>
                          <option value="alta">Alta</option>
                          <option value="urgente">Urgente</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Información del cliente */}
                  <div className="border-bottom pb-3 mb-4">
                    <h6 className="text-primary mb-3">
                      <User size={20} className="me-2" />
                      Cliente
                    </h6>
                    {modoVista !== 'ver' ? (
                      <div className="row">
                        <div className="col-md-12">
                          <label className="form-label">Seleccionar Cliente</label>
                          <select
                            className="form-select"
                            value={clienteSeleccionado?.id || ''}
                            onChange={(e) => {
                              const cliente = clientesEjemplo.find(c => c.id === parseInt(e.target.value));
                              setClienteSeleccionado(cliente || null);
                              if (cliente) {
                                setFormData(prev => ({ ...prev, direccionEntrega: cliente.direccion }));
                              }
                            }}
                          >
                            <option value="">Seleccionar cliente...</option>
                            {clientesEjemplo.map(cliente => (
                              <option key={cliente.id} value={cliente.id}>
                                {cliente.nombre} - {cliente.email}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    ) : (
                      clienteSeleccionado && (
                        <div className="row">
                          <div className="col-md-6">
                            <strong>Nombre:</strong> {clienteSeleccionado.nombre}
                          </div>
                          <div className="col-md-6">
                            <strong>Email:</strong> {clienteSeleccionado.email}
                          </div>
                          <div className="col-md-6 mt-2">
                            <strong>Teléfono:</strong> {clienteSeleccionado.telefono}
                          </div>
                          <div className="col-md-6 mt-2">
                            <strong>Dirección:</strong> {clienteSeleccionado.direccion}
                          </div>
                        </div>
                      )
                    )}
                  </div>

                  {/* Productos */}
                  <div className="border-bottom pb-3 mb-4">
                    <h6 className="text-primary mb-3">
                      <Package size={20} className="me-2" />
                      Productos
                    </h6>
                    
                    {modoVista !== 'ver' && (
                      <div className="mb-3">
                        <label className="form-label">Agregar Productos</label>
                        <div className="row">
                          {productosEjemplo.map(producto => (
                            <div key={producto.id} className="col-md-6 mb-2">
                              <div className="card">
                                <div className="card-body p-2">
                                  <div className="d-flex justify-content-between align-items-center">
                                    <div>
                                      <small className="fw-bold">{producto.nombre}</small>
                                      <br />
                                      <small className="text-muted">${producto.precio}</small>
                                    </div>
                                    <button
                                      type="button"
                                      className="btn btn-sm btn-outline-primary"
                                      onClick={() => agregarProducto(producto)}
                                    >
                                      <Plus size={16} />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Lista de productos seleccionados */}
                    {productosSeleccionados.length > 0 && (
                      <div className="table-responsive">
                        <table className="table table-sm">
                          <thead className="table-light">
                            <tr>
                              <th>Producto</th>
                              <th>Precio</th>
                              <th>Cantidad</th>
                              <th>Total</th>
                              {modoVista !== 'ver' && <th>Acciones</th>}
                            </tr>
                          </thead>
                          <tbody>
                            {productosSeleccionados.map(producto => (
                              <tr key={producto.productoId}>
                                <td>{producto.nombreProducto}</td>
                                <td>${producto.precio.toFixed(2)}</td>
                                <td>
                                  {modoVista !== 'ver' ? (
                                    <input
                                      type="number"
                                      className="form-control form-control-sm"
                                      style={{ width: '80px' }}
                                      min="1"
                                      value={producto.cantidad}
                                      onChange={(e) => actualizarCantidadProducto(
                                        producto.productoId,
                                        parseInt(e.target.value) || 0
                                      )}
                                    />
                                  ) : (
                                    producto.cantidad
                                  )}
                                </td>
                                <td className="fw-bold">${producto.total.toFixed(2)}</td>
                                {modoVista !== 'ver' && (
                                  <td>
                                    <button
                                      type="button"
                                      className="btn btn-sm btn-outline-danger"
                                      onClick={() => removerProducto(producto.productoId)}
                                    >
                                      <Trash2 size={16} />
                                    </button>
                                  </td>
                                )}
                              </tr>
                            ))}
                          </tbody>
                          <tfoot>
                            <tr>
                              <td colSpan={modoVista !== 'ver' ? 4 : 3} className="text-end fw-bold">Subtotal:</td>
                              <td className="fw-bold">${calcularTotales().subtotal.toFixed(2)}</td>
                              {modoVista !== 'ver' && <td></td>}
                            </tr>
                            <tr>
                              <td colSpan={modoVista !== 'ver' ? 4 : 3} className="text-end fw-bold">Impuestos (10%):</td>
                              <td className="fw-bold">${calcularTotales().impuestos.toFixed(2)}</td>
                              {modoVista !== 'ver' && <td></td>}
                            </tr>
                            <tr>
                              <td colSpan={modoVista !== 'ver' ? 4 : 3} className="text-end fw-bold">Total:</td>
                              <td className="fw-bold text-primary">${calcularTotales().total.toFixed(2)}</td>
                              {modoVista !== 'ver' && <td></td>}
                            </tr>
                          </tfoot>
                        </table>
                      </div>
                    )}
                  </div>

                  {/* Entrega */}
                  <div className="border-bottom pb-3 mb-4">
                    <h6 className="text-primary mb-3">
                      <Truck size={20} className="me-2" />
                      Información de Entrega
                    </h6>
                    <div className="row">
                      <div className="col-md-6">
                        <label className="form-label">Tipo de Entrega</label>
                        <select
                          className="form-select"
                          value={formData.tipoEntrega}
                          disabled={modoVista === 'ver'}
                          onChange={(e) => setFormData(prev => ({ ...prev, tipoEntrega: e.target.value as SolicitudPedido['tipoEntrega'] }))}
                        >
                          <option value="domicilio">Entrega a Domicilio</option>
                          <option value="recoger">Recoger en Tienda</option>
                          <option value="express">Entrega Express</option>
                        </select>
                      </div>
                      <div className="col-md-6">
                        <label className="form-label">Dirección de Entrega</label>
                        <input
                          type="text"
                          className="form-control"
                          value={formData.direccionEntrega}
                          disabled={modoVista === 'ver'}
                          onChange={(e) => setFormData(prev => ({ ...prev, direccionEntrega: e.target.value }))}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Observaciones */}
                  <div className="mb-3">
                    <label className="form-label">Observaciones</label>
                    <textarea
                      className="form-control"
                      rows={3}
                      value={formData.observaciones}
                      disabled={modoVista === 'ver'}
                      onChange={(e) => setFormData(prev => ({ ...prev, observaciones: e.target.value }))}
                      placeholder="Instrucciones especiales, notas sobre la entrega, etc."
                    />
                  </div>
                </form>
              </div>
              
              <div className="modal-footer">
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={cerrarModal}
                >
                  {modoVista === 'ver' ? 'Cerrar' : 'Cancelar'}
                </button>
                {modoVista !== 'ver' && (
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={guardarSolicitud}
                  >
                    <DollarSign size={16} className="me-2" />
                    {modoVista === 'crear' ? 'Crear Solicitud' : 'Actualizar Solicitud'}
                  </button>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}