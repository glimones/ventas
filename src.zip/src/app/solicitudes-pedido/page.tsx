import { AppShell } from '@/components/app-shell';
import SolicitudesPedidoPage from './SolicitudesPedidoPage';

export default function Page() {
  return <AppShell><SolicitudesPedidoPage /></AppShell>;
}