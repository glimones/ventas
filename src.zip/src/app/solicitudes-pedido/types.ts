// Tipos para Solicitudes de Pedido

export interface InfoCliente {
  tipo_identificacion: string;
  identificacion: string;
  razon_social: string;
  direccion: string;
  telefono?: string;
  email?: string;
}

export interface DetallePedido {
  id: string;
  codigo_producto: string;
  descripcion: string;
  cantidad_solicitada: number;
  precio_unitario_referencial: number;
  descuento_porcentaje: number;
  subtotal: number;
  observaciones?: string;
}

export interface SolicitudPedido {
  id: number;
  numero_solicitud: string;
  fecha_solicitud: string;
  fecha_entrega_solicitada: string;
  estado: 'BORRADOR' | 'ENVIADA' | 'EN_REVISION' | 'APROBADA' | 'RECHAZADA' | 'COTIZADA' | 'CANCELADA';
  prioridad: 'BAJA' | 'NORMAL' | 'ALTA' | 'URGENTE';
  tipo_solicitud: 'PRODUCTOS' | 'SERVICIOS' | 'MIXTA';
  info_cliente: InfoCliente;
  detalles: DetallePedido[];
  subtotal: number;
  descuento_total: number;
  iva: number;
  total_estimado: number;
  observaciones_generales?: string;
  vendedor_asignado?: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
  creado_por: string;
  sucursal: string;
}

export interface SolicitudPedidoFormValues {
  // Info básica
  fecha_solicitud: string;
  fecha_entrega_solicitada: string;
  prioridad: string;
  tipo_solicitud: string;
  sucursal: string;
  vendedor_asignado: string;
  
  // Info del cliente
  tipo_identificacion: string;
  identificacion: string;
  razon_social: string;
  direccion: string;
  telefono: string;
  email: string;
  
  // Detalle del pedido (para agregar productos)
  codigo_producto: string;
  descripcion: string;
  cantidad_solicitada: number;
  precio_unitario_referencial: number;
  descuento_porcentaje: number;
  observaciones_producto: string;
  
  // Observaciones generales
  observaciones_generales: string;
}

// Tipos de identificación
export const tiposIdentificacion = [
  { codigo: "04", descripcion: "RUC" },
  { codigo: "05", descripcion: "Cédula" },
  { codigo: "06", descripcion: "Pasaporte" },
  { codigo: "08", descripcion: "Identificación del exterior" }
];

// Estados de solicitud
export const estadosSolicitud = [
  { codigo: "BORRADOR", descripcion: "Borrador", color: "secondary" },
  { codigo: "ENVIADA", descripcion: "Enviada", color: "primary" },
  { codigo: "EN_REVISION", descripcion: "En Revisión", color: "warning" },
  { codigo: "APROBADA", descripcion: "Aprobada", color: "success" },
  { codigo: "RECHAZADA", descripcion: "Rechazada", color: "danger" },
  { codigo: "COTIZADA", descripcion: "Cotizada", color: "info" },
  { codigo: "CANCELADA", descripcion: "Cancelada", color: "dark" }
];

// Prioridades
export const prioridades = [
  { codigo: "BAJA", descripcion: "Baja", color: "secondary" },
  { codigo: "NORMAL", descripcion: "Normal", color: "primary" },
  { codigo: "ALTA", descripcion: "Alta", color: "warning" },
  { codigo: "URGENTE", descripcion: "Urgente", color: "danger" }
];

// Tipos de solicitud
export const tiposSolicitud = [
  { codigo: "PRODUCTOS", descripcion: "Solo Productos" },
  { codigo: "SERVICIOS", descripcion: "Solo Servicios" },
  { codigo: "MIXTA", descripcion: "Productos y Servicios" }
];

// Sucursales
export const sucursales = [
  { codigo: "001", descripcion: "Sucursal Principal" },
  { codigo: "002", descripcion: "Sucursal Norte" },
  { codigo: "003", descripcion: "Sucursal Sur" },
  { codigo: "004", descripcion: "Sucursal Centro" }
];

// Vendedores
export const vendedores = [
  { codigo: "VEND001", descripcion: "Juan Pérez" },
  { codigo: "VEND002", descripcion: "María García" },
  { codigo: "VEND003", descripcion: "Carlos López" },
  { codigo: "VEND004", descripcion: "Ana Martínez" },
  { codigo: "VEND005", descripcion: "Luis Rodríguez" }
];
