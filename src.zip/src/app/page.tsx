import { AppShell } from "@/components/app-shell";

export default function Home() {
  return (
    <AppShell showFooter={false}>
      <div className="flex min-h-full items-center justify-center px-6 py-16">
        <div className="rounded-xl border border-black/10 bg-white px-8 py-10 text-center shadow-sm">
          <h1 className="text-2xl font-semibold text-neutral-900">Sistema de Ventas</h1>
          <p className="mt-3 text-sm text-neutral-600">
            Seleccione una opción del menú para continuar.
          </p>
        </div>
      </div>
    </AppShell>
  );
}