"use client";
import React, { useState } from "react";
import { Factura, FacturaFormValues, DetalleFormValues, InfoTributaria, InfoFactura, TotalConImpuesto, Pago } from "./types";
import FacturaModal from "./FacturaModal";
import { SRIService } from "./sri-service";
import "./facturas.css";
import { CirclePlus, SquarePen, Trash2, Eye, Send, Download, FileText } from 'lucide-react';

const initialForm: FacturaFormValues = {
  ambiente: "1", // Pruebas por defecto
  razon_social: "",
  nombre_comercial: "",
  ruc: "",
  estab: "001",
  ptoEmi: "001",
  secuencial: "1",
  direccion_matriz: "",
  fecha_emision: new Date().toISOString().split('T')[0],
  direccion_establecimiento: "",
  contribuyente_especial: "",
  obligado_contabilidad: "NO",
  tipo_identificacion_comprador: "",
  guia_remision: "",
  razon_social_comprador: "",
  identificacion_comprador: "",
  direccion_comprador: "",
  propina: 0,
  moneda: "DOLAR",
  forma_pago: "01",
};

const initialFacturas: Factura[] = [
  {
    id: 1,
    info_tributaria: {
      ambiente: "1",
      tipo_emision: "1",
      razon_social: "EMPRESA DEMO S.A.",
      nombre_comercial: "Demo",
      ruc: "1234567890001",
      clave_acceso: "2309202401123456789000110010010000000011234567891",
      cod_doc: "01",
      estab: "001",
      ptoEmi: "001",
      secuencial: "000000001",
      direccion_matriz: "Av. Principal 123, Ciudad Demo"
    },
    info_factura: {
      fecha_emision: "23/09/2024",
      direccion_establecimiento: "Av. Principal 123, Ciudad Demo",
      contribuyente_especial: "",
      obligado_contabilidad: "SI",
      tipo_identificacion_comprador: "05",
      guia_remision: "",
      razon_social_comprador: "CLIENTE DEMO",
      identificacion_comprador: "1234567890",
      direccion_comprador: "Calle Cliente 456",
      total_sin_impuestos: 100.00,
      total_descuento: 0.00,
      propina: 0.00,
      importe_total: 112.00,
      moneda: "DOLAR",
      forma_pago: "01",
    },
    detalles: [
      {
        id: 1,
        codigo_principal: "PROD001",
        descripcion: "Producto Demo",
        cantidad: 1,
        precio_unitario: 100.00,
        descuento: 0.00,
        precio_total_sin_impuesto: 100.00,
        codigo_porcentaje_iva: "2",
        tarifa_iva: 0.12,
        valor_iva: 12.00,
        precio_total_con_impuesto: 112.00
      }
    ],
    total_con_impuestos: [
      {
        codigo: "2",
        codigo_porcentaje: "2",
        descuento_adicional: 0.00,
        base_imponible: 100.00,
        tarifa: 0.12,
        valor: 12.00
      }
    ],
    pagos: [
      {
        forma_pago: "01",
        total: 112.00
      }
    ],
    estado_sri: 'AUTORIZADA',
    numero_autorizacion: "2309202412345678901234567890123456",
    fecha_autorizacion: "2024-09-23T10:30:00.000Z",
    fecha_creacion: "2024-09-23T10:00:00.000Z",
    fecha_actualizacion: "2024-09-23T10:30:00.000Z"
  }
];

export default function FacturasPage() {
  const [facturas, setFacturas] = useState<Factura[]>(initialFacturas);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<FacturaFormValues>(initialForm);
  const [detalles, setDetalles] = useState<DetalleFormValues[]>([]);
  const [enviandoSRI, setEnviandoSRI] = useState<boolean>(false);

  const sriService = SRIService.getInstance();

  const limpiarForm = () => {
    setForm(initialForm);
    setDetalles([]);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    // Auto-incrementar secuencial
    const ultimoSecuencial = Math.max(...facturas.map(f => parseInt(f.info_tributaria.secuencial) || 0), 0);
    setForm(prev => ({
      ...prev,
      secuencial: (ultimoSecuencial + 1).toString()
    }));
    setShowModal(true);
  };
  
  const abrirModalEditar = (factura: Factura) => {
    setForm({
      ambiente: factura.info_tributaria.ambiente,
      razon_social: factura.info_tributaria.razon_social,
      nombre_comercial: factura.info_tributaria.nombre_comercial,
      ruc: factura.info_tributaria.ruc,
      estab: factura.info_tributaria.estab,
      ptoEmi: factura.info_tributaria.ptoEmi,
      secuencial: factura.info_tributaria.secuencial,
      direccion_matriz: factura.info_tributaria.direccion_matriz,
      fecha_emision: factura.info_factura.fecha_emision.split('/').reverse().join('-'), // DD/MM/YYYY -> YYYY-MM-DD
      direccion_establecimiento: factura.info_factura.direccion_establecimiento,
      contribuyente_especial: factura.info_factura.contribuyente_especial || "",
      obligado_contabilidad: factura.info_factura.obligado_contabilidad,
      tipo_identificacion_comprador: factura.info_factura.tipo_identificacion_comprador,
      guia_remision: factura.info_factura.guia_remision || "",
      razon_social_comprador: factura.info_factura.razon_social_comprador,
      identificacion_comprador: factura.info_factura.identificacion_comprador,
      direccion_comprador: factura.info_factura.direccion_comprador || "",
      propina: factura.info_factura.propina,
      moneda: factura.info_factura.moneda,
      forma_pago: factura.info_factura.forma_pago,
    });
    
    setDetalles(factura.detalles.map(det => ({
      codigo_principal: det.codigo_principal,
      codigo_auxiliar: det.codigo_auxiliar || "",
      descripcion: det.descripcion,
      cantidad: det.cantidad,
      precio_unitario: det.precio_unitario,
      descuento: det.descuento,
      codigo_porcentaje_iva: det.codigo_porcentaje_iva,
    })));
    
    setEditandoId(factura.id);
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const calcularTotalesFactura = (detallesFactura: DetalleFormValues[]) => {
    let totalSinImpuestos = 0;
    let totalDescuentos = 0;
    let totalIva = 0;
    const totalesConImpuestos: TotalConImpuesto[] = [];

    detallesFactura.forEach(detalle => {
      const subtotal = (detalle.cantidad * detalle.precio_unitario) - detalle.descuento;
      totalSinImpuestos += subtotal;
      totalDescuentos += detalle.descuento;

      let tarifaIva = 0;
      if (detalle.codigo_porcentaje_iva === "2") {
        tarifaIva = 0.12;
      } else if (detalle.codigo_porcentaje_iva === "3") {
        tarifaIva = 0.14;
      }

      const valorIva = subtotal * tarifaIva;
      totalIva += valorIva;

      // Agrupar por código de porcentaje
      const existente = totalesConImpuestos.find(t => t.codigo_porcentaje === detalle.codigo_porcentaje_iva);
      if (existente) {
        existente.base_imponible += subtotal;
        existente.valor += valorIva;
      } else {
        totalesConImpuestos.push({
          codigo: "2",
          codigo_porcentaje: detalle.codigo_porcentaje_iva,
          descuento_adicional: 0,
          base_imponible: subtotal,
          tarifa: tarifaIva,
          valor: valorIva
        });
      }
    });

    return {
      totalSinImpuestos,
      totalDescuentos,
      totalIva,
      totalesConImpuestos,
      importeTotal: totalSinImpuestos + totalIva + (form.propina || 0)
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (detalles.length === 0) {
      alert('Debe agregar al menos un detalle a la factura');
      return;
    }

    setEnviandoSRI(true);
    
    try {
      const totales = calcularTotalesFactura(detalles);
      
      // Crear estructura completa de la factura
      const infoTributaria: InfoTributaria = {
        ambiente: form.ambiente,
        tipo_emision: "1",
        razon_social: form.razon_social,
        nombre_comercial: form.nombre_comercial,
        ruc: form.ruc,
        clave_acceso: "", // Se genera en el servicio SRI
        cod_doc: "01",
        estab: form.estab,
        ptoEmi: form.ptoEmi,
        secuencial: form.secuencial,
        direccion_matriz: form.direccion_matriz,
      };

      const infoFactura: InfoFactura = {
        fecha_emision: form.fecha_emision.split('-').reverse().join('/'), // YYYY-MM-DD -> DD/MM/YYYY
        direccion_establecimiento: form.direccion_establecimiento,
        contribuyente_especial: form.contribuyente_especial,
        obligado_contabilidad: form.obligado_contabilidad,
        tipo_identificacion_comprador: form.tipo_identificacion_comprador,
        guia_remision: form.guia_remision,
        razon_social_comprador: form.razon_social_comprador,
        identificacion_comprador: form.identificacion_comprador,
        direccion_comprador: form.direccion_comprador,
        total_sin_impuestos: totales.totalSinImpuestos,
        total_descuento: totales.totalDescuentos,
        propina: form.propina || 0,
        importe_total: totales.importeTotal,
        moneda: form.moneda,
        forma_pago: form.forma_pago,
      };

      const detallesCompletos = detalles.map((det, index) => {
        const subtotal = (det.cantidad * det.precio_unitario) - det.descuento;
        let tarifaIva = 0;
        if (det.codigo_porcentaje_iva === "2") {
          tarifaIva = 0.12;
        } else if (det.codigo_porcentaje_iva === "3") {
          tarifaIva = 0.14;
        }
        const valorIva = subtotal * tarifaIva;

        return {
          id: index + 1,
          codigo_principal: det.codigo_principal,
          codigo_auxiliar: det.codigo_auxiliar,
          descripcion: det.descripcion,
          cantidad: det.cantidad,
          precio_unitario: det.precio_unitario,
          descuento: det.descuento,
          precio_total_sin_impuesto: subtotal,
          codigo_porcentaje_iva: det.codigo_porcentaje_iva,
          tarifa_iva: tarifaIva,
          valor_iva: valorIva,
          precio_total_con_impuesto: subtotal + valorIva
        };
      });

      const pagos: Pago[] = [{
        forma_pago: form.forma_pago,
        total: totales.importeTotal
      }];

      const nuevaFactura: Factura = {
        id: editandoId || Date.now(),
        info_tributaria: infoTributaria,
        info_factura: infoFactura,
        detalles: detallesCompletos,
        total_con_impuestos: totales.totalesConImpuestos,
        pagos: pagos,
        estado_sri: 'PENDIENTE',
        fecha_creacion: new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString()
      };

      // Enviar al SRI
      console.log('🚀 Enviando factura al SRI...', nuevaFactura);
      const respuestaSRI = await sriService.enviarFacturaSRI(nuevaFactura);

      // Actualizar factura con respuesta del SRI
      nuevaFactura.estado_sri = respuestaSRI.estado;
      if (respuestaSRI.success) {
        nuevaFactura.numero_autorizacion = respuestaSRI.numero_autorizacion;
        nuevaFactura.fecha_autorizacion = respuestaSRI.fecha_autorizacion;
        nuevaFactura.xml_generado = respuestaSRI.xml_autorizado;
      }
      nuevaFactura.observaciones_sri = respuestaSRI.observaciones;

      // Actualizar lista de facturas
      if (editandoId) {
        setFacturas((prev) =>
          prev.map((factura) =>
            factura.id === editandoId ? nuevaFactura : factura
          )
        );
      } else {
        setFacturas((prev) => [...prev, nuevaFactura]);
      }

      // Mostrar resultado
      if (respuestaSRI.success) {
        alert(`✅ Factura ${respuestaSRI.estado.toLowerCase()} exitosamente.\nNúmero de autorización: ${respuestaSRI.numero_autorizacion}`);
        cerrarModal();
      } else {
        alert(`❌ Error del SRI: ${respuestaSRI.mensaje_error}\n\nObservaciones: ${respuestaSRI.observaciones}`);
      }

    } catch (error) {
      console.error('Error procesando factura:', error);
      alert('Error inesperado al procesar la factura');
    } finally {
      setEnviandoSRI(false);
    }
  };

  const eliminarFactura = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta factura?")) {
      setFacturas((prev) => prev.filter((factura) => factura.id !== id));
    }
  };

  const reenviarSRI = async (factura: Factura) => {
    if (window.confirm("¿Desea reenviar esta factura al SRI?")) {
      setEnviandoSRI(true);
      try {
        const respuestaSRI = await sriService.enviarFacturaSRI(factura);
        
        // Actualizar factura
        const facturaActualizada = {
          ...factura,
          estado_sri: respuestaSRI.estado,
          numero_autorizacion: respuestaSRI.numero_autorizacion,
          fecha_autorizacion: respuestaSRI.fecha_autorizacion,
          xml_generado: respuestaSRI.xml_autorizado,
          observaciones_sri: respuestaSRI.observaciones,
          fecha_actualizacion: new Date().toISOString()
        };

        setFacturas(prev => prev.map(f => f.id === factura.id ? facturaActualizada : f));

        if (respuestaSRI.success) {
          alert(`✅ Factura ${respuestaSRI.estado.toLowerCase()} exitosamente.`);
        } else {
          alert(`❌ Error del SRI: ${respuestaSRI.mensaje_error}`);
        }
      } catch (err) {
        console.error('Error reenviar SRI:', err);
        alert('Error al reenviar factura al SRI');
      } finally {
        setEnviandoSRI(false);
      }
    }
  };

  const descargarPDF = (factura: Factura) => {
    // Crear contenido HTML para el PDF con formato oficial SRI Ecuador
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Factura ${factura.info_tributaria.secuencial}</title>
        <style>
          body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 10px;
            font-size: 11px;
            line-height: 1.2;
          }
          
          .factura-container {
            max-width: 210mm;
            margin: 0 auto;
            border: 2px solid #000;
          }
          
          .header-section {
            display: flex;
            border-bottom: 1px solid #000;
          }
          
          .company-section {
            flex: 2;
            padding: 10px;
            border-right: 1px solid #000;
          }
          
          .document-info {
            flex: 1;
            padding: 10px;
            text-align: center;
          }
          
          .company-name {
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 5px;
          }
          
          .company-details {
            text-align: center;
            margin-bottom: 10px;
          }
          
          .ruc-info {
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            background-color: #f0f0f0;
            padding: 3px;
            border: 1px solid #000;
            margin: 5px 0;
          }
          
          .document-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
            background-color: #f0f0f0;
            padding: 5px;
            border: 1px solid #000;
          }
          
          .document-number {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 10px;
          }
          
          .authorization-box {
            border: 1px solid #000;
            padding: 5px;
            margin: 5px 0;
            background-color: #f9f9f9;
          }
          
          .client-section {
            padding: 10px;
            border-bottom: 1px solid #000;
          }
          
          .client-title {
            font-weight: bold;
            margin-bottom: 5px;
            background-color: #f0f0f0;
            padding: 3px;
          }
          
          .client-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
          }
          
          .details-section {
            padding: 10px;
          }
          
          .details-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
          }
          
          .details-table th {
            background-color: #f0f0f0;
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
            font-weight: bold;
            font-size: 10px;
          }
          
          .details-table td {
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
            font-size: 10px;
          }
          
          .details-table .desc-col {
            text-align: left;
          }
          
          .details-table .num-col {
            text-align: right;
          }
          
          .totals-section {
            display: flex;
            justify-content: flex-end;
            padding: 10px;
            border-top: 1px solid #000;
          }
          
          .totals-table {
            border-collapse: collapse;
            width: 300px;
          }
          
          .totals-table td {
            border: 1px solid #000;
            padding: 5px;
            font-size: 11px;
          }
          
          .totals-table .label-col {
            background-color: #f0f0f0;
            font-weight: bold;
            text-align: right;
            width: 150px;
          }
          
          .totals-table .amount-col {
            text-align: right;
            width: 150px;
          }
          
          .total-final {
            font-weight: bold;
            font-size: 12px;
            background-color: #e0e0e0;
          }
          
          .footer-section {
            padding: 10px;
            border-top: 1px solid #000;
            font-size: 10px;
            text-align: center;
          }
          
          .payment-info {
            margin-top: 10px;
            border-top: 1px dotted #000;
            padding-top: 10px;
          }
          
          @media print {
            body { margin: 0; }
            .factura-container { border: 2px solid #000; }
          }
        </style>
      </head>
      <body>
        <div class="factura-container">
          <!-- HEADER SECTION -->
          <div class="header-section">
            <div class="company-section">
              <div class="company-name">${factura.info_tributaria.razon_social}</div>
              <div class="company-details">
                <strong>Nombre Comercial:</strong> ${factura.info_tributaria.nombre_comercial}<br>
                <strong>Dirección Matriz:</strong> ${factura.info_tributaria.direccion_matriz}<br>
                <strong>Dirección Sucursal:</strong> ${factura.info_factura.direccion_establecimiento || factura.info_tributaria.direccion_matriz}
              </div>
              <div class="ruc-info">R.U.C.: ${factura.info_tributaria.ruc}</div>
              ${factura.info_factura.contribuyente_especial ? `<div class="ruc-info">CONTRIBUYENTE ESPECIAL NO. ${factura.info_factura.contribuyente_especial}</div>` : ''}
              <div class="ruc-info">OBLIGADO A LLEVAR CONTABILIDAD: ${factura.info_factura.obligado_contabilidad}</div>
            </div>
            
            <div class="document-info">
              <div class="document-title">FACTURA</div>
              <div class="document-number">No. ${factura.info_tributaria.estab}-${factura.info_tributaria.ptoEmi}-${factura.info_tributaria.secuencial.padStart(9, '0')}</div>
              
              <div class="authorization-box">
                <strong>NÚMERO DE AUTORIZACIÓN</strong><br>
                ${factura.numero_autorizacion || 'PENDIENTE DE AUTORIZACIÓN'}
              </div>
              
              <div class="authorization-box">
                <strong>FECHA Y HORA DE AUTORIZACIÓN:</strong><br>
                ${factura.fecha_autorizacion ? new Date(factura.fecha_autorizacion).toLocaleString('es-EC', {
                  year: 'numeric',
                  month: '2-digit', 
                  day: '2-digit',
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit'
                }) : 'PENDIENTE'}
              </div>
              
              <div class="authorization-box">
                <strong>AMBIENTE:</strong> ${factura.info_tributaria.ambiente === '1' ? 'PRUEBAS' : 'PRODUCCIÓN'}<br>
                <strong>EMISIÓN:</strong> NORMAL
              </div>
              
              <div class="authorization-box">
                <strong>CLAVE DE ACCESO</strong><br>
                <div style="font-family: monospace; font-size: 9px; word-break: break-all;">
                  ${factura.info_tributaria.clave_acceso || 'PENDIENTE DE GENERACIÓN'}
                </div>
              </div>
            </div>
          </div>
          
          <!-- CLIENT SECTION -->
          <div class="client-section">
            <div class="client-title">DATOS DEL CLIENTE</div>
            <div class="client-info">
              <span><strong>Razón Social / Nombres y Apellidos:</strong> ${factura.info_factura.razon_social_comprador}</span>
              <span><strong>Fecha de Emisión:</strong> ${factura.info_factura.fecha_emision}</span>
            </div>
            <div class="client-info">
              <span><strong>Identificación:</strong> ${factura.info_factura.identificacion_comprador}</span>
              <span><strong>Guía de Remisión:</strong> ${factura.info_factura.guia_remision || 'N/A'}</span>
            </div>
            <div class="client-info">
              <span><strong>Dirección:</strong> ${factura.info_factura.direccion_comprador || 'N/A'}</span>
            </div>
          </div>
          
          <!-- DETAILS SECTION -->
          <div class="details-section">
            <table class="details-table">
              <thead>
                <tr>
                  <th style="width: 12%;">Código<br>Principal</th>
                  <th style="width: 10%;">Código<br>Auxiliar</th>
                  <th style="width: 30%;">Descripción</th>
                  <th style="width: 8%;">Cantidad</th>
                  <th style="width: 10%;">Precio<br>Unitario</th>
                  <th style="width: 10%;">Descuento</th>
                  <th style="width: 10%;">Precio Total<br>Sin Impuesto</th>
                  <th style="width: 10%;">Precio Total<br>Con Impuesto</th>
                </tr>
              </thead>
              <tbody>
                ${factura.detalles.map(detalle => `
                  <tr>
                    <td>${detalle.codigo_principal}</td>
                    <td>${detalle.codigo_auxiliar || ''}</td>
                    <td class="desc-col">${detalle.descripcion}</td>
                    <td class="num-col">${detalle.cantidad}</td>
                    <td class="num-col">${detalle.precio_unitario.toFixed(2)}</td>
                    <td class="num-col">${detalle.descuento.toFixed(2)}</td>
                    <td class="num-col">${detalle.precio_total_sin_impuesto.toFixed(2)}</td>
                    <td class="num-col">${detalle.precio_total_con_impuesto.toFixed(2)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          
          <!-- TOTALS SECTION -->
          <div class="totals-section">
            <table class="totals-table">
              <tr>
                <td class="label-col">SUBTOTAL 12%</td>
                <td class="amount-col">${factura.total_con_impuestos.find(t => t.codigo_porcentaje === '2')?.base_imponible.toFixed(2) || '0.00'}</td>
              </tr>
              <tr>
                <td class="label-col">SUBTOTAL 0%</td>
                <td class="amount-col">${factura.total_con_impuestos.find(t => t.codigo_porcentaje === '0')?.base_imponible.toFixed(2) || '0.00'}</td>
              </tr>
              <tr>
                <td class="label-col">SUBTOTAL NO OBJETO DE IVA</td>
                <td class="amount-col">0.00</td>
              </tr>
              <tr>
                <td class="label-col">SUBTOTAL SIN IMPUESTOS</td>
                <td class="amount-col">${factura.info_factura.total_sin_impuestos.toFixed(2)}</td>
              </tr>
              <tr>
                <td class="label-col">SUBTOTAL EXENTO DE IVA</td>
                <td class="amount-col">0.00</td>
              </tr>
              <tr>
                <td class="label-col">DESCUENTO</td>
                <td class="amount-col">${factura.info_factura.total_descuento.toFixed(2)}</td>
              </tr>
              <tr>
                <td class="label-col">ICE</td>
                <td class="amount-col">0.00</td>
              </tr>
              <tr>
                <td class="label-col">IRBPNR</td>
                <td class="amount-col">0.00</td>
              </tr>
              <tr>
                <td class="label-col">IVA 12%</td>
                <td class="amount-col">${factura.total_con_impuestos.find(t => t.codigo_porcentaje === '2')?.valor.toFixed(2) || '0.00'}</td>
              </tr>
              <tr>
                <td class="label-col">IVA 0%</td>
                <td class="amount-col">0.00</td>
              </tr>
              ${factura.info_factura.propina > 0 ? `
              <tr>
                <td class="label-col">PROPINA</td>
                <td class="amount-col">${factura.info_factura.propina.toFixed(2)}</td>
              </tr>
              ` : ''}
              <tr class="total-final">
                <td class="label-col">VALOR TOTAL</td>
                <td class="amount-col">${factura.info_factura.importe_total.toFixed(2)}</td>
              </tr>
            </table>
          </div>
          
          <!-- PAYMENT INFO -->
          <div class="payment-info">
            <strong>FORMA DE PAGO:</strong> ${getFormaPagoDescripcion(factura.info_factura.forma_pago)} - 
            <strong>VALOR:</strong> ${factura.info_factura.importe_total.toFixed(2)}
          </div>
          
          <!-- FOOTER -->
          <div class="footer-section">
            <small>
              Este documento constituye un comprobante de venta autorizado por el Servicio de Rentas Internas del Ecuador, 
              en virtud de lo dispuesto en el RUC No. ${factura.info_tributaria.ruc}, de fecha ${factura.info_factura.fecha_emision}.
            </small>
          </div>
        </div>
      </body>
      </html>
    `;

    // Crear una nueva ventana para imprimir
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      
      // Esperar a que se cargue el contenido y luego imprimir
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 100);
      };
    }
  };

  const getFormaPagoDescripcion = (codigo: string) => {
    const formasPago: { [key: string]: string } = {
      '01': 'SIN UTILIZACION DEL SISTEMA FINANCIERO',
      '15': 'COMPENSACIÓN DE DEUDAS',
      '16': 'TARJETA DE DÉBITO',
      '17': 'DINERO ELECTRÓNICO',
      '18': 'TARJETA PREPAGO',
      '19': 'TARJETA DE CRÉDITO',
      '20': 'OTROS CON UTILIZACION DEL SISTEMA FINANCIERO',
      '21': 'ENDOSO DE TÍTULOS'
    };
    return formasPago[codigo] || 'OTROS';
  };

  const facturasFiltradas = facturas.filter((factura) =>
    Object.values(factura.info_factura)
      .concat(Object.values(factura.info_tributaria))
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'AUTORIZADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'DEVUELTA': return 'bg-warning text-dark';
      case 'PENDIENTE': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="p-4">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Facturas Electrónicas</h1>
            <p className="text-muted mb-0">Gestión de comprobantes electrónicos SRI Ecuador</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-info">Ambiente: Pruebas</span>
            <span className="badge bg-primary">{facturas.length} facturas</span>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar por cliente, RUC, secuencial..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-primary d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Factura</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Secuencial</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>RUC/Cédula</th>
                <th>Total</th>
                <th>Estado SRI</th>
                <th>Autorización</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {facturasFiltradas.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-4">
                    <div className="text-muted">
                      <i className="fas fa-file-invoice fa-3x mb-3 d-block"></i>
                      No se encontraron facturas
                    </div>
                  </td>
                </tr>
              )}
              {facturasFiltradas.map((factura) => (
                <tr key={factura.id}>
                  <td>
                    <strong>{factura.info_tributaria.estab}-{factura.info_tributaria.ptoEmi}-{factura.info_tributaria.secuencial.padStart(9, '0')}</strong>
                  </td>
                  <td>{factura.info_factura.fecha_emision}</td>
                  <td>{factura.info_factura.razon_social_comprador}</td>
                  <td>{factura.info_factura.identificacion_comprador}</td>
                  <td className="text-end">
                    <strong>${factura.info_factura.importe_total.toFixed(2)}</strong>
                  </td>
                  <td>
                    <span className={`badge ${getEstadoBadgeClass(factura.estado_sri)}`}>
                      {factura.estado_sri}
                    </span>
                  </td>
                  <td>
                    {factura.numero_autorizacion ? (
                      <small className="text-muted">
                        {factura.numero_autorizacion.substring(0, 15)}...
                      </small>
                    ) : (
                      <small className="text-muted">Sin autorizar</small>
                    )}
                  </td>
                  <td>
                    <div className="btn-group" role="group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => abrirModalEditar(factura)}
                        title="Ver detalles"
                      >
                        <Eye size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(factura)}
                        title="Editar"
                        disabled={factura.estado_sri === 'AUTORIZADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      {(factura.estado_sri === 'RECHAZADA' || factura.estado_sri === 'DEVUELTA' || factura.estado_sri === 'PENDIENTE') && (
                        <button
                          className="btn btn-outline-primary btn-sm"
                          onClick={() => reenviarSRI(factura)}
                          title="Reenviar al SRI"
                          disabled={enviandoSRI}
                        >
                          <Send size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-info btn-sm"
                        title="Descargar PDF"
                        onClick={() => descargarPDF(factura)}
                      >
                        <FileText size={14} />
                      </button>
                      
                      {factura.xml_generado && (
                        <button
                          className="btn btn-outline-success btn-sm"
                          title="Descargar XML"
                          onClick={() => {
                            const blob = new Blob([factura.xml_generado!], { type: 'application/xml' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `factura_${factura.info_tributaria.secuencial}.xml`;
                            a.click();
                          }}
                        >
                          <Download size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarFactura(factura.id)}
                        title="Eliminar"
                        disabled={factura.estado_sri === 'AUTORIZADA'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <FacturaModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          detalles={detalles}
          onChange={handleChange}
          onDetallesChange={setDetalles}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          enviandoSRI={enviandoSRI}
        />
      </div>
    </div>
  );
}
