// Servicio simulado para integración con SRI Ecuador
import { Factura } from './types';

export interface RespuestaSRI {
  success: boolean;
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  estado: 'AUTORIZADA' | 'RECHAZADA' | 'DEVUELTA';
  xml_autorizado?: string;
  observaciones?: string;
  codigo_error?: string;
  mensaje_error?: string;
}

export class SRIService {
  private static instance: SRIService;
  private readonly URL_SRI_PRUEBAS = 'https://celcer.sri.gob.ec/comprobantes-electronicos-ws/RecepcionComprobantesOffline?wsdl';
  private readonly URL_SRI_AUTORIZACION = 'https://celcer.sri.gob.ec/comprobantes-electronicos-ws/AutorizacionComprobantesOffline?wsdl';

  public static getInstance(): SRIService {
    if (!SRIService.instance) {
      SRIService.instance = new SRIService();
    }
    return SRIService.instance;
  }

  /**
   * Genera una clave de acceso de 49 dígitos según las especificaciones del SRI
   */
  private generarClaveAcceso(fecha: string, tipoComprobante: string, ruc: string, ambiente: string, establecimiento: string, puntoEmision: string, secuencial: string): string {
    // Formato: ddmmaaaa + tipo_comprobante + ruc + ambiente + serie + numero_comprobante + codigo_numerico + tipo_emision
    const fechaFormateada = fecha.split('/').reverse().join(''); // DDMMAAAA
    const codigoNumerico = Math.floor(Math.random() * 99999999).toString().padStart(8, '0');
    const tipoEmision = '1'; // Emisión normal
    
    const claveBase = fechaFormateada + tipoComprobante + ruc + ambiente + establecimiento + puntoEmision + secuencial.padStart(9, '0') + codigoNumerico + tipoEmision;
    
    // Calcular dígito verificador usando módulo 11
    const digitoVerificador = this.calcularDigitoVerificador(claveBase);
    
    return claveBase + digitoVerificador;
  }

  /**
   * Calcula el dígito verificador usando módulo 11
   */
  private calcularDigitoVerificador(clave: string): string {
    const factores = [2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7];
    let suma = 0;
    
    for (let i = 0; i < clave.length; i++) {
      suma += parseInt(clave[i]) * factores[i];
    }
    
    const residuo = suma % 11;
    const digitoVerificador = residuo < 2 ? residuo : 11 - residuo;
    
    return digitoVerificador.toString();
  }

  /**
   * Simula la generación del XML de la factura
   */
  private generarXMLFactura(factura: Factura): string {
    const claveAcceso = this.generarClaveAcceso(
      factura.info_factura.fecha_emision,
      '01', // Código para factura
      factura.info_tributaria.ruc,
      factura.info_tributaria.ambiente,
      factura.info_tributaria.estab,
      factura.info_tributaria.ptoEmi,
      factura.info_tributaria.secuencial
    );

    // Actualizar la clave de acceso en la factura
    factura.info_tributaria.clave_acceso = claveAcceso;

    return `<?xml version="1.0" encoding="UTF-8"?>
<factura id="comprobante" version="1.1.0">
  <infoTributaria>
    <ambiente>${factura.info_tributaria.ambiente}</ambiente>
    <tipoEmision>${factura.info_tributaria.tipo_emision}</tipoEmision>
    <razonSocial><![CDATA[${factura.info_tributaria.razon_social}]]></razonSocial>
    <nombreComercial><![CDATA[${factura.info_tributaria.nombre_comercial}]]></nombreComercial>
    <ruc>${factura.info_tributaria.ruc}</ruc>
    <claveAcceso>${claveAcceso}</claveAcceso>
    <codDoc>${factura.info_tributaria.cod_doc}</codDoc>
    <estab>${factura.info_tributaria.estab}</estab>
    <ptoEmi>${factura.info_tributaria.ptoEmi}</ptoEmi>
    <secuencial>${factura.info_tributaria.secuencial}</secuencial>
    <dirMatriz><![CDATA[${factura.info_tributaria.direccion_matriz}]]></dirMatriz>
  </infoTributaria>
  <infoFactura>
    <fechaEmision>${factura.info_factura.fecha_emision}</fechaEmision>
    <dirEstablecimiento><![CDATA[${factura.info_factura.direccion_establecimiento}]]></dirEstablecimiento>
    <obligadoContabilidad>${factura.info_factura.obligado_contabilidad}</obligadoContabilidad>
    <tipoIdentificacionComprador>${factura.info_factura.tipo_identificacion_comprador}</tipoIdentificacionComprador>
    <razonSocialComprador><![CDATA[${factura.info_factura.razon_social_comprador}]]></razonSocialComprador>
    <identificacionComprador>${factura.info_factura.identificacion_comprador}</identificacionComprador>
    <totalSinImpuestos>${factura.info_factura.total_sin_impuestos.toFixed(2)}</totalSinImpuestos>
    <totalDescuento>${factura.info_factura.total_descuento.toFixed(2)}</totalDescuento>
    <totalConImpuestos>
      ${factura.total_con_impuestos.map(impuesto => `
      <totalImpuesto>
        <codigo>${impuesto.codigo}</codigo>
        <codigoPorcentaje>${impuesto.codigo_porcentaje}</codigoPorcentaje>
        <baseImponible>${impuesto.base_imponible.toFixed(2)}</baseImponible>
        <tarifa>${impuesto.tarifa.toFixed(2)}</tarifa>
        <valor>${impuesto.valor.toFixed(2)}</valor>
      </totalImpuesto>`).join('')}
    </totalConImpuestos>
    <propina>${factura.info_factura.propina.toFixed(2)}</propina>
    <importeTotal>${factura.info_factura.importe_total.toFixed(2)}</importeTotal>
    <moneda>${factura.info_factura.moneda}</moneda>
    <pagos>
      ${factura.pagos.map(pago => `
      <pago>
        <formaPago>${pago.forma_pago}</formaPago>
        <total>${pago.total.toFixed(2)}</total>
      </pago>`).join('')}
    </pagos>
  </infoFactura>
  <detalles>
    ${factura.detalles.map(detalle => `
    <detalle>
      <codigoPrincipal><![CDATA[${detalle.codigo_principal}]]></codigoPrincipal>
      <descripcion><![CDATA[${detalle.descripcion}]]></descripcion>
      <cantidad>${detalle.cantidad}</cantidad>
      <precioUnitario>${detalle.precio_unitario.toFixed(6)}</precioUnitario>
      <descuento>${detalle.descuento.toFixed(2)}</descuento>
      <precioTotalSinImpuesto>${detalle.precio_total_sin_impuesto.toFixed(2)}</precioTotalSinImpuesto>
      <impuestos>
        <impuesto>
          <codigo>2</codigo>
          <codigoPorcentaje>${detalle.codigo_porcentaje_iva}</codigoPorcentaje>
          <tarifa>${detalle.tarifa_iva.toFixed(2)}</tarifa>
          <baseImponible>${detalle.precio_total_sin_impuesto.toFixed(2)}</baseImponible>
          <valor>${detalle.valor_iva.toFixed(2)}</valor>
        </impuesto>
      </impuestos>
    </detalle>`).join('')}
  </detalles>
</factura>`;
  }

  /**
   * Simula la firma electrónica del XML
   */
  private async firmarXML(xml: string): Promise<string> {
    // Simular tiempo de procesamiento
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // En un entorno real, aquí se usaría la biblioteca de firma electrónica
    // Por ahora solo agregamos un comentario de firma simulada
    const xmlFirmado = xml.replace(
      '</factura>',
      '  <!-- Firma electrónica simulada -->\n  <ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#" Id="Signature">\n    <!-- Firma P12 simulada -->\n  </ds:Signature>\n</factura>'
    );
    
    return xmlFirmado;
  }

  /**
   * Simula el envío al SRI y retorna la respuesta
   */
  public async enviarFacturaSRI(factura: Factura): Promise<RespuestaSRI> {
    try {
      console.log('🚀 Iniciando proceso de envío al SRI...');
      
      // Paso 1: Generar XML
      console.log('📄 Generando XML de la factura...');
      const xml = this.generarXMLFactura(factura);
      
      // Paso 2: Firmar XML
      console.log('✍️ Firmando electrónicamente el XML...');
      const xmlFirmado = await this.firmarXML(xml);
      
      // Paso 3: Validaciones básicas
      console.log('🔍 Validando estructura del comprobante...');
      const validacion = this.validarFactura(factura);
      if (!validacion.valida) {
        return {
          success: false,
          estado: 'RECHAZADA',
          codigo_error: '70',
          mensaje_error: validacion.errores.join(', '),
          observaciones: 'Comprobante rechazado por errores de validación'
        };
      }
      
      // Paso 4: Simular envío a SRI (recepción)
      console.log('📤 Enviando comprobante al SRI...');
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Paso 5: Simular proceso de autorización
      console.log('⏳ Procesando autorización...');
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simular diferentes escenarios de respuesta
      const probabilidadExito = 0.85; // 85% de probabilidad de éxito
      const random = Math.random();
      
      if (random < probabilidadExito) {
        // Autorizada
        const numeroAutorizacion = this.generarNumeroAutorizacion();
        const fechaAutorizacion = new Date().toISOString();
        
        console.log('✅ Factura autorizada exitosamente');
        
        return {
          success: true,
          numero_autorizacion: numeroAutorizacion,
          fecha_autorizacion: fechaAutorizacion,
          estado: 'AUTORIZADA',
          xml_autorizado: xmlFirmado,
          observaciones: 'Comprobante autorizado correctamente'
        };
      } else if (random < 0.95) {
        // Devuelta (errores menores)
        console.log('⚠️ Factura devuelta por observaciones');
        
        return {
          success: false,
          estado: 'DEVUELTA',
          codigo_error: '43',
          mensaje_error: 'CLAVE DE ACCESO REGISTRADA',
          observaciones: 'El comprobante fue devuelto. Corrija los errores y reenvíe.'
        };
      } else {
        // Rechazada (errores graves)
        console.log('❌ Factura rechazada');
        
        return {
          success: false,
          estado: 'RECHAZADA',
          codigo_error: '70',
          mensaje_error: 'ESTRUCTURA DEL COMPROBANTE ERRONEA',
          observaciones: 'El comprobante contiene errores estructurales graves.'
        };
      }
      
    } catch (error) {
      console.error('💥 Error en el proceso de envío al SRI:', error);
      
      return {
        success: false,
        estado: 'RECHAZADA',
        codigo_error: '999',
        mensaje_error: 'Error interno del sistema',
        observaciones: 'Ocurrió un error inesperado durante el procesamiento.'
      };
    }
  }

  /**
   * Genera un número de autorización simulado
   */
  private generarNumeroAutorizacion(): string {
    const timestamp = Date.now().toString();
    const random = Math.floor(Math.random() * 999999).toString().padStart(6, '0');
    return timestamp + random;
  }

  /**
   * Valida la estructura básica de la factura
   */
  private validarFactura(factura: Factura): { valida: boolean; errores: string[] } {
    const errores: string[] = [];
    
    // Validar RUC
    if (!factura.info_tributaria.ruc || factura.info_tributaria.ruc.length !== 13) {
      errores.push('RUC debe tener 13 dígitos');
    }
    
    // Validar identificación del comprador
    if (!factura.info_factura.identificacion_comprador) {
      errores.push('Identificación del comprador es requerida');
    }
    
    // Validar que tenga al menos un detalle
    if (!factura.detalles || factura.detalles.length === 0) {
      errores.push('La factura debe tener al menos un detalle');
    }
    
    // Validar secuencial
    if (!factura.info_tributaria.secuencial || isNaN(parseInt(factura.info_tributaria.secuencial))) {
      errores.push('Secuencial debe ser numérico');
    }
    
    // Validar establecimiento y punto de emisión
    if (!factura.info_tributaria.estab || factura.info_tributaria.estab.length !== 3) {
      errores.push('Establecimiento debe tener 3 dígitos');
    }
    
    if (!factura.info_tributaria.ptoEmi || factura.info_tributaria.ptoEmi.length !== 3) {
      errores.push('Punto de emisión debe tener 3 dígitos');
    }
    
    return {
      valida: errores.length === 0,
      errores
    };
  }

  /**
   * Consulta el estado de autorización de una factura
   */
  public async consultarAutorizacion(claveAcceso: string): Promise<RespuestaSRI> {
    console.log(`🔍 Consultando autorización para clave: ${claveAcceso}`);
    
    // Simular consulta
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Por simplicidad, siempre retornamos autorizada en las consultas
    return {
      success: true,
      numero_autorizacion: this.generarNumeroAutorizacion(),
      fecha_autorizacion: new Date().toISOString(),
      estado: 'AUTORIZADA',
      observaciones: 'Comprobante autorizado correctamente'
    };
  }
}
