"use client";
import React, { useState } from "react";
import { FacturaFormValues, DetalleFormValues, TIPO_IDENTIFICACION_OPTIONS, CODIGO_IVA_OPTIONS, FORMA_PAGO_OPTIONS, AMBIENTE_OPTIONS } from "./types";
import { Plus, Trash2 } from "lucide-react";

interface Props {
  values: FacturaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  detalles: DetalleFormValues[];
  onDetallesChange: (detalles: DetalleFormValues[]) => void;
}

const FacturaForm: React.FC<Props> = ({ values, onChange, detalles, onDetallesChange }) => {
  const [nuevoDetalle, setNuevoDetalle] = useState<DetalleFormValues>({
    codigo_principal: "",
    codigo_auxiliar: "",
    descripcion: "",
    cantidad: 1,
    precio_unitario: 0,
    descuento: 0,
    codigo_porcentaje_iva: "2", // 12% por defecto
  });

  const calcularTotalesDetalle = (detalle: DetalleFormValues) => {
    const precioTotalSinImpuesto = (detalle.cantidad * detalle.precio_unitario) - detalle.descuento;
    
    let tarifaIva = 0;
    if (detalle.codigo_porcentaje_iva === "2") {
      tarifaIva = 0.12;
    } else if (detalle.codigo_porcentaje_iva === "3") {
      tarifaIva = 0.14;
    }
    
    const valorIva = precioTotalSinImpuesto * tarifaIva;
    const precioTotalConImpuesto = precioTotalSinImpuesto + valorIva;
    
    return {
      precioTotalSinImpuesto,
      tarifaIva,
      valorIva,
      precioTotalConImpuesto
    };
  };

  const agregarDetalle = () => {
    if (nuevoDetalle.descripcion && nuevoDetalle.cantidad > 0 && nuevoDetalle.precio_unitario > 0) {
      onDetallesChange([...detalles, nuevoDetalle]);
      setNuevoDetalle({
        codigo_principal: "",
        codigo_auxiliar: "",
        descripcion: "",
        cantidad: 1,
        precio_unitario: 0,
        descuento: 0,
        codigo_porcentaje_iva: "2",
      });
    }
  };

  const eliminarDetalle = (index: number) => {
    onDetallesChange(detalles.filter((_, i) => i !== index));
  };

  const handleDetalleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNuevoDetalle(prev => ({
      ...prev,
      [name]: name === 'cantidad' || name === 'precio_unitario' || name === 'descuento' 
        ? parseFloat(value) || 0 
        : value
    }));
  };

  const calcularSubtotal = () => {
    return detalles.reduce((total, detalle) => {
      const { precioTotalSinImpuesto } = calcularTotalesDetalle(detalle);
      return total + precioTotalSinImpuesto;
    }, 0);
  };

  const calcularTotalIva = () => {
    return detalles.reduce((total, detalle) => {
      const { valorIva } = calcularTotalesDetalle(detalle);
      return total + valorIva;
    }, 0);
  };

  const calcularTotalDescuentos = () => {
    return detalles.reduce((total, detalle) => total + detalle.descuento, 0);
  };

  const calcularTotal = () => {
    return calcularSubtotal() + calcularTotalIva() + (values.propina || 0);
  };

  return (
    <div className="factura-form">
      {/* Información Tributaria */}
      <div className="card mb-4">
        <div className="card-header bg-primary text-white">
          <h6 className="mb-0">Información Tributaria</h6>
        </div>
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-3">
              <label htmlFor="ambiente" className="form-label">Ambiente *</label>
              <select
                className="form-select"
                id="ambiente"
                name="ambiente"
                value={values.ambiente}
                onChange={onChange}
                required
              >
                {AMBIENTE_OPTIONS.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="col-md-6">
              <label htmlFor="razon_social" className="form-label">Razón Social *</label>
              <input
                type="text"
                className="form-control"
                id="razon_social"
                name="razon_social"
                value={values.razon_social}
                onChange={onChange}
                required
              />
            </div>
            
            <div className="col-md-3">
              <label htmlFor="ruc" className="form-label">RUC *</label>
              <input
                type="text"
                className="form-control"
                id="ruc"
                name="ruc"
                value={values.ruc}
                onChange={onChange}
                maxLength={13}
                pattern="[0-9]{13}"
                required
              />
            </div>
            
            <div className="col-md-6">
              <label htmlFor="nombre_comercial" className="form-label">Nombre Comercial</label>
              <input
                type="text"
                className="form-control"
                id="nombre_comercial"
                name="nombre_comercial"
                value={values.nombre_comercial}
                onChange={onChange}
              />
            </div>
            
            <div className="col-md-2">
              <label htmlFor="estab" className="form-label">Establecimiento *</label>
              <input
                type="text"
                className="form-control"
                id="estab"
                name="estab"
                value={values.estab}
                onChange={onChange}
                maxLength={3}
                pattern="[0-9]{3}"
                placeholder="001"
                required
              />
            </div>
            
            <div className="col-md-2">
              <label htmlFor="ptoEmi" className="form-label">Punto Emisión *</label>
              <input
                type="text"
                className="form-control"
                id="ptoEmi"
                name="ptoEmi"
                value={values.ptoEmi}
                onChange={onChange}
                maxLength={3}
                pattern="[0-9]{3}"
                placeholder="001"
                required
              />
            </div>
            
            <div className="col-md-2">
              <label htmlFor="secuencial" className="form-label">Secuencial *</label>
              <input
                type="text"
                className="form-control"
                id="secuencial"
                name="secuencial"
                value={values.secuencial}
                onChange={onChange}
                maxLength={9}
                pattern="[0-9]+"
                placeholder="000000001"
                required
              />
            </div>
            
            <div className="col-md-12">
              <label htmlFor="direccion_matriz" className="form-label">Dirección Matriz *</label>
              <textarea
                className="form-control"
                id="direccion_matriz"
                name="direccion_matriz"
                value={values.direccion_matriz}
                onChange={onChange}
                rows={2}
                required
              />
            </div>
          </div>
        </div>
      </div>

      {/* Información de la Factura */}
      <div className="card mb-4">
        <div className="card-header bg-info text-white">
          <h6 className="mb-0">Información de la Factura</h6>
        </div>
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-3">
              <label htmlFor="fecha_emision" className="form-label">Fecha Emisión *</label>
              <input
                type="date"
                className="form-control"
                id="fecha_emision"
                name="fecha_emision"
                value={values.fecha_emision}
                onChange={onChange}
                required
              />
            </div>
            
            <div className="col-md-3">
              <label htmlFor="obligado_contabilidad" className="form-label">Obligado Contabilidad *</label>
              <select
                className="form-select"
                id="obligado_contabilidad"
                name="obligado_contabilidad"
                value={values.obligado_contabilidad}
                onChange={onChange}
                required
              >
                <option value="">Seleccione...</option>
                <option value="SI">SI</option>
                <option value="NO">NO</option>
              </select>
            </div>
            
            <div className="col-md-3">
              <label htmlFor="contribuyente_especial" className="form-label">Contribuyente Especial</label>
              <input
                type="text"
                className="form-control"
                id="contribuyente_especial"
                name="contribuyente_especial"
                value={values.contribuyente_especial}
                onChange={onChange}
                placeholder="Ej: 5368"
              />
            </div>
            
            <div className="col-md-3">
              <label htmlFor="guia_remision" className="form-label">Guía de Remisión</label>
              <input
                type="text"
                className="form-control"
                id="guia_remision"
                name="guia_remision"
                value={values.guia_remision}
                onChange={onChange}
              />
            </div>
            
            <div className="col-md-12">
              <label htmlFor="direccion_establecimiento" className="form-label">Dirección Establecimiento *</label>
              <textarea
                className="form-control"
                id="direccion_establecimiento"
                name="direccion_establecimiento"
                value={values.direccion_establecimiento}
                onChange={onChange}
                rows={2}
                required
              />
            </div>
          </div>
        </div>
      </div>

      {/* Información del Comprador */}
      <div className="card mb-4">
        <div className="card-header bg-success text-white">
          <h6 className="mb-0">Información del Comprador</h6>
        </div>
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-3">
              <label htmlFor="tipo_identificacion_comprador" className="form-label">Tipo Identificación *</label>
              <select
                className="form-select"
                id="tipo_identificacion_comprador"
                name="tipo_identificacion_comprador"
                value={values.tipo_identificacion_comprador}
                onChange={onChange}
                required
              >
                <option value="">Seleccione...</option>
                {TIPO_IDENTIFICACION_OPTIONS.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="col-md-3">
              <label htmlFor="identificacion_comprador" className="form-label">Identificación *</label>
              <input
                type="text"
                className="form-control"
                id="identificacion_comprador"
                name="identificacion_comprador"
                value={values.identificacion_comprador}
                onChange={onChange}
                required
              />
            </div>
            
            <div className="col-md-6">
              <label htmlFor="razon_social_comprador" className="form-label">Razón Social / Nombres *</label>
              <input
                type="text"
                className="form-control"
                id="razon_social_comprador"
                name="razon_social_comprador"
                value={values.razon_social_comprador}
                onChange={onChange}
                required
              />
            </div>
            
            <div className="col-md-12">
              <label htmlFor="direccion_comprador" className="form-label">Dirección</label>
              <textarea
                className="form-control"
                id="direccion_comprador"
                name="direccion_comprador"
                value={values.direccion_comprador}
                onChange={onChange}
                rows={2}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Detalles de la Factura */}
      <div className="card mb-4">
        <div className="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
          <h6 className="mb-0">Detalles de la Factura</h6>
          <small className="text-muted">Total Items: {detalles.length}</small>
        </div>
        <div className="card-body">
          {/* Agregar nuevo detalle */}
          <div className="row g-2 mb-3 p-3 bg-light rounded">
            <div className="col-md-2">
              <input
                type="text"
                className="form-control form-control-sm"
                name="codigo_principal"
                value={nuevoDetalle.codigo_principal}
                onChange={handleDetalleChange}
                placeholder="Código"
              />
            </div>
            <div className="col-md-3">
              <input
                type="text"
                className="form-control form-control-sm"
                name="descripcion"
                value={nuevoDetalle.descripcion}
                onChange={handleDetalleChange}
                placeholder="Descripción *"
                required
              />
            </div>
            <div className="col-md-1">
              <input
                type="number"
                className="form-control form-control-sm"
                name="cantidad"
                value={nuevoDetalle.cantidad}
                onChange={handleDetalleChange}
                min="0.01"
                step="0.01"
                placeholder="Cant."
              />
            </div>
            <div className="col-md-2">
              <input
                type="number"
                className="form-control form-control-sm"
                name="precio_unitario"
                value={nuevoDetalle.precio_unitario}
                onChange={handleDetalleChange}
                min="0"
                step="0.01"
                placeholder="Precio Unit."
              />
            </div>
            <div className="col-md-1">
              <input
                type="number"
                className="form-control form-control-sm"
                name="descuento"
                value={nuevoDetalle.descuento}
                onChange={handleDetalleChange}
                min="0"
                step="0.01"
                placeholder="Desc."
              />
            </div>
            <div className="col-md-2">
              <select
                className="form-select form-select-sm"
                name="codigo_porcentaje_iva"
                value={nuevoDetalle.codigo_porcentaje_iva}
                onChange={handleDetalleChange}
              >
                {CODIGO_IVA_OPTIONS.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="col-md-1">
              <button
                type="button"
                className="btn btn-primary btn-sm w-100"
                onClick={agregarDetalle}
                disabled={!nuevoDetalle.descripcion || nuevoDetalle.cantidad <= 0}
              >
                <Plus size={16} />
              </button>
            </div>
          </div>

          {/* Lista de detalles */}
          {detalles.length > 0 && (
            <div className="table-responsive">
              <table className="table table-sm table-striped">
                <thead className="table-dark">
                  <tr>
                    <th>Código</th>
                    <th>Descripción</th>
                    <th>Cant.</th>
                    <th>P. Unit.</th>
                    <th>Desc.</th>
                    <th>Subtotal</th>
                    <th>IVA</th>
                    <th>Total</th>
                    <th>Acc.</th>
                  </tr>
                </thead>
                <tbody>
                  {detalles.map((detalle, index) => {
                    const totales = calcularTotalesDetalle(detalle);
                    return (
                      <tr key={`detalle-${detalle.codigo_principal}-${index}`}>
                        <td>{detalle.codigo_principal}</td>
                        <td>{detalle.descripcion}</td>
                        <td>{detalle.cantidad}</td>
                        <td>${detalle.precio_unitario.toFixed(2)}</td>
                        <td>${detalle.descuento.toFixed(2)}</td>
                        <td>${totales.precioTotalSinImpuesto.toFixed(2)}</td>
                        <td>${totales.valorIva.toFixed(2)}</td>
                        <td>${totales.precioTotalConImpuesto.toFixed(2)}</td>
                        <td>
                          <button
                            type="button"
                            className="btn btn-danger btn-sm"
                            onClick={() => eliminarDetalle(index)}
                          >
                            <Trash2 size={14} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Información de Pagos y Totales */}
      <div className="card mb-4">
        <div className="card-header bg-secondary text-white">
          <h6 className="mb-0">Totales y Forma de Pago</h6>
        </div>
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-4">
              <label htmlFor="forma_pago" className="form-label">Forma de Pago *</label>
              <select
                className="form-select"
                id="forma_pago"
                name="forma_pago"
                value={values.forma_pago}
                onChange={onChange}
                required
              >
                <option value="">Seleccione...</option>
                {FORMA_PAGO_OPTIONS.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="col-md-2">
              <label htmlFor="propina" className="form-label">Propina</label>
              <input
                type="number"
                className="form-control"
                id="propina"
                name="propina"
                value={values.propina}
                onChange={onChange}
                min="0"
                step="0.01"
              />
            </div>
            
            <div className="col-md-2">
              <label htmlFor="moneda" className="form-label">Moneda *</label>
              <select
                className="form-select"
                id="moneda"
                name="moneda"
                value={values.moneda}
                onChange={onChange}
                required
              >
                <option value="">Seleccione...</option>
                <option value="DOLAR">DÓLAR</option>
                <option value="PESO">PESO</option>
                <option value="EURO">EURO</option>
              </select>
            </div>
            
            <div className="col-md-4">
              <div className="card bg-light">
                <div className="card-body p-2">
                  <div className="row text-center">
                    <div className="col-6">
                      <small className="text-muted">Subtotal:</small><br/>
                      <strong>${calcularSubtotal().toFixed(2)}</strong>
                    </div>
                    <div className="col-6">
                      <small className="text-muted">IVA:</small><br/>
                      <strong>${calcularTotalIva().toFixed(2)}</strong>
                    </div>
                    <div className="col-6">
                      <small className="text-muted">Descuentos:</small><br/>
                      <strong>${calcularTotalDescuentos().toFixed(2)}</strong>
                    </div>
                    <div className="col-6">
                      <small className="text-muted">TOTAL:</small><br/>
                      <strong className="text-primary fs-5">${calcularTotal().toFixed(2)}</strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FacturaForm;
