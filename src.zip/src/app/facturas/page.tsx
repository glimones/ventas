import { AppShell } from "@/components/app-shell";
import FacturasPage from "./FacturasPage";

export default function Page() {
  return <AppShell><FacturasPage /></AppShell>;
}
