"use client";
import React, { useEffect } from "react";
import { FacturaFormValues, DetalleFormValues } from "./types";
import FacturaForm from "./FacturaForm";

interface Props {
  show: boolean;
  editando: boolean;
  values: FacturaFormValues;
  detalles: DetalleFormValues[];
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onDetallesChange: (detalles: DetalleFormValues[]) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  enviandoSRI?: boolean;
}

const FacturaModal: React.FC<Props> = ({
  show,
  editando,
  values,
  detalles,
  onChange,
  onDetallesChange,
  onClose,
  onSubmit,
  enviandoSRI = false,
}) => {
  // Bloquear el scroll del body cuando el modal está abierto
  useEffect(() => {
    if (show) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [show]);

  if (!show) return null;

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Solo cerrar si se hace clic directamente en el backdrop, no en el contenido
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="modal-overlay"
      onClick={handleBackdropClick}
      style={{ 
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1050,
        padding: '20px'
      }}
    >
      <div 
        className="modal-container"
        style={{
          background: 'white',
          borderRadius: '12px',
          width: '100%',
          maxWidth: '1200px',
          maxHeight: '90vh',
          overflow: 'hidden',
          boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)',
          display: 'flex',
          flexDirection: 'column'
        }}
      >
        <form onSubmit={onSubmit}>
          <div className="modal-header bg-primary text-white" style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <h5 className="modal-title d-flex align-items-center" style={{ margin: 0, fontSize: '1.25rem', fontWeight: 600 }}>
              <i className="fas fa-file-invoice me-2"></i>
              {editando ? "Editar Factura Electrónica" : "Nueva Factura Electrónica"}
              {editando && (
                <span className="badge bg-warning text-dark ms-2">
                  {values.secuencial.padStart(3, '0')}-{values.ptoEmi.padStart(3, '0')}-{values.secuencial.padStart(9, '0')}
                </span>
              )}
            </h5>
            <button
              type="button"
              className="btn-close"
              onClick={onClose}
              aria-label="Cerrar"
              disabled={enviandoSRI}
              style={{ 
                background: 'none',
                border: 'none',
                color: 'white',
                fontSize: '1.5rem',
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer'
              }}
            >
              ×
            </button>
          </div>
          
          <div className="modal-body" style={{ padding: '1.5rem', flex: 1, overflowY: 'auto', backgroundColor: '#fafbfc' }}>
            <div className="alert alert-info d-flex align-items-center mb-3">
              <i className="fas fa-info-circle me-2"></i>
              <div>
                <strong>Información importante:</strong> Los campos marcados con * son obligatorios para el SRI. 
                Asegúrese de completar toda la información antes de enviar la factura.
              </div>
            </div>
            
            <FacturaForm 
              values={values} 
              onChange={onChange}
              detalles={detalles}
              onDetallesChange={onDetallesChange}
            />
          </div>
          
          <div className="modal-footer" style={{ padding: '1rem 1.5rem', backgroundColor: 'white', borderTop: '1px solid #e9ecef', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem' }}>
            <button 
              type="button" 
              className="btn btn-secondary me-2"
              onClick={onClose}
              disabled={enviandoSRI}
            >
              Cancelar
            </button>
            
            <button 
              type="submit" 
              className="btn btn-success"
              disabled={enviandoSRI || detalles.length === 0}
            >
              {enviandoSRI ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                  Enviando al SRI...
                </>
              ) : (
                <>
                  <i className="fas fa-paper-plane me-1"></i>
                  {editando ? "Actualizar" : "Crear"} y Enviar al SRI
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FacturaModal;
