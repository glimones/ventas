export interface Empresa {
  id: number;
  nombre_comercial: string;
  nombre_legal: string;
  ruc: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  email: string;
  telefono?: string;
  logo_url?: string;
  moneda: string;
  estado: string;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface EmpresaFormValues {
  nombre_comercial: string;
  nombre_legal: string;
  ruc: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  email: string;
  telefono: string;
  logo_url?: string;
  moneda: string;
  estado: string;
}
  