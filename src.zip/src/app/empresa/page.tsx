import { AppShell } from '@/components/app-shell';
import EmpresaPage from './EmpresaPage';
// Removemos la importación del CSS aquí, ya que está importado en EmpresaPage 

export default function Page() {
  return (
    <AppShell>
        <EmpresaPage />
    </AppShell>
  );
}