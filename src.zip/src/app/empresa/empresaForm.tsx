import React from "react";
import { EmpresaFormValues } from "./types";

interface Props {
  values: EmpresaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const paisesOptions = [
  { value: "", label: "Seleccione un país" },
  { value: "es", label: "España" },
  { value: "mx", label: "México" },
  { value: "co", label: "Colombia" },
  { value: "ar", label: "Argentina" },
  { value: "cl", label: "Chile" },
  { value: "pe", label: "Perú" },
  { value: "ec", label: "Ecuador" },
  { value: "ve", label: "Venezuela" },
  { value: "us", label: "Estados Unidos" },
  { value: "ca", label: "Canadá" },
];

const monedasOptions = [
  { value: "", label: "Seleccione una moneda" },
  { value: "USD", label: "Dólar estadounidense (USD)" },
  { value: "EUR", label: "Euro (EUR)" },
  { value: "MXN", label: "Peso mexicano (MXN)" },
  { value: "COP", label: "Peso colombiano (COP)" },
  { value: "ARS", label: "Peso argentino (ARS)" },
  { value: "CLP", label: "Peso chileno (CLP)" },
  { value: "PEN", label: "Sol peruano (PEN)" },
  { value: "VES", label: "Bolívar venezolano (VES)" },
  { value: "GBP", label: "Libra esterlina (GBP)" },
];

const EmpresaForm: React.FC<Props> = ({ values, onChange }) => {
  return (
    <div className="row g-3">
      {/* Primera columna */}
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="nombre_comercial" className="form-label">
            Nombre comercial *
          </label>
          <input
            type="text"
            className="form-control"
            id="nombre_comercial"
            name="nombre_comercial"
            value={values.nombre_comercial}
            onChange={onChange}
            required
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="nombre_legal" className="form-label">
            Razón social *
          </label>
          <input
            type="text"
            className="form-control"
            id="nombre_legal"
            name="nombre_legal"
            value={values.nombre_legal}
            onChange={onChange}
            required
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="ruc" className="form-label">
            RUC/CIF/NIT *
          </label>
          <input
            type="text"
            className="form-control"
            id="ruc"
            name="ruc"
            value={values.ruc}
            onChange={onChange}
            required
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="direccion" className="form-label">
            Dirección *
          </label>
          <textarea
            className="form-control"
            id="direccion"
            name="direccion"
            value={values.direccion}
            onChange={onChange}
            rows={3}
            required
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="ciudad" className="form-label">
            Ciudad *
          </label>
          <input
            type="text"
            className="form-control"
            id="ciudad"
            name="ciudad"
            value={values.ciudad}
            onChange={onChange}
            required
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="provincia" className="form-label">
            Provincia/Estado
          </label>
          <input
            type="text"
            className="form-control"
            id="provincia"
            name="provincia"
            value={values.provincia}
            onChange={onChange}
          />
        </div>
      </div>
      
      {/* Segunda columna */}
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="pais" className="form-label">
            País *
          </label>
          <select
            className="form-select"
            id="pais"
            name="pais"
            value={values.pais}
            onChange={onChange}
            required
          >
            {paisesOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="email" className="form-label">
            Correo electrónico *
          </label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            value={values.email}
            onChange={onChange}
            required
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="telefono" className="form-label">
            Teléfono
          </label>
          <input
            type="tel"
            className="form-control"
            id="telefono"
            name="telefono"
            value={values.telefono}
            onChange={onChange}
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="logo_url" className="form-label">
            Logo
          </label>
          <input
            type="file"
            className="form-control"
            id="logo_url"
            name="logo_url"
            onChange={onChange}
            accept="image/*"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="moneda" className="form-label">
            Moneda principal *
          </label>
          <select
            className="form-select"
            id="moneda"
            name="moneda"
            value={values.moneda}
            onChange={onChange}
            required
          >
            {monedasOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="estado" className="form-label">
            Estado
          </label>
          <select
            className="form-select"
            id="estado"
            name="estado"
            value={values.estado}
            onChange={onChange}
          >
            <option value="Activa">Activa</option>
            <option value="Inactiva">Inactiva</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default EmpresaForm;