// Tipos para Liquidaciones de Compra SRI Ecuador

export interface InfoTributaria {
  ambiente: string;
  tipo_emision: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  clave_acceso: string;
  cod_doc: string; // "03" para liquidaciones de compra
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
}

export interface InfoLiquidacionCompra {
  fecha_emision: string;
  dir_establecimiento: string;
  contribuyente_especial?: string;
  obligado_contabilidad: string;
  tipo_identificacion_proveedor: string;
  razon_social_proveedor: string;
  identificacion_proveedor: string;
  direccion_proveedor: string;
  total_sin_impuestos: number;
  total_descuento: number;
  total_con_impuestos: number;
  import_total: number;
  moneda: string;
}

export interface DetalleLiquidacion {
  cod_principal: string;
  cod_auxiliar?: string;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  descuento: number;
  precio_total_sin_impuesto: number;
}

export interface ImpuestoDetalle {
  codigo: string;
  codigo_porcentaje: string;
  tarifa: number;
  base_imponible: number;
  valor: number;
}

export interface LiquidacionCompra {
  id: number;
  info_tributaria: InfoTributaria;
  info_liquidacion_compra: InfoLiquidacionCompra;
  detalles: DetalleLiquidacion[];
  estado_sri: 'PENDIENTE' | 'AUTORIZADA' | 'RECHAZADA' | 'DEVUELTA';
  numero_autorizacion?: string;
  fecha_autorizacion?: string;
  xml_generado?: string;
  observaciones_sri?: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
}

export interface LiquidacionCompraFormValues {
  // Info tributaria básica
  ambiente: string;
  razon_social: string;
  nombre_comercial: string;
  ruc: string;
  estab: string;
  ptoEmi: string;
  secuencial: string;
  direccion_matriz: string;
  
  // Info de la liquidación
  fecha_emision: string;
  dir_establecimiento: string;
  contribuyente_especial: string;
  obligado_contabilidad: string;
  tipo_identificacion_proveedor: string;
  razon_social_proveedor: string;
  identificacion_proveedor: string;
  direccion_proveedor: string;
  moneda: string;
  
  // Detalle
  cod_principal: string;
  descripcion: string;
  cantidad: number;
  precio_unitario: number;
  descuento: number;
  
  // Impuestos
  iva_aplica: boolean;
  tarifa_iva: number;
}

// Tipos de identificación del proveedor
export const tiposIdentificacion = [
  { codigo: "04", descripcion: "RUC" },
  { codigo: "05", descripcion: "Cédula" },
  { codigo: "06", descripcion: "Pasaporte" },
  { codigo: "07", descripcion: "Venta a consumidor final" },
  { codigo: "08", descripcion: "Identificación del exterior" }
];

// Tipos de IVA
export const tiposIVA = [
  { codigo: "0", descripcion: "0% IVA", tarifa: 0 },
  { codigo: "2", descripcion: "12% IVA", tarifa: 12 },
  { codigo: "3", descripcion: "14% IVA", tarifa: 14 },
  { codigo: "6", descripcion: "No objeto de impuesto", tarifa: 0 },
  { codigo: "7", descripcion: "Exento de IVA", tarifa: 0 }
];

// Monedas
export const monedas = [
  { codigo: "DOLAR", descripcion: "Dólar Estadounidense" },
  { codigo: "EURO", descripcion: "Euro" },
  { codigo: "PESO", descripcion: "Peso Colombiano" },
  { codigo: "SOL", descripcion: "Sol Peruano" }
];

// Ambientes
export const ambientes = [
  { codigo: "1", descripcion: "Pruebas" },
  { codigo: "2", descripcion: "Producción" }
];

// Obligado a llevar contabilidad
export const obligadoContabilidad = [
  { codigo: "SI", descripcion: "Sí" },
  { codigo: "NO", descripcion: "No" }
];
