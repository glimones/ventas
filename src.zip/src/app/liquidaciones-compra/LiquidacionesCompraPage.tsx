"use client";

import React, { useState } from "react";
import { LiquidacionCompra, LiquidacionCompraFormValues, InfoLiquidacionCompra, DetalleLiquidacion } from "./types";
import { SRIUniversalService } from "../../services/sri-universal.service";
import "./liquidaciones-compra.css";
import { CirclePlus, SquarePen, Trash2, Eye, Download } from 'lucide-react';

const initialForm: LiquidacionCompraFormValues = {
  ambiente: "1",
  razon_social: "EMPRESA DEMO S.A.",
  nombre_comercial: "Demo",
  ruc: "1234567890001",
  estab: "001",
  ptoEmi: "001",
  secuencial: "1",
  direccion_matriz: "Av. Principal 123, Ciudad Demo",
  fecha_emision: new Date().toISOString().split('T')[0],
  dir_establecimiento: "Av. Principal 123, Ciudad Demo",
  contribuyente_especial: "",
  obligado_contabilidad: "SI",
  tipo_identificacion_proveedor: "",
  razon_social_proveedor: "",
  identificacion_proveedor: "",
  direccion_proveedor: "",
  moneda: "DOLAR",
  cod_principal: "",
  descripcion: "",
  cantidad: 0,
  precio_unitario: 0,
  descuento: 0,
  iva_aplica: true,
  tarifa_iva: 12,
};

const initialLiquidaciones: LiquidacionCompra[] = [
  {
    id: 1,
    info_tributaria: {
      ambiente: "1",
      tipo_emision: "1",
      razon_social: "EMPRESA DEMO S.A.",
      nombre_comercial: "Demo",
      ruc: "1234567890001",
      clave_acceso: "2309202403123456789000110010010000000011234567892",
      cod_doc: "03",
      estab: "001",
      ptoEmi: "001",
      secuencial: "000000001",
      direccion_matriz: "Av. Principal 123, Ciudad Demo"
    },
    info_liquidacion_compra: {
      fecha_emision: "23/09/2024",
      dir_establecimiento: "Av. Principal 123, Ciudad Demo",
      contribuyente_especial: "",
      obligado_contabilidad: "SI",
      tipo_identificacion_proveedor: "05",
      razon_social_proveedor: "PERSONA NATURAL DEMO",
      identificacion_proveedor: "1234567890",
      direccion_proveedor: "Av. Proveedor 789, Ciudad Demo",
      total_sin_impuestos: 100.00,
      total_descuento: 0.00,
      total_con_impuestos: 112.00,
      import_total: 112.00,
      moneda: "DOLAR"
    },
    detalles: [
      {
        cod_principal: "SERV001",
        descripcion: "Servicios profesionales",
        cantidad: 1,
        precio_unitario: 100.00,
        descuento: 0.00,
        precio_total_sin_impuesto: 100.00
      }
    ],
    estado_sri: 'AUTORIZADA',
    numero_autorizacion: "2309202412345678901234567890123456",
    fecha_autorizacion: "2024-09-23T10:30:00.000Z",
    fecha_creacion: "2024-09-23T10:00:00.000Z",
    fecha_actualizacion: "2024-09-23T10:30:00.000Z"
  }
];

export default function LiquidacionesCompraPage() {
  const [liquidaciones, setLiquidaciones] = useState<LiquidacionCompra[]>(initialLiquidaciones);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<LiquidacionCompraFormValues>(initialForm);
  const [enviandoSRI, setEnviandoSRI] = useState<boolean>(false);

  const sriService = SRIUniversalService.getInstance();

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    const ultimoSecuencial = Math.max(...liquidaciones.map(l => parseInt(l.info_tributaria.secuencial) || 0), 0);
    setForm(prev => ({
      ...prev,
      secuencial: (ultimoSecuencial + 1).toString()
    }));
    setShowModal(true);
  };

  const abrirModalEditar = (liquidacion: LiquidacionCompra) => {
    const primerDetalle = liquidacion.detalles[0] || {};
    
    setForm({
      ambiente: liquidacion.info_tributaria.ambiente,
      razon_social: liquidacion.info_tributaria.razon_social,
      nombre_comercial: liquidacion.info_tributaria.nombre_comercial,
      ruc: liquidacion.info_tributaria.ruc,
      estab: liquidacion.info_tributaria.estab,
      ptoEmi: liquidacion.info_tributaria.ptoEmi,
      secuencial: liquidacion.info_tributaria.secuencial,
      direccion_matriz: liquidacion.info_tributaria.direccion_matriz,
      fecha_emision: liquidacion.info_liquidacion_compra.fecha_emision.split('/').reverse().join('-'),
      dir_establecimiento: liquidacion.info_liquidacion_compra.dir_establecimiento,
      contribuyente_especial: liquidacion.info_liquidacion_compra.contribuyente_especial || "",
      obligado_contabilidad: liquidacion.info_liquidacion_compra.obligado_contabilidad,
      tipo_identificacion_proveedor: liquidacion.info_liquidacion_compra.tipo_identificacion_proveedor,
      razon_social_proveedor: liquidacion.info_liquidacion_compra.razon_social_proveedor,
      identificacion_proveedor: liquidacion.info_liquidacion_compra.identificacion_proveedor,
      direccion_proveedor: liquidacion.info_liquidacion_compra.direccion_proveedor,
      moneda: liquidacion.info_liquidacion_compra.moneda,
      cod_principal: primerDetalle.cod_principal || "",
      descripcion: primerDetalle.descripcion || "",
      cantidad: primerDetalle.cantidad || 0,
      precio_unitario: primerDetalle.precio_unitario || 0,
      descuento: primerDetalle.descuento || 0,
      iva_aplica: true,
      tarifa_iva: 12,
    });
    
    setEditandoId(liquidacion.id);
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const calcularTotales = () => {
    const subtotal = form.cantidad * form.precio_unitario - form.descuento;
    const iva = form.iva_aplica ? (subtotal * form.tarifa_iva) / 100 : 0;
    const total = subtotal + iva;
    
    return {
      subtotal,
      iva,
      total
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setEnviandoSRI(true);
    
    try {
      const totales = calcularTotales();
      
      const infoLiquidacion: InfoLiquidacionCompra = {
        fecha_emision: form.fecha_emision.split('-').reverse().join('/'),
        dir_establecimiento: form.dir_establecimiento,
        contribuyente_especial: form.contribuyente_especial,
        obligado_contabilidad: form.obligado_contabilidad,
        tipo_identificacion_proveedor: form.tipo_identificacion_proveedor,
        razon_social_proveedor: form.razon_social_proveedor,
        identificacion_proveedor: form.identificacion_proveedor,
        direccion_proveedor: form.direccion_proveedor,
        total_sin_impuestos: totales.subtotal,
        total_descuento: form.descuento,
        total_con_impuestos: totales.total,
        import_total: totales.total,
        moneda: form.moneda,
      };

      const detalle: DetalleLiquidacion = {
        cod_principal: form.cod_principal,
        descripcion: form.descripcion,
        cantidad: form.cantidad,
        precio_unitario: form.precio_unitario,
        descuento: form.descuento,
        precio_total_sin_impuesto: totales.subtotal,
      };

      const nuevaLiquidacion: LiquidacionCompra = {
        id: editandoId || Date.now(),
        info_tributaria: {
          ambiente: form.ambiente,
          tipo_emision: "1",
          razon_social: form.razon_social,
          nombre_comercial: form.nombre_comercial,
          ruc: form.ruc,
          clave_acceso: "",
          cod_doc: "03",
          estab: form.estab,
          ptoEmi: form.ptoEmi,
          secuencial: form.secuencial,
          direccion_matriz: form.direccion_matriz,
        },
        info_liquidacion_compra: infoLiquidacion,
        detalles: [detalle],
        estado_sri: 'PENDIENTE',
        fecha_creacion: new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString()
      };

      const comprobanteParaSRI = {
        id: nuevaLiquidacion.id,
        tipo_comprobante: '03' as const,
        info_tributaria: nuevaLiquidacion.info_tributaria,
        estado_sri: nuevaLiquidacion.estado_sri,
        fecha_creacion: nuevaLiquidacion.fecha_creacion,
        fecha_actualizacion: nuevaLiquidacion.fecha_actualizacion
      };

      const datosEspecificos = `
  <infoLiquidacionCompra>
    <fechaEmision>${infoLiquidacion.fecha_emision}</fechaEmision>
    <dirEstablecimiento><![CDATA[${infoLiquidacion.dir_establecimiento}]]></dirEstablecimiento>
    <obligadoContabilidad>${infoLiquidacion.obligado_contabilidad}</obligadoContabilidad>
    <tipoIdentificacionProveedor>${infoLiquidacion.tipo_identificacion_proveedor}</tipoIdentificacionProveedor>
    <razonSocialProveedor><![CDATA[${infoLiquidacion.razon_social_proveedor}]]></razonSocialProveedor>
    <identificacionProveedor>${infoLiquidacion.identificacion_proveedor}</identificacionProveedor>
    <direccionProveedor><![CDATA[${infoLiquidacion.direccion_proveedor}]]></direccionProveedor>
    <totalSinImpuestos>${infoLiquidacion.total_sin_impuestos.toFixed(2)}</totalSinImpuestos>
    <totalDescuento>${infoLiquidacion.total_descuento.toFixed(2)}</totalDescuento>
    <importeTotal>${infoLiquidacion.import_total.toFixed(2)}</importeTotal>
    <moneda>${infoLiquidacion.moneda}</moneda>
  </infoLiquidacionCompra>
  <detalles>
    <detalle>
      <codigoPrincipal>${detalle.cod_principal}</codigoPrincipal>
      <descripcion><![CDATA[${detalle.descripcion}]]></descripcion>
      <cantidad>${detalle.cantidad}</cantidad>
      <precioUnitario>${detalle.precio_unitario.toFixed(2)}</precioUnitario>
      <descuento>${detalle.descuento.toFixed(2)}</descuento>
      <precioTotalSinImpuesto>${detalle.precio_total_sin_impuesto.toFixed(2)}</precioTotalSinImpuesto>
    </detalle>
  </detalles>`;

      console.log('🚀 Enviando liquidación de compra al SRI...', nuevaLiquidacion);
      const respuestaSRI = await sriService.enviarComprobanteSRI(comprobanteParaSRI, datosEspecificos, infoLiquidacion.fecha_emision);

      nuevaLiquidacion.estado_sri = respuestaSRI.estado;
      if (respuestaSRI.success) {
        nuevaLiquidacion.numero_autorizacion = respuestaSRI.numero_autorizacion;
        nuevaLiquidacion.fecha_autorizacion = respuestaSRI.fecha_autorizacion;
        nuevaLiquidacion.xml_generado = respuestaSRI.xml_autorizado;
      }
      nuevaLiquidacion.observaciones_sri = respuestaSRI.observaciones;

      if (editandoId) {
        setLiquidaciones((prev) =>
          prev.map((liq) =>
            liq.id === editandoId ? nuevaLiquidacion : liq
          )
        );
      } else {
        setLiquidaciones((prev) => [...prev, nuevaLiquidacion]);
      }

      if (respuestaSRI.success) {
        alert(`✅ Liquidación de Compra ${respuestaSRI.estado.toLowerCase()} exitosamente.\nNúmero de autorización: ${respuestaSRI.numero_autorizacion}`);
        cerrarModal();
      } else {
        alert(`❌ Error del SRI: ${respuestaSRI.mensaje_error}\n\nObservaciones: ${respuestaSRI.observaciones}`);
      }

    } catch (error) {
      console.error('Error procesando liquidación de compra:', error);
      alert('Error inesperado al procesar la liquidación de compra');
    } finally {
      setEnviandoSRI(false);
    }
  };

  const eliminarLiquidacion = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta liquidación de compra?")) {
      setLiquidaciones((prev) => prev.filter((liq) => liq.id !== id));
    }
  };

  const liquidacionesFiltradas = liquidaciones.filter((liq) =>
    Object.values(liq.info_liquidacion_compra)
      .concat(Object.values(liq.info_tributaria))
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'AUTORIZADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'DEVUELTA': return 'bg-warning text-dark';
      case 'PENDIENTE': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  const totalesFormulario = calcularTotales();

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Liquidaciones de Compra Electrónicas</h1>
            <p className="text-muted mb-0">Gestión de liquidaciones SRI Ecuador</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-info">Ambiente: Pruebas</span>
            <span className="badge bg-dark text-white">{liquidaciones.length} liquidaciones</span>
          </div>
        </div>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar por proveedor, RUC, secuencial..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-dark d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Liquidación de Compra</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Secuencial</th>
                <th>Fecha</th>
                <th>Proveedor</th>
                <th>Servicio</th>
                <th>Subtotal</th>
                <th>Total</th>
                <th>Estado SRI</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {liquidacionesFiltradas.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-4">
                    <div className="text-muted">
                      No se encontraron liquidaciones de compra
                    </div>
                  </td>
                </tr>
              )}
              {liquidacionesFiltradas.map((liq) => (
                <tr key={liq.id}>
                  <td>
                    <strong>{liq.info_tributaria.estab}-{liq.info_tributaria.ptoEmi}-{liq.info_tributaria.secuencial.padStart(9, '0')}</strong>
                  </td>
                  <td>{liq.info_liquidacion_compra.fecha_emision}</td>
                  <td>{liq.info_liquidacion_compra.razon_social_proveedor}</td>
                  <td>
                    <small className="text-muted">
                      {liq.detalles[0]?.descripcion || 'N/A'}
                    </small>
                  </td>
                  <td className="text-end">
                    ${liq.info_liquidacion_compra.total_sin_impuestos.toFixed(2)}
                  </td>
                  <td className="text-end">
                    <strong>${liq.info_liquidacion_compra.import_total.toFixed(2)}</strong>
                  </td>
                  <td>
                    <span className={`badge ${getEstadoBadgeClass(liq.estado_sri)}`}>
                      {liq.estado_sri}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => abrirModalEditar(liq)}
                        title="Ver detalles"
                      >
                        <Eye size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(liq)}
                        title="Editar"
                        disabled={liq.estado_sri === 'AUTORIZADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      {liq.xml_generado && (
                        <button
                          className="btn btn-outline-success btn-sm"
                          title="Descargar XML"
                          onClick={() => {
                            const blob = new Blob([liq.xml_generado!], { type: 'application/xml' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `liquidacion_compra_${liq.info_tributaria.secuencial}.xml`;
                            a.click();
                          }}
                        >
                          <Download size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarLiquidacion(liq.id)}
                        title="Eliminar"
                        disabled={liq.estado_sri === 'AUTORIZADA'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Modal para liquidaciones de compra */}
        {showModal && (
          <div className="modal fade show d-block" style={{ zIndex: 1050 }}>
            <div className="modal-dialog modal-lg">
              <div className="modal-content">
                <form onSubmit={handleSubmit}>
                  <div className="modal-header bg-dark text-white">
                    <h5 className="modal-title">
                      {editandoId ? "Editar Liquidación de Compra" : "Nueva Liquidación de Compra"}
                    </h5>
                    <button
                      type="button"
                      className="btn-close btn-close-white"
                      onClick={cerrarModal}
                      disabled={enviandoSRI}
                    />
                  </div>
                  
                  <div className="modal-body" style={{ maxHeight: '70vh', overflowY: 'auto' }}>
                    <div className="row g-3">
                      {/* Datos del proveedor */}
                      <div className="col-12">
                        <h6 className="text-dark border-bottom pb-2">Datos del Proveedor</h6>
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="razon_social_proveedor" className="form-label">Proveedor *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="razon_social_proveedor"
                          name="razon_social_proveedor"
                          value={form.razon_social_proveedor}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-6">
                        <label htmlFor="identificacion_proveedor" className="form-label">Cédula/Pasaporte *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="identificacion_proveedor"
                          name="identificacion_proveedor"
                          value={form.identificacion_proveedor}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-12">
                        <label htmlFor="direccion_proveedor" className="form-label">Dirección Proveedor *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="direccion_proveedor"
                          name="direccion_proveedor"
                          value={form.direccion_proveedor}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      
                      {/* Detalle del servicio */}
                      <div className="col-12">
                        <h6 className="text-dark border-bottom pb-2 mt-3">Detalle del Servicio/Bien</h6>
                      </div>
                      <div className="col-md-4">
                        <label htmlFor="cod_principal" className="form-label">Código *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="cod_principal"
                          name="cod_principal"
                          value={form.cod_principal}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-8">
                        <label htmlFor="descripcion" className="form-label">Descripción *</label>
                        <input
                          type="text"
                          className="form-control"
                          id="descripcion"
                          name="descripcion"
                          value={form.descripcion}
                          onChange={handleChange}
                          required
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="cantidad" className="form-label">Cantidad *</label>
                        <input
                          type="number"
                          className="form-control"
                          id="cantidad"
                          name="cantidad"
                          value={form.cantidad}
                          onChange={handleChange}
                          min="1"
                          step="0.01"
                          required
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="precio_unitario" className="form-label">Precio Unit. *</label>
                        <input
                          type="number"
                          className="form-control"
                          id="precio_unitario"
                          name="precio_unitario"
                          value={form.precio_unitario}
                          onChange={handleChange}
                          min="0"
                          step="0.01"
                          required
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="descuento" className="form-label">Descuento</label>
                        <input
                          type="number"
                          className="form-control"
                          id="descuento"
                          name="descuento"
                          value={form.descuento}
                          onChange={handleChange}
                          min="0"
                          step="0.01"
                        />
                      </div>
                      <div className="col-md-3">
                        <label htmlFor="subtotal_display" className="form-label">Subtotal</label>
                        <input
                          type="text"
                          className="form-control"
                          id="subtotal_display"
                          value={`$${totalesFormulario.subtotal.toFixed(2)}`}
                          readOnly
                        />
                      </div>
                      
                      {/* Impuestos */}
                      <div className="col-12">
                        <h6 className="text-dark border-bottom pb-2 mt-3">Impuestos</h6>
                      </div>
                      <div className="col-md-4">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="iva_aplica"
                            name="iva_aplica"
                            checked={form.iva_aplica}
                            onChange={handleChange}
                          />
                          <label className="form-check-label" htmlFor="iva_aplica">
                            Aplicar IVA
                          </label>
                        </div>
                      </div>
                      {form.iva_aplica && (
                        <div className="col-md-4">
                          <label htmlFor="tarifa_iva" className="form-label">Tarifa IVA (%)</label>
                          <select
                            className="form-select"
                            id="tarifa_iva"
                            name="tarifa_iva"
                            value={form.tarifa_iva}
                            onChange={handleChange}
                          >
                            <option value={0}>0% IVA</option>
                            <option value={12}>12% IVA</option>
                            <option value={14}>14% IVA</option>
                          </select>
                        </div>
                      )}
                      <div className="col-md-4">
                        <label htmlFor="total_display" className="form-label">Total</label>
                        <input
                          type="text"
                          className="form-control fw-bold"
                          id="total_display"
                          value={`$${totalesFormulario.total.toFixed(2)}`}
                          readOnly
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={cerrarModal}
                      disabled={enviandoSRI}
                    >
                      Cancelar
                    </button>
                    <button 
                      type="submit" 
                      className="btn btn-dark"
                      disabled={enviandoSRI}
                    >
                      {enviandoSRI ? 'Enviando...' : 'Crear y Enviar al SRI'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
            <div className="modal-backdrop fade show"></div>
          </div>
        )}
      </div>
    </div>
  );
}
