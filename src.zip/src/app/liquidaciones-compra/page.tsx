import { AppShell } from "@/components/app-shell";
import LiquidacionesCompraPage from "./LiquidacionesCompraPage";

export default function Page() {
  return <AppShell><LiquidacionesCompraPage /></AppShell>;
}
