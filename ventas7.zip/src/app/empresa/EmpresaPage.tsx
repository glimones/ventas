"use client";

import React, { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Empresa, EmpresaFormValues } from "./types";
import EmpresaModal from "./EmpresaModal";
import "./empresa.css";
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: EmpresaFormValues = {
  nombre_comercial: "",
  nombre_legal: "",
  ruc: "",
  direccion: "", 
  ciudad: "",
  provincia: "",
  pais: "",
  email: "",
  telefono: "",
  logo_url: "",
  moneda: "",
  estado: "Activa",
  slug: "",
  giro_negocio: "alimentos",
  descripcion_web: "",
  color_primario: "#212529",
  color_secundario: "#fd7e14",
  tienda_online: false,
  cuenta_clientes_habilitada: true,
};

export default function EmpresasPage() {
  const [empresas, setEmpresas] = useState<Empresa[]>([]);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<EmpresaFormValues>(initialForm);
  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState("");

  const cargarEmpresas = useCallback(async () => {
    setCargando(true);
    try {
      const response = await fetch("/api/empresas", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudieron cargar las empresas.");
      const records = Array.isArray(result.data) ? result.data as Record<string, unknown>[] : [];
      setEmpresas(records.map((record) => ({
        ...initialForm,
        ...record,
        id: Number(record.id),
        estado: record.estado === "Inactivo" || record.estado === "Inactiva" ? "Inactiva" : "Activa",
        giro_negocio: (record.giro_negocio as Empresa["giro_negocio"]) || "comercio",
        color_primario: typeof record.color_primario === "string" ? record.color_primario : "#212529",
        color_secundario: typeof record.color_secundario === "string" ? record.color_secundario : "#fd7e14",
        tienda_online: Boolean(record.tienda_online),
        cuenta_clientes_habilitada: record.cuenta_clientes_habilitada !== false,
      })));
      setError("");
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Error al cargar empresas.");
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => { void cargarEmpresas(); }, [cargarEmpresas]);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setError("");
    setShowModal(true);
  };
  
  const abrirModalEditar = (empresa: Empresa) => {
    setForm({
      nombre_legal: empresa.nombre_legal ?? "",
      nombre_comercial: empresa.nombre_comercial ?? "",
      ruc: empresa.ruc ?? "",
      direccion: empresa.direccion ?? "",
      ciudad: empresa.ciudad ?? "",
      provincia: empresa.provincia ?? "",
      pais: empresa.pais ?? "",
      email: empresa.email ?? "",
      telefono: empresa.telefono ?? "",
      logo_url: empresa.logo_url ?? "",
      moneda: empresa.moneda ?? "",
      estado: empresa.estado ?? "Activa",
      slug: empresa.slug ?? "",
      giro_negocio: empresa.giro_negocio ?? "alimentos",
      descripcion_web: empresa.descripcion_web ?? "",
      color_primario: empresa.color_primario ?? "#212529",
      color_secundario: empresa.color_secundario ?? "#fd7e14",
      tienda_online: empresa.tienda_online ?? false,
      cuenta_clientes_habilitada: empresa.cuenta_clientes_habilitada ?? true,
    });
    setEditandoId(empresa.id);
    setShowModal(true);
    setError("");
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type, checked } = e.target as HTMLInputElement;
    
    if (type === 'file') {
      const fileInput = e.target as HTMLInputElement;
      const file = fileInput.files?.[0];
      if (file) {
        // En una aplicación real, aquí subirías el archivo y obtendrías una URL
        // Para este ejemplo, simplemente creamos una URL local temporal
        const url = URL.createObjectURL(file);
        setForm((prev) => ({
          ...prev,
          [name]: url,
        }));
      }
    } else {
      setForm((prev) => ({
        ...prev,
        [name]: type === "checkbox" ? checked : value,
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setError("");
    try {
      const response = await fetch(editandoId ? `/api/empresas/${editandoId}` : "/api/empresas", {
        method: editandoId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nombre_comercial: form.nombre_comercial,
          nombre_legal: form.nombre_legal,
          ruc: form.ruc,
          direccion: form.direccion,
          ciudad: form.ciudad,
          provincia: form.provincia,
          pais: form.pais,
          email: form.email,
          telefono: form.telefono,
          logo_url: form.logo_url,
          moneda: form.moneda,
          estado: form.estado,
          slug: form.slug,
          giro_negocio: form.giro_negocio,
          descripcion_web: form.descripcion_web,
          color_primario: form.color_primario,
          color_secundario: form.color_secundario,
          tienda_online: form.tienda_online,
          cuenta_clientes_habilitada: form.cuenta_clientes_habilitada,
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo guardar la empresa.");
      await cargarEmpresas();
      cerrarModal();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Error al guardar la empresa.");
    } finally {
      setGuardando(false);
    }
  };

  const eliminarEmpresa = async (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta empresa?")) {
      try {
        const response = await fetch(`/api/empresas/${id}`, { method: "DELETE" });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "No se pudo desactivar la empresa.");
        await cargarEmpresas();
      } catch (deleteError) {
        setError(deleteError instanceof Error ? deleteError.message : "Error al desactivar la empresa.");
      }
    }
  };

  const empresasFiltradas = empresas.filter((emp) =>
    Object.values(emp)
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
            <h1 className="mb-4">Empresas</h1>
            <p className="text-muted mb-0">Creación de nuevas empresas</p>
        <br></br>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar empresa..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-primary d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Añadir Empresa</span>
          </button>
        </div>
        {error && !showModal && <div className="alert alert-danger" role="alert">{error}</div>}
         <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Nombre Legal</th>
                <th>Nombre Comercial</th>
                <th>Giro</th>
                <th>RUC/NIT</th>
                <th>Teléfono</th>
                <th>Email</th>
                <th>Estado</th>
                <th>Sitio</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && <tr><td colSpan={9} className="text-center">Cargando empresas...</td></tr>}
              {!cargando && empresasFiltradas.length === 0 && (
                <tr>
                  <td colSpan={9} className="text-center">
                    {error ? "No se pudieron cargar las empresas" : "No se encontraron empresas"}
                  </td>
                </tr>
              )}
              {empresasFiltradas.map((empresa) => (
                <tr key={empresa.id}>
                  <td>{empresa.nombre_legal}</td>
                  <td>{empresa.nombre_comercial}</td>
                  <td className="text-capitalize">{empresa.giro_negocio}</td>
                  <td>{empresa.ruc}</td>
                  <td>{empresa.telefono}</td>
                  <td>{empresa.email}</td>
                  <td>
                    <span
                      className={`badge bg-${
                        empresa.estado === "Activa"
                          ? "success"
                          : empresa.estado === "Inactiva"
                          ? "secondary"
                          : "warning"
                      }`}
                    >
                      {empresa.estado}
                    </span>
                  </td>
                  <td>{empresa.slug ? <Link href={`/sitio/${empresa.slug}`} target="_blank">Ver sitio</Link> : "Sin sitio"}</td>
                  <td>
                    <div className="d-flex align-items-center">
                    <button
                      className="btn btn-warning d-flex align-items-center me-1"
                      onClick={() => abrirModalEditar(empresa)}>
                       <SquarePen  className="me-2" size={16}/>
                       <span>Editar</span>
                    </button>
                   
                    <button className="btn btn-danger d-flex align-items-center me-2" onClick={() => eliminarEmpresa(empresa.id)}>
                      <Trash2 className="me-2" size={16} />
                      <span>Eliminar</span>
                    </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <EmpresaModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          saving={guardando}
          submitError={error}
        />
      </div>
    </div>
  );
}