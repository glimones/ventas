'use client';
import React, { useState, useCallback, useEffect } from 'react';
import { Proveedores, ProveedoresFormValues } from './types';
import ProveedoresModal from './ProveedoresModal';
import './bootstrap-proveedores.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: ProveedoresFormValues = {
  codigo: '',
  razon_social: '',
  nombre_comercial: '',
  tipo_identificacion: '',
  identificacion: '',
  categoria: '',
  email: '',
  telefono: '',
  ciudad: '',
  dias_credito: 0,
  estado: 'Activo',
};

export default function ProveedoresPage() {
  const [data, setData] = useState<Proveedores[]>([]);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ProveedoresFormValues>(initialForm);
  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState('');

  const cargarProveedores = useCallback(async () => {
    setCargando(true);
    try {
      const response = await fetch('/api/proveedores', { cache: 'no-store' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudieron cargar los proveedores.');
      setData(result.data as Proveedores[]);
      setError('');
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Error al cargar proveedores.');
    } finally { setCargando(false); }
  }, []);

  useEffect(() => { void cargarProveedores(); }, [cargarProveedores]);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setError('');
    setShowModal(true);
  };

  const abrirModalEditar = (item: Proveedores) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      razon_social: item.razon_social || '',
      nombre_comercial: item.nombre_comercial || '',
      tipo_identificacion: item.tipo_identificacion || '',
      identificacion: item.identificacion || '',
      categoria: item.categoria || '',
      email: item.email || '',
      telefono: item.telefono || '',
      ciudad: item.ciudad || '',
      dias_credito: item.dias_credito || 0,
      estado: item.estado || '',
    });
    setError('');
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.name === 'dias_credito' ? Number(e.target.value) : e.target.value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setError('');
    try {
      const response = await fetch('/api/proveedores', {
        method: editandoId !== null ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editandoId !== null ? { ...form, id: editandoId } : form),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo guardar el proveedor.');
      await cargarProveedores();
      cerrarModal();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Error al guardar el proveedor.');
    } finally {
      setGuardando(false);
    }
  };

  const eliminar = async (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      try {
        const response = await fetch('/api/proveedores', {
          method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }),
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'No se pudo desactivar el proveedor.');
        await cargarProveedores();
      } catch (deleteError) {
        setError(deleteError instanceof Error ? deleteError.message : 'Error al desactivar proveedor.');
      }
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.razon_social.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre_comercial.toLowerCase().includes(filtro.toLowerCase()) ||
    item.identificacion.toLowerCase().includes(filtro.toLowerCase()) ||
            item.categoria.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Proveedores</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        {error && <div className='alert alert-danger' role='alert'>{error}</div>}
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Razón social</th>
                <th>Identificación</th>
                <th>Categoría</th>
                <th>Correo / teléfono</th>
                <th>Condiciones</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && <tr><td colSpan={9} className='text-center'>Cargando proveedores...</td></tr>}
              {!cargando && filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className='text-center text-muted py-4'>
                    {error ? 'No se pudieron cargar los proveedores' : 'No se encontraron registros'}
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td><strong>{item.razon_social}</strong><br /><small className='text-muted'>{item.nombre_comercial}</small></td>
                  <td>{item.tipo_identificacion}: {item.identificacion}</td>
                  <td>{item.categoria}</td>
                  <td>{item.email}<br /><small className='text-muted'>{item.telefono}</small></td>
                  <td>{item.dias_credito > 0 ? `${item.dias_credito} días` : 'Contado'}</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <ProveedoresModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          saving={guardando}
          submitError={error}
        />
      </div>
    </div>
  );
}
