import { NextRequest, NextResponse } from "next/server";
import {
  actualizarRegistro,
  buscarRegistro,
  crearRegistro,
  eliminarRegistro,
  listarRegistros,
  UnsupportedFieldError,
  UnsupportedModuleError,
} from "@/services/module-records.service";
import { DatabaseConfigurationError } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteContext = {
  params: Promise<{ module: string[] }>;
};

type ApiTarget = {
  moduleKey: string;
  id?: number;
};

async function getTarget(context: RouteContext): Promise<ApiTarget | null> {
  const { module: segments } = await context.params;

  if (!segments?.length || segments.some((segment) => !/^[a-z0-9-]+$/i.test(segment))) {
    return null;
  }

  const lastSegment = segments.at(-1);
  const id = lastSegment && /^\d+$/.test(lastSegment) ? Number(lastSegment) : undefined;
  const moduleSegments = id === undefined ? segments : segments.slice(0, -1);

  if (!moduleSegments.length || (id !== undefined && !Number.isSafeInteger(id))) {
    return null;
  }

  return { moduleKey: moduleSegments.join("/").toLowerCase(), id };
}

function invalidTarget() {
  return NextResponse.json({ error: "Módulo o identificador inválido." }, { status: 400 });
}

function invalidBody() {
  return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
}

function handleError(error: unknown) {
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }
  if (error instanceof UnsupportedModuleError) {
    return NextResponse.json({ error: error.message }, { status: 501 });
  }
  if (error instanceof UnsupportedFieldError) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  const code = (error as { code?: string })?.code;
  if (code === "23505") {
    return NextResponse.json({ error: "Ya existe un registro con esos datos." }, { status: 409 });
  }
  if (code === "23503" || code === "23502" || code === "22P02") {
    return NextResponse.json({ error: "Los datos no cumplen las reglas de la base de datos." }, { status: 400 });
  }

  console.error("Error en API modular:", error);
  return NextResponse.json({ error: "No se pudo completar la operación." }, { status: 500 });
}

async function readBody(request: NextRequest): Promise<Record<string, unknown> | null> {
  try {
    const body: unknown = await request.json();
    return body !== null && typeof body === "object" && !Array.isArray(body)
      ? (body as Record<string, unknown>)
      : null;
  } catch {
    return null;
  }
}

export async function GET(request: NextRequest, context: RouteContext) {
  try {
    const target = await getTarget(context);
    if (!target) return invalidTarget();

    if (target.id !== undefined) {
      const record = await buscarRegistro(target.moduleKey, target.id);
      return record
        ? NextResponse.json({ data: record, adapter: "postgresql" })
        : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
    }

    const searchParams = request.nextUrl.searchParams;
    return NextResponse.json(await listarRegistros(target.moduleKey, {
      search: searchParams.get("q") ?? undefined,
      page: Number(searchParams.get("page")) || 1,
      pageSize: Number(searchParams.get("limit")) || 50,
    }));
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest, context: RouteContext) {
  try {
    const target = await getTarget(context);
    if (!target || target.id !== undefined) return invalidTarget();

    const body = await readBody(request);
    if (!body) return invalidBody();

    const record = await crearRegistro(target.moduleKey, body);
    return NextResponse.json({ data: record, adapter: "postgresql" }, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

export async function PUT(request: NextRequest, context: RouteContext) {
  return updateRecord(request, context);
}

export async function PATCH(request: NextRequest, context: RouteContext) {
  return updateRecord(request, context);
}

async function updateRecord(request: NextRequest, context: RouteContext) {
  try {
    const target = await getTarget(context);
    if (!target || target.id === undefined) return invalidTarget();

    const body = await readBody(request);
    if (!body) return invalidBody();

    const record = await actualizarRegistro(target.moduleKey, target.id, body);
    return record
      ? NextResponse.json({ data: record, adapter: "postgresql" })
      : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(_request: NextRequest, context: RouteContext) {
  try {
    const target = await getTarget(context);
    if (!target || target.id === undefined) return invalidTarget();

    const record = await eliminarRegistro(target.moduleKey, target.id);
    return record
      ? NextResponse.json({ data: record, adapter: "postgresql" })
      : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
  } catch (error) {
    return handleError(error);
  }
}