"use client";
import React, { useEffect, useState } from "react";
import {
  DetalleFormValues,
  EstadoFactura,
  Factura,
  FacturaFormValues,
  FACTURAS_HISTORY_STORAGE_KEY,
  InfoFactura,
  InfoTributaria,
  IVA_RATE_BY_CODE,
  Pago,
  QUICK_SALE_INVOICE_DRAFT_KEY,
  QUICK_SALE_INVOICE_DRAFT_NOTE,
  QuickSaleInvoiceDraft,
  TotalConImpuesto,
} from "./types";
import FacturaModal from "./FacturaModal";
import FacturaSeguimientoModal from "./FacturaSeguimientoModal";
import { SRIService } from "./sri-service";
import "./facturas.css";
import { CirclePlus, SquarePen, Trash2, Eye, Send, Download, FileText } from 'lucide-react';

const initialForm: FacturaFormValues = {
  ambiente: "1", // Pruebas por defecto
  razon_social: "",
  nombre_comercial: "",
  ruc: "",
  estab: "001",
  ptoEmi: "001",
  secuencial: "1",
  direccion_matriz: "",
  fecha_emision: new Date().toISOString().split('T')[0],
  direccion_establecimiento: "",
  contribuyente_especial: "",
  obligado_contabilidad: "NO",
  tipo_identificacion_comprador: "",
  guia_remision: "",
  razon_social_comprador: "",
  identificacion_comprador: "",
  direccion_comprador: "",
  propina: 0,
  moneda: "DOLAR",
  forma_pago: "01",
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const FACTURA_STATUSES: EstadoFactura[] = [
  "PENDIENTE",
  "AUTORIZADA",
  "RECHAZADA",
  "DEVUELTA",
];

const isEstadoFactura = (value: unknown): value is EstadoFactura =>
  typeof value === "string" &&
  FACTURA_STATUSES.some((estado) => estado === value);

const isStoredFactura = (value: unknown): value is Factura => {
  if (!isRecord(value)) return false;
  const infoTributaria = value.info_tributaria;
  const infoFactura = value.info_factura;

  if (
    !Number.isFinite(value.id) ||
    !isRecord(infoTributaria) ||
    !isRecord(infoFactura) ||
    !Array.isArray(value.detalles) ||
    !Array.isArray(value.total_con_impuestos) ||
    !Array.isArray(value.pagos) ||
    !isEstadoFactura(value.estado_sri) ||
    typeof value.fecha_creacion !== "string" ||
    typeof value.fecha_actualizacion !== "string"
  ) {
    return false;
  }

  const tributaryStringFields = [
    "ambiente",
    "tipo_emision",
    "razon_social",
    "nombre_comercial",
    "ruc",
    "clave_acceso",
    "cod_doc",
    "estab",
    "ptoEmi",
    "secuencial",
    "direccion_matriz",
  ];
  const invoiceStringFields = [
    "fecha_emision",
    "direccion_establecimiento",
    "obligado_contabilidad",
    "tipo_identificacion_comprador",
    "razon_social_comprador",
    "identificacion_comprador",
    "moneda",
    "forma_pago",
  ];
  const invoiceNumberFields = [
    "total_sin_impuestos",
    "total_descuento",
    "propina",
    "importe_total",
  ];

  if (
    !Number.isFinite(value.id) ||
    !tributaryStringFields.every(
      (field) => typeof infoTributaria[field] === "string",
    ) ||
    !invoiceStringFields.every(
      (field) => typeof infoFactura[field] === "string",
    ) ||
    !invoiceNumberFields.every((field) =>
      Number.isFinite(infoFactura[field]),
    )
  ) {
    return false;
  }

  const validDetails = value.detalles.every(
    (detail) =>
      isRecord(detail) &&
      Number.isFinite(detail.id) &&
      typeof detail.codigo_principal === "string" &&
      typeof detail.descripcion === "string" &&
      Number.isFinite(detail.cantidad) &&
      Number.isFinite(detail.precio_unitario) &&
      Number.isFinite(detail.descuento) &&
      Number.isFinite(detail.precio_total_sin_impuesto) &&
      typeof detail.codigo_porcentaje_iva === "string" &&
      Number.isFinite(detail.tarifa_iva) &&
      Number.isFinite(detail.valor_iva) &&
      Number.isFinite(detail.precio_total_con_impuesto),
  );
  const validTotals = value.total_con_impuestos.every(
    (total) =>
      isRecord(total) &&
      typeof total.codigo === "string" &&
      typeof total.codigo_porcentaje === "string" &&
      Number.isFinite(total.base_imponible) &&
      Number.isFinite(total.tarifa) &&
      Number.isFinite(total.valor),
  );
  const validPayments = value.pagos.every(
    (payment) =>
      isRecord(payment) &&
      typeof payment.forma_pago === "string" &&
      Number.isFinite(payment.total),
  );
  const validHistory =
    value.historial_estados === undefined ||
    (Array.isArray(value.historial_estados) &&
      value.historial_estados.every(
        (event) =>
          isRecord(event) &&
          isEstadoFactura(event.estado) &&
          typeof event.fecha === "string" &&
          ["VENTA_RAPIDA", "SIMULADOR_SRI", "SISTEMA"].includes(
            String(event.origen),
          ) &&
          typeof event.detalle === "string",
      ));

  return validDetails && validTotals && validPayments && validHistory;
};

const isQuickSaleInvoiceDraft = (
  value: unknown,
): value is QuickSaleInvoiceDraft => {
  if (
    !isRecord(value) ||
    typeof value.saleNumber !== "string" ||
    typeof value.paymentDestination !== "string" ||
    !isRecord(value.form) ||
    !Array.isArray(value.detalles)
  ) {
    return false;
  }

  const stringFormFields = [
    "ambiente",
    "razon_social",
    "nombre_comercial",
    "ruc",
    "estab",
    "ptoEmi",
    "secuencial",
    "direccion_matriz",
    "fecha_emision",
    "direccion_establecimiento",
    "contribuyente_especial",
    "obligado_contabilidad",
    "tipo_identificacion_comprador",
    "guia_remision",
    "razon_social_comprador",
    "identificacion_comprador",
    "direccion_comprador",
    "moneda",
    "forma_pago",
  ];
  const form = value.form;
  if (
    !stringFormFields.every((field) => typeof form[field] === "string") ||
    typeof form.propina !== "number"
  ) {
    return false;
  }

  return value.detalles.every(
    (detail) =>
      isRecord(detail) &&
      typeof detail.codigo_principal === "string" &&
      typeof detail.codigo_auxiliar === "string" &&
      typeof detail.descripcion === "string" &&
      typeof detail.codigo_porcentaje_iva === "string" &&
      Number.isFinite(detail.cantidad) &&
      Number.isFinite(detail.precio_unitario) &&
      Number.isFinite(detail.descuento),
  );
};

const initialFacturas: Factura[] = [
  {
    id: 1,
    info_tributaria: {
      ambiente: "1",
      tipo_emision: "1",
      razon_social: "EMPRESA DEMO S.A.",
      nombre_comercial: "Demo",
      ruc: "1234567890001",
      clave_acceso: "2309202401123456789000110010010000000011234567891",
      cod_doc: "01",
      estab: "001",
      ptoEmi: "001",
      secuencial: "000000001",
      direccion_matriz: "Av. Principal 123, Ciudad Demo"
    },
    info_factura: {
      fecha_emision: "23/09/2024",
      direccion_establecimiento: "Av. Principal 123, Ciudad Demo",
      contribuyente_especial: "",
      obligado_contabilidad: "SI",
      tipo_identificacion_comprador: "05",
      guia_remision: "",
      razon_social_comprador: "CLIENTE DEMO",
      identificacion_comprador: "1234567890",
      direccion_comprador: "Calle Cliente 456",
      total_sin_impuestos: 100.00,
      total_descuento: 0.00,
      propina: 0.00,
      importe_total: 112.00,
      moneda: "DOLAR",
      forma_pago: "01",
    },
    detalles: [
      {
        id: 1,
        codigo_principal: "PROD001",
        descripcion: "Producto Demo",
        cantidad: 1,
        precio_unitario: 100.00,
        descuento: 0.00,
        precio_total_sin_impuesto: 100.00,
        codigo_porcentaje_iva: "2",
        tarifa_iva: 0.12,
        valor_iva: 12.00,
        precio_total_con_impuesto: 112.00
      }
    ],
    total_con_impuestos: [
      {
        codigo: "2",
        codigo_porcentaje: "2",
        descuento_adicional: 0.00,
        base_imponible: 100.00,
        tarifa: 0.12,
        valor: 12.00
      }
    ],
    pagos: [
      {
        forma_pago: "01",
        total: 112.00
      }
    ],
    estado_sri: 'AUTORIZADA',
    numero_autorizacion: "2309202412345678901234567890123456",
    fecha_autorizacion: "2024-09-23T10:30:00.000Z",
    fecha_creacion: "2024-09-23T10:00:00.000Z",
    fecha_actualizacion: "2024-09-23T10:30:00.000Z"
  }
];

export default function FacturasPage() {
  const [facturas, setFacturas] = useState<Factura[]>(initialFacturas);
  const [historialListo, setHistorialListo] = useState(false);
  const [almacenamientoDisponible, setAlmacenamientoDisponible] =
    useState(true);
  const [mensajeAlmacenamiento, setMensajeAlmacenamiento] = useState("");
  const [filtro, setFiltro] = useState<string>("");
  const [filtroEstado, setFiltroEstado] = useState<
    "TODOS" | "PROBLEMATICAS" | EstadoFactura
  >("TODOS");
  const [filtroOrigen, setFiltroOrigen] = useState<
    "TODAS" | "VENTA_RAPIDA" | "OTRAS"
  >("TODAS");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [facturaSeguimientoId, setFacturaSeguimientoId] = useState<
    number | null
  >(null);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<FacturaFormValues>(initialForm);
  const [detalles, setDetalles] = useState<DetalleFormValues[]>([]);
  const [enviandoSRI, setEnviandoSRI] = useState<boolean>(false);
  const [desdeVentaRapida, setDesdeVentaRapida] = useState(false);
  const [numeroVentaRapida, setNumeroVentaRapida] = useState("");
  const [destinoIngresoVentaRapida, setDestinoIngresoVentaRapida] = useState("");

  const sriService = SRIService.getInstance();

  const guardarFacturasEnHistorial = (listaActualizada: Factura[]) => {
    setFacturas(listaActualizada);
    if (!historialListo || !almacenamientoDisponible) return false;

    try {
      window.localStorage.setItem(
        FACTURAS_HISTORY_STORAGE_KEY,
        JSON.stringify(listaActualizada),
      );
      return true;
    } catch {
      setAlmacenamientoDisponible(false);
      setMensajeAlmacenamiento(
        "No se pudo guardar el historial en este navegador. Los cambios estarán disponibles solo mientras esta página permanezca abierta.",
      );
      return false;
    }
  };

  useEffect(() => {
    let serializedHistory: string | null;
    try {
      serializedHistory = window.localStorage.getItem(
        FACTURAS_HISTORY_STORAGE_KEY,
      );
    } catch {
      setAlmacenamientoDisponible(false);
      setMensajeAlmacenamiento(
        "El navegador no permitió leer el historial local. Los cambios solo estarán disponibles mientras esta página permanezca abierta.",
      );
      setHistorialListo(true);
      return;
    }

    if (serializedHistory) {
      let parsedHistory: unknown;
      try {
        parsedHistory = JSON.parse(serializedHistory);
      } catch {
        setAlmacenamientoDisponible(false);
        setMensajeAlmacenamiento(
          "El historial local está dañado y no fue sobrescrito. Los cambios de esta sesión no quedarán guardados.",
        );
        setHistorialListo(true);
        return;
      }

      if (!Array.isArray(parsedHistory) || !parsedHistory.every(isStoredFactura)) {
        setAlmacenamientoDisponible(false);
        setMensajeAlmacenamiento(
          "El historial local tiene un formato no válido y no fue sobrescrito. Los cambios de esta sesión no quedarán guardados.",
        );
        setHistorialListo(true);
        return;
      }

      setFacturas(parsedHistory);
    }

    setHistorialListo(true);
  }, []);

  useEffect(() => {
    if (!historialListo || !almacenamientoDisponible) return;

    try {
      window.localStorage.setItem(
        FACTURAS_HISTORY_STORAGE_KEY,
        JSON.stringify(facturas),
      );
    } catch {
      setAlmacenamientoDisponible(false);
      setMensajeAlmacenamiento(
        "No se pudo guardar el historial en este navegador. Los cambios estarán disponibles solo mientras esta página permanezca abierta.",
      );
    }
  }, [facturas, historialListo, almacenamientoDisponible]);

  useEffect(() => {
    if (!historialListo) return;

    let serializedDraft: string | null;
    try {
      serializedDraft = sessionStorage.getItem(QUICK_SALE_INVOICE_DRAFT_KEY);
      if (serializedDraft) {
        sessionStorage.removeItem(QUICK_SALE_INVOICE_DRAFT_KEY);
      }
    } catch {
      window.alert("No se pudo leer el borrador de facturación de esta sesión.");
      return;
    }
    if (!serializedDraft) return;

    let parsedDraft: unknown;
    try {
      parsedDraft = JSON.parse(serializedDraft);
    } catch {
      window.alert("El borrador de facturación está dañado y no se pudo abrir.");
      return;
    }
    if (!isQuickSaleInvoiceDraft(parsedDraft)) {
      window.alert("El borrador de venta rápida no tiene un formato válido.");
      return;
    }

    const nextSequence =
      Math.max(
        ...facturas.map(
          (factura) => parseInt(factura.info_tributaria.secuencial) || 0,
        ),
        0,
      ) + 1;
    setForm({ ...parsedDraft.form, secuencial: String(nextSequence) });
    setDetalles(parsedDraft.detalles);
    setEditandoId(null);
    setDesdeVentaRapida(true);
    setNumeroVentaRapida(parsedDraft.saleNumber);
    setDestinoIngresoVentaRapida(parsedDraft.paymentDestination);
    setShowModal(true);
  }, [facturas, historialListo]);

  const limpiarForm = () => {
    setForm(initialForm);
    setDetalles([]);
    setEditandoId(null);
    setDesdeVentaRapida(false);
    setNumeroVentaRapida("");
    setDestinoIngresoVentaRapida("");
  };

  const abrirModalNueva = () => {
    limpiarForm();
    // Auto-incrementar secuencial
    const ultimoSecuencial = Math.max(...facturas.map(f => parseInt(f.info_tributaria.secuencial) || 0), 0);
    setForm(prev => ({
      ...prev,
      secuencial: (ultimoSecuencial + 1).toString()
    }));
    setShowModal(true);
  };
  
  const abrirModalEditar = (factura: Factura) => {
    setForm({
      ambiente: factura.info_tributaria.ambiente,
      razon_social: factura.info_tributaria.razon_social,
      nombre_comercial: factura.info_tributaria.nombre_comercial,
      ruc: factura.info_tributaria.ruc,
      estab: factura.info_tributaria.estab,
      ptoEmi: factura.info_tributaria.ptoEmi,
      secuencial: factura.info_tributaria.secuencial,
      direccion_matriz: factura.info_tributaria.direccion_matriz,
      fecha_emision: factura.info_factura.fecha_emision.split('/').reverse().join('-'), // DD/MM/YYYY -> YYYY-MM-DD
      direccion_establecimiento: factura.info_factura.direccion_establecimiento,
      contribuyente_especial: factura.info_factura.contribuyente_especial || "",
      obligado_contabilidad: factura.info_factura.obligado_contabilidad,
      tipo_identificacion_comprador: factura.info_factura.tipo_identificacion_comprador,
      guia_remision: factura.info_factura.guia_remision || "",
      razon_social_comprador: factura.info_factura.razon_social_comprador,
      identificacion_comprador: factura.info_factura.identificacion_comprador,
      direccion_comprador: factura.info_factura.direccion_comprador || "",
      propina: factura.info_factura.propina,
      moneda: factura.info_factura.moneda,
      forma_pago: factura.info_factura.forma_pago,
    });
    
    setDetalles(factura.detalles.map(det => ({
      codigo_principal: det.codigo_principal,
      codigo_auxiliar: det.codigo_auxiliar || "",
      descripcion: det.descripcion,
      cantidad: det.cantidad,
      precio_unitario: det.precio_unitario,
      descuento: det.descuento,
      codigo_porcentaje_iva: det.codigo_porcentaje_iva,
    })));
    
    setEditandoId(factura.id);
    setDesdeVentaRapida(
      factura.observaciones_sri === QUICK_SALE_INVOICE_DRAFT_NOTE,
    );
    setNumeroVentaRapida(factura.origen_venta_rapida ?? "");
    setDestinoIngresoVentaRapida(factura.destino_ingreso ?? "");
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const calcularTotalesFactura = (detallesFactura: DetalleFormValues[]) => {
    let totalSinImpuestos = 0;
    let totalDescuentos = 0;
    let totalIva = 0;
    const totalesConImpuestos: TotalConImpuesto[] = [];

    detallesFactura.forEach(detalle => {
      const subtotal = (detalle.cantidad * detalle.precio_unitario) - detalle.descuento;
      totalSinImpuestos += subtotal;
      totalDescuentos += detalle.descuento;

      const tarifaIva = IVA_RATE_BY_CODE[detalle.codigo_porcentaje_iva] ?? 0;

      const valorIva = subtotal * tarifaIva;
      totalIva += valorIva;

      // Agrupar por código de porcentaje
      const existente = totalesConImpuestos.find(t => t.codigo_porcentaje === detalle.codigo_porcentaje_iva);
      if (existente) {
        existente.base_imponible += subtotal;
        existente.valor += valorIva;
      } else {
        totalesConImpuestos.push({
          codigo: "2",
          codigo_porcentaje: detalle.codigo_porcentaje_iva,
          descuento_adicional: 0,
          base_imponible: subtotal,
          tarifa: tarifaIva,
          valor: valorIva
        });
      }
    });

    return {
      totalSinImpuestos,
      totalDescuentos,
      totalIva,
      totalesConImpuestos,
      importeTotal: totalSinImpuestos + totalIva + (form.propina || 0)
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (detalles.length === 0) {
      alert('Debe agregar al menos un detalle a la factura');
      return;
    }

    setEnviandoSRI(true);
    
    try {
      const totales = calcularTotalesFactura(detalles);
      
      // Crear estructura completa de la factura
      const infoTributaria: InfoTributaria = {
        ambiente: form.ambiente,
        tipo_emision: "1",
        razon_social: form.razon_social,
        nombre_comercial: form.nombre_comercial,
        ruc: form.ruc,
        clave_acceso: "", // Se genera en el servicio SRI
        cod_doc: "01",
        estab: form.estab,
        ptoEmi: form.ptoEmi,
        secuencial: form.secuencial,
        direccion_matriz: form.direccion_matriz,
      };

      const infoFactura: InfoFactura = {
        fecha_emision: form.fecha_emision.split('-').reverse().join('/'), // YYYY-MM-DD -> DD/MM/YYYY
        direccion_establecimiento: form.direccion_establecimiento,
        contribuyente_especial: form.contribuyente_especial,
        obligado_contabilidad: form.obligado_contabilidad,
        tipo_identificacion_comprador: form.tipo_identificacion_comprador,
        guia_remision: form.guia_remision,
        razon_social_comprador: form.razon_social_comprador,
        identificacion_comprador: form.identificacion_comprador,
        direccion_comprador: form.direccion_comprador,
        total_sin_impuestos: totales.totalSinImpuestos,
        total_descuento: totales.totalDescuentos,
        propina: form.propina || 0,
        importe_total: totales.importeTotal,
        moneda: form.moneda,
        forma_pago: form.forma_pago,
      };

      const detallesCompletos = detalles.map((det, index) => {
        const subtotal = (det.cantidad * det.precio_unitario) - det.descuento;
        const tarifaIva = IVA_RATE_BY_CODE[det.codigo_porcentaje_iva] ?? 0;
        const valorIva = subtotal * tarifaIva;

        return {
          id: index + 1,
          codigo_principal: det.codigo_principal,
          codigo_auxiliar: det.codigo_auxiliar,
          descripcion: det.descripcion,
          cantidad: det.cantidad,
          precio_unitario: det.precio_unitario,
          descuento: det.descuento,
          precio_total_sin_impuesto: subtotal,
          codigo_porcentaje_iva: det.codigo_porcentaje_iva,
          tarifa_iva: tarifaIva,
          valor_iva: valorIva,
          precio_total_con_impuesto: subtotal + valorIva
        };
      });

      const pagos: Pago[] = [{
        forma_pago: form.forma_pago,
        total: totales.importeTotal
      }];

      const nuevaFactura: Factura = {
        id: editandoId || Date.now(),
        ...(desdeVentaRapida
          ? {
              origen_venta_rapida: numeroVentaRapida,
              destino_ingreso: destinoIngresoVentaRapida,
            }
          : {}),
        info_tributaria: infoTributaria,
        info_factura: infoFactura,
        detalles: detallesCompletos,
        total_con_impuestos: totales.totalesConImpuestos,
        pagos: pagos,
        estado_sri: 'PENDIENTE',
        fecha_creacion: new Date().toISOString(),
        fecha_actualizacion: new Date().toISOString()
      };

      if (desdeVentaRapida) {
        nuevaFactura.observaciones_sri = QUICK_SALE_INVOICE_DRAFT_NOTE;
        const historialPrevio = editandoId
          ? facturas.find((factura) => factura.id === editandoId)
              ?.historial_estados ?? []
          : [];
        nuevaFactura.historial_estados = [
          ...historialPrevio,
          {
            estado: "PENDIENTE",
            fecha: new Date().toISOString(),
            origen: "VENTA_RAPIDA",
            detalle: editandoId
              ? "Borrador actualizado localmente; no se envió al SRI."
              : "Borrador creado desde Venta rápida y pendiente de revisión; no se envió al SRI.",
          },
        ];
        const listaActualizada = editandoId
          ? facturas.map((factura) =>
              factura.id === editandoId ? nuevaFactura : factura,
            )
          : [...facturas, nuevaFactura];
        const guardadoLocal = guardarFacturasEnHistorial(listaActualizada);
        alert(
          guardadoLocal
            ? "Borrador guardado en el historial de este navegador y pendiente de revisión. No se envió al SRI."
            : "Borrador agregado a esta sesión, pero no se pudo conservar en el navegador. No se envió al SRI.",
        );
        cerrarModal();
        return;
      }

      // Enviar al SRI
      console.log('🚀 Enviando factura al SRI...', nuevaFactura);
      const respuestaSRI = await sriService.enviarFacturaSRI(nuevaFactura);

      // Actualizar factura con respuesta del SRI
      nuevaFactura.estado_sri = respuestaSRI.estado;
      if (respuestaSRI.success) {
        nuevaFactura.numero_autorizacion = respuestaSRI.numero_autorizacion;
        nuevaFactura.fecha_autorizacion = respuestaSRI.fecha_autorizacion;
        nuevaFactura.xml_generado = respuestaSRI.xml_autorizado;
      }
      nuevaFactura.observaciones_sri = respuestaSRI.observaciones;
      const historialPrevio = editandoId
        ? facturas.find((factura) => factura.id === editandoId)
            ?.historial_estados ?? []
        : [];
      const fechaRespuesta = new Date().toISOString();
      nuevaFactura.historial_estados = [
        ...historialPrevio,
        ...(!editandoId
          ? [
              {
                estado: "PENDIENTE" as const,
                fecha: nuevaFactura.fecha_creacion,
                origen: "SISTEMA" as const,
                detalle: "Factura creada y enviada al simulador local.",
              },
            ]
          : []),
        {
          estado: respuestaSRI.estado,
          fecha: fechaRespuesta,
          origen: "SIMULADOR_SRI",
          detalle:
            respuestaSRI.observaciones ||
            respuestaSRI.mensaje_error ||
            `El simulador respondió: ${respuestaSRI.estado.toLowerCase()}.`,
        },
      ];

      const listaActualizada = editandoId
        ? facturas.map((factura) =>
            factura.id === editandoId ? nuevaFactura : factura,
          )
        : [...facturas, nuevaFactura];
      const guardadoLocal = guardarFacturasEnHistorial(listaActualizada);

      // Mostrar resultado
      if (respuestaSRI.success) {
        alert(
          `El simulador local marcó la factura como ${respuestaSRI.estado.toLowerCase()}. Esto no es una autorización real del SRI.\nReferencia simulada: ${respuestaSRI.numero_autorizacion || "no disponible"}.\n${guardadoLocal ? "El historial quedó guardado en este navegador." : "No se pudo conservar el historial en este navegador."}`,
        );
        cerrarModal();
      } else {
        alert(
          `El simulador local devolvió ${respuestaSRI.estado.toLowerCase()}; no se contactó al SRI.\n${respuestaSRI.mensaje_error || respuestaSRI.observaciones || ""}\n${guardadoLocal ? "El estado quedó guardado en este navegador." : "No se pudo conservar el historial en este navegador."}`,
        );
      }

    } catch (error) {
      console.error('Error procesando factura:', error);
      alert('Error inesperado al procesar la factura');
    } finally {
      setEnviandoSRI(false);
    }
  };

  const eliminarFactura = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta factura?")) {
      const listaActualizada = facturas.filter((factura) => factura.id !== id);
      const eliminadoLocal = guardarFacturasEnHistorial(listaActualizada);
      if (!eliminadoLocal) {
        alert(
          "El registro se quitó de esta sesión, pero no se pudo actualizar el historial guardado en el navegador.",
        );
      }
    }
  };

  const reenviarSRI = async (factura: Factura) => {
    if (
      window.confirm(
        "¿Desea volver a simular el envío de esta factura? No se contactará al SRI.",
      )
    ) {
      setEnviandoSRI(true);
      try {
        const respuestaSRI = await sriService.enviarFacturaSRI(factura);
        
        // Actualizar factura
        const fechaRespuesta = new Date().toISOString();
        const facturaActualizada = {
          ...factura,
          estado_sri: respuestaSRI.estado,
          numero_autorizacion: respuestaSRI.numero_autorizacion,
          fecha_autorizacion: respuestaSRI.fecha_autorizacion,
          xml_generado: respuestaSRI.xml_autorizado,
          observaciones_sri: respuestaSRI.observaciones,
          fecha_actualizacion: fechaRespuesta,
          historial_estados: [
            ...(factura.historial_estados ?? []),
            {
              estado: respuestaSRI.estado,
              fecha: fechaRespuesta,
              origen: "SIMULADOR_SRI" as const,
              detalle:
                respuestaSRI.observaciones ||
                respuestaSRI.mensaje_error ||
                `El simulador respondió: ${respuestaSRI.estado.toLowerCase()}.`,
            },
          ],
        };

        const listaActualizada = facturas.map((item) =>
          item.id === factura.id ? facturaActualizada : item,
        );
        const guardadoLocal = guardarFacturasEnHistorial(listaActualizada);

        if (respuestaSRI.success) {
          alert(
            `El simulador local marcó la factura como ${respuestaSRI.estado.toLowerCase()}. No es una autorización real del SRI.${guardadoLocal ? " El historial quedó guardado en este navegador." : " No se pudo conservar el historial en este navegador."}`,
          );
        } else {
          alert(
            `El simulador local devolvió ${respuestaSRI.estado.toLowerCase()}. No se contactó al SRI.${guardadoLocal ? "" : " No se pudo conservar el historial en este navegador."}`,
          );
        }
      } catch (err) {
        console.error("Error en el reintento del simulador SRI:", err);
        alert("No se pudo completar la simulación de reintento.");
      } finally {
        setEnviandoSRI(false);
      }
    }
  };

  const descargarPDF = (factura: Factura) => {
    const esBorradorVentaRapida =
      factura.observaciones_sri === QUICK_SALE_INVOICE_DRAFT_NOTE;
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Factura ${factura.info_tributaria.secuencial}</title>
        <style>
          body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 10px;
            font-size: 11px;
            line-height: 1.2;
          }

          .demo-banner {
            padding: 9px;
            border-bottom: 2px solid #92400e;
            background: #fef3c7;
            color: #78350f;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
          }
          
          .factura-container {
            max-width: 210mm;
            margin: 0 auto;
            border: 2px solid #000;
          }
          
          .header-section {
            display: flex;
            border-bottom: 1px solid #000;
          }
          
          .company-section {
            flex: 2;
            padding: 10px;
            border-right: 1px solid #000;
          }
          
          .document-info {
            flex: 1;
            padding: 10px;
            text-align: center;
          }
          
          .company-name {
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 5px;
          }
          
          .company-details {
            text-align: center;
            margin-bottom: 10px;
          }
          
          .ruc-info {
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            background-color: #f0f0f0;
            padding: 3px;
            border: 1px solid #000;
            margin: 5px 0;
          }
          
          .document-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
            background-color: #f0f0f0;
            padding: 5px;
            border: 1px solid #000;
          }
          
          .document-number {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 10px;
          }
          
          .authorization-box {
            border: 1px solid #000;
            padding: 5px;
            margin: 5px 0;
            background-color: #f9f9f9;
          }
          
          .client-section {
            padding: 10px;
            border-bottom: 1px solid #000;
          }
          
          .client-title {
            font-weight: bold;
            margin-bottom: 5px;
            background-color: #f0f0f0;
            padding: 3px;
          }
          
          .client-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 3px;
          }
          
          .details-section {
            padding: 10px;
          }
          
          .details-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
          }
          
          .details-table th {
            background-color: #f0f0f0;
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
            font-weight: bold;
            font-size: 10px;
          }
          
          .details-table td {
            border: 1px solid #000;
            padding: 5px;
            text-align: center;
            font-size: 10px;
          }
          
          .details-table .desc-col {
            text-align: left;
          }
          
          .details-table .num-col {
            text-align: right;
          }
          
          .totals-section {
            display: flex;
            justify-content: flex-end;
            padding: 10px;
            border-top: 1px solid #000;
          }
          
          .totals-table {
            border-collapse: collapse;
            width: 300px;
          }
          
          .totals-table td {
            border: 1px solid #000;
            padding: 5px;
            font-size: 11px;
          }
          
          .totals-table .label-col {
            background-color: #f0f0f0;
            font-weight: bold;
            text-align: right;
            width: 150px;
          }
          
          .totals-table .amount-col {
            text-align: right;
            width: 150px;
          }
          
          .total-final {
            font-weight: bold;
            font-size: 12px;
            background-color: #e0e0e0;
          }
          
          .footer-section {
            padding: 10px;
            border-top: 1px solid #000;
            font-size: 10px;
            text-align: center;
          }
          
          .payment-info {
            margin-top: 10px;
            border-top: 1px dotted #000;
            padding-top: 10px;
          }
          
          @media print {
            body { margin: 0; }
            .factura-container { border: 2px solid #000; }
          }
        </style>
      </head>
      <body>
        <div class="factura-container">
          <div class="demo-banner">
            DOCUMENTO DE DEMOSTRACIÓN · NO ES UN COMPROBANTE TRIBUTARIO AUTORIZADO
          </div>
          <!-- HEADER SECTION -->
          <div class="header-section">
            <div class="company-section">
              <div class="company-name">${factura.info_tributaria.razon_social}</div>
              <div class="company-details">
                <strong>Nombre Comercial:</strong> ${factura.info_tributaria.nombre_comercial}<br>
                <strong>Dirección Matriz:</strong> ${factura.info_tributaria.direccion_matriz}<br>
                <strong>Dirección Sucursal:</strong> ${factura.info_factura.direccion_establecimiento || factura.info_tributaria.direccion_matriz}
              </div>
              <div class="ruc-info">R.U.C.: ${factura.info_tributaria.ruc}</div>
              ${factura.info_factura.contribuyente_especial ? `<div class="ruc-info">CONTRIBUYENTE ESPECIAL NO. ${factura.info_factura.contribuyente_especial}</div>` : ''}
              <div class="ruc-info">OBLIGADO A LLEVAR CONTABILIDAD: ${factura.info_factura.obligado_contabilidad}</div>
            </div>
            
            <div class="document-info">
              <div class="document-title">FACTURA</div>
              <div class="document-number">No. ${factura.info_tributaria.estab}-${factura.info_tributaria.ptoEmi}-${factura.info_tributaria.secuencial.padStart(9, '0')}</div>
              
              <div class="authorization-box">
                <strong>REFERENCIA DEL SIMULADOR</strong><br>
                ${factura.numero_autorizacion ? `SIMULADA: ${factura.numero_autorizacion}` : esBorradorVentaRapida ? 'NO ENVIADA AL SRI' : 'SIN RESPUESTA DEL SIMULADOR'}
              </div>
              
              <div class="authorization-box">
                <strong>FECHA Y HORA DE RESPUESTA DEL SIMULADOR:</strong><br>
                ${factura.fecha_autorizacion ? new Date(factura.fecha_autorizacion).toLocaleString('es-EC', {
                  year: 'numeric',
                  month: '2-digit', 
                  day: '2-digit',
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit'
                }) : 'PENDIENTE'}
              </div>
              
              <div class="authorization-box">
                <strong>AMBIENTE:</strong> ${factura.info_tributaria.ambiente === '1' ? 'PRUEBAS' : 'PRODUCCIÓN'}<br>
                <strong>EMISIÓN:</strong> NORMAL
              </div>
              
              <div class="authorization-box">
                <strong>CLAVE DE ACCESO (SIMULADA)</strong><br>
                <div style="font-family: monospace; font-size: 9px; word-break: break-all;">
                  ${factura.info_tributaria.clave_acceso || 'PENDIENTE DE GENERACIÓN'}
                </div>
              </div>
            </div>
          </div>
          
          <!-- CLIENT SECTION -->
          <div class="client-section">
            <div class="client-title">DATOS DEL CLIENTE</div>
            <div class="client-info">
              <span><strong>Razón Social / Nombres y Apellidos:</strong> ${factura.info_factura.razon_social_comprador}</span>
              <span><strong>Fecha de Emisión:</strong> ${factura.info_factura.fecha_emision}</span>
            </div>
            <div class="client-info">
              <span><strong>Identificación:</strong> ${factura.info_factura.identificacion_comprador}</span>
              <span><strong>Guía de Remisión:</strong> ${factura.info_factura.guia_remision || 'N/A'}</span>
            </div>
            <div class="client-info">
              <span><strong>Dirección:</strong> ${factura.info_factura.direccion_comprador || 'N/A'}</span>
            </div>
          </div>
          
          <!-- DETAILS SECTION -->
          <div class="details-section">
            <table class="details-table">
              <thead>
                <tr>
                  <th style="width: 12%;">Código<br>Principal</th>
                  <th style="width: 10%;">Código<br>Auxiliar</th>
                  <th style="width: 30%;">Descripción</th>
                  <th style="width: 8%;">Cantidad</th>
                  <th style="width: 10%;">Precio<br>Unitario</th>
                  <th style="width: 10%;">Descuento</th>
                  <th style="width: 10%;">Precio Total<br>Sin Impuesto</th>
                  <th style="width: 10%;">Precio Total<br>Con Impuesto</th>
                </tr>
              </thead>
              <tbody>
                ${factura.detalles.map(detalle => `
                  <tr>
                    <td>${detalle.codigo_principal}</td>
                    <td>${detalle.codigo_auxiliar || ''}</td>
                    <td class="desc-col">${detalle.descripcion}</td>
                    <td class="num-col">${detalle.cantidad}</td>
                    <td class="num-col">${detalle.precio_unitario.toFixed(2)}</td>
                    <td class="num-col">${detalle.descuento.toFixed(2)}</td>
                    <td class="num-col">${detalle.precio_total_sin_impuesto.toFixed(2)}</td>
                    <td class="num-col">${detalle.precio_total_con_impuesto.toFixed(2)}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          
          <!-- TOTALS SECTION -->
          <div class="totals-section">
            <table class="totals-table">
              ${factura.total_con_impuestos.map(impuesto => `
              <tr>
                <td class="label-col">SUBTOTAL ${Math.round(impuesto.tarifa * 100)}%</td>
                <td class="amount-col">${impuesto.base_imponible.toFixed(2)}</td>
              </tr>
              `).join('')}
              <tr>
                <td class="label-col">SUBTOTAL NO OBJETO DE IVA</td>
                <td class="amount-col">0.00</td>
              </tr>
              <tr>
                <td class="label-col">SUBTOTAL SIN IMPUESTOS</td>
                <td class="amount-col">${factura.info_factura.total_sin_impuestos.toFixed(2)}</td>
              </tr>
              <tr>
                <td class="label-col">SUBTOTAL EXENTO DE IVA</td>
                <td class="amount-col">0.00</td>
              </tr>
              <tr>
                <td class="label-col">DESCUENTO</td>
                <td class="amount-col">${factura.info_factura.total_descuento.toFixed(2)}</td>
              </tr>
              <tr>
                <td class="label-col">ICE</td>
                <td class="amount-col">0.00</td>
              </tr>
              <tr>
                <td class="label-col">IRBPNR</td>
                <td class="amount-col">0.00</td>
              </tr>
              ${factura.total_con_impuestos.map(impuesto => `
              <tr>
                <td class="label-col">IVA ${Math.round(impuesto.tarifa * 100)}%</td>
                <td class="amount-col">${impuesto.valor.toFixed(2)}</td>
              </tr>
              `).join('')}
              ${factura.info_factura.propina > 0 ? `
              <tr>
                <td class="label-col">PROPINA</td>
                <td class="amount-col">${factura.info_factura.propina.toFixed(2)}</td>
              </tr>
              ` : ''}
              <tr class="total-final">
                <td class="label-col">VALOR TOTAL</td>
                <td class="amount-col">${factura.info_factura.importe_total.toFixed(2)}</td>
              </tr>
            </table>
          </div>
          
          <!-- PAYMENT INFO -->
          <div class="payment-info">
            <strong>FORMA DE PAGO:</strong> ${getFormaPagoDescripcion(factura.info_factura.forma_pago)} - 
            <strong>VALOR:</strong> ${factura.info_factura.importe_total.toFixed(2)}
          </div>
          
          <!-- FOOTER -->
          <div class="footer-section">
            <small>
              Documento de demostración. No constituye una factura electrónica autorizada por el SRI ni tiene validez tributaria.
              RUC de ejemplo: ${factura.info_tributaria.ruc}, fecha: ${factura.info_factura.fecha_emision}.
            </small>
          </div>
        </div>
      </body>
      </html>
    `;

    // Crear una nueva ventana para imprimir
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(htmlContent);
      printWindow.document.close();
      
      // Esperar a que se cargue el contenido y luego imprimir
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 100);
      };
    }
  };

  const getFormaPagoDescripcion = (codigo: string) => {
    const formasPago: { [key: string]: string } = {
      '01': 'SIN UTILIZACION DEL SISTEMA FINANCIERO',
      '15': 'COMPENSACIÓN DE DEUDAS',
      '16': 'TARJETA DE DÉBITO',
      '17': 'DINERO ELECTRÓNICO',
      '18': 'TARJETA PREPAGO',
      '19': 'TARJETA DE CRÉDITO',
      '20': 'OTROS CON UTILIZACION DEL SISTEMA FINANCIERO',
      '21': 'ENDOSO DE TÍTULOS'
    };
    return formasPago[codigo] || 'OTROS';
  };

  const facturasDisponibles = historialListo ? facturas : [];
  const facturasFiltradas = facturasDisponibles.filter((factura) => {
    const esBorradorVentaRapida =
      factura.observaciones_sri === QUICK_SALE_INVOICE_DRAFT_NOTE;
    const textoBusqueda = Object.values(factura.info_factura)
      .concat(Object.values(factura.info_tributaria))
      .concat([
        factura.origen_venta_rapida ?? "",
        factura.destino_ingreso ?? "",
        esBorradorVentaRapida ? "borrador local venta rápida" : "",
      ])
      .join(" ")
      .toLowerCase();
    const coincideEstado =
      filtroEstado === "TODOS" ||
      (filtroEstado === "PROBLEMATICAS"
        ? factura.estado_sri === "RECHAZADA" ||
          factura.estado_sri === "DEVUELTA"
        : factura.estado_sri === filtroEstado);
    const coincideOrigen =
      filtroOrigen === "TODAS" ||
      (filtroOrigen === "VENTA_RAPIDA"
        ? esBorradorVentaRapida
        : !esBorradorVentaRapida);

    return (
      textoBusqueda.includes(filtro.toLowerCase()) &&
      coincideEstado &&
      coincideOrigen
    );
  });

  const facturasPendientes = facturasDisponibles.filter(
    (factura) => factura.estado_sri === "PENDIENTE",
  ).length;
  const facturasAutorizadas = facturasDisponibles.filter(
    (factura) => factura.estado_sri === "AUTORIZADA",
  ).length;
  const facturasConProblemas = facturasDisponibles.filter(
    (factura) =>
      factura.estado_sri === "RECHAZADA" ||
      factura.estado_sri === "DEVUELTA",
  ).length;
  const facturaEnSeguimiento =
    facturaSeguimientoId === null
      ? null
      : facturas.find((factura) => factura.id === facturaSeguimientoId) ?? null;

  const getEstadoBadgeClass = (estado: string) => {
    switch (estado) {
      case 'AUTORIZADA': return 'bg-success';
      case 'RECHAZADA': return 'bg-danger';
      case 'DEVUELTA': return 'bg-warning text-dark';
      case 'PENDIENTE': return 'bg-secondary';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="bootstrap-container">
      <div className="p-4">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="mb-2">Facturas Electrónicas</h1>
            <p className="text-muted mb-0">Historial y seguimiento de comprobantes</p>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span className="badge bg-warning text-dark">Modo demostración</span>
            <span className="badge bg-primary">
              {historialListo ? `${facturas.length} facturas` : "Cargando historial..."}
            </span>
          </div>
        </div>

        <div className="alert alert-warning factura-demo-notice" role="status">
          <strong>Datos locales de demostración.</strong> El historial se guarda
          solo en este navegador. Los borradores de Venta rápida no se envían
          al SRI; las respuestas del flujo regular son simuladas.
        </div>
        {mensajeAlmacenamiento && (
          <div className="alert alert-danger factura-storage-warning" role="alert">
            {mensajeAlmacenamiento}
          </div>
        )}

        <div className="invoice-history-cards" aria-label="Resumen de facturas">
          <button
            type="button"
            className={`invoice-history-card ${filtroEstado === "TODOS" ? "is-selected" : ""}`}
            onClick={() => setFiltroEstado("TODOS")}
            aria-pressed={filtroEstado === "TODOS"}
          >
            <span>Total en historial</span>
            <strong>{historialListo ? facturas.length : "—"}</strong>
          </button>
          <button
            type="button"
            className={`invoice-history-card is-pending ${filtroEstado === "PENDIENTE" ? "is-selected" : ""}`}
            onClick={() => setFiltroEstado("PENDIENTE")}
            aria-pressed={filtroEstado === "PENDIENTE"}
          >
            <span>Pendientes</span>
            <strong>{historialListo ? facturasPendientes : "—"}</strong>
          </button>
          <button
            type="button"
            className={`invoice-history-card is-authorized ${filtroEstado === "AUTORIZADA" ? "is-selected" : ""}`}
            onClick={() => setFiltroEstado("AUTORIZADA")}
            aria-pressed={filtroEstado === "AUTORIZADA"}
          >
            <span>Autorizadas (demo)</span>
            <strong>{historialListo ? facturasAutorizadas : "—"}</strong>
          </button>
          <button
            type="button"
            className={`invoice-history-card is-problem ${filtroEstado === "PROBLEMATICAS" ? "is-selected" : ""}`}
            onClick={() => setFiltroEstado("PROBLEMATICAS")}
            aria-pressed={filtroEstado === "PROBLEMATICAS"}
          >
            <span>Rechazadas / devueltas</span>
            <strong>{historialListo ? facturasConProblemas : "—"}</strong>
          </button>
        </div>

        <div className="invoice-history-toolbar">
          <input
            type="text"
            className="form-control w-50"
            aria-label="Buscar en el historial"
            placeholder="Buscar cliente, RUC, secuencial o venta..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <select
            className="form-select invoice-history-filter"
            aria-label="Filtrar por estado"
            value={filtroEstado}
            onChange={(event) => {
              const value = event.target.value;
              setFiltroEstado(
                value === "TODOS" || value === "PROBLEMATICAS"
                  ? value
                  : isEstadoFactura(value)
                    ? value
                    : "TODOS",
              );
            }}
          >
            <option value="TODOS">Todos los estados</option>
            <option value="PENDIENTE">Pendientes</option>
            <option value="AUTORIZADA">Autorizadas (demo)</option>
            <option value="RECHAZADA">Rechazadas</option>
            <option value="DEVUELTA">Devueltas</option>
            <option value="PROBLEMATICAS">Rechazadas y devueltas</option>
          </select>
          <select
            className="form-select invoice-history-filter"
            aria-label="Filtrar por origen"
            value={filtroOrigen}
            onChange={(event) => {
              const value = event.target.value;
              setFiltroOrigen(
                value === "VENTA_RAPIDA" || value === "OTRAS"
                  ? value
                  : "TODAS",
              );
            }}
          >
            <option value="TODAS">Todos los orígenes</option>
            <option value="VENTA_RAPIDA">Venta rápida</option>
            <option value="OTRAS">Otras facturas</option>
          </select>
          <button
            className="btn btn-primary d-flex align-items-center"
            onClick={abrirModalNueva}
            disabled={!historialListo}
          >
            <CirclePlus className="me-2" size={16} />
            <span>Nueva Factura</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Secuencial</th>
                <th>Fecha</th>
                <th>Cliente</th>
                <th>RUC/Cédula</th>
                <th>Total</th>
                <th>Estado del documento</th>
                <th>Envío / autorización</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {!historialListo && (
                <tr>
                  <td colSpan={8} className="text-center py-4 text-muted">
                    Cargando historial local...
                  </td>
                </tr>
              )}
              {historialListo && facturasFiltradas.length === 0 && (
                <tr>
                  <td colSpan={8} className="text-center py-4">
                    <div className="text-muted">
                      <i className="fas fa-file-invoice fa-3x mb-3 d-block"></i>
                      No se encontraron facturas
                    </div>
                  </td>
                </tr>
              )}
              {facturasFiltradas.map((factura) => {
                const esBorradorVentaRapida =
                  factura.observaciones_sri === QUICK_SALE_INVOICE_DRAFT_NOTE;
                return (
                <tr key={factura.id}>
                  <td>
                    <strong>{factura.info_tributaria.estab}-{factura.info_tributaria.ptoEmi}-{factura.info_tributaria.secuencial.padStart(9, '0')}</strong>
                  </td>
                  <td>{factura.info_factura.fecha_emision}</td>
                  <td>{factura.info_factura.razon_social_comprador}</td>
                  <td>{factura.info_factura.identificacion_comprador}</td>
                  <td className="text-end">
                    <strong>${factura.info_factura.importe_total.toFixed(2)}</strong>
                  </td>
                  <td>
                    <span className={`badge ${esBorradorVentaRapida ? "bg-warning text-dark" : getEstadoBadgeClass(factura.estado_sri)}`}>
                      {esBorradorVentaRapida
                        ? "Borrador local"
                        : factura.estado_sri}
                    </span>
                  </td>
                  <td>
                    {esBorradorVentaRapida ? (
                      <small className="text-muted">No enviado al SRI</small>
                    ) : factura.numero_autorizacion ? (
                      <small className="text-muted">
                        {factura.numero_autorizacion.substring(0, 15)}...
                      </small>
                    ) : (
                      <small className="text-muted">Sin autorizar</small>
                    )}
                  </td>
                  <td>
                    <div className="btn-group" role="group">
                      <button
                        className="btn btn-outline-info btn-sm"
                        onClick={() => setFacturaSeguimientoId(factura.id)}
                        title="Ver seguimiento"
                        aria-label={`Ver seguimiento de factura ${factura.info_tributaria.secuencial}`}
                      >
                        <Eye size={14} />
                      </button>
                      
                      <button
                        className="btn btn-outline-warning btn-sm"
                        onClick={() => abrirModalEditar(factura)}
                        title="Editar"
                        disabled={factura.estado_sri === 'AUTORIZADA'}
                      >
                        <SquarePen size={14} />
                      </button>
                      
                      {(factura.estado_sri === 'RECHAZADA' || factura.estado_sri === 'DEVUELTA' || factura.estado_sri === 'PENDIENTE') &&
                        factura.observaciones_sri !== QUICK_SALE_INVOICE_DRAFT_NOTE && (
                        <button
                          className="btn btn-outline-primary btn-sm"
                          onClick={() => reenviarSRI(factura)}
                          title="Reintentar simulación"
                          aria-label={`Reintentar simulación de factura ${factura.info_tributaria.secuencial}`}
                          disabled={enviandoSRI}
                        >
                          <Send size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-info btn-sm"
                        title="Descargar PDF"
                        onClick={() => descargarPDF(factura)}
                      >
                        <FileText size={14} />
                      </button>
                      
                      {factura.xml_generado && (
                        <button
                          className="btn btn-outline-success btn-sm"
                          title="Descargar XML"
                          onClick={() => {
                            const blob = new Blob([factura.xml_generado!], { type: 'application/xml' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = `factura_${factura.info_tributaria.secuencial}.xml`;
                            a.click();
                          }}
                        >
                          <Download size={14} />
                        </button>
                      )}
                      
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={() => eliminarFactura(factura.id)}
                        title="Eliminar"
                        disabled={factura.estado_sri === 'AUTORIZADA'}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <FacturaModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          detalles={detalles}
          onChange={handleChange}
          onDetallesChange={setDetalles}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          enviandoSRI={enviandoSRI}
          modoBorrador={desdeVentaRapida}
          numeroVentaRapida={numeroVentaRapida}
          destinoIngresoVentaRapida={destinoIngresoVentaRapida}
        />
        {facturaEnSeguimiento && (
          <FacturaSeguimientoModal
            factura={facturaEnSeguimiento}
            onClose={() => setFacturaSeguimientoId(null)}
            getFormaPagoDescripcion={getFormaPagoDescripcion}
          />
        )}
      </div>
    </div>
  );
}
