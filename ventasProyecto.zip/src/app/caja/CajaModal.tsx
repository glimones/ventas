import React, { useEffect } from 'react';
import { CajaFormValues } from './types';
import type { TreasuryBranch, TreasuryCompany, TreasuryUser } from './types';
import CajaForm from './CajaForm';

interface Props {
  show: boolean;
  editando: boolean;
  values: CajaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  saving: boolean;
  formError: string;
  companies: TreasuryCompany[];
  branches: TreasuryBranch[];
  users: TreasuryUser[];
  occupiedBranchIds: number[];
  editingId: number | null;
}

const CajaModal: React.FC<Props> = ({ show, editando, values, onChange, onClose, onSubmit, saving, formError, companies, branches, users, occupiedBranchIds, editingId }) => {
  useEffect(() => {
    if (show) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [show]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && show && !saving) {
        onClose();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [show, onClose, saving]);

  if (!show) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget && !saving) {
      onClose();
    }
  };

  return (
    <div className='modal-overlay' onClick={handleBackdropClick} style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0, 0, 0, 0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1050, padding: '20px' }}>
      <div className='modal-container' style={{ background: 'white', borderRadius: '12px', width: '100%', maxWidth: '800px', maxHeight: '95vh', overflow: 'hidden', boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)', display: 'flex', flexDirection: 'column' }}>
        <form onSubmit={onSubmit}>
          <div className='modal-header text-white' style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#343a40' }}>
            <h5 className='modal-title'>{editando ? 'Editar caja' : 'Nueva caja'}</h5>
            <button type='button' className='btn-close btn-close-white' onClick={onClose} disabled={saving} aria-label='Cerrar' style={{ filter: 'brightness(0) invert(1)' }} />
          </div>
          <div className='modal-body' style={{ padding: '1.5rem', overflowY: 'auto', maxHeight: 'calc(85vh - 140px)' }}>
            {formError && <div className='alert alert-danger' role='alert'>{formError}</div>}
            <CajaForm values={values} onChange={onChange} companies={companies} branches={branches} users={users} occupiedBranchIds={occupiedBranchIds} editingId={editingId} />
          </div>
          <div className='modal-footer' style={{ padding: '1rem 1.5rem', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', borderTop: '1px solid #dee2e6', background: '#f8f9fa' }}>
            <button type='button' className='btn btn-secondary' onClick={onClose} disabled={saving}>Cancelar</button>
            <button type='submit' className='btn btn-primary' disabled={saving || !values.codigo}>
              {saving && <span className='spinner-border spinner-border-sm me-2' aria-hidden='true' />}
              {saving ? 'Guardando...' : editando ? 'Actualizar' : 'Guardar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CajaModal;
