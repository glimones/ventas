import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const databaseDirectory = path.dirname(fileURLToPath(import.meta.url));
const schema = fs.readFileSync(
  path.join(databaseDirectory, "001_schema.sql"),
  "utf8",
);

function placeholderFor(column, definition) {
  if (/\bDEFAULT\b/i.test(definition)) return "DEFAULT";
  if (!/\bNOT NULL\b/i.test(definition)) return "NULL";

  const type = definition.trim().split(/\s+/)[0].toUpperCase();
  if (["SMALLINT", "INTEGER", "BIGINT", "NUMERIC", "DECIMAL", "REAL", "DOUBLE"].includes(type)) {
    return `0 /* TODO: reemplazar ${column}; si es FK, usar el ID existente */`;
  }
  if (type === "BOOLEAN") return `FALSE /* TODO: reemplazar ${column} */`;
  if (type === "DATE") return `DATE '2000-01-01' /* TODO: reemplazar ${column} */`;
  if (type === "TIMESTAMPTZ" || type === "TIMESTAMP") {
    return `TIMESTAMPTZ '2000-01-01 00:00:00+00' /* TODO: reemplazar ${column} */`;
  }
  if (type === "JSONB" || type === "JSON") {
    return `'{}'::${type.toLowerCase()} /* TODO: reemplazar ${column} */`;
  }
  if (type === "INET") return `'127.0.0.1'::inet /* TODO: reemplazar ${column} */`;
  return `'REEMPLAZAR' /* TODO: reemplazar ${column} */`;
}

function getColumns(tableDefinition) {
  return tableDefinition
    .split("\n")
    .map((line) => line.trim().replace(/,$/, ""))
    .map((line) => line.match(/^([a-z][a-z0-9_]*)\s+(.+)$/i))
    .filter(Boolean)
    .filter(([, name]) => !["PRIMARY", "FOREIGN", "UNIQUE", "CHECK", "CONSTRAINT"].includes(name.toUpperCase()))
    .filter(([, , definition]) => !/\bGENERATED\s+.+\bAS\s+IDENTITY\b/i.test(definition))
    .map(([, name, definition]) => ({ name, definition }));
}

const tables = [...schema.matchAll(
  /CREATE TABLE IF NOT EXISTS\s+([a-z][a-z0-9_]*)\s*\(([\s\S]*?)\n\);/gi,
)];

if (tables.length === 0) {
  throw new Error("No se encontraron tablas en database/001_schema.sql");
}

const output = [
  "-- Plantillas generadas desde 001_schema.sql.",
  "-- Son ejemplos comentados: reemplaza todos los TODO y descomenta solo el INSERT que vas a ejecutar.",
  "-- Carga primero las tablas padre y luego las tablas detalle para respetar las claves foráneas.",
  "-- Las columnas IDENTITY se omiten; usa RETURNING id para recuperar IDs generados.",
  "",
];

for (const [, tableName, tableDefinition] of tables) {
  const columns = getColumns(tableDefinition);
  if (columns.length === 0) {
    throw new Error(`No se encontraron columnas para ${tableName}`);
  }

  output.push(`-- ${tableName}`);
  output.push(`-- INSERT INTO ${tableName} (`);
  output.push(`--   ${columns.map(({ name }) => name).join(",\n--   ")}`);
  output.push("-- ) VALUES (");
  output.push(`--   ${columns.map(({ name, definition }) => placeholderFor(name, definition)).join(",\n--   ")}`);
  output.push("-- );");
  output.push("");
}

const outputPath = path.join(databaseDirectory, "002_insert_templates.sql");
fs.writeFileSync(outputPath, `${output.join("\n")}\n`);
console.log(`Generadas ${tables.length} plantillas INSERT en ${outputPath}`);