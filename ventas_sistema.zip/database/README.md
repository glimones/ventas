# Esquema inicial de la base de datos

El proyecto actual es una interfaz Next.js/TypeScript: los CRUD mantienen datos en estado del navegador y no hay ORM, driver SQL ni API conectada a persistencia. `001_schema.sql` es el punto de partida relacional para integrar esos módulos gradualmente, no una migración de datos existentes.

## Motor y ejecución

El script está escrito para PostgreSQL y usa comandos propios de `psql` para crear la base `sistema_ventas` si aún no existe y conectarse a ella. Se requiere un usuario PostgreSQL con permiso `CREATEDB`.

```sh
psql -U postgres -f database/001_schema.sql
```

Para usar otro nombre, reemplaza `sistema_ventas` tanto en la instrucción de creación como en `\connect` antes de ejecutar. El bloque de tablas es transaccional. Este archivo sirve como bootstrap inicial; los cambios posteriores deben versionarse como nuevas migraciones, no editarse sobre una base ya desplegada.

## Plantillas de INSERT

`002_insert_templates.sql` contiene una plantilla comentada por cada tabla. No se ejecuta directamente ni contiene registros de ejemplo: reemplaza los valores `REEMPLAZAR`/`TODO` con datos reales y descomenta únicamente las sentencias que vayas a cargar.

```sh
node database/generate-insert-templates.mjs
```

Ese comando vuelve a generar `002_insert_templates.sql` leyendo el esquema actual. Omite las columnas `IDENTITY`; al insertar una fila padre, recupera su clave con `RETURNING id` y utiliza ese valor real en las tablas relacionadas. Carga primero catálogos y tablas padre, después cabeceras y finalmente detalles. Para el vínculo opcional pedido/factura, crea primero el pedido sin factura asociada y actualiza el vínculo después.

No uses los valores de marcador (`0`, fechas `2000-01-01` o textos `REEMPLAZAR`) como datos reales. Inserta `password_hash` únicamente desde el backend con un hash seguro, nunca con una contraseña en claro.

## Cobertura

- Empresa, sucursales, puntos de emisión, usuarios, roles, permisos y auditoría.
- Terceros, perfiles explícitos de clientes y proveedores, monedas, formas de pago, impuestos y numeraciones.
- Productos, categorías, marcas, unidades, bodegas, ubicaciones, stock, lotes, compras y recepciones.
- Pedidos, facturas electrónicas de venta, detalle, pagos, impuestos, abonos, notas de crédito y despachos.
- Periodos, plan de cuentas, centros de costo y asientos con líneas.
- Cajas, cuentas bancarias, movimientos y conciliaciones.
- CRM, empleados, nómina y activos fijos/depreciaciones.

Los reportes (cartera, estados de cuenta, kardex, libro mayor, balances, IVA y KPI) deben obtenerse inicialmente mediante consultas sobre documentos y movimientos; no se almacenan como copias independientes. Los módulos todavía sin contrato de datos claro se incorporarán al definir su flujo y reglas.

## Decisiones pendientes para la integración

- Confirmar campos obligatorios, catálogos y estados de cada flujo con el negocio. Algunas pantallas y archivos `types.ts` existentes no coinciden.
- Definir reglas tributarias SRI vigentes, secuencias por establecimiento/punto de emisión, redondeos y conservación legal del XML.
- Definir si stock se calcula exclusivamente desde movimientos y cómo se registra cada despacho, devolución y ajuste.
- Validar en la API que los asientos contabilizados cuadren (total debe = total haber) y que el periodo esté abierto; un `CHECK` por fila no puede garantizar el balance del asiento completo.
- La autenticación del login actual es solo visual/estado de sesión del navegador. No almacenar contraseñas en claro: `usuarios.password_hash` espera hashes generados y verificados en servidor.
- Configurar `ON DELETE` y retención de documentos según políticas contables y fiscales antes de producción.

El script usa referencias FK compuestas con `empresa_id` para impedir cruces accidentales entre empresas. Los importes usan `NUMERIC`; la capa de API deberá convertirlos sin perder precisión.

## API inicial de clientes

La opción Cliente usa `GET`, `POST`, `PUT` y `DELETE /api/clientes`, con las consultas en `src/services/clientes.service.ts`. La lectura filtra `terceros.tipo = 'CLIENTE'`; la creación escribe en `terceros` y crea su perfil en `clientes` dentro de una transacción. La edición actualiza `terceros` y la eliminación lógica cambia `estado` a `INACTIVO`.

El primer bloque de catálogos persistentes usa `GET`, `POST`, `PUT` y baja lógica en `/api/domain-catalog/{formas-pago,sucursales,roles,impuestos}`. Está implementado por `src/services/domain-catalog.service.ts` y se limita a una lista blanca de tablas/columnas. El resto de pantallas genéricas muestra un aviso de que todavía mantiene datos locales; reportes y documentos con relaciones se integrarán con consultas/servicios específicos, no como CRUD de una tabla arbitraria.

Configura las variables de servidor usando `.env.example` como referencia:

- `DATABASE_URL`: cadena de conexión PostgreSQL; el último segmento es el nombre de la base de datos, por ejemplo `postgres`.
- `DATABASE_EMPRESA_ID`: ID existente de la empresa cuyos clientes se mostrarán y gestionarán.
- `DATABASE_SCHEMA`: esquema que contiene las tablas, por ejemplo `sistema_ventas`. La conexión lo configura en `search_path` y también incluye `public` como esquema alternativo.

Después de configurar `.env.local`, reinicia Next.js. La tabla `empresas` debe tener la empresa correspondiente y la tabla `clientes` debe existir según `001_schema.sql`. El login actual del frontend no es autenticación de servidor; protege la API antes de exponerla a usuarios o redes no confiables.