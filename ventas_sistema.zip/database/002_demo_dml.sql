-- DML ejecutable de demostracion para PostgreSQL desde DBeaver.
-- Inserta datos ficticios relacionados en las 65 tablas del esquema.
-- Solo se ejecuta si empresas esta vacia. No usar como migracion de datos reales.
-- Ejecutar despues de database/001_schema.sql.

BEGIN;

DO $$
DECLARE
    v_empresa_id BIGINT;
    v_sucursal_id BIGINT;
    v_punto_emision_id BIGINT;
    v_rol_id BIGINT;
    v_usuario_id BIGINT;
    v_cliente_tercero_id BIGINT;
    v_proveedor_tercero_id BIGINT;
    v_categoria_id BIGINT;
    v_marca_id BIGINT;
    v_unidad_id BIGINT;
    v_bodega_id BIGINT;
    v_bodega_destino_id BIGINT;
    v_ubicacion_id BIGINT;
    v_producto_id BIGINT;
    v_forma_pago_id BIGINT;
    v_impuesto_id BIGINT;
    v_orden_compra_id BIGINT;
    v_orden_compra_detalle_id BIGINT;
    v_factura_compra_id BIGINT;
    v_recepcion_id BIGINT;
    v_periodo_id BIGINT;
    v_cuenta_id BIGINT;
    v_cuenta_pasivo_id BIGINT;
    v_centro_costo_id BIGINT;
    v_asiento_id BIGINT;
    v_pedido_id BIGINT;
    v_factura_id BIGINT;
    v_nota_credito_id BIGINT;
    v_transferencia_id BIGINT;
    v_inventario_fisico_id BIGINT;
    v_cuenta_bancaria_id BIGINT;
    v_cuenta_bancaria_destino_id BIGINT;
    v_caja_id BIGINT;
    v_oportunidad_id BIGINT;
    v_empleado_id BIGINT;
    v_nomina_id BIGINT;
    v_activo_id BIGINT;
BEGIN
    IF EXISTS (SELECT 1 FROM empresas) THEN
        RAISE EXCEPTION 'Carga cancelada: empresas ya contiene registros. Este DML de demostracion solo admite una base vacia.';
    END IF;

    -- Moneda global
    INSERT INTO monedas (codigo, nombre, simbolo, estado)
    VALUES ('USD', 'Dolar estadounidense', '$', 'ACTIVA')
    ON CONFLICT (codigo) DO NOTHING;

    -- Empresa, sucursal, punto de emision y seguridad
    INSERT INTO empresas (nombre_comercial, nombre_legal, ruc, direccion, ciudad, pais, email, moneda_base, estado)
    VALUES ('Empresa Demo Ventas', 'Empresa Demo Ventas S.A.', '0999999999001', 'Av. Principal 100', 'Guayaquil', 'Ecuador', 'demo@example.test', 'USD', 'ACTIVA')
    RETURNING id INTO v_empresa_id;

    INSERT INTO sucursales (empresa_id, codigo, nombre, direccion, ciudad, responsable, estado)
    VALUES (v_empresa_id, '001', 'Matriz', 'Av. Principal 100', 'Guayaquil', 'Administrador Demo', 'ACTIVA')
    RETURNING id INTO v_sucursal_id;

    INSERT INTO puntos_emision (empresa_id, sucursal_id, codigo, nombre, direccion, estado)
    VALUES (v_empresa_id, v_sucursal_id, '001', 'Punto principal', 'Av. Principal 100', 'ACTIVO')
    RETURNING id INTO v_punto_emision_id;

    INSERT INTO roles (empresa_id, codigo, nombre, descripcion, estado)
    VALUES (v_empresa_id, 'ADMIN', 'Administrador', 'Rol de demostracion', 'ACTIVO')
    RETURNING id INTO v_rol_id;

    INSERT INTO usuarios (empresa_id, nombre, usuario, email, password_hash, estado)
    VALUES (v_empresa_id, 'Usuario Demo', 'demo', 'demo@example.test', 'REEMPLAZAR_CON_HASH_BCRYPT_REAL', 'ACTIVO')
    RETURNING id INTO v_usuario_id;

    INSERT INTO usuarios_roles (empresa_id, usuario_id, rol_id)
    VALUES (v_empresa_id, v_usuario_id, v_rol_id);

    INSERT INTO permisos (codigo, modulo, accion)
    VALUES ('facturas.leer', 'facturas', 'leer')
    RETURNING id INTO STRICT v_cuenta_id;

    INSERT INTO roles_permisos (rol_id, permiso_id)
    VALUES (v_rol_id, v_cuenta_id);

    INSERT INTO auditoria_eventos (empresa_id, usuario_id, modulo, accion, entidad, registro_id, datos, resultado)
    VALUES (v_empresa_id, v_usuario_id, 'sistema', 'carga_demo', 'empresas', v_empresa_id::text, '{"origen":"002_demo_dml"}'::jsonb, 'OK');

    -- Cliente y proveedor: los datos comunes se guardan en terceros.
    INSERT INTO terceros (empresa_id, tipo, tipo_documento, documento, nombre, apellido, razon_social, email, telefono, direccion, ciudad, pais, estado)
    VALUES (v_empresa_id, 'CLIENTE', 'RUC', '0990000001001', 'Cliente', 'Demo', 'Cliente Demo S.A.', 'cliente@example.test', '040000001', 'Calle Cliente 10', 'Guayaquil', 'Ecuador', 'ACTIVO')
    RETURNING id INTO v_cliente_tercero_id;

    INSERT INTO clientes (tercero_id, empresa_id, codigo_cliente, limite_credito, dias_credito, grupo)
    VALUES (v_cliente_tercero_id, v_empresa_id, 'CLI-DEMO-001', 5000, 30, 'General');

    INSERT INTO terceros (empresa_id, tipo, tipo_documento, documento, nombre, apellido, razon_social, email, telefono, direccion, ciudad, pais, estado)
    VALUES (v_empresa_id, 'PROVEEDOR', 'RUC', '0990000002001', 'Proveedor', 'Demo', 'Proveedor Demo S.A.', 'proveedor@example.test', '040000002', 'Calle Proveedor 20', 'Guayaquil', 'Ecuador', 'ACTIVO')
    RETURNING id INTO v_proveedor_tercero_id;

    INSERT INTO proveedores (tercero_id, empresa_id, codigo_proveedor, dias_credito, limite_credito, categoria)
    VALUES (v_proveedor_tercero_id, v_empresa_id, 'PROV-DEMO-001', 30, 10000, 'General');

    -- Parametros comerciales y tributarios
    INSERT INTO tipos_cambio (moneda_origen, moneda_destino, fecha, tasa)
    VALUES ('USD', 'USD', CURRENT_DATE, 1);

    INSERT INTO formas_pago (empresa_id, codigo, nombre, tipo, dias_credito, estado)
    VALUES (v_empresa_id, 'EFE', 'Efectivo', 'CONTADO', 0, 'ACTIVA')
    RETURNING id INTO v_forma_pago_id;

    INSERT INTO impuestos (empresa_id, codigo, nombre, tipo, porcentaje, codigo_sri, codigo_porcentaje_sri, vigente_desde, estado)
    VALUES (v_empresa_id, 'IVA-DEMO', 'IVA de demostracion', 'IVA', 15, '2', '4', CURRENT_DATE, 'ACTIVO')
    RETURNING id INTO v_impuesto_id;

    INSERT INTO numeraciones (empresa_id, punto_emision_id, tipo_documento, secuencial_actual, secuencial_maximo, estado)
    VALUES (v_empresa_id, v_punto_emision_id, 'FACTURA', 1, 999999999, 'ACTIVA');

    -- Catalogos e inventario
    INSERT INTO categorias_productos (empresa_id, codigo, nombre, margen_objetivo, estado)
    VALUES (v_empresa_id, 'CAT-DEMO', 'Categoria Demo', 25, 'ACTIVA')
    RETURNING id INTO v_categoria_id;

    INSERT INTO marcas (empresa_id, codigo, nombre, estado)
    VALUES (v_empresa_id, 'MAR-DEMO', 'Marca Demo', 'ACTIVA')
    RETURNING id INTO v_marca_id;

    INSERT INTO unidades_medida (empresa_id, codigo, nombre, abreviatura, estado)
    VALUES (v_empresa_id, 'UND', 'Unidad', 'und', 'ACTIVA')
    RETURNING id INTO v_unidad_id;

    INSERT INTO bodegas (empresa_id, sucursal_id, codigo, nombre, direccion, responsable, tipo, ciudad, estado)
    VALUES (v_empresa_id, v_sucursal_id, 'BOD-001', 'Bodega principal', 'Av. Principal 100', 'Administrador Demo', 'GENERAL', 'Guayaquil', 'ACTIVA')
    RETURNING id INTO v_bodega_id;

    INSERT INTO bodegas (empresa_id, sucursal_id, codigo, nombre, direccion, responsable, tipo, ciudad, estado)
    VALUES (v_empresa_id, v_sucursal_id, 'BOD-002', 'Bodega secundaria', 'Av. Secundaria 200', 'Administrador Demo', 'GENERAL', 'Guayaquil', 'ACTIVA')
    RETURNING id INTO v_bodega_destino_id;

    INSERT INTO ubicaciones_bodega (empresa_id, bodega_id, codigo, pasillo, estanteria, nivel, capacidad, ocupacion)
    VALUES (v_empresa_id, v_bodega_id, 'A-01-01', 'A', '01', '01', 100, 10)
    RETURNING id INTO v_ubicacion_id;

    INSERT INTO productos (empresa_id, codigo, nombre, descripcion, categoria_id, marca_id, unidad_medida_id, ubicacion_id, precio_compra, precio_venta, costo, stock_minimo, stock_maximo, controla_stock, estado)
    VALUES (v_empresa_id, 'PROD-DEMO-001', 'Producto Demo', 'Registro de prueba', v_categoria_id, v_marca_id, v_unidad_id, v_ubicacion_id, 10, 15, 10, 2, 100, TRUE, 'ACTIVO')
    RETURNING id INTO v_producto_id;

    INSERT INTO productos_proveedores (empresa_id, producto_id, proveedor_id, codigo_proveedor, costo_referencia)
    VALUES (v_empresa_id, v_producto_id, v_proveedor_tercero_id, 'PROV-PROD-001', 10);

    INSERT INTO stock_bodega (empresa_id, producto_id, bodega_id, cantidad)
    VALUES (v_empresa_id, v_producto_id, v_bodega_id, 10);

    INSERT INTO lotes (empresa_id, producto_id, bodega_id, numero_lote, fecha_fabricacion, fecha_vencimiento, cantidad_inicial, cantidad_actual)
    VALUES (v_empresa_id, v_producto_id, v_bodega_id, 'LOTE-DEMO-001', CURRENT_DATE, CURRENT_DATE + 365, 10, 10);

    -- Compras y recepcion
    INSERT INTO ordenes_compra (empresa_id, numero, proveedor_id, fecha_orden, fecha_entrega_requerida, tipo_orden, prioridad, estado, moneda, subtotal, impuesto_total, total, observaciones, creado_por)
    VALUES (v_empresa_id, 'OC-DEMO-001', v_proveedor_tercero_id, CURRENT_DATE, CURRENT_DATE + 7, 'NORMAL', 'NORMAL', 'APROBADA', 'USD', 10, 1.5, 11.5, 'Orden demo', v_usuario_id)
    RETURNING id INTO v_orden_compra_id;

    INSERT INTO ordenes_compra_detalle (empresa_id, orden_compra_id, producto_id, descripcion, cantidad, precio_unitario, impuesto, total)
    VALUES (v_empresa_id, v_orden_compra_id, v_producto_id, 'Producto Demo', 1, 10, 1.5, 11.5)
    RETURNING id INTO v_orden_compra_detalle_id;

    INSERT INTO facturas_compra (empresa_id, proveedor_id, orden_compra_id, numero_factura, identificacion_proveedor, fecha_emision, fecha_vencimiento, moneda, subtotal, impuesto_total, total, estado)
    VALUES (v_empresa_id, v_proveedor_tercero_id, v_orden_compra_id, 'FC-DEMO-001', '0990000002001', CURRENT_DATE, CURRENT_DATE + 30, 'USD', 10, 1.5, 11.5, 'REGISTRADA')
    RETURNING id INTO v_factura_compra_id;

    INSERT INTO facturas_compra_detalle (empresa_id, factura_compra_id, producto_id, descripcion, cantidad, precio_unitario, impuesto, total)
    VALUES (v_empresa_id, v_factura_compra_id, v_producto_id, 'Producto Demo', 1, 10, 1.5, 11.5);

    INSERT INTO recepciones_mercaderia (empresa_id, orden_compra_id, bodega_id, codigo, guia_remision, recibido_por, estado)
    VALUES (v_empresa_id, v_orden_compra_id, v_bodega_id, 'REC-DEMO-001', 'GR-DEMO-001', v_usuario_id, 'RECIBIDA')
    RETURNING id INTO v_recepcion_id;

    INSERT INTO recepciones_mercaderia_detalle (empresa_id, recepcion_id, orden_compra_detalle_id, producto_id, cantidad)
    VALUES (v_empresa_id, v_recepcion_id, v_orden_compra_detalle_id, v_producto_id, 1);

    -- Contabilidad
    INSERT INTO periodos_contables (empresa_id, codigo, fecha_inicio, fecha_fin, estado)
    VALUES (v_empresa_id, TO_CHAR(CURRENT_DATE, 'YYYY-MM'), DATE_TRUNC('month', CURRENT_DATE)::date, (DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month - 1 day')::date, 'ABIERTO')
    RETURNING id INTO v_periodo_id;

    INSERT INTO cuentas_contables (empresa_id, codigo, nombre, tipo, naturaleza, acepta_movimientos, estado)
    VALUES (v_empresa_id, '1.01.01', 'Caja', 'ACTIVO', 'DEUDORA', TRUE, 'ACTIVA')
    RETURNING id INTO v_cuenta_id;

    INSERT INTO cuentas_contables (empresa_id, codigo, nombre, tipo, naturaleza, acepta_movimientos, estado)
    VALUES (v_empresa_id, '2.01.01', 'Proveedores por pagar', 'PASIVO', 'ACREEDORA', TRUE, 'ACTIVA')
    RETURNING id INTO v_cuenta_pasivo_id;

    INSERT INTO centros_costos (empresa_id, codigo, nombre, responsable_id, presupuesto, estado)
    VALUES (v_empresa_id, 'CC-DEMO-001', 'Administracion', v_usuario_id, 1000, 'ACTIVO')
    RETURNING id INTO v_centro_costo_id;

    INSERT INTO asientos_contables (empresa_id, periodo_id, numero, fecha, descripcion, origen_modulo, estado, creado_por, contabilizado_por)
    VALUES (v_empresa_id, v_periodo_id, 'ASI-DEMO-001', CURRENT_DATE, 'Asiento de apertura demo', 'contabilidad', 'CONTABILIZADO', v_usuario_id, v_usuario_id)
    RETURNING id INTO v_asiento_id;

    INSERT INTO asientos_contables_detalle (empresa_id, asiento_id, linea, cuenta_id, centro_costo_id, descripcion, debe, haber, tercero_id)
    VALUES
        (v_empresa_id, v_asiento_id, 1, v_cuenta_id, v_centro_costo_id, 'Aporte inicial', 100, 0, NULL),
        (v_empresa_id, v_asiento_id, 2, v_cuenta_pasivo_id, v_centro_costo_id, 'Contrapartida', 0, 100, NULL);

    -- Pedido, factura, pago, abono y nota de credito
    INSERT INTO pedidos (empresa_id, codigo, cliente_id, fecha_pedido, fecha_entrega, subtotal, descuento, impuesto_total, total, vendedor_id, estado)
    VALUES (v_empresa_id, 'PED-DEMO-001', v_cliente_tercero_id, CURRENT_DATE, CURRENT_DATE + 2, 15, 0, 2.25, 17.25, v_usuario_id, 'PENDIENTE')
    RETURNING id INTO v_pedido_id;

    INSERT INTO pedidos_detalle (empresa_id, pedido_id, producto_id, descripcion, cantidad, precio_unitario, impuesto, total)
    VALUES (v_empresa_id, v_pedido_id, v_producto_id, 'Producto Demo', 1, 15, 2.25, 17.25);

    INSERT INTO facturas_venta (empresa_id, sucursal_id, punto_emision_id, cliente_id, pedido_id, numero, fecha_emision, fecha_vencimiento, moneda, subtotal, impuesto_total, total, estado, estado_sri, ambiente_sri, tipo_emision_sri, tipo_documento_sri, clave_acceso_sri, razon_social_emisor, nombre_comercial_emisor, ruc_emisor, direccion_matriz_emisor, direccion_establecimiento_emisor, obligado_contabilidad, tipo_identificacion_comprador, razon_social_comprador, identificacion_comprador, direccion_comprador, creado_por)
    VALUES (v_empresa_id, v_sucursal_id, v_punto_emision_id, v_cliente_tercero_id, v_pedido_id, '001-001-000000001', CURRENT_DATE, CURRENT_DATE + 30, 'USD', 15, 2.25, 17.25, 'EMITIDA', 'PENDIENTE', '1', '1', '01', 'CLAVE-ACCESO-DEMO-001', 'Empresa Demo Ventas S.A.', 'Empresa Demo Ventas', '0999999999001', 'Av. Principal 100', 'Av. Principal 100', TRUE, '04', 'Cliente Demo S.A.', '0990000001001', 'Calle Cliente 10', v_usuario_id)
    RETURNING id INTO v_factura_id;

    INSERT INTO facturas_venta_detalle (empresa_id, factura_id, linea, producto_id, codigo_principal, descripcion, cantidad, precio_unitario, base_imponible, impuesto_id, codigo_porcentaje_sri, tarifa_impuesto, valor_impuesto, total)
    VALUES (v_empresa_id, v_factura_id, 1, v_producto_id, 'PROD-DEMO-001', 'Producto Demo', 1, 15, 15, v_impuesto_id, '4', 15, 2.25, 17.25);

    INSERT INTO facturas_venta_pagos (empresa_id, factura_id, forma_pago_id, codigo_sri, importe, plazo, unidad_tiempo)
    VALUES (v_empresa_id, v_factura_id, v_forma_pago_id, '01', 17.25, 0, 'dias');

    INSERT INTO facturas_venta_impuestos (empresa_id, factura_id, impuesto_id, codigo_sri, codigo_porcentaje_sri, tarifa, base_imponible, valor)
    VALUES (v_empresa_id, v_factura_id, v_impuesto_id, '2', '4', 15, 15, 2.25);

    INSERT INTO abonos_clientes (empresa_id, factura_id, numero, importe, forma_pago_id, referencia, observacion, estado, creado_por)
    VALUES (v_empresa_id, v_factura_id, 'ABO-DEMO-001', 5, v_forma_pago_id, 'REF-DEMO-001', 'Abono de demostracion', 'APLICADO', v_usuario_id);

    INSERT INTO notas_credito_venta (empresa_id, factura_id, numero, fecha, motivo, subtotal, impuesto_total, total, estado)
    VALUES (v_empresa_id, v_factura_id, 'NC-DEMO-001', CURRENT_DATE, 'Nota de credito de demostracion', 1, 0.15, 1.15, 'BORRADOR')
    RETURNING id INTO v_nota_credito_id;

    INSERT INTO notas_credito_venta_detalle (empresa_id, nota_credito_id, producto_id, descripcion, cantidad, precio_unitario, impuesto, total)
    VALUES (v_empresa_id, v_nota_credito_id, v_producto_id, 'Ajuste demo', 1, 1, 0.15, 1.15);

    INSERT INTO despachos (empresa_id, codigo, pedido_id, cliente_id, bodega_id, transportista, guia_remision, fecha_despacho, estado)
    VALUES (v_empresa_id, 'DES-DEMO-001', v_pedido_id, v_cliente_tercero_id, v_bodega_id, 'Transportista Demo', 'GR-DEMO-001', now(), 'PENDIENTE');

    -- Movimientos, transferencias y conteo de inventario
    INSERT INTO movimientos_inventario (empresa_id, producto_id, bodega_id, tipo, cantidad, motivo, documento_tipo, documento_referencia, usuario_id)
    VALUES (v_empresa_id, v_producto_id, v_bodega_id, 'ENTRADA', 10, 'Saldo inicial demo', 'APERTURA', 'INV-DEMO-001', v_usuario_id);

    INSERT INTO transferencias_inventario (empresa_id, codigo, bodega_origen_id, bodega_destino_id, motivo, responsable_id, estado)
    VALUES (v_empresa_id, 'TRI-DEMO-001', v_bodega_id, v_bodega_destino_id, 'Transferencia de prueba', v_usuario_id, 'PENDIENTE')
    RETURNING id INTO v_transferencia_id;

    INSERT INTO transferencias_inventario_detalle (empresa_id, transferencia_id, producto_id, cantidad)
    VALUES (v_empresa_id, v_transferencia_id, v_producto_id, 1);

    INSERT INTO inventarios_fisicos (empresa_id, bodega_id, codigo, fecha_conteo, responsable_id, estado)
    VALUES (v_empresa_id, v_bodega_id, 'IF-DEMO-001', CURRENT_DATE, v_usuario_id, 'BORRADOR')
    RETURNING id INTO v_inventario_fisico_id;

    INSERT INTO inventarios_fisicos_detalle (empresa_id, inventario_fisico_id, producto_id, cantidad_sistema, cantidad_contada, costo_unitario)
    VALUES (v_empresa_id, v_inventario_fisico_id, v_producto_id, 10, 10, 10);

    -- Tesoreria
    INSERT INTO cuentas_bancarias (empresa_id, codigo, banco, numero_cuenta, tipo_cuenta, moneda, saldo_inicial, estado)
    VALUES (v_empresa_id, 'CTA-DEMO-001', 'Banco Demo', '0000000001', 'CORRIENTE', 'USD', 1000, 'ACTIVA')
    RETURNING id INTO v_cuenta_bancaria_id;

    INSERT INTO cuentas_bancarias (empresa_id, codigo, banco, numero_cuenta, tipo_cuenta, moneda, saldo_inicial, estado)
    VALUES (v_empresa_id, 'CTA-DEMO-002', 'Banco Demo', '0000000002', 'CORRIENTE', 'USD', 500, 'ACTIVA')
    RETURNING id INTO v_cuenta_bancaria_destino_id;

    INSERT INTO cajas (empresa_id, sucursal_id, codigo, nombre, ubicacion, responsable_id, moneda, saldo_inicial, estado)
    VALUES (v_empresa_id, v_sucursal_id, 'CAJ-DEMO-001', 'Caja principal', 'Matriz', v_usuario_id, 'USD', 100, 'ACTIVA')
    RETURNING id INTO v_caja_id;

    INSERT INTO movimientos_tesoreria (empresa_id, cuenta_bancaria_id, tipo, concepto, referencia, importe, documento_tipo, documento_id, usuario_id)
    VALUES (v_empresa_id, v_cuenta_bancaria_id, 'INGRESO', 'Deposito inicial demo', 'REF-BANCO-001', 100, 'APERTURA', 1, v_usuario_id);

    INSERT INTO transferencias_bancarias (empresa_id, codigo, cuenta_origen_id, cuenta_destino_id, beneficiario, fecha, importe, concepto, estado)
    VALUES (v_empresa_id, 'TB-DEMO-001', v_cuenta_bancaria_id, v_cuenta_bancaria_destino_id, 'Beneficiario Demo', CURRENT_DATE, 25, 'Transferencia de prueba', 'PENDIENTE');

    INSERT INTO conciliaciones_bancarias (empresa_id, cuenta_bancaria_id, periodo, fecha_conciliacion, saldo_libros, saldo_banco, diferencia, responsable_id, estado)
    VALUES (v_empresa_id, v_cuenta_bancaria_id, TO_CHAR(CURRENT_DATE, 'YYYY-MM'), CURRENT_DATE, 1100, 1100, 0, v_usuario_id, 'BORRADOR');

    -- CRM, personal y activos
    INSERT INTO oportunidades (empresa_id, cliente_id, prospecto_nombre, nombre, valor, etapa, cierre_estimado, responsable_id, estado)
    VALUES (v_empresa_id, v_cliente_tercero_id, 'Contacto Demo', 'Oportunidad Demo', 500, 'PROPUESTA', CURRENT_DATE + 30, v_usuario_id, 'ABIERTA')
    RETURNING id INTO v_oportunidad_id;

    INSERT INTO actividades_comerciales (empresa_id, oportunidad_id, tercero_id, tipo, asunto, contacto, fecha, responsable_id, resultado, proxima_accion, estado)
    VALUES (v_empresa_id, v_oportunidad_id, v_cliente_tercero_id, 'LLAMADA', 'Seguimiento demo', 'Contacto Demo', now(), v_usuario_id, 'Contacto realizado', 'Enviar propuesta', 'COMPLETADA');

    INSERT INTO empleados (empresa_id, codigo, tipo_documento, identificacion, nombres, apellidos, email, telefono, cargo, departamento, fecha_ingreso, sueldo_base, estado, usuario_id)
    VALUES (v_empresa_id, 'EMP-DEMO-001', 'CEDULA', '0990000003', 'Empleado', 'Demo', 'empleado@example.test', '040000003', 'Asistente', 'Administracion', CURRENT_DATE, 500, 'ACTIVO', v_usuario_id)
    RETURNING id INTO v_empleado_id;

    INSERT INTO nominas (empresa_id, codigo, periodo_inicio, periodo_fin, fecha_pago, total_ingresos, total_deducciones, total_neto, estado)
    VALUES (v_empresa_id, 'NOM-DEMO-001', DATE_TRUNC('month', CURRENT_DATE)::date, CURRENT_DATE, CURRENT_DATE, 500, 0, 500, 'BORRADOR')
    RETURNING id INTO v_nomina_id;

    INSERT INTO nominas_detalle (empresa_id, nomina_id, empleado_id, sueldo, beneficios, deducciones, neto, detalle)
    VALUES (v_empresa_id, v_nomina_id, v_empleado_id, 500, 0, 0, 500, '{"tipo":"demo"}'::jsonb);

    INSERT INTO activos_fijos (empresa_id, codigo, nombre, categoria, fecha_adquisicion, costo, valor_residual, vida_util_meses, metodo_depreciacion, estado)
    VALUES (v_empresa_id, 'AF-DEMO-001', 'Equipo Demo', 'Equipos', CURRENT_DATE, 1200, 0, 60, 'LINEA_RECTA', 'ACTIVO')
    RETURNING id INTO v_activo_id;

    INSERT INTO depreciaciones_activos (empresa_id, activo_id, periodo_id, valor_inicial, depreciacion, valor_neto, estado)
    VALUES (v_empresa_id, v_activo_id, v_periodo_id, 1200, 20, 1180, 'CALCULADA');

    INSERT INTO documentos_adjuntos (empresa_id, entidad, registro_id, nombre_archivo, mime_type, url_almacenamiento, subido_por)
    VALUES (v_empresa_id, 'facturas_venta', v_factura_id, 'documento-demo.pdf', 'application/pdf', 'https://example.test/documento-demo.pdf', v_usuario_id);
END $$;

COMMIT;
