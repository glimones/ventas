const fs = require('fs');
const path = require('path');

// Helper: convert folder name to PascalCase component name
function toPascalCase(str) {
  return str.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join('');
}

// Helper: singular Spanish name for labels
function toSingularLabel(name) {
  const map = {
    'tipos-cliente': 'Tipo de Cliente', 'grupos-clientes': 'Grupo de Clientes', 'sucursales': 'Sucursal',
    'estado-cuenta': 'Estado de Cuenta', 'proveedores': 'Proveedor', 'estado-cuenta-proveedor': 'Estado de Cuenta Proveedor',
    'clasificacion-proveedores': 'Clasificación de Proveedor', 'marcas': 'Marca', 'unidades-medida': 'Unidad de Medida',
    'lotes-series': 'Lote/Serie', 'transferencias': 'Transferencia', 'ajustes-inventario': 'Ajuste de Inventario',
    'kardex': 'Kardex', 'inventario-fisico': 'Inventario Físico', 'ubicaciones': 'Ubicación',
    'pedidos': 'Pedido', 'despachos': 'Despacho', 'devoluciones': 'Devolución',
    'estado-cuenta-clientes': 'Estado de Cuenta Cliente', 'recepcion-mercaderia': 'Recepción de Mercadería',
    'facturas-compra': 'Factura de Compra', 'devoluciones-proveedor': 'Devolución a Proveedor',
    'cuentas-por-pagar': 'Cuenta por Pagar', 'caja': 'Caja', 'apertura-cierre-caja': 'Apertura/Cierre de Caja',
    'movimientos-caja': 'Movimiento de Caja', 'bancos': 'Banco', 'transferencias-bancarias': 'Transferencia Bancaria',
    'conciliacion-bancaria': 'Conciliación Bancaria', 'cheques': 'Cheque', 'depositos': 'Depósito',
    'plan-cuentas': 'Plan de Cuentas', 'centros-costos': 'Centro de Costos', 'asientos-contables': 'Asiento Contable',
    'diario-general': 'Diario General', 'mayor-general': 'Mayor General', 'balance-comprobacion': 'Balance de Comprobación',
    'cierre-periodos': 'Cierre de Período', 'cierre-fiscal': 'Cierre Fiscal', 'configuracion-contable': 'Configuración Contable',
    'cartera': 'Cartera', 'abonos': 'Abono', 'anticipos': 'Anticipo', 'notas-credito-cxc': 'Nota de Crédito CxC',
    'estado-cuenta-cxc': 'Estado de Cuenta CxC', 'gestion-cobranza': 'Gestión de Cobranza', 'obligaciones': 'Obligación',
    'pagos': 'Pago', 'anticipos-cxp': 'Anticipo CxP', 'retenciones-cxp': 'Retención CxP',
    'estado-cuenta-cxp': 'Estado de Cuenta CxP', 'activos': 'Activo Fijo', 'depreciaciones': 'Depreciación',
    'revalorizaciones': 'Revalorización', 'bajas-activos': 'Baja de Activo', 'iva': 'IVA',
    'retenciones-tributacion': 'Retención', 'ats': 'ATS', 'anexos-tributarios': 'Anexo Tributario',
    'reportes-sri': 'Reporte SRI', 'empleados': 'Empleado', 'nomina': 'Nómina', 'vacaciones': 'Vacación',
    'prestamos': 'Préstamo', 'decimos': 'Décimo', 'liquidaciones': 'Liquidación', 'prospectos': 'Prospecto',
    'oportunidades': 'Oportunidad', 'actividades': 'Actividad', 'seguimiento-comercial': 'Seguimiento Comercial',
    'ventas': 'Reporte de Ventas', 'compras': 'Reporte de Compras', 'inventario': 'Reporte de Inventario',
    'financiero': 'Reporte Financiero', 'tributario': 'Reporte Tributario', 'gerencial': 'Reporte Gerencial',
    'dashboard-kpi': 'Dashboard KPI', 'monedas': 'Moneda', 'impuestos': 'Impuesto', 'formas-pago': 'Forma de Pago',
    'numeraciones': 'Numeración', 'configuracion-general': 'Configuración General',
  };
  return map[name] || name.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
}

function toPluralLabel(name) {
  const plurals = {
    'tipos-cliente': 'Tipos de Cliente', 'grupos-clientes': 'Grupos de Clientes', 'sucursales': 'Sucursales',
    'estado-cuenta': 'Estados de Cuenta', 'proveedores': 'Proveedores', 'estado-cuenta-proveedor': 'Estados de Cuenta Proveedores',
    'clasificacion-proveedores': 'Clasificaciones de Proveedores', 'marcas': 'Marcas', 'unidades-medida': 'Unidades de Medida',
    'lotes-series': 'Lotes/Series', 'transferencias': 'Transferencias', 'ajustes-inventario': 'Ajustes de Inventario',
    'kardex': 'Kardex', 'inventario-fisico': 'Inventario Físico', 'ubicaciones': 'Ubicaciones',
    'pedidos': 'Pedidos', 'despachos': 'Despachos', 'devoluciones': 'Devoluciones',
    'estado-cuenta-clientes': 'Estados de Cuenta Clientes', 'recepcion-mercaderia': 'Recepción de Mercadería',
    'facturas-compra': 'Facturas de Compra', 'devoluciones-proveedor': 'Devoluciones a Proveedores',
    'cuentas-por-pagar': 'Cuentas por Pagar', 'caja': 'Caja', 'apertura-cierre-caja': 'Apertura/Cierre de Caja',
    'movimientos-caja': 'Movimientos de Caja', 'bancos': 'Bancos', 'transferencias-bancarias': 'Transferencias Bancarias',
    'conciliacion-bancaria': 'Conciliación Bancaria', 'cheques': 'Cheques', 'depositos': 'Depósitos',
    'plan-cuentas': 'Plan de Cuentas', 'centros-costos': 'Centros de Costos', 'asientos-contables': 'Asientos Contables',
    'diario-general': 'Diario General', 'mayor-general': 'Mayor General', 'balance-comprobacion': 'Balance de Comprobación',
    'cierre-periodos': 'Cierres de Período', 'cierre-fiscal': 'Cierre Fiscal', 'configuracion-contable': 'Configuración Contable',
    'cartera': 'Cartera', 'abonos': 'Abonos', 'anticipos': 'Anticipos', 'notas-credito-cxc': 'Notas de Crédito CxC',
    'estado-cuenta-cxc': 'Estados de Cuenta CxC', 'gestion-cobranza': 'Gestión de Cobranza', 'obligaciones': 'Obligaciones',
    'pagos': 'Pagos', 'anticipos-cxp': 'Anticipos CxP', 'retenciones-cxp': 'Retenciones CxP',
    'estado-cuenta-cxp': 'Estados de Cuenta CxP', 'activos': 'Activos Fijos', 'depreciaciones': 'Depreciaciones',
    'revalorizaciones': 'Revalorizaciones', 'bajas-activos': 'Bajas de Activos', 'iva': 'IVA',
    'retenciones-tributacion': 'Retenciones', 'ats': 'ATS', 'anexos-tributarios': 'Anexos Tributarios',
    'reportes-sri': 'Reportes SRI', 'empleados': 'Empleados', 'nomina': 'Nómina', 'vacaciones': 'Vacaciones',
    'prestamos': 'Préstamos', 'decimos': 'Décimos', 'liquidaciones': 'Liquidaciones', 'prospectos': 'Prospectos',
    'oportunidades': 'Oportunidades', 'actividades': 'Actividades', 'seguimiento-comercial': 'Seguimiento Comercial',
    'ventas': 'Reportes de Ventas', 'compras': 'Reportes de Compras', 'inventario': 'Reportes de Inventario',
    'financiero': 'Reportes Financieros', 'tributario': 'Reportes Tributarios', 'gerencial': 'Reportes Gerenciales',
    'dashboard-kpi': 'Dashboard KPI', 'monedas': 'Monedas', 'impuestos': 'Impuestos', 'formas-pago': 'Formas de Pago',
    'numeraciones': 'Numeraciones', 'configuracion-general': 'Configuración General',
  };
  return plurals[name] || name.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) + 's';
}

const BT = '`';

function generateTypes(componentName) {
  return `export interface ${componentName} {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}

export interface ${componentName}FormValues {
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}
`;
}

function generateForm(componentName) {
  return `'use client';
import React from 'react';
import { ${componentName}FormValues } from './types';

interface Props {
  values: ${componentName}FormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const ${componentName}Form: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre' className='form-label'>Nombre *</label>
          <input type='text' className='form-control' id='nombre' name='nombre' value={values.nombre || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-12'>
        <div className='mb-3'>
          <label htmlFor='descripcion' className='form-label'>Descripción</label>
          <textarea className='form-control' id='descripcion' name='descripcion' value={values.descripcion || ''} onChange={handleInputChange} rows={3} autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='fecha' className='form-label'>Fecha</label>
          <input type='date' className='form-control' id='fecha' name='fecha' value={values.fecha || ''} onChange={handleInputChange} autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default ${componentName}Form;
`;
}

function generateModal(componentName, label) {
  return `import React, { useEffect } from 'react';
import { ${componentName}FormValues } from './types';
import ${componentName}Form from './${componentName}Form';

interface Props {
  show: boolean;
  editando: boolean;
  values: ${componentName}FormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

const ${componentName}Modal: React.FC<Props> = ({ show, editando, values, onChange, onClose, onSubmit }) => {
  useEffect(() => {
    if (show) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [show]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && show) {
        onClose();
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [show, onClose]);

  if (!show) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div className='modal-overlay' onClick={handleBackdropClick} style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0, 0, 0, 0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1050, padding: '20px' }}>
      <div className='modal-container' style={{ background: 'white', borderRadius: '12px', width: '100%', maxWidth: '800px', maxHeight: '95vh', overflow: 'hidden', boxShadow: '0 20px 60px rgba(0, 0, 0, 0.3)', display: 'flex', flexDirection: 'column' }}>
        <form onSubmit={onSubmit}>
          <div className='modal-header text-white' style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: '#343a40' }}>
            <h5 className='modal-title'>{editando ? 'Editar ${label}' : 'Nuevo ${label}'}</h5>
            <button type='button' className='btn-close btn-close-white' onClick={onClose} aria-label='Cerrar' style={{ filter: 'brightness(0) invert(1)' }} />
          </div>
          <div className='modal-body' style={{ padding: '1.5rem', overflowY: 'auto', maxHeight: 'calc(85vh - 140px)' }}>
            <${componentName}Form values={values} onChange={onChange} />
          </div>
          <div className='modal-footer' style={{ padding: '1rem 1.5rem', display: 'flex', justifyContent: 'flex-end', gap: '0.5rem', borderTop: '1px solid #dee2e6', background: '#f8f9fa' }}>
            <button type='button' className='btn btn-secondary' onClick={onClose}>Cancelar</button>
            <button type='submit' className='btn btn-primary'>{editando ? 'Actualizar' : 'Guardar'}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ${componentName}Modal;
`;
}

function generatePage(moduleName, componentName, label, pluralLabel) {
  const badgeClass = BT + 'badge bg-${item.estado === \'Activo\' ? \'success\' : \'secondary\'}' + BT;
  return `'use client';
import React, { useState } from 'react';
import { ${componentName}, ${componentName}FormValues } from './types';
import ${componentName}Modal from './${componentName}Modal';
import './bootstrap-${moduleName}.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: ${componentName}FormValues = {
  codigo: '',
  nombre: '',
  descripcion: '',
  fecha: '',
  estado: 'Activo',
};

const initialData: ${componentName}[] = [
  { id: 1, codigo: '001', nombre: '${label} Ejemplo 1', descripcion: 'Descripción de ejemplo', fecha: '2025-01-15', estado: 'Activo' },
  { id: 2, codigo: '002', nombre: '${label} Ejemplo 2', descripcion: 'Otra descripción', fecha: '2025-02-20', estado: 'Inactivo' },
];

export default function ${componentName}Page() {
  const [data, setData] = useState<${componentName}[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<${componentName}FormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (item: ${componentName}) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      nombre: item.nombre || '',
      descripcion: item.descripcion || '',
      fecha: item.fecha || '',
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, codigo: form.codigo, nombre: form.nombre, descripcion: form.descripcion, fecha: form.fecha, estado: form.estado }
          : item
      ));
    } else {
      const nuevo: ${componentName} = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        codigo: form.codigo,
        nombre: form.nombre,
        descripcion: form.descripcion,
        fecha: form.fecha,
        estado: form.estado,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre.toLowerCase().includes(filtro.toLowerCase()) ||
    item.descripcion.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>${pluralLabel}</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Fecha</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.nombre}</td>
                  <td>{item.descripcion}</td>
                  <td>{item.fecha}</td>
                  <td>
                    <span className={${badgeClass}}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <${componentName}Modal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
`;
}

function generatePageTsx(componentName, appPath) {
  return `import { AppShell } from '${appPath}';
import ${componentName}Page from './${componentName}Page';

export default function Page() {
  return (
    <AppShell>
      <${componentName}Page />
    </AppShell>
  );
}
`;
}

function generateCss(pluralLabel) {
  return `/* Aislamiento de Bootstrap para que no afecte a elementos fuera del contenedor */
.bootstrap-container {
  @import 'bootstrap/dist/css/bootstrap.min.css';
}

/* Anular completamente cualquier estilo que Bootstrap pueda aplicar al menú */
:root {
  --sidebar-width: 240px;
}

body {
  overflow-x: hidden;
}

/* Estilos para restaurar el menú lateral a su posición y apariencia original */
.sidebar-wrapper {
  position: fixed !important;
  left: 0 !important;
  top: 0 !important;
  height: 100vh !important;
  width: var(--sidebar-width) !important;
  transform: none !important;
}

.sidebar-wrapper a,
.sidebar-wrapper button,
.sidebar-wrapper [data-sidebar="menu-button"],
.sidebar-wrapper [data-sidebar="menu-sub-button"],
.sidebar-wrapper [data-slot="sidebar-menu-button"],
.sidebar-wrapper [data-slot="sidebar-menu-sub-button"] {
  text-decoration: none !important;
  box-shadow: none !important;
  border-bottom: none !important;
  outline: none !important;
  font-style: normal !important;
}

/* Asegurar que el contenido principal esté correctamente posicionado */
.main-content {
  margin-left: var(--sidebar-width) !important;
  width: calc(100% - var(--sidebar-width)) !important;
}

/* $${pluralLabel} - estilos específicos */
.modal-overlay {
  animation: fadeIn 0.2s ease;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.table-responsive {
  border-radius: 8px;
  overflow: hidden;
}

.table th {
  font-weight: 600;
  font-size: 0.875rem;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
`;
}

// Main generation
const baseDir = 'src/app';
const allModules = [
  // Domain-specific modules are maintained manually and must not be regenerated.
];

let count = 0;
for (const modulePath of allModules) {
  const folderName = path.basename(modulePath);
  const componentName = toPascalCase(folderName);
  const label = toSingularLabel(folderName);
  const pluralLabel = toPluralLabel(folderName);
  
  const depth = modulePath.split('/').length;
  const appPath = '@/components/app-shell';
  
  const dir = path.join(baseDir, modulePath);
  
  fs.writeFileSync(path.join(dir, 'types.ts'), generateTypes(componentName));
  fs.writeFileSync(path.join(dir, componentName + 'Form.tsx'), generateForm(componentName));
  fs.writeFileSync(path.join(dir, componentName + 'Modal.tsx'), generateModal(componentName, label));
  fs.writeFileSync(path.join(dir, componentName + 'Page.tsx'), generatePage(folderName, componentName, label, pluralLabel));
  fs.writeFileSync(path.join(dir, 'page.tsx'), generatePageTsx(componentName, appPath));
  fs.writeFileSync(path.join(dir, 'bootstrap-' + folderName + '.css'), generateCss(pluralLabel));
  
  count++;
}

console.log('Generated ' + count + ' modules with 6 files each = ' + (count * 6) + ' files total');