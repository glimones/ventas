import { getDatabasePool, getEmpresaId } from "@/lib/db";

type CatalogField = {
  column: string;
  required?: boolean;
  kind?: "status" | "paymentType";
};

type CatalogDefinition = {
  table: string;
  companyScoped: boolean;
  activeState: string;
  inactiveState: string;
  fields: Record<string, CatalogField>;
};

const definitions: Record<string, CatalogDefinition> = {
  "formas-pago": {
    table: "formas_pago",
    companyScoped: true,
    activeState: "ACTIVA",
    inactiveState: "INACTIVA",
    fields: {
      codigo: { column: "codigo", required: true },
      nombre: { column: "nombre", required: true },
      dias_credito: { column: "dias_credito" },
      tipo: { column: "tipo", required: true, kind: "paymentType" },
      estado: { column: "estado", kind: "status" },
    },
  },
  sucursales: {
    table: "sucursales",
    companyScoped: true,
    activeState: "ACTIVA",
    inactiveState: "INACTIVA",
    fields: {
      codigo: { column: "codigo", required: true },
      nombre: { column: "nombre", required: true },
      direccion: { column: "direccion" },
      telefono: { column: "telefono" },
      responsable: { column: "responsable" },
      estado: { column: "estado", kind: "status" },
    },
  },
  roles: {
    table: "roles",
    companyScoped: true,
    activeState: "ACTIVO",
    inactiveState: "INACTIVO",
    fields: {
      codigo: { column: "codigo", required: true },
      nombre: { column: "nombre", required: true },
      descripcion: { column: "descripcion" },
      estado: { column: "estado", kind: "status" },
    },
  },
  impuestos: {
    table: "impuestos",
    companyScoped: true,
    activeState: "ACTIVO",
    inactiveState: "INACTIVO",
    fields: {
      codigo: { column: "codigo", required: true },
      nombre: { column: "nombre", required: true },
      tipo: { column: "tipo", required: true },
      porcentaje: { column: "porcentaje", required: true },
      estado: { column: "estado", kind: "status" },
    },
  },
};

function getDefinition(resource: string) {
  const definition = definitions[resource];
  if (!definition) throw new Error("CATALOG_NOT_SUPPORTED");
  return definition;
}

function fromDatabase(field: CatalogField, value: unknown) {
  if (value == null) return "";
  if (field.kind === "status") {
    return String(value).startsWith("INACT") ? "Inactivo" : "Activo";
  }
  if (field.kind === "paymentType") {
    const normalized = String(value);
    return normalized === "CREDITO" ? "Crédito" : normalized === "CONTADO" ? "Contado" : "Otro";
  }
  return value;
}

function toDatabase(field: CatalogField, value: unknown) {
  if (field.kind === "paymentType") {
    const normalized = String(value).toLowerCase();
    if (normalized.startsWith("cr")) return "CREDITO";
    if (normalized.startsWith("con")) return "CONTADO";
    return "OTRO";
  }
  if (value === "" || value == null) return null;
  if (field.column === "dias_credito" || field.column === "porcentaje") return Number(value);
  return value;
}

function statusValue(definition: CatalogDefinition, value: unknown) {
  return String(value).toLowerCase() === "inactivo"
    ? definition.inactiveState
    : definition.activeState;
}

function mapRow(resource: string, definition: CatalogDefinition, row: Record<string, unknown>) {
  const result: Record<string, unknown> = { id: Number(row.id) };
  for (const [fieldName, field] of Object.entries(definition.fields)) {
    result[fieldName] = field.kind === "status"
      ? (String(row[field.column]).startsWith("INACT") ? "Inactivo" : "Activo")
      : fromDatabase(field, row[field.column]);
  }
  return result;
}

export async function listDomainCatalog(resource: string) {
  const definition = getDefinition(resource);
  const columns = [...new Set(Object.values(definition.fields).map((field) => field.column))];
  const scopeClause = definition.companyScoped ? "WHERE empresa_id = $1" : "";
  const values = definition.companyScoped ? [getEmpresaId()] : [];
  const result = await getDatabasePool().query(
    `SELECT id, ${columns.join(", ")} FROM ${definition.table} ${scopeClause} ORDER BY id`,
    values,
  );

  return result.rows.map((row) => mapRow(resource, definition, row));
}

export async function saveDomainCatalog(
  resource: string,
  input: Record<string, unknown>,
  id?: number,
) {
  const definition = getDefinition(resource);
  const entries = Object.entries(definition.fields).filter(([name]) => name in input);
  const missingField = Object.entries(definition.fields).find(
    ([name, field]) => field.required && !(name in input),
  );
  if (missingField) throw new Error(`FIELD_REQUIRED:${missingField[0]}`);
  if (entries.some(([name, field]) => field.required && String(input[name] ?? "").trim() === "")) {
    throw new Error("FIELD_REQUIRED");
  }

  const companyId = definition.companyScoped ? getEmpresaId() : null;
  const columns = entries.map(([, field]) => field.column);
  const values = entries.map(([name, field]) =>
    field.kind === "status" ? statusValue(definition, input[name]) : toDatabase(field, input[name]),
  );

  if (id !== undefined) {
    const setValues = [...values, id];
    const companyFilter = definition.companyScoped
      ? ` AND empresa_id = $${setValues.length + 1}`
      : "";
    if (definition.companyScoped) setValues.push(companyId);
    const assignments = columns.map((column, index) => `${column} = $${index + 1}`).join(", ");
    const result = await getDatabasePool().query(
      `UPDATE ${definition.table} SET ${assignments} WHERE id = $${values.length + 1}${companyFilter} RETURNING id`,
      setValues,
    );
    return result.rowCount ? id : null;
  }

  if (definition.companyScoped) {
    columns.unshift("empresa_id");
    values.unshift(companyId);
  }
  const placeholders = values.map((_, index) => `$${index + 1}`).join(", ");
  const result = await getDatabasePool().query(
    `INSERT INTO ${definition.table} (${columns.join(", ")}) VALUES (${placeholders}) RETURNING id`,
    values,
  );
  return Number(result.rows[0].id);
}

export async function deactivateDomainCatalog(resource: string, id: number) {
  const definition = getDefinition(resource);
  if (!definition.fields.estado) throw new Error("CATALOG_DELETE_NOT_SUPPORTED");

  const state = statusValue(definition, "Inactivo");
  const values = definition.companyScoped ? [state, id, getEmpresaId()] : [state, id];
  const companyClause = definition.companyScoped ? " AND empresa_id = $3" : "";
  const result = await getDatabasePool().query(
    `UPDATE ${definition.table} SET estado = $1 WHERE id = $2${companyClause} RETURNING id`,
    values,
  );
  return (result.rowCount ?? 0) > 0;
}