"use client"
import {  BarChart3,  BrickWallShield, Building2, Calculator, CircleUserRound, ClipboardList, Cog, CreditCard, Factory, FileText, FolderPlus, Landmark, NotebookText, PackageSearch, Receipt, ReceiptText, Scale, ShoppingCart, Tags, Truck, Users, Wallet, Wrench } from "lucide-react"
import { usePathname } from "next/navigation"
import React, { useState } from "react"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,  
  SidebarProvider,
} from "@/components/ui/sidebar"
import { NavMain } from "./nav-main"

// Tipos para los items del menú
import { type LucideIcon } from "lucide-react"

interface SubMenuItem {
  title: string;
  url: string;
}

interface MenuItem {
  title: string;
  url: string;
  icon?: LucideIcon;
  isActive: boolean;
  items?: SubMenuItem[];
}

// Menu items.
const normalizeUrl = (url: string) => (url === "#" ? url : url.startsWith("/") ? url : `/${url}`);

const items: MenuItem[] = [
  {
    title: "Empresas",
    url: "/empresa",
    icon: Building2,
    isActive: false,
  },
  {
    title: "Clientes",
    url: "#",
    icon: CircleUserRound,
    isActive: false,
    items: [
      { title: "Clientes", url: "/cliente" },
      { title: "Tipos de Cliente", url: "/cliente/tipos-cliente" },
      { title: "Grupos de Clientes", url: "/cliente/grupos-clientes" },
      { title: "Sucursales", url: "/cliente/sucursales" },
      { title: "Estado de Cuenta", url: "/cliente/estado-cuenta" },
    ],
  },
  {
    title: "Proveedores",
    url: "#",
    icon: Truck,
    isActive: false,
    items: [
      { title: "Proveedores", url: "/proveedores" },
      { title: "Estado de Cuenta", url: "/proveedores/estado-cuenta" },
      { title: "Clasificación", url: "/proveedores/clasificacion" },
    ],
  },
  {
    title: "Inventario",
    url: "#",
    icon: PackageSearch,
    isActive: false,
    items: [
      { title: "Productos", url: "/productos" },
      { title: "Categorías", url: "/categorias" },
      { title: "Marcas", url: "/marcas" },
      { title: "Unidades de Medida", url: "/unidades-medida" },
      { title: "Lotes/Series", url: "/lotes-series" },
      { title: "Bodegas", url: "/bodegas" },
      { title: "Ubicaciones", url: "/ubicaciones" },
      { title: "Transferencias", url: "/transferencias" },
      { title: "Ajustes de Inventario", url: "/ajustes-inventario" },
      { title: "Movimientos", url: "/movimientos" },
      { title: "Kardex", url: "/kardex" },
      { title: "Inventario Físico", url: "/inventario-fisico" },
    ],
  },
  {
    title: "Ventas",
    url: "#",
    icon: ShoppingCart,
    isActive: false,
    items: [
      { title: "Pedidos", url: "/pedidos" },
      { title: "Despachos", url: "/despachos" },
      { title: "Devoluciones", url: "/devoluciones" },
      { title: "Estado de Cuenta", url: "/estado-cuenta-clientes" },
    ],
  },
  {
    title: "Compras",
    url: "#",
    icon: Scale,
    isActive: false,
    items: [
      { title: "Solicitudes de Compra", url: "/solicitudes-compra" },
      { title: "Órdenes de Compra", url: "/ordenes-compra" },
      { title: "Cotizaciones", url: "/cotizaciones" },
      { title: "Recepción de Mercadería", url: "/recepcion-mercaderia" },
      { title: "Facturas de Compra", url: "/facturas-compra" },
      { title: "Devoluciones a Proveedor", url: "/devoluciones-proveedor" },
      { title: "Cuentas por Pagar", url: "/cuentas-por-pagar" },
    ],
  },
  {
    title: "Comprobantes Electrónicos",
    url: "#",
    icon: Receipt,
    isActive: false,
    items: [
      { title: "Facturas", url: "/facturas" },
      { title: "Notas de Crédito", url: "/notas-credito" },
      { title: "Notas de Débito", url: "/notas-debito" },
      { title: "Comprobantes de Retención", url: "/comprobantes-retencion" },
      { title: "Guías de Remisión", url: "/guias-remision" },
      { title: "Liquidaciones de Compra", url: "/liquidaciones-compra" },
      { title: "Solicitudes de Pedido", url: "/solicitudes-pedido" },
    ],
  },
  {
    title: "Tesorería",
    url: "#",
    icon: Landmark,
    isActive: false,
    items: [
      { title: "Caja", url: "/caja" },
      { title: "Apertura/Cierre de Caja", url: "/apertura-cierre-caja" },
      { title: "Movimientos de Caja", url: "/movimientos-caja" },
      { title: "Bancos", url: "/bancos" },
      { title: "Transferencias Bancarias", url: "/transferencias-bancarias" },
      { title: "Conciliación Bancaria", url: "/conciliacion-bancaria" },
      { title: "Cheques", url: "/cheques" },
      { title: "Depósitos", url: "/depositos" },
    ],
  },
  {
    title: "Contabilidad",
    url: "#",
    icon: Calculator,
    isActive: false,
    items: [
      { title: "Plan de Cuentas", url: "/plan-cuentas" },
      { title: "Centros de Costos", url: "/centros-costos" },
      { title: "Asientos Contables", url: "/asientos-contables" },
      { title: "Diario General", url: "/diario-general" },
      { title: "Mayor General", url: "/mayor-general" },
      { title: "Balance de Comprobación", url: "/balance-comprobacion" },
      { title: "Cierre de Períodos", url: "/cierre-periodos" },
      { title: "Cierre Fiscal", url: "/cierre-fiscal" },
      { title: "Configuración Contable", url: "/configuracion-contable" },
    ],
  },
  {
    title: "Cuentas por Cobrar",
    url: "#",
    icon: CreditCard,
    isActive: false,
    items: [
      { title: "Cartera", url: "/cartera" },
      { title: "Abonos", url: "/abonos" },
      { title: "Anticipos", url: "/anticipos" },
      { title: "Notas de Crédito CxC", url: "/notas-credito-cxc" },
      { title: "Estado de Cuenta CxC", url: "/estado-cuenta-cxc" },
      { title: "Gestión de Cobranza", url: "/gestion-cobranza" },
    ],
  },
  {
    title: "Cuentas por Pagar",
    url: "#",
    icon: ReceiptText,
    isActive: false,
    items: [
      { title: "Obligaciones", url: "/obligaciones" },
      { title: "Pagos", url: "/pagos" },
      { title: "Anticipos CxP", url: "/anticipos-cxp" },
      { title: "Retenciones CxP", url: "/retenciones-cxp" },
      { title: "Estado de Cuenta CxP", url: "/estado-cuenta-cxp" },
    ],
  },
  {
    title: "Activos Fijos",
    url: "#",
    icon: Factory,
    isActive: false,
    items: [
      { title: "Activos", url: "/activos" },
      { title: "Depreciaciones", url: "/depreciaciones" },
      { title: "Revalorizaciones", url: "/revalorizaciones" },
      { title: "Bajas de Activos", url: "/bajas-activos" },
    ],
  },
  {
    title: "Tributación",
    url: "#",
    icon: FileText,
    isActive: false,
    items: [
      { title: "IVA", url: "/iva" },
      { title: "Retenciones", url: "/retenciones-tributacion" },
      { title: "ATS", url: "/ats" },
      { title: "Anexos Tributarios", url: "/anexos-tributarios" },
      { title: "Reportes SRI", url: "/reportes-sri" },
    ],
  },
  {
    title: "RRHH",
    url: "#",
    icon: Users,
    isActive: false,
    items: [
      { title: "Empleados", url: "/empleados" },
      { title: "Nómina", url: "/nomina" },
      { title: "Vacaciones", url: "/vacaciones" },
      { title: "Préstamos", url: "/prestamos" },
      { title: "Décimos", url: "/decimos" },
      { title: "Liquidaciones", url: "/liquidaciones" },
    ],
  },
  {
    title: "CRM",
    url: "#",
    icon: ClipboardList,
    isActive: false,
    items: [
      { title: "Prospectos", url: "/prospectos" },
      { title: "Oportunidades", url: "/oportunidades" },
      { title: "Actividades", url: "/actividades" },
      { title: "Seguimiento Comercial", url: "/seguimiento-comercial" },
    ],
  },
  {
    title: "Reportes",
    url: "#",
    icon: BarChart3,
    isActive: false,
    items: [
      { title: "Dashboard KPI", url: "/reportes/dashboard-kpi" },
      { title: "Reportes de Ventas", url: "/reportes/ventas" },
      { title: "Reportes de Compras", url: "/reportes/compras" },
      { title: "Reportes de Inventario", url: "/reportes/inventario" },
      { title: "Reportes Financieros", url: "/reportes/financiero" },
      { title: "Reportes Tributarios", url: "/reportes/tributario" },
      { title: "Reportes Gerenciales", url: "/reportes/gerencial" },
    ],
  },
  {
    title: "Parámetros",
    url: "#",
    icon: Wrench,
    isActive: false,
    items: [
      { title: "Monedas", url: "/parametros/monedas" },
      { title: "Impuestos", url: "/parametros/impuestos" },
      { title: "Formas de Pago", url: "/parametros/formas-pago" },
      { title: "Numeraciones", url: "/parametros/numeraciones" },
      { title: "Sucursales", url: "/parametros/sucursales" },
      { title: "Puntos de Emisión", url: "/parametros/puntos-emision" },
      { title: "Configuración General", url: "/parametros/configuracion-general" },
    ],
  },
  {
    title: "Seguridad",
    url: "#",
    icon: BrickWallShield,
    isActive: false,
    items: [
      { title: "Usuarios", url: "/seguridad/usuarios" },
      { title: "Roles", url: "/seguridad/roles" },
      { title: "Permisos Usuarios", url: "/seguridad/permisos-usuarios" },
      { title: "Auditoría", url: "/seguridad/auditoria" },
      { title: "Bitácora", url: "/seguridad/bitacora" },
      { title: "Configuración", url: "/seguridad/configuracion" },
    ],
  },
]


export function AppSidebarMenu() {
  const pathname = usePathname();
  const [openGroup, setOpenGroup] = useState<string | null>(null);
  
  const isItemActive = (item: MenuItem) => {
    if (item.items) {
      return item.items.some((subItem: SubMenuItem) => {
        if (subItem.url === "#") return false;
        return pathname.includes(normalizeUrl(subItem.url));
      });
    }
    if (item.url === "#") return false;
    return pathname.includes(normalizeUrl(item.url));
  };
  
  const dynamicItems = items.map(item => ({
    ...item,
    isActive: isItemActive(item)
  }));

  React.useEffect(() => {
    const activeGroup = items.find(item => {
      if (!item.items) return false;
      return item.items.some(subItem => {
        if (subItem.url === "#") return false;
        return pathname.includes(normalizeUrl(subItem.url));
      });
    });
    if (activeGroup) {
      setOpenGroup(activeGroup.title);
    }
  }, [pathname]);

  const handleGroupToggle = (groupTitle: string, hasItems: boolean) => {
    if (!hasItems) return;
    setOpenGroup(prevOpen => 
      prevOpen === groupTitle ? null : groupTitle
    );
  };

  return (
      <SidebarProvider className="h-full min-h-0 w-full text-left">
        <Sidebar collapsible="none" className="h-full border-r border-black/10 bg-white text-left">
          <SidebarContent className="items-stretch text-left">
            <SidebarGroup className="items-stretch text-left">
              <SidebarGroupContent className="text-left">
                <NavMain 
                  items={dynamicItems} 
                  openGroup={openGroup}
                  onGroupToggle={handleGroupToggle}
                />           
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>
      </SidebarProvider>
  )
}