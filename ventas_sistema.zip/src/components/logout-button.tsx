"use client";

import { LogOut } from "lucide-react";

export function LogoutButton() {
  function handleLogout() {
    window.sessionStorage.removeItem("ventas-session");
    window.location.assign("/");
  }

  return (
    <button
      type="button"
      aria-label="Cerrar sesión"
      title="Cerrar sesión"
      onClick={handleLogout}
      className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-white/8 text-white transition-colors hover:bg-white hover:text-black"
    >
      <LogOut className="h-4.5 w-4.5" />
    </button>
  );
}