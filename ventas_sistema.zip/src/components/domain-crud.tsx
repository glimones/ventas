'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { CirclePlus, SquarePen, Trash2, X } from 'lucide-react';

export interface DomainField {
  name: string;
  label: string;
  type?: string;
}

export interface DomainConfig {
  title: string;
  search: string;
  resource?: string;
  fields: DomainField[];
  sample: Record<string, string | number>;
}

type DomainRow = { id: number } & Record<string, string | number>;

export default function DomainCrud({ config }: { config: DomainConfig }) {
  const [rows, setRows] = useState<DomainRow[]>(
    config.resource ? [] : [{ id: 1, ...config.sample }],
  );
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<number | null>(null);
  const [form, setForm] = useState<Record<string, string | number>>({ ...config.sample });
  const [loading, setLoading] = useState(Boolean(config.resource));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const loadRows = useCallback(async () => {
    if (!config.resource) return;
    setLoading(true);
    try {
      const response = await fetch(
        `/api/domain-catalog/${encodeURIComponent(config.resource)}`,
        { cache: 'no-store' },
      );
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || 'No se pudieron cargar los datos.');
      setRows(body as DomainRow[]);
      setError('');
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Error al cargar los datos.');
    } finally {
      setLoading(false);
    }
  }, [config.resource]);

  useEffect(() => {
    if (config.resource) void loadRows();
  }, [config.resource, loadRows]);

  function close() {
    setOpen(false);
    setEditing(null);
    setForm({ ...config.sample });
  }

  async function save(event: React.FormEvent) {
    event.preventDefault();
    setSaving(true);
    setError('');
    try {
      if (config.resource) {
        const response = await fetch(
          `/api/domain-catalog/${encodeURIComponent(config.resource)}`,
          {
            method: editing === null ? 'POST' : 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(
              editing === null ? form : { id: editing, values: form },
            ),
          },
        );
        const body = await response.json();
        if (!response.ok) throw new Error(body.error || 'No se pudo guardar el registro.');
        await loadRows();
      } else {
        setRows(previous => editing === null
          ? [...previous, { id: Date.now(), ...form }]
          : previous.map(row => row.id === editing ? { ...row, ...form } : row));
      }
      close();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Error al guardar.');
    } finally {
      setSaving(false);
    }
  }

  async function remove(id: number) {
    if (!window.confirm('¿Deseas desactivar este registro?')) return;
    if (!config.resource) {
      setRows(previous => previous.filter(row => row.id !== id));
      return;
    }

    try {
      const response = await fetch(
        `/api/domain-catalog/${encodeURIComponent(config.resource)}`,
        {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id }),
        },
      );
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || 'No se pudo desactivar el registro.');
      await loadRows();
    } catch (removeError) {
      setError(removeError instanceof Error ? removeError.message : 'Error al desactivar.');
    }
  }

  const filtered = rows.filter(row =>
    Object.values(row).join(' ').toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">{config.title}</h1>
        <div className="d-flex justify-content-between mb-3">
          <input
            className="form-control w-50"
            placeholder={config.search}
            value={query}
            onChange={event => setQuery(event.target.value)}
          />
          <button
            className="btn btn-primary"
            onClick={() => {
              setForm({ ...config.sample });
              setEditing(null);
              setOpen(true);
            }}
          >
            <CirclePlus size={16} className="me-2" />Añadir
          </button>
        </div>
        {!config.resource && (
          <div className="alert alert-warning" role="status">
            Este módulo todavía usa datos locales y no guarda cambios en PostgreSQL.
          </div>
        )}
        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead>
              <tr>
                {config.fields.map(field => <th key={field.name}>{field.label}</th>)}
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {loading && <tr><td colSpan={config.fields.length + 1} className="text-center">Cargando...</td></tr>}
              {!loading && filtered.map(row => (
                <tr key={row.id}>
                  {config.fields.map(field => <td key={field.name}>{row[field.name]}</td>)}
                  <td>
                    <button
                      className="btn btn-warning btn-sm me-1"
                      onClick={() => {
                        setEditing(row.id);
                        setForm({ ...row });
                        setOpen(true);
                      }}
                      aria-label="Editar"
                    >
                      <SquarePen size={15} />
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => void remove(row.id)}
                      aria-label="Desactivar"
                    >
                      <Trash2 size={15} />
                    </button>
                  </td>
                </tr>
              ))}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={config.fields.length + 1} className="text-center">No hay registros.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        {open && (
          <div className="modal d-block" tabIndex={-1} role="dialog">
            <div className="modal-dialog modal-lg">
              <div className="modal-content">
                <form onSubmit={save}>
                  <div className="modal-header">
                    <h5 className="modal-title">
                      {editing === null ? `Nuevo ${config.title}` : `Editar ${config.title}`}
                    </h5>
                    <button type="button" className="btn-close" onClick={close} aria-label="Cerrar">
                      <X size={16} />
                    </button>
                  </div>
                  <div className="modal-body row g-3">
                    {config.fields.map(field => {
                      const inputId = `${config.resource ?? config.title}-${field.name}`;
                      return (
                        <div className="col-md-6" key={field.name}>
                          <label className="form-label" htmlFor={inputId}>{field.label}</label>
                          <input
                            className="form-control"
                            id={inputId}
                            name={field.name}
                            type={field.type || 'text'}
                            value={form[field.name] ?? ''}
                            onChange={event => setForm(previous => ({
                              ...previous,
                              [field.name]: field.type === 'number'
                                ? Number(event.target.value)
                                : event.target.value,
                            }))}
                            required
                          />
                        </div>
                      );
                    })}
                  </div>
                  <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" onClick={close} disabled={saving}>Cancelar</button>
                    <button type="submit" className="btn btn-success" disabled={saving}>
                      {saving ? 'Guardando...' : 'Guardar'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}