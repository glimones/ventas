"use client";

import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  FileText,
  LockKeyhole,
} from "lucide-react";
import { type FormEvent, useEffect, useState } from "react";

type AccessState = "checking" | "signed-out" | "signed-in";

export function AuthGate({ children }: { children: React.ReactNode }) {
  const [accessState, setAccessState] = useState<AccessState>("checking");

  useEffect(() => {
    setAccessState(
      window.sessionStorage.getItem("ventas-session") === "active"
        ? "signed-in"
        : "signed-out",
    );
  }, []);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    window.sessionStorage.setItem("ventas-session", "active");
    setAccessState("signed-in");
  }

  if (accessState === "checking") {
    return <div className="min-h-screen bg-[#f8f9fa]" aria-busy="true" />;
  }

  if (accessState === "signed-in") {
    return children;
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#f1f2f3] px-5 py-10">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-lg bg-white shadow-[0_18px_60px_rgba(20,24,28,0.12)] md:min-h-[560px] md:grid-cols-[1.05fr_0.95fr]">
        <section className="order-2 relative flex flex-col justify-between overflow-hidden bg-[#212529] px-8 py-9 text-white md:order-1 md:px-12 md:py-12">
          <div className="absolute inset-y-0 right-0 w-1 bg-lime-500" />
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-white/55">
              Gestión empresarial
            </p>
            <h1 className="mt-3 max-w-sm text-3xl font-semibold leading-tight">
              Sistema de Ventas
            </h1>
            <p className="mt-3 max-w-sm text-sm leading-6 text-white/65">
              Gestión comercial, financiera y contable en un solo lugar.
            </p>
          </div>
          <div
            role="img"
            aria-label="Vista ilustrativa del sistema contable con resumen de ingresos y movimientos recientes"
            className="my-8 rounded-md border border-white/10 bg-white p-4 text-[#212529] shadow-[0_18px_40px_rgba(0,0,0,0.22)] sm:p-5"
          >
            <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded bg-[#212529] text-lime-400">
                  <BarChart3 className="h-4 w-4" aria-hidden="true" />
                </div>
                <div>
                  <p className="text-xs font-semibold">Resumen contable</p>
                  <p className="text-[10px] text-neutral-500">Período actual</p>
                </div>
              </div>
              <span className="rounded-sm bg-lime-100 px-2 py-1 text-[10px] font-medium text-lime-800">
                Al día
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3 py-4">
              <div className="rounded border border-neutral-200 p-3">
                <p className="text-[10px] text-neutral-500">Ingresos del mes</p>
                <p className="mt-1 text-lg font-semibold">$24,850</p>
                <p className="mt-1 flex items-center gap-1 text-[10px] font-medium text-green-700">
                  <ArrowUpRight className="h-3 w-3" aria-hidden="true" /> 12.8%
                </p>
              </div>
              <div className="rounded border border-neutral-200 p-3">
                <p className="text-[10px] text-neutral-500">Asientos registrados</p>
                <p className="mt-1 text-lg font-semibold">186</p>
                <div className="mt-2 flex items-center gap-1 text-[10px] text-neutral-500">
                  <FileText className="h-3 w-3" aria-hidden="true" /> Último: hoy
                </div>
              </div>
            </div>
            <div className="flex h-20 items-end gap-2 rounded border border-neutral-200 bg-neutral-50 px-4 pt-3">
              {[35, 52, 42, 68, 49, 82, 61, 92, 70, 100, 78, 88].map(
                (height, index) => (
                  <div
                    key={index}
                    className="flex-1 rounded-t-sm bg-[#212529]"
                    style={{ height: `${height}%` }}
                  />
                ),
              )}
            </div>
            <div className="mt-3 flex items-center justify-between text-[10px] text-neutral-500">
              <span>Movimientos recientes</span>
              <span>Ver todos</span>
            </div>
          </div>
          <p className="mt-12 text-xs text-white/45">Motorizado por GLM</p>
        </section>

        <section className="order-1 flex items-center px-7 py-10 sm:px-12 md:order-2 md:px-14">
          <div className="mx-auto w-full max-w-sm">
            <div className="mb-8 flex h-11 w-11 items-center justify-center rounded-md bg-[#f1f2f3] text-[#212529]">
              <LockKeyhole className="h-5 w-5" aria-hidden="true" />
            </div>
            <p className="text-sm font-medium text-neutral-500">Bienvenido</p>
            <h2 className="mt-1 text-2xl font-semibold text-[#212529]">
              Iniciar sesión
            </h2>

            <form className="mt-8 space-y-5" onSubmit={handleSubmit}>
              <div>
                <label
                  htmlFor="username"
                  className="mb-2 block text-sm font-medium text-neutral-700"
                >
                  Usuario
                </label>
                <input
                  id="username"
                  name="username"
                  type="text"
                  autoComplete="username"
                  required
                  className="h-11 w-full rounded-md border border-neutral-300 bg-white px-3 text-sm text-neutral-900 outline-none transition focus:border-[#212529] focus:ring-2 focus:ring-neutral-900/10"
                  placeholder="Ingresa tu usuario"
                />
              </div>
              <div>
                <label
                  htmlFor="password"
                  className="mb-2 block text-sm font-medium text-neutral-700"
                >
                  Contraseña
                </label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  className="h-11 w-full rounded-md border border-neutral-300 bg-white px-3 text-sm text-neutral-900 outline-none transition focus:border-[#212529] focus:ring-2 focus:ring-neutral-900/10"
                  placeholder="Ingresa tu contraseña"
                />
              </div>
              <button
                type="submit"
                className="flex h-11 w-full items-center justify-center gap-2 rounded-md bg-[#212529] px-4 text-sm font-semibold text-white transition-colors hover:bg-[#1c1f23] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neutral-500 focus-visible:ring-offset-2"
              >
                Entrar al sistema
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </button>
            </form>
          </div>
        </section>
      </div>
    </main>
  );
}