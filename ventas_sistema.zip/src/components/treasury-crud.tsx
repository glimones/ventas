'use client';
import React, { useState } from 'react';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

export interface TreasuryField { name: string; label: string; type?: string; }
interface Props { title: string; searchPlaceholder: string; fields: TreasuryField[]; initialForm: any; initialData: any[]; Modal: React.ComponentType<any>; css: string; }

export default function TreasuryCrudPage({ title, searchPlaceholder, fields, initialForm, initialData, Modal, css }: Props) {
  const [data, setData] = useState(initialData); const [query, setQuery] = useState(''); const [show, setShow] = useState(false); const [editId, setEditId] = useState<number | null>(null); const [form, setForm] = useState(initialForm);
  const close = () => { setShow(false); setEditId(null); setForm(initialForm); };
  const edit = (item: any) => { setEditId(item.id); setForm({ ...item }); setShow(true); };
  const change = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setForm((p: any) => ({ ...p, [e.target.name]: e.target.type === 'number' ? Number(e.target.value) : e.target.value }));
  const submit = (e: React.FormEvent) => { e.preventDefault(); setData((p: any[]) => editId === null ? [...p, { ...form, id: Date.now() }] : p.map(x => x.id === editId ? { ...x, ...form } : x)); close(); };
  const rows = data.filter(item => Object.values(item).join(' ').toLowerCase().includes(query.toLowerCase()));
  return <div className="bootstrap-container"><div className="content-wrapper"><h1 className="mb-4">{title}</h1><div className="d-flex justify-content-between mb-3"><input className="form-control w-50" placeholder={searchPlaceholder} value={query} onChange={e => setQuery(e.target.value)} /><button className="btn btn-primary" onClick={() => setShow(true)}><CirclePlus size={16} className="me-2" />Añadir</button></div><div className="table-responsive"><table className="table table-striped"><thead><tr>{fields.map(f => <th key={f.name}>{f.label}</th>)}<th>Acciones</th></tr></thead><tbody>{rows.map(item => <tr key={item.id}>{fields.map(f => <td key={f.name}>{typeof item[f.name] === 'number' && ['monto','saldo','importe','valor','balance'].some(x => f.name.includes(x)) ? `$${Number(item[f.name]).toFixed(2)}` : item[f.name]}</td>)}<td><button className="btn btn-warning btn-sm me-1" onClick={() => edit(item)}><SquarePen size={15} /></button><button className="btn btn-danger btn-sm" onClick={() => setData(p => p.filter(x => x.id !== item.id))}><Trash2 size={15} /></button></td></tr>)}</tbody></table></div><Modal show={show} editando={editId !== null} values={form} onChange={change} onClose={close} onSubmit={submit} /></div></div>;
}