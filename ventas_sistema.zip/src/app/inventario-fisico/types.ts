export interface InventarioFisico {
  id: number;
  codigo: string;
  bodega: string;
  fecha_conteo: string;
  responsable: string;
  productos_contados: number;
  diferencias: number;
  valor_diferencia: number;
  fecha: string;
  estado: string;
}

export interface InventarioFisicoFormValues {
  codigo: string;
  bodega: string;
  fecha_conteo: string;
  responsable: string;
  productos_contados: number;
  diferencias: number;
  valor_diferencia: number;
  fecha: string;
  estado: string;
}
