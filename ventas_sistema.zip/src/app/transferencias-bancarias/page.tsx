import { AppShell } from '@/components/app-shell';
import TransferenciasBancariasPage from './TransferenciasBancariasPage';

export default function Page() {
  return (
    <AppShell>
      <TransferenciasBancariasPage />
    </AppShell>
  );
}
