import DomainCrud from "@/components/domain-crud";
import { domainConfigs } from "@/components/domain-config";

export default function PermisosUsuariosPage() {
  return <DomainCrud config={domainConfigs['seguridad/permisos-usuarios']} />;
}