export interface Vacaciones {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}

export interface VacacionesFormValues {
  codigo: string;
  nombre: string;
  descripcion: string;
  fecha: string;
  estado: string;
}
