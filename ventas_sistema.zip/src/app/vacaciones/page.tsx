import { AppShell } from '@/components/app-shell';
import VacacionesPage from './VacacionesPage';

export default function Page() {
  return (
    <AppShell>
      <VacacionesPage />
    </AppShell>
  );
}
