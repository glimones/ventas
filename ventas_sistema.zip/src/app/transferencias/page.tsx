import { AppShell } from '@/components/app-shell';
import TransferenciasPage from './TransferenciasPage';

export default function Page() {
  return (
    <AppShell>
      <TransferenciasPage />
    </AppShell>
  );
}
