export interface Transferencias {
  id: number;
  codigo: string;
  producto: string;
  bodega_origen: string;
  bodega_destino: string;
  cantidad: number;
  fecha: string;
  responsable: string;
  motivo: string;
  estado: string;
}

export interface TransferenciasFormValues {
  codigo: string;
  producto: string;
  bodega_origen: string;
  bodega_destino: string;
  cantidad: number;
  fecha: string;
  responsable: string;
  motivo: string;
  estado: string;
}
