'use client';
import React, { useState } from 'react';
import { Proveedores, ProveedoresFormValues } from './types';
import ProveedoresModal from './ProveedoresModal';
import './bootstrap-proveedores.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: ProveedoresFormValues = {
  codigo: '',
  razon_social: '',
  nombre_comercial: '',
  tipo_identificacion: '',
  identificacion: '',
  categoria: '',
  contacto: '',
  email: '',
  telefono: '',
  ciudad: '',
  condiciones_pago: '',
  dias_credito: 0,
  estado: 'Activo',
};

const initialData: Proveedores[] = [
  { id: 1, codigo: 'PROV-001', razon_social: 'Suministros Andinos S.A.', nombre_comercial: 'Suministros Andinos', tipo_identificacion: 'RUC', identificacion: '1799876543001', categoria: 'Suministros de oficina', contacto: 'Laura Cedeño', email: 'compras@suministrosandinos.ec', telefono: '02 245 8010', ciudad: 'Quito', condiciones_pago: 'CREDITO', dias_credito: 30, estado: 'Activo' },
  { id: 2, codigo: 'PROV-002', razon_social: 'Tecnología Empresarial Cía. Ltda.', nombre_comercial: 'TecnoEmpresarial', tipo_identificacion: 'RUC', identificacion: '1790012345001', categoria: 'Tecnología', contacto: 'Andrés Molina', email: 'ventas@tecnoempresarial.ec', telefono: '02 398 2210', ciudad: 'Quito', condiciones_pago: 'CONTADO', dias_credito: 0, estado: 'Activo' },
];

export default function ProveedoresPage() {
  const [data, setData] = useState<Proveedores[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ProveedoresFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (item: Proveedores) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      razon_social: item.razon_social || '',
      nombre_comercial: item.nombre_comercial || '',
      tipo_identificacion: item.tipo_identificacion || '',
      identificacion: item.identificacion || '',
      categoria: item.categoria || '',
      contacto: item.contacto || '',
      email: item.email || '',
      telefono: item.telefono || '',
      ciudad: item.ciudad || '',
      condiciones_pago: item.condiciones_pago || '',
      dias_credito: item.dias_credito || 0,
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.name === 'dias_credito' ? Number(e.target.value) : e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, ...form }
          : item
      ));
    } else {
      const nuevo: Proveedores = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        ...form,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.razon_social.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre_comercial.toLowerCase().includes(filtro.toLowerCase()) ||
    item.identificacion.toLowerCase().includes(filtro.toLowerCase()) ||
    item.categoria.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Proveedores</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Razón social</th>
                <th>Identificación</th>
                <th>Categoría</th>
                <th>Contacto</th>
                <th>Condiciones</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td><strong>{item.razon_social}</strong><br /><small className='text-muted'>{item.nombre_comercial}</small></td>
                  <td>{item.tipo_identificacion}: {item.identificacion}</td>
                  <td>{item.categoria}</td>
                  <td>{item.contacto}<br /><small className='text-muted'>{item.telefono}</small></td>
                  <td>{item.condiciones_pago === 'CREDITO' ? `${item.dias_credito} días` : 'Contado'}</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <ProveedoresModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
