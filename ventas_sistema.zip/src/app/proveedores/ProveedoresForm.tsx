'use client';
import React from 'react';
import { ProveedoresFormValues } from './types';

interface Props {
  values: ProveedoresFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const ProveedoresForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='tipo_identificacion' className='form-label'>Tipo de identificación *</label>
          <select className='form-select' id='tipo_identificacion' name='tipo_identificacion' value={values.tipo_identificacion || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='RUC'>RUC</option>
            <option value='CEDULA'>Cédula</option>
            <option value='PASAPORTE'>Pasaporte</option>
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='identificacion' className='form-label'>Identificación *</label>
          <input type='text' className='form-control' id='identificacion' name='identificacion' value={values.identificacion || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='razon_social' className='form-label'>Razón social *</label>
          <input type='text' className='form-control' id='razon_social' name='razon_social' value={values.razon_social || ''} onChange={handleInputChange} required autoComplete='organization' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre_comercial' className='form-label'>Nombre comercial</label>
          <input type='text' className='form-control' id='nombre_comercial' name='nombre_comercial' value={values.nombre_comercial || ''} onChange={handleInputChange} autoComplete='organization' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='categoria' className='form-label'>Categoría / modelo de negocio *</label>
          <input type='text' className='form-control' id='categoria' name='categoria' value={values.categoria || ''} onChange={handleInputChange} required placeholder='Ej. Tecnología, servicios, suministros' autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='contacto' className='form-label'>Persona de contacto *</label>
          <input type='text' className='form-control' id='contacto' name='contacto' value={values.contacto || ''} onChange={handleInputChange} required autoComplete='name' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='email' className='form-label'>Correo electrónico</label>
          <input type='email' className='form-control' id='email' name='email' value={values.email || ''} onChange={handleInputChange} autoComplete='email' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='telefono' className='form-label'>Teléfono</label>
          <input type='tel' className='form-control' id='telefono' name='telefono' value={values.telefono || ''} onChange={handleInputChange} autoComplete='tel' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='ciudad' className='form-label'>Ciudad</label>
          <input type='text' className='form-control' id='ciudad' name='ciudad' value={values.ciudad || ''} onChange={handleInputChange} autoComplete='address-level2' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='condiciones_pago' className='form-label'>Condiciones de pago *</label>
          <select className='form-select' id='condiciones_pago' name='condiciones_pago' value={values.condiciones_pago || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='CONTADO'>Contado</option>
            <option value='CREDITO'>Crédito</option>
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='dias_credito' className='form-label'>Días de crédito</label>
          <input type='number' min='0' className='form-control' id='dias_credito' name='dias_credito' value={values.dias_credito || 0} onChange={handleInputChange} disabled={values.condiciones_pago !== 'CREDITO'} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default ProveedoresForm;
