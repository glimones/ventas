export interface Proveedores {
  id: number;
  codigo: string;
  razon_social: string;
  nombre_comercial: string;
  tipo_identificacion: string;
  identificacion: string;
  categoria: string;
  contacto: string;
  email: string;
  telefono: string;
  ciudad: string;
  condiciones_pago: string;
  dias_credito: number;
  estado: string;
}

export interface ProveedoresFormValues {
  codigo: string;
  razon_social: string;
  nombre_comercial: string;
  tipo_identificacion: string;
  identificacion: string;
  categoria: string;
  contacto: string;
  email: string;
  telefono: string;
  ciudad: string;
  condiciones_pago: string;
  dias_credito: number;
  estado: string;
}
