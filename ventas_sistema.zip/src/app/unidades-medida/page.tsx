import { AppShell } from '@/components/app-shell';
import UnidadesMedidaPage from './UnidadesMedidaPage';

export default function Page() {
  return (
    <AppShell>
      <UnidadesMedidaPage />
    </AppShell>
  );
}
