export interface UnidadesMedida {
  id: number;
  codigo: string;
  nombre: string;
  abreviatura: string;
  tipo: string;
  factor_conversion: number;
  estado: string;
}

export interface UnidadesMedidaFormValues {
  codigo: string;
  nombre: string;
  abreviatura: string;
  tipo: string;
  factor_conversion: number;
  estado: string;
}
