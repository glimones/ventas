'use client';
import React from 'react';
import { UnidadesMedidaFormValues } from './types';

interface Props {
  values: UnidadesMedidaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const UnidadesMedidaForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre' className='form-label'>Nombre *</label>
          <input type='text' className='form-control' id='nombre' name='nombre' value={values.nombre || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-12'>
        <div className='mb-3'>
          <label htmlFor='abreviatura' className='form-label'>Abreviatura *</label>
          <input type='text' className='form-control' id='abreviatura' name='abreviatura' value={values.abreviatura || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='tipo' className='form-label'>Tipo de unidad *</label>
          <select className='form-select' id='tipo' name='tipo' value={values.tipo || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='CANTIDAD'>Cantidad</option>
            <option value='PESO'>Peso</option>
            <option value='VOLUMEN'>Volumen</option>
            <option value='LONGITUD'>Longitud</option>
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='factor_conversion' className='form-label'>Factor de conversión</label>
          <input type='number' min='0.0001' step='0.0001' className='form-control' id='factor_conversion' name='factor_conversion' value={values.factor_conversion || 1} onChange={handleInputChange} required />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default UnidadesMedidaForm;
