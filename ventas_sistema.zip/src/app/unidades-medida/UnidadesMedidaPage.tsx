'use client';
import React, { useState } from 'react';
import { UnidadesMedida, UnidadesMedidaFormValues } from './types';
import UnidadesMedidaModal from './UnidadesMedidaModal';
import './bootstrap-unidades-medida.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: UnidadesMedidaFormValues = {
  codigo: '',
  nombre: '',
  abreviatura: '',
  tipo: '',
  factor_conversion: 1,
  estado: 'Activo',
};

const initialData: UnidadesMedida[] = [
  { id: 1, codigo: 'UND', nombre: 'Unidad', abreviatura: 'und', tipo: 'CANTIDAD', factor_conversion: 1, estado: 'Activo' },
  { id: 2, codigo: 'KG', nombre: 'Kilogramo', abreviatura: 'kg', tipo: 'PESO', factor_conversion: 1, estado: 'Activo' },
];

export default function UnidadesMedidaPage() {
  const [data, setData] = useState<UnidadesMedida[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<UnidadesMedidaFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (item: UnidadesMedida) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      nombre: item.nombre || '',
      abreviatura: item.abreviatura || '',
      tipo: item.tipo || '',
      factor_conversion: item.factor_conversion || 1,
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.name === 'factor_conversion' ? Number(e.target.value) : e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, ...form }
          : item
      ));
    } else {
      const nuevo: UnidadesMedida = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        ...form,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre.toLowerCase().includes(filtro.toLowerCase()) ||
    item.abreviatura.toLowerCase().includes(filtro.toLowerCase()) ||
    item.tipo.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Unidades de Medida</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Abreviatura</th>
                <th>Tipo</th>
                <th>Factor</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={8} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.nombre}</td>
                  <td>{item.abreviatura}</td>
                  <td>{item.tipo}</td>
                  <td>{item.factor_conversion}</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <UnidadesMedidaModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
