"use client";

import React, { useState } from "react";
import { Categoria, CategoriaFormValues } from "./types";
import CategoriaModal from "./CategoriaModal";
import { CirclePlus, SquarePen, Trash2 } from "lucide-react";

const initialForm: CategoriaFormValues = {
  codigo: "",
  nombre: "",
  categoria_padre: "",
  margen_objetivo: 0,
  estado: "Activo",
};

const initialCategorias: Categoria[] = [
  {
    id: 1,
    codigo: "CAT001",
    nombre: "Electrónica",
    categoria_padre: "",
    margen_objetivo: 25,
    estado: "Activo",
  },
  {
    id: 2,
    codigo: "CAT002",
    nombre: "Ropa",
    categoria_padre: "",
    margen_objetivo: 35,
    estado: "Activo",
  },
  {
    id: 3,
    codigo: "CAT003",
    nombre: "Hogar",
    categoria_padre: "",
    margen_objetivo: 20,
    estado: "Activo",
  },
];

export default function CategoriasPage() {
  const [categorias, setCategorias] = useState<Categoria[]>(initialCategorias);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<CategoriaFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (categoria: Categoria) => {
    setForm({
      codigo: categoria.codigo ?? "",
      nombre: categoria.nombre ?? "",
      categoria_padre: categoria.categoria_padre ?? "",
      margen_objetivo: categoria.margen_objetivo ?? 0,
      estado: categoria.estado ?? "Activo",
    });
    setEditandoId(categoria.id);
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: name === "margen_objetivo" ? Number(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId) {
      setCategorias((prev) => prev.map((c) => (c.id === editandoId ? { ...c, ...form } : c)));
    } else {
      setCategorias((prev) => [...prev, { ...form, id: Date.now() }]);
    }
    cerrarModal();
  };

  const eliminarCategoria = (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta categoría?")) {
      setCategorias((prev) => prev.filter((c) => c.id !== id));
    }
  };

  const categoriasFiltradas = categorias.filter((c) =>
    Object.values(c)
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-0">Categorías</h1>
        <p className="text-muted">Gestión de categorías de productos</p>

        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar categoría..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-primary d-flex align-items-center" onClick={abrirModalNueva} type="button">
            <CirclePlus className="me-2" size={16} />
            <span>Añadir Categoría</span>
          </button>
        </div>

        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Categoría padre</th>
                <th>Margen objetivo</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {categoriasFiltradas.length === 0 && (
                <tr>
                  <td colSpan={6} className="text-center">
                    No se encontraron categorías
                  </td>
                </tr>
              )}
              {categoriasFiltradas.map((categoria) => (
                <tr key={categoria.id}>
                  <td>{categoria.codigo}</td>
                  <td>{categoria.nombre}</td>
                  <td>{categoria.categoria_padre || "Principal"}</td>
                  <td>{categoria.margen_objetivo}%</td>
                  <td>
                    <span
                      className={`badge bg-${
                        categoria.estado === "Activo" ? "success" : "secondary"
                      }`}
                    >
                      {categoria.estado}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex align-items-center">
                      <button
                        className="btn btn-warning d-flex align-items-center me-1"
                        onClick={() => abrirModalEditar(categoria)}
                        type="button"
                      >
                        <SquarePen className="me-2" size={16} />
                        <span>Editar</span>
                      </button>
                      <button
                        className="btn btn-danger d-flex align-items-center me-2"
                        onClick={() => eliminarCategoria(categoria.id)}
                        type="button"
                      >
                        <Trash2 className="me-2" size={16} />
                        <span>Eliminar</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <CategoriaModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
