﻿'use client';

import React, { useState, useCallback } from 'react';
import { Bodega, BodegaFormValues } from './types';
import BodegaModal from './BodegaModal';
import './bootstrap-bodegas.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: BodegaFormValues = {
  nombre: '',
  codigo: '',
  ubicacion: '',
  responsable: '',
  capacidad: '',
  tipo: '',
  ciudad: '',
  telefono: '',
  estado: 'Activo',
  notas: '',
};

const initialBodegas: Bodega[] = [
  {
    id: 1,
    nombre: 'Bodega Principal',
    codigo: 'BOD-001',
    ubicacion: 'Av. Industrial 100, Zona Norte',
    responsable: 'Carlos Ramírez',
    capacidad: 500,
    tipo: 'General',
    ciudad: 'Quito',
    telefono: '022345678',
    estado: 'Activo',
    notas: 'Bodega principal de distribución',
  },
  {
    id: 2,
    nombre: 'Bodega Materia Prima',
    codigo: 'BOD-002',
    ubicacion: 'Calle 45 Sur, Parque Industrial',
    responsable: 'Ana Lucía Torres',
    capacidad: 300,
    tipo: 'Materia Prima',
    ciudad: 'Guayaquil',
    telefono: '042345679',
    estado: 'Activo',
  },
];

export default function BodegasPage() {
  const [bodegas, setBodegas] = useState<Bodega[]>(initialBodegas);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<BodegaFormValues>(initialForm);

  const limpiarForm = useCallback(() => {
    setForm(initialForm);
    setEditandoId(null);
  }, []);

  const abrirModalNueva = useCallback(() => {
    limpiarForm();
    setTimeout(() => setShowModal(true), 0);
  }, [limpiarForm]);

  const abrirModalEditar = useCallback((bodega: Bodega) => {
    setForm({
      nombre: bodega.nombre || '',
      codigo: bodega.codigo || '',
      ubicacion: bodega.ubicacion || '',
      responsable: bodega.responsable || '',
      capacidad: String(bodega.capacidad || ''),
      tipo: bodega.tipo || '',
      ciudad: bodega.ciudad || '',
      telefono: bodega.telefono || '',
      estado: bodega.estado || 'Activo',
      notas: bodega.notas || '',
    });
    setEditandoId(bodega.id);
    setTimeout(() => setShowModal(true), 0);
  }, []);

  const cerrarModal = useCallback(() => {
    setShowModal(false);
    setTimeout(limpiarForm, 300);
  }, [limpiarForm]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId) {
      setBodegas(prev =>
        prev.map(bodega =>
          bodega.id === editandoId
            ? { ...bodega, ...form, capacidad: Number(form.capacidad), id: editandoId }
            : bodega
        )
      );
    } else {
      const nuevoId = Date.now();
      setBodegas(prev => [
        ...prev,
        { ...form, id: nuevoId, capacidad: Number(form.capacidad) } as Bodega,
      ]);
    }
    cerrarModal();
  }, [form, editandoId, cerrarModal]);

  const eliminarBodega = useCallback((id: number) => {
    if (window.confirm('¿Seguro que deseas eliminar esta bodega?')) {
      setBodegas(prev => prev.filter(bodega => bodega.id !== id));
    }
  }, []);

  const bodegasFiltradas = bodegas.filter(bodega =>
    Object.values(bodega).join(' ').toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Bodegas</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input type='text' className='form-control w-50' placeholder='Buscar bodega...' value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva} type='button'>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir Bodega</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>Nombre</th>
                <th>Código</th>
                <th>Ubicación</th>
                <th>Responsable</th>
                <th>Tipo</th>
                <th>Capacidad</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {bodegasFiltradas.length === 0 && (
                <tr><td colSpan={8} className='text-center'>No se encontraron bodegas</td></tr>
              )}
              {bodegasFiltradas.map((bodega) => (
                <tr key={bodega.id}>
                  <td>{bodega.nombre}</td>
                  <td>{bodega.codigo}</td>
                  <td>{bodega.ubicacion}</td>
                  <td>{bodega.responsable}</td>
                  <td>{bodega.tipo}</td>
                  <td>{bodega.capacidad}</td>
                  <td><span className={`badge bg-${bodega.estado === 'Activo' ? 'success' : 'secondary'}`}>{bodega.estado}</span></td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(bodega)} type='button'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminarBodega(bodega.id)} type='button'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <BodegaModal show={showModal} editando={!!editandoId} values={form} onChange={handleChange} onClose={cerrarModal} onSubmit={handleSubmit} />
      </div>
    </div>
  );
}
