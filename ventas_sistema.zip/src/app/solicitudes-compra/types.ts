// Tipos para Solicitudes de Compra (requisiciones internas)

export interface SolicitudCompra {
  id: number;
  numero_solicitud: string;
  fecha_solicitud: string;
  solicitante: string;
  departamento: string;
  centro_costo: string;
  prioridad: string;
  estado: string;
  items_solicitados: number;
  total_estimado: number;
  justificacion: string;
  fecha_creacion: string;
}

export interface SolicitudesCompraFormValues {
  numero_solicitud: string;
  fecha_solicitud: string;
  solicitante: string;
  departamento: string;
  centro_costo: string;
  prioridad: string;
  estado: string;
  total_estimado: number;
  justificacion: string;
}