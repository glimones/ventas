"use client";

import React, { useState, useCallback } from "react";
import { CirclePlus, SquarePen, Trash2 } from "lucide-react";
import { SolicitudCompra, SolicitudesCompraFormValues } from "./types";
import SolicitudesCompraModal from "./SolicitudesCompraModal";
import "./solicitudes-compra.css";

const INITIAL: SolicitudesCompraFormValues = {
  numero_solicitud: "",
  fecha_solicitud: "",
  solicitante: "",
  departamento: "",
  centro_costo: "",
  prioridad: "NORMAL",
  estado: "BORRADOR",
  total_estimado: 0,
  justificacion: "",
};

const SAMPLE: SolicitudCompra[] = [
  { id: 1, numero_solicitud: "SC-2025-001", fecha_solicitud: "2025-01-03", solicitante: "Mar�a Garc�a", departamento: "TI", centro_costo: "CC-TI-001", prioridad: "ALTA", estado: "CONVERTIDA_OC", items_solicitados: 5, total_estimado: 8500.00, justificacion: "Renovaci�n de equipos de c�mputo", fecha_creacion: "2025-01-03" },
  { id: 2, numero_solicitud: "SC-2025-002", fecha_solicitud: "2025-02-15", solicitante: "Carlos L�pez", departamento: "MANTENIMIENTO", centro_costo: "CC-MANT-003", prioridad: "NORMAL", estado: "APROBADA", items_solicitados: 12, total_estimado: 3200.00, justificacion: "Materiales de mantenimiento preventivo", fecha_creacion: "2025-02-15" },
  { id: 3, numero_solicitud: "SC-2025-003", fecha_solicitud: "2025-03-05", solicitante: "Ana Rojas", departamento: "ADMINISTRACION", centro_costo: "CC-ADM-001", prioridad: "URGENTE", estado: "PENDIENTE_APROBACION", items_solicitados: 3, total_estimado: 1500.00, justificacion: "Suministros de oficina urgentes", fecha_creacion: "2025-03-05" },
];

const ESTADOS: Record<string, string> = {
  BORRADOR: "#6c757d", PENDIENTE_APROBACION: "#ffc107", APROBADA: "#0d6efd",
  RECHAZADA: "#dc3545", CONVERTIDA_OC: "#198754", CANCELADA: "#343a40",
};

const PRIORIDADES: Record<string, string> = {
  BAJA: "#198754", NORMAL: "#0d6efd", ALTA: "#fd7e14", URGENTE: "#dc3545",
};

export default function SolicitudesCompraPage() {
  const [data, setData] = useState<SolicitudCompra[]>(SAMPLE);
  const [modalOpen, setModalOpen] = useState(false);
  const [editando, setEditando] = useState(false);
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [form, setForm] = useState<SolicitudesCompraFormValues>(INITIAL);
  const [filtro, setFiltro] = useState("");
  const [estadoFiltro, setEstadoFiltro] = useState("");
  const [nextId, setNextId] = useState(4);

  const filtered = data.filter(
    (s) =>
      (!filtro || s.solicitante.toLowerCase().includes(filtro.toLowerCase()) || s.numero_solicitud.toLowerCase().includes(filtro.toLowerCase()) || s.departamento.toLowerCase().includes(filtro.toLowerCase())) &&
      (!estadoFiltro || s.estado === estadoFiltro)
  );

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setForm((prev) => ({ ...prev, [name]: type === "number" ? parseFloat(value) || 0 : value }));
  }, []);

  const openNew = () => {
    setEditando(false);
    setCurrentId(null);
    setForm({ ...INITIAL, numero_solicitud: "SC-2025-00" + nextId });
    setModalOpen(true);
  };

  const openEdit = (s: SolicitudCompra) => {
    setEditando(true);
    setCurrentId(s.id);
    setForm({
      numero_solicitud: s.numero_solicitud,
      fecha_solicitud: s.fecha_solicitud,
      solicitante: s.solicitante,
      departamento: s.departamento,
      centro_costo: s.centro_costo,
      prioridad: s.prioridad,
      estado: s.estado,
      total_estimado: s.total_estimado,
      justificacion: s.justificacion,
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editando && currentId !== null) {
      setData((prev) =>
        prev.map((s) =>
          s.id === currentId
            ? { ...s, ...form, estado: form.estado, prioridad: form.prioridad }
            : s
        )
      );
    } else {
      const nuevo: SolicitudCompra = {
        id: nextId,
        ...form,
        estado: form.estado,
        prioridad: form.prioridad,
        items_solicitados: 0,
        fecha_creacion: new Date().toISOString().split("T")[0],
      };
      setData((prev) => [...prev, nuevo]);
      setNextId((n) => n + 1);
    }
    setModalOpen(false);
  };

  const handleDelete = (id: number) => {
    if (window.confirm("Eliminar esta solicitud?")) {
      setData((prev) => prev.filter((s) => s.id !== id));
    }
  };

  return (
    <div className="container-fluid p-4">
      <h4 className="mb-4">Solicitudes de Compra</h4>

      <div className="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
        <div className="d-flex gap-2 align-items-center flex-wrap">
          <input type="text" className="form-control" style={{ width: "280px" }} placeholder="Buscar por solicitante, N# o depto..." value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <select className="form-select" style={{ width: "220px" }} value={estadoFiltro} onChange={(e) => setEstadoFiltro(e.target.value)}>
            <option value="">Todos los estados</option>
            {Object.keys(ESTADOS).map((e) => <option key={e} value={e}>{e.replace(/_/g, " ")}</option>)}
          </select>
        </div>
        <button className="btn text-white d-flex align-items-center gap-1" style={{ background: "#fd7e14" }} onClick={openNew}>
          <CirclePlus size={18} /> Nueva Solicitud
        </button>
      </div>

      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead className="table-light">
            <tr>
              <th>N# Solicitud</th>
              <th>Fecha</th>
              <th>Solicitante</th>
              <th>Departamento</th>
              <th>Total Estimado</th>
              <th>Prioridad</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center text-muted py-4">Sin solicitudes registradas</td>
              </tr>
            ) : (
              filtered.map((s) => (
                <tr key={s.id}>
                  <td><strong>{s.numero_solicitud}</strong></td>
                  <td>{s.fecha_solicitud}</td>
                  <td>{s.solicitante}</td>
                  <td><span className="badge bg-secondary">{s.departamento}</span></td>
                  <td className="fw-bold">${s.total_estimado.toFixed(2)}</td>
                  <td>
                    <span style={{ backgroundColor: PRIORIDADES[s.prioridad] || "#6c757d", color: "white", padding: "4px 10px", borderRadius: "20px", fontSize: "0.75rem", fontWeight: 600 }}>
                      {s.prioridad}
                    </span>
                  </td>
                  <td>
                    <span style={{ backgroundColor: ESTADOS[s.estado] || "#6c757d", color: "white", padding: "4px 10px", borderRadius: "20px", fontSize: "0.75rem", fontWeight: 600 }}>
                      {s.estado.replace(/_/g, " ")}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      <button className="btn btn-sm btn-outline-primary" title="Editar" onClick={() => openEdit(s)}><SquarePen size={16} /></button>
                      <button className="btn btn-sm btn-outline-danger" title="Eliminar" onClick={() => handleDelete(s.id)}><Trash2 size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <p className="text-muted small mt-2">Mostrando {filtered.length} de {data.length} registros</p>

      <SolicitudesCompraModal show={modalOpen} editando={editando} values={form} onChange={handleChange} onClose={() => setModalOpen(false)} onSubmit={handleSubmit} />
    </div>
  );
}