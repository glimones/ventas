"use client";
import React from "react";
import { SolicitudesCompraFormValues } from "./types";

interface Props {
  values: SolicitudesCompraFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const SolicitudesCompraForm: React.FC<Props> = ({ values, onChange }) => (
  <div className="row g-3">
    <div className="col-md-3">
      <label htmlFor="numero_solicitud" className="form-label">N# Solicitud *</label>
      <input type="text" className="form-control" id="numero_solicitud" name="numero_solicitud" value={values.numero_solicitud} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="fecha_solicitud" className="form-label">Fecha *</label>
      <input type="date" className="form-control" id="fecha_solicitud" name="fecha_solicitud" value={values.fecha_solicitud} onChange={onChange} required />
    </div>
    <div className="col-md-3">
      <label htmlFor="prioridad" className="form-label">Prioridad *</label>
      <select className="form-select" id="prioridad" name="prioridad" value={values.prioridad} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="BAJA">Baja</option>
        <option value="NORMAL">Normal</option>
        <option value="ALTA">Alta</option>
        <option value="URGENTE">Urgente</option>
      </select>
    </div>
    <div className="col-md-3">
      <label htmlFor="estado" className="form-label">Estado *</label>
      <select className="form-select" id="estado" name="estado" value={values.estado} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="BORRADOR">Borrador</option>
        <option value="PENDIENTE_APROBACION">Pendiente aprobaci�n</option>
        <option value="APROBADA">Aprobada</option>
        <option value="RECHAZADA">Rechazada</option>
        <option value="CONVERTIDA_OC">Convertida a OC</option>
        <option value="CANCELADA">Cancelada</option>
      </select>
    </div>
    <div className="col-md-4">
      <label htmlFor="solicitante" className="form-label">Solicitante *</label>
      <input type="text" className="form-control" id="solicitante" name="solicitante" value={values.solicitante} onChange={onChange} required />
    </div>
    <div className="col-md-4">
      <label htmlFor="departamento" className="form-label">Departamento *</label>
      <select className="form-select" id="departamento" name="departamento" value={values.departamento} onChange={onChange} required>
        <option value="">Seleccione...</option>
        <option value="COMPRAS">Compras</option>
        <option value="TI">Tecnolog�a</option>
        <option value="MANTENIMIENTO">Mantenimiento</option>
        <option value="ADMINISTRACION">Administraci�n</option>
        <option value="VENTAS">Ventas</option>
        <option value="PRODUCCION">Producci�n</option>
        <option value="LOGISTICA">Log�stica</option>
      </select>
    </div>
    <div className="col-md-4">
      <label htmlFor="centro_costo" className="form-label">Centro de Costo</label>
      <input type="text" className="form-control" id="centro_costo" name="centro_costo" value={values.centro_costo} onChange={onChange} />
    </div>
    <div className="col-md-4">
      <label htmlFor="total_estimado" className="form-label">Total Estimado</label>
      <input type="number" step="0.01" className="form-control" id="total_estimado" name="total_estimado" value={values.total_estimado} onChange={onChange} />
    </div>
    <div className="col-md-12">
      <label htmlFor="justificacion" className="form-label">Justificaci�n</label>
      <textarea className="form-control" id="justificacion" name="justificacion" value={values.justificacion} onChange={onChange} rows={3} />
    </div>
  </div>
);

export default SolicitudesCompraForm;