'use client';
import React, { useState } from 'react';
import { Ubicaciones, UbicacionesFormValues } from './types';
import UbicacionesModal from './UbicacionesModal';
import './bootstrap-ubicaciones.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: UbicacionesFormValues = {
  codigo: '',
  nombre: '', bodega: '', pasillo: '', estanteria: '', nivel: '', capacidad: 0, ocupacion: 0,
  estado: 'Activo',
};

const initialData: Ubicaciones[] = [
  { id: 1, codigo: 'A-01-01', nombre: 'Rack A nivel 1', bodega: 'Matriz Quito', pasillo: 'A', estanteria: '01', nivel: '01', capacidad: 100, ocupacion: 72, estado: 'Activo' },
];

export default function UbicacionesPage() {
  const [data, setData] = useState<Ubicaciones[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<UbicacionesFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setShowModal(true);
  };

  const abrirModalEditar = (item: Ubicaciones) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      nombre: item.nombre || '',
      bodega: item.bodega || '', pasillo: item.pasillo || '', estanteria: item.estanteria || '', nivel: item.nivel || '', capacidad: item.capacidad || 0, ocupacion: item.ocupacion || 0,
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: ['capacidad', 'ocupacion'].includes(e.target.name) ? Number(e.target.value) : e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, ...form }
          : item
      ));
    } else {
      const nuevo: Ubicaciones = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        ...form,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre.toLowerCase().includes(filtro.toLowerCase()) || item.bodega.toLowerCase().includes(filtro.toLowerCase()) || item.pasillo.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Ubicaciones</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Bodega</th><th>Pasillo</th><th>Capacidad</th><th>Ocupación</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.nombre}</td>
                  <td>{item.bodega}</td><td>{item.pasillo}-{item.estanteria}-{item.nivel}</td><td>{item.capacidad}</td><td>{item.ocupacion}</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <UbicacionesModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
