export interface Ubicaciones {
  id: number;
  codigo: string;
  nombre: string;
  bodega: string;
  pasillo: string;
  estanteria: string;
  nivel: string;
  capacidad: number;
  ocupacion: number;
  estado: string;
}

export interface UbicacionesFormValues {
  codigo: string;
  nombre: string;
  bodega: string;
  pasillo: string;
  estanteria: string;
  nivel: string;
  capacidad: number;
  ocupacion: number;
  estado: string;
}
