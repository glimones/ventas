import { AppShell } from '@/components/app-shell';
import UbicacionesPage from './UbicacionesPage';

export default function Page() {
  return (
    <AppShell>
      <UbicacionesPage />
    </AppShell>
  );
}
