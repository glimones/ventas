"use client";

import React, { useState, useCallback } from "react";
import { CirclePlus, SquarePen, Trash2 } from "lucide-react";
import { OrdenCompra, OrdenesCompraFormValues } from "./types";
import OrdenesCompraModal from "./OrdenesCompraModal";
import "./ordenes-compra.css";

const INITIAL: OrdenesCompraFormValues = {
  numero_orden: "",
  fecha_orden: "",
  fecha_entrega_requerida: "",
  estado: "BORRADOR",
  tipo_orden: "",
  prioridad: "NORMAL",
  proveedor: "",
  identificacion_proveedor: "",
  subtotal: 0,
  iva: 0,
  total: 0,
  observaciones: "",
};

const SAMPLE: OrdenCompra[] = [
  { id: 1, numero_orden: "OC-2025-001", fecha_orden: "2025-01-05", fecha_entrega_requerida: "2025-02-01", estado: "RECIBIDA_TOTAL", tipo_orden: "ORDEN_DIRECTA", prioridad: "ALTA", proveedor: "Suministros XYZ", identificacion_proveedor: "1799876543001", subtotal: 4800.00, iva: 720.00, total: 5520.00, observaciones: "Materiales de construcci�n", fecha_creacion: "2025-01-05" },
  { id: 2, numero_orden: "OC-2025-002", fecha_orden: "2025-02-10", fecha_entrega_requerida: "2025-03-15", estado: "ENVIADA", tipo_orden: "DESDE_COTIZACION", prioridad: "NORMAL", proveedor: "Distribuidora ABC", identificacion_proveedor: "1790012345001", subtotal: 12500.00, iva: 1875.00, total: 14375.00, observaciones: "Equipos de oficina", fecha_creacion: "2025-02-10" },
  { id: 3, numero_orden: "OC-2025-003", fecha_orden: "2025-03-01", fecha_entrega_requerida: "2025-03-20", estado: "BORRADOR", tipo_orden: "ORDEN_URGENTE", prioridad: "URGENTE", proveedor: "Tecnolog�a S.A.", identificacion_proveedor: "1795555555001", subtotal: 8100.00, iva: 1215.00, total: 9315.00, observaciones: "Servidores y networking", fecha_creacion: "2025-03-01" },
];

const ESTADOS: Record<string, string> = {
  BORRADOR: "#6c757d", EMITIDA: "#0d6efd", ENVIADA: "#0dcaf0", CONFIRMADA: "#17a2b8",
  EN_PROCESO: "#fd7e14", RECIBIDA_PARCIAL: "#ffc107", RECIBIDA_TOTAL: "#28a745",
  FACTURADA: "#20c997", PAGADA: "#198754", CANCELADA: "#dc3545", ANULADA: "#343a40",
};

const PRIORIDADES: Record<string, string> = {
  BAJA: "#198754", NORMAL: "#0d6efd", ALTA: "#fd7e14", URGENTE: "#dc3545",
};

export default function OrdenesCompraPage() {
  const [data, setData] = useState<OrdenCompra[]>(SAMPLE);
  const [modalOpen, setModalOpen] = useState(false);
  const [editando, setEditando] = useState(false);
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [form, setForm] = useState<OrdenesCompraFormValues>(INITIAL);
  const [filtro, setFiltro] = useState("");
  const [estadoFiltro, setEstadoFiltro] = useState("");
  const [nextId, setNextId] = useState(4);

  const filtered = data.filter(
    (o) =>
      (!filtro || o.proveedor.toLowerCase().includes(filtro.toLowerCase()) || o.numero_orden.toLowerCase().includes(filtro.toLowerCase())) &&
      (!estadoFiltro || o.estado === estadoFiltro)
  );

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setForm((prev) => ({ ...prev, [name]: type === "number" ? parseFloat(value) || 0 : value }));
  }, []);

  const openNew = () => {
    setEditando(false);
    setCurrentId(null);
    setForm({ ...INITIAL, numero_orden: "OC-2025-00" + nextId });
    setModalOpen(true);
  };

  const openEdit = (o: OrdenCompra) => {
    setEditando(true);
    setCurrentId(o.id);
    setForm({
      numero_orden: o.numero_orden,
      fecha_orden: o.fecha_orden,
      fecha_entrega_requerida: o.fecha_entrega_requerida,
      estado: o.estado,
      tipo_orden: o.tipo_orden,
      prioridad: o.prioridad,
      proveedor: o.proveedor,
      identificacion_proveedor: o.identificacion_proveedor,
      subtotal: o.subtotal,
      iva: o.iva,
      total: o.total,
      observaciones: o.observaciones || "",
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editando && currentId !== null) {
      setData((prev) =>
        prev.map((o) =>
          o.id === currentId
            ? { ...o, ...form, estado: form.estado, tipo_orden: form.tipo_orden, prioridad: form.prioridad }
            : o
        )
      );
    } else {
      const nuevo: OrdenCompra = {
        id: nextId,
        ...form,
        estado: form.estado,
        tipo_orden: form.tipo_orden,
        prioridad: form.prioridad,
        observaciones: form.observaciones,
        fecha_creacion: new Date().toISOString().split("T")[0],
      };
      setData((prev) => [...prev, nuevo]);
      setNextId((n) => n + 1);
    }
    setModalOpen(false);
  };

  const handleDelete = (id: number) => {
    if (window.confirm("�Eliminar esta orden de compra?")) {
      setData((prev) => prev.filter((o) => o.id !== id));
    }
  };

  return (
    <div className="container-fluid p-4">
      <h4 className="mb-4">Órdenes de Compra</h4>

      <div className="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
        <div className="d-flex gap-2 align-items-center flex-wrap">
          <input type="text" className="form-control" style={{ width: "280px" }} placeholder="Buscar por proveedor o N# orden..." value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <select className="form-select" style={{ width: "220px" }} value={estadoFiltro} onChange={(e) => setEstadoFiltro(e.target.value)}>
            <option value="">Todos los estados</option>
            {Object.keys(ESTADOS).map((e) => <option key={e} value={e}>{e}</option>)}
          </select>
        </div>
        <button className="btn text-white d-flex align-items-center gap-1" style={{ background: "#6f42c1" }} onClick={openNew}>
          <CirclePlus size={18} /> Nueva Orden
        </button>
      </div>

      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead className="table-light">
            <tr>
              <th>N# Orden</th>
              <th>Fecha</th>
              <th>Entrega</th>
              <th>Proveedor</th>
              <th>Prioridad</th>
              <th>Total</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center text-muted py-4">Sin Órdenes de compra registradas</td>
              </tr>
            ) : (
              filtered.map((o) => (
                <tr key={o.id}>
                  <td><strong>{o.numero_orden}</strong></td>
                  <td>{o.fecha_orden}</td>
                  <td>{o.fecha_entrega_requerida}</td>
                  <td>{o.proveedor}</td>
                  <td>
                    <span style={{ backgroundColor: PRIORIDADES[o.prioridad] || "#6c757d", color: "white", padding: "4px 10px", borderRadius: "20px", fontSize: "0.75rem", fontWeight: 600 }}>
                      {o.prioridad}
                    </span>
                  </td>
                  <td className="fw-bold">${o.total.toFixed(2)}</td>
                  <td>
                    <span style={{ backgroundColor: ESTADOS[o.estado] || "#6c757d", color: "white", padding: "4px 10px", borderRadius: "20px", fontSize: "0.75rem", fontWeight: 600 }}>
                      {o.estado.replace(/_/g, " ")}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      <button className="btn btn-sm btn-outline-primary" title="Editar" onClick={() => openEdit(o)}><SquarePen size={16} /></button>
                      <button className="btn btn-sm btn-outline-danger" title="Eliminar" onClick={() => handleDelete(o.id)}><Trash2 size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <p className="text-muted small mt-2">Mostrando {filtered.length} de {data.length} registros</p>

      <OrdenesCompraModal show={modalOpen} editando={editando} values={form} onChange={handleChange} onClose={() => setModalOpen(false)} onSubmit={handleSubmit} />
    </div>
  );
}