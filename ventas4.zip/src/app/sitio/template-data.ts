import { postgresMock } from "@/lib/postgres-mock";
import type { Empresa, GiroNegocio } from "@/app/empresa/types";

export type SiteItem = {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
};

export type SiteTemplate = {
  eyebrow: string;
  headline: string;
  description: string;
  heroImage: string;
  sectionTitle: string;
  sectionDescription: string;
  highlights: string[];
  aboutTitle: string;
  aboutDescription: string;
  contactPrompt: string;
  items: SiteItem[];
};

const unsplash = (photo: string) => `https://images.unsplash.com/${photo}?auto=format&fit=crop&w=1200&q=85`;

export const siteTemplates: Record<GiroNegocio, SiteTemplate> = {
  alimentos: {
    eyebrow: "COCINA DE PRODUCTOR LOCAL",
    headline: "Lo bueno empieza en la mesa.",
    description: "Ingredientes frescos, recetas honestas y el sabor de compartir bien.",
    heroImage: unsplash("photo-1547592180-85f173990554"),
    sectionTitle: "De nuestra cocina",
    sectionDescription: "Preparado con cuidado. Listo para disfrutar.",
    highlights: ["Ingredientes de temporada", "Recetas para compartir", "Atención cercana"],
    aboutTitle: "Sabor local, hecho para compartir.",
    aboutDescription: "Nos inspira la cocina honesta: productos frescos, preparaciones cuidadas y el gusto de sentarnos a la mesa. Queremos que cada visita se sienta cercana y especial.",
    contactPrompt: "¿Tienes una pregunta o quieres hacer un pedido? Estamos para ayudarte.",
    items: [
      { id: "almuerzo", name: "Almuerzo de temporada", description: "Sopa del día, plato fuerte y bebida natural.", price: 8.5, image: unsplash("photo-1547592180-85f173990554") },
      { id: "pan", name: "Pan de masa madre", description: "Fermentación lenta, harina local y corteza dorada.", price: 4.25, image: unsplash("photo-1585478259715-876acc5be8eb") },
      { id: "canasta", name: "Canasta de la huerta", description: "Selección semanal de frutas y verduras frescas.", price: 14.0, image: unsplash("photo-1542838132-92c53300491e") },
    ],
  },
  comercio: {
    eyebrow: "OBJETOS PARA VIVIR MEJOR",
    headline: "Tu casa, a tu manera.",
    description: "Piezas funcionales y duraderas, elegidas para acompañarte todos los días.",
    heroImage: unsplash("photo-1600210492486-724fe5c67fb0"),
    sectionTitle: "Selección de la casa",
    sectionDescription: "Diseño cotidiano, materiales honestos y detalles que duran.",
    highlights: ["Piezas para todos los días", "Selección con intención", "Atención personalizada"],
    aboutTitle: "Objetos que hacen tu espacio más tuyo.",
    aboutDescription: "Elegimos piezas funcionales y con carácter para acompañar tu día a día. Nos importa el diseño que se disfruta, se usa y se queda contigo.",
    contactPrompt: "¿Buscas una pieza especial? Escríbenos y te ayudamos a encontrarla.",
    items: [
      { id: "ceramica", name: "Vajilla de cerámica", description: "Juego artesanal de cuatro piezas, hecho en Ecuador.", price: 38.0, image: unsplash("photo-1490312278390-ab64016e0aa9") },
      { id: "textil", name: "Manta de algodón", description: "Tejido suave de producción responsable.", price: 42.5, image: unsplash("photo-1600210492486-724fe5c67fb0") },
      { id: "canasto", name: "Canasto tejido", description: "Fibra natural trenzada a mano para cada espacio.", price: 24.0, image: unsplash("photo-1593085260707-5377ba37f868") },
    ],
  },
  servicios: {
    eyebrow: "IDEAS QUE SE VUELVEN PROYECTOS",
    headline: "Hagamos espacio para lo nuevo.",
    description: "Estrategia, creatividad y acompañamiento para impulsar lo que viene.",
    heroImage: unsplash("photo-1497366754035-f200968a6e72"),
    sectionTitle: "En qué podemos ayudarte",
    sectionDescription: "Un equipo cercano, un proceso claro y objetivos compartidos.",
    highlights: ["Estrategia con propósito", "Acompañamiento cercano", "Ideas que toman forma"],
    aboutTitle: "Construyamos juntos lo que sigue.",
    aboutDescription: "Acompañamos a marcas y equipos a convertir ideas en proyectos claros. Combinamos estrategia, identidad y experiencia digital con colaboración en cada etapa.",
    contactPrompt: "Cuéntanos qué tienes en mente. Podemos conversar sobre tu próximo proyecto.",
    items: [
      { id: "estrategia", name: "Estrategia de marca", description: "Posicionamiento, narrativa y dirección para crecer.", price: 0, image: unsplash("photo-1497366754035-f200968a6e72") },
      { id: "identidad", name: "Identidad visual", description: "Un sistema visual propio, consistente y memorable.", price: 0, image: unsplash("photo-1455390582262-044cdead277a") },
      { id: "digital", name: "Experiencia digital", description: "Diseño y contenido centrados en las personas.", price: 0, image: unsplash("photo-1498050108023-c5249f4df085") },
    ],
  },
};

export async function getCompanyBySlug(slug: string): Promise<Empresa | undefined> {
  const { data } = await postgresMock.list("empresas", { pageSize: 100 });
  return (data as unknown as Empresa[]).find((company) => company.slug === slug && company.estado === "Activa");
}

export async function getActiveCompanies(): Promise<Empresa[]> {
  const { data } = await postgresMock.list("empresas", { pageSize: 100 });
  return (data as unknown as Empresa[]).filter((company) => company.estado === "Activa");
}