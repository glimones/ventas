import { notFound } from "next/navigation";
import { getCompanyBySlug } from "../template-data";
import BusinessSite from "./site-page";

export const dynamic = "force-dynamic";

export default async function BusinessSiteRoute({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const company = await getCompanyBySlug(slug);

  if (!company) notFound();

  return <BusinessSite company={company} />;
}