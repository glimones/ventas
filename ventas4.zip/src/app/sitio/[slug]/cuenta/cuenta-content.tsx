"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { ArrowRight, CheckCircle2, Clock3, CreditCard, LogOut, ShoppingBag, ShoppingCart, Trash2, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Empresa } from "@/app/empresa/types";
import { siteTemplates } from "../../template-data";
import {
  readCustomerCart,
  readCustomerOrders,
  readCustomerProfile,
  removeCustomerProfile,
  saveCustomerProfile,
  saveCustomerOrders,
  type CustomerCart,
  type CustomerOrder,
  type CustomerProfile,
} from "../customer-store";
import CustomerRegistration from "./registro-form";

export default function CustomerAccountContent({ company }: { company: Empresa }) {
  const [profile, setProfile] = useState<CustomerProfile | null>(null);
  const [cart, setCart] = useState<CustomerCart>({});
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [storageError, setStorageError] = useState("");
  const [accountStatus, setAccountStatus] = useState<"loading" | "ready" | "error">("loading");
  const [paymentConfirmation, setPaymentConfirmation] = useState<{ orderId: string; reference: string } | null>(null);
  const items = siteTemplates[company.giro_negocio].items;
  const formatter = useMemo(
    () => new Intl.NumberFormat(company.pais === "ec" ? "es-EC" : "es", {
      style: "currency",
      currency: company.moneda || "USD",
    }),
    [company.moneda, company.pais],
  );
  const cartItems = items.filter((item) => cart[item.id]);
  const cartTotal = cartItems.reduce((total, item) => total + item.price * cart[item.id], 0);
  const customerOrders = orders.filter((order) => order.customerEmail === profile?.email);
  const pendingOrders = customerOrders.filter((order) => order.status === "PENDIENTE");
  const completedOrders = customerOrders.filter((order) => order.status === "COMPLETADA");

  useEffect(() => {
    const refreshOrders = () => {
      try {
        setOrders(readCustomerOrders(company.slug));
        setStorageError("");
      } catch {
        setStorageError("No pudimos actualizar tus pedidos en este navegador.");
      }
    };

    try {
      setProfile(readCustomerProfile(company.slug));
      setCart(readCustomerCart(company.slug));
      refreshOrders();
      setAccountStatus("ready");
    } catch {
      setStorageError("No pudimos leer toda la información guardada en este navegador.");
      setAccountStatus("error");
    }

    window.addEventListener("customer-orders-updated", refreshOrders);
    return () => window.removeEventListener("customer-orders-updated", refreshOrders);
  }, [company.slug]);

  function handleRegistered(newProfile: CustomerProfile) {
    try {
      saveCustomerProfile(newProfile);
      const nextOrders = readCustomerOrders(company.slug).map((order) =>
        order.customerEmail === null && order.status === "PENDIENTE"
          ? { ...order, customerEmail: newProfile.email }
          : order,
      );
      saveCustomerOrders(company.slug, nextOrders);
      setProfile(newProfile);
      setOrders(nextOrders);
      setStorageError("");
      setAccountStatus("ready");
    } catch {
      setStorageError("No pudimos guardar tu perfil en este navegador. Intenta de nuevo.");
    }
  }

  function handleSignOut() {
    try {
      removeCustomerProfile(company.slug);
      setProfile(null);
      setStorageError("");
    } catch {
      setStorageError("No pudimos cerrar la sesión de demostración.");
    }
  }

  function saveOrders(nextOrders: CustomerOrder[]): boolean {
    try {
      saveCustomerOrders(company.slug, nextOrders);
      setOrders(nextOrders);
      setStorageError("");
      return true;
    } catch {
      setStorageError("No pudimos actualizar tus pedidos en este navegador. Intenta de nuevo.");
      return false;
    }
  }

  function buyOrder(orderId: string) {
    const order = orders.find((candidate) => candidate.id === orderId && candidate.status === "PENDIENTE");
    if (!order) {
      setStorageError("No encontramos el pedido pendiente para procesar la compra.");
      return;
    }

    const response = {
      status: "APPROVED" as const,
      authorizationCode: `ALG-DEMO-${Date.now()}`,
    };
    const nextOrders = orders.map((candidate) =>
      candidate.id === orderId
        ? { ...candidate, status: "COMPLETADA" as const, paymentReference: response.authorizationCode }
        : candidate,
    );

    if (response.status === "APPROVED" && saveOrders(nextOrders)) {
      setPaymentConfirmation({ orderId, reference: response.authorizationCode });
    }
  }

  function deleteOrder(orderId: string) {
    if (!window.confirm("¿Eliminar este pedido pendiente?")) return;
    saveOrders(orders.filter((order) => order.id !== orderId));
  }

  function deleteOrderLine(orderId: string, productId: string) {
    const nextOrders = orders.flatMap((order) => {
      if (order.id !== orderId || order.status !== "PENDIENTE") return [order];
      const nextItems = order.items.filter((item) => item.productId !== productId);
      if (!nextItems.length) return [];
      return [{
        ...order,
        items: nextItems,
        total: nextItems.reduce((total, item) => total + item.quantity * item.unitPrice, 0),
      }];
    });
    saveOrders(nextOrders);
  }

  if (accountStatus === "loading") {
    return <p className="customer-account-loading" role="status">Cargando tu cuenta...</p>;
  }

  if (accountStatus === "error") {
    return <p className="customer-registration-error" role="alert">{storageError}</p>;
  }

  if (!profile) {
    return (
      <div className="customer-registration-panel-content">
        <span className="customer-account-icon"><UserRound size={20} /></span>
        <span className="customer-account-kicker">CLIENTES DE {company.nombre_comercial.toUpperCase()}</span>
        <h1>Crea tu perfil</h1>
        <p className="customer-account-intro">Registra tus datos para consultar tus pedidos, compras y el carrito guardado.</p>
        {storageError && <p className="customer-registration-error" role="alert">{storageError}</p>}
        <CustomerRegistration
          company={{ id: company.id, slug: company.slug, name: company.nombre_comercial }}
          onRegistered={handleRegistered}
        />
        <p className="customer-account-demo">Perfil de demostración guardado en este navegador. No se crea una contraseña ni se habilita autenticación real.</p>
      </div>
    );
  }

  return (
    <div className="customer-dashboard">
      <div className="customer-dashboard-heading">
        <div>
          <span className="customer-account-kicker">TU ESPACIO EN {company.nombre_comercial.toUpperCase()}</span>
          <h1>Hola, {profile.name.split(" ")[0]}</h1>
          <p>{profile.email}{profile.phone ? ` · ${profile.phone}` : ""}</p>
        </div>
        <Button className="customer-signout" type="button" variant="outline" onClick={handleSignOut}><LogOut size={15} /> Cerrar sesión demo</Button>
      </div>
      {storageError && <p className="customer-registration-error" role="alert">{storageError}</p>}
      {paymentConfirmation && (
        <div className="customer-payment-notice customer-payment-success" role="status">
          <div><CheckCircle2 size={19} /><strong>Compra aprobada (simulación de Alignet)</strong></div>
          <p>El pedido {paymentConfirmation.orderId} pasó a Compras realizadas. Referencia de prueba: {paymentConfirmation.reference}. No se realizó ningún cobro real.</p>
          <Button type="button" variant="outline" onClick={() => setPaymentConfirmation(null)}>Entendido</Button>
        </div>
      )}

      <section className="customer-summary" aria-label="Resumen de tu cuenta">
        <article><span><Clock3 size={17} /></span><strong>{pendingOrders.length}</strong><small>Pedidos pendientes</small></article>
        <article><span><CheckCircle2 size={17} /></span><strong>{completedOrders.length}</strong><small>Compras realizadas</small></article>
        <article><span><ShoppingCart size={17} /></span><strong>{cartItems.reduce((total, item) => total + cart[item.id], 0)}</strong><small>Productos en carrito</small></article>
      </section>

      <section className="customer-dashboard-section">
        <div className="customer-dashboard-title"><h2><Clock3 size={18} /> Pedidos pendientes</h2><span>{pendingOrders.length}</span></div>
        {pendingOrders.length ? pendingOrders.map((order) => (
          <article className="customer-order-card" key={order.id}>
            <div className="customer-order-heading">
              <div><strong>{order.id}</strong><span>{new Date(order.date).toLocaleDateString("es-EC")}</span></div>
              <Button className="customer-delete-order" type="button" variant="outline" aria-label={`Eliminar pedido ${order.id}`} onClick={() => deleteOrder(order.id)}><Trash2 size={15} /></Button>
            </div>
            <div className="customer-order-lines">
              {order.items.map((item) => (
                <div className="customer-order-line" key={item.productId}>
                  <span>{item.quantity} × {item.name}</span>
                  <strong>{formatter.format(item.quantity * item.unitPrice)}</strong>
                  <Button className="customer-delete-line" type="button" variant="ghost" size="icon" aria-label={`Eliminar ${item.name} del pedido ${order.id}`} onClick={() => deleteOrderLine(order.id, item.productId)}><Trash2 size={14} /></Button>
                </div>
              ))}
            </div>
            <div className="customer-order-footer">
              <span>Total del pedido <strong>{formatter.format(order.total)}</strong></span>
              <Button className="customer-buy-order" type="button" onClick={() => buyOrder(order.id)}><CreditCard size={15} /> Comprar</Button>
            </div>
          </article>
        )) : <p className="customer-empty-state">Todavía no tienes pedidos pendientes. Cuando envíes uno desde la tienda aparecerá aquí.</p>}
      </section>

      <section className="customer-dashboard-section">
        <div className="customer-dashboard-title"><h2><ShoppingBag size={18} /> Compras realizadas</h2><span>{completedOrders.length}</span></div>
        {completedOrders.length ? completedOrders.map((order) => (
          <article className="customer-order-card customer-completed-order" key={order.id}>
            <div className="customer-order-heading"><div><strong>{order.id}</strong><span>{new Date(order.date).toLocaleDateString("es-EC")}</span></div><span className="customer-completed-badge"><CheckCircle2 size={13} /> Pagada</span></div>
            <div className="customer-order-lines">
              {order.items.map((item) => (
                <div className="customer-order-line" key={item.productId}>
                  <span>{item.quantity} × {item.name}</span>
                  <strong>{formatter.format(item.quantity * item.unitPrice)}</strong>
                </div>
              ))}
            </div>
            <div className="customer-order-footer">
              <span>Total pagado <strong>{formatter.format(order.total)}</strong></span>
              {order.paymentReference && <span>Referencia de prueba <strong>{order.paymentReference}</strong></span>}
            </div>
          </article>
        )) : <p className="customer-empty-state">Aún no registras compras completadas con {company.nombre_comercial}.</p>}
      </section>

      <section className="customer-dashboard-section">
        <div className="customer-dashboard-title"><h2><ShoppingCart size={18} /> Lo que dejaste en el carrito</h2><span>{cartItems.reduce((total, item) => total + cart[item.id], 0)}</span></div>
        {cartItems.length ? (
          <>
            <div className="customer-cart-list">
              {cartItems.map((item) => (
                <div className="customer-cart-item" key={item.id}>
                  <span>{cart[item.id]} × {item.name}</span>
                  <strong>{formatter.format(item.price * cart[item.id])}</strong>
                </div>
              ))}
              <div className="customer-cart-total"><span>Total estimado</span><strong>{formatter.format(cartTotal)}</strong></div>
            </div>
            <Button className="customer-continue-shopping" asChild><Link href={`/sitio/${company.slug}`}>Continuar en la tienda <ArrowRight size={15} /></Link></Button>
          </>
        ) : <p className="customer-empty-state">Tu carrito está vacío. Explora la tienda y agrega lo que te guste.</p>}
      </section>
    </div>
  );
}
