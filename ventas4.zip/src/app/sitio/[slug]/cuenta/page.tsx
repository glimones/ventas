import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getCompanyBySlug } from "../../template-data";
import CustomerAccountContent from "./cuenta-content";
import "./cuenta.css";

export const dynamic = "force-dynamic";

export default async function CustomerAccountPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const company = await getCompanyBySlug(slug);

  if (!company) notFound();

  return (
    <main className="customer-account" style={{ "--company-primary": company.color_primario, "--company-secondary": company.color_secundario } as React.CSSProperties}>
      <header className="customer-account-header">
        <Link href={`/sitio/${company.slug}`}><ArrowLeft size={15} /> Volver a {company.nombre_comercial}</Link>
        <span>{company.nombre_comercial}</span>
      </header>
      {company.cuenta_clientes_habilitada ? (
        <section className="customer-account-panel customer-account-dashboard-panel">
          <CustomerAccountContent company={company} />
        </section>
      ) : (
        <section className="customer-account-panel customer-account-disabled">
          <h1>Registro no disponible</h1>
          <p>{company.nombre_comercial} todavía no habilita las cuentas de clientes.</p>
          <Button asChild variant="outline"><Link href={`/sitio/${company.slug}`}>Volver al sitio</Link></Button>
        </section>
      )}
      <footer className="customer-account-footer">© {new Date().getFullYear()} {company.nombre_comercial}</footer>
    </main>
  );
}