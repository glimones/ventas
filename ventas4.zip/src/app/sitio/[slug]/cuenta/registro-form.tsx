"use client";

import { useState, type FormEvent } from "react";
import { ArrowRight, Mail, Phone, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { CustomerProfile } from "../customer-store";

type CustomerRegistrationProps = {
  company: { id: number; slug: string; name: string };
  onRegistered: (profile: CustomerProfile) => void;
};

export default function CustomerRegistration({ company, onRegistered }: CustomerRegistrationProps) {
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setMessage("");

    const formData = new FormData(event.currentTarget);
    const profile: CustomerProfile = {
      companyId: company.id,
      slug: company.slug,
      name: String(formData.get("nombre") ?? "").trim(),
      email: String(formData.get("email") ?? "").trim(),
      phone: String(formData.get("telefono") ?? "").trim(),
    };

    try {
      const response = await fetch(`/api/clientes/${company.slug}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          empresa_id: company.id,
          empresa_slug: company.slug,
          nombre: profile.name,
          email: profile.email,
          telefono: profile.phone,
        }),
      });

      if (!response.ok) {
        setMessage("No pudimos registrar el perfil. Intenta de nuevo.");
        return;
      }

      onRegistered(profile);
    } catch {
      setMessage("No pudimos conectar para registrar el perfil. Intenta de nuevo.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form className="customer-registration-form" onSubmit={handleSubmit}>
      <label htmlFor="customer-name">Nombre completo</label>
      <div className="customer-input-wrap"><UserRound size={16} /><Input id="customer-name" name="nombre" autoComplete="name" placeholder="Cómo te llamas" minLength={2} required /></div>
      <label htmlFor="customer-email">Correo electrónico</label>
      <div className="customer-input-wrap"><Mail size={16} /><Input id="customer-email" name="email" type="email" autoComplete="email" placeholder="nombre@correo.com" required /></div>
      <label htmlFor="customer-phone">Teléfono</label>
      <div className="customer-input-wrap"><Phone size={16} /><Input id="customer-phone" name="telefono" type="tel" autoComplete="tel" placeholder="+593 99 000 0000" /></div>
      {message && <p className="customer-registration-error" role="alert">{message}</p>}
      <Button className="customer-registration-submit" type="submit" disabled={submitting}>{submitting ? "Registrando..." : "Crear perfil"}<ArrowRight size={16} /></Button>
    </form>
  );
}