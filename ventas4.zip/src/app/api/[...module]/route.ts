import { NextRequest, NextResponse } from "next/server";
import { postgresMock } from "@/lib/postgres-mock";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteContext = {
  params: Promise<{ module: string[] }>;
};

type ApiTarget = {
  moduleKey: string;
  id?: number;
};

async function getTarget(context: RouteContext): Promise<ApiTarget | null> {
  const { module: segments } = await context.params;

  if (!segments?.length || segments.some((segment) => !/^[a-z0-9-]+$/i.test(segment))) {
    return null;
  }

  const lastSegment = segments.at(-1);
  const id = lastSegment && /^\d+$/.test(lastSegment) ? Number(lastSegment) : undefined;
  const moduleSegments = id === undefined ? segments : segments.slice(0, -1);

  if (!moduleSegments.length || (id !== undefined && !Number.isSafeInteger(id))) {
    return null;
  }

  return {
    moduleKey: moduleSegments.join("/").toLowerCase(),
    id,
  };
}

function invalidTarget() {
  return NextResponse.json({ error: "Módulo o identificador inválido." }, { status: 400 });
}

function invalidBody() {
  return NextResponse.json(
    { error: "El cuerpo debe ser un objeto JSON." },
    { status: 400 },
  );
}

async function readBody(request: NextRequest): Promise<Record<string, unknown> | null> {
  try {
    const body: unknown = await request.json();
    return body !== null && typeof body === "object" && !Array.isArray(body)
      ? (body as Record<string, unknown>)
      : null;
  } catch {
    return null;
  }
}

export async function GET(request: NextRequest, context: RouteContext) {
  const target = await getTarget(context);
  if (!target) return invalidTarget();

  if (target.id !== undefined) {
    const record = await postgresMock.find(target.moduleKey, target.id);
    return record
      ? NextResponse.json({ data: record, adapter: postgresMock.adapter })
      : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
  }

  const searchParams = request.nextUrl.searchParams;
  const result = await postgresMock.list(target.moduleKey, {
    search: searchParams.get("q") ?? undefined,
    page: Number(searchParams.get("page")) || 1,
    pageSize: Number(searchParams.get("limit")) || 50,
  });

  return NextResponse.json(result);
}

export async function POST(request: NextRequest, context: RouteContext) {
  const target = await getTarget(context);
  if (!target || target.id !== undefined) return invalidTarget();

  const body = await readBody(request);
  if (!body) return invalidBody();

  const record = await postgresMock.create(target.moduleKey, body);
  return NextResponse.json(
    { data: record, adapter: postgresMock.adapter },
    { status: 201 },
  );
}

export async function PUT(request: NextRequest, context: RouteContext) {
  return updateRecord(request, context);
}

export async function PATCH(request: NextRequest, context: RouteContext) {
  return updateRecord(request, context);
}

async function updateRecord(request: NextRequest, context: RouteContext) {
  const target = await getTarget(context);
  if (!target || target.id === undefined) return invalidTarget();

  const body = await readBody(request);
  if (!body) return invalidBody();

  const record = await postgresMock.update(target.moduleKey, target.id, body);
  return record
    ? NextResponse.json({ data: record, adapter: postgresMock.adapter })
    : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
}

export async function DELETE(_request: NextRequest, context: RouteContext) {
  const target = await getTarget(context);
  if (!target || target.id === undefined) return invalidTarget();

  const record = await postgresMock.delete(target.moduleKey, target.id);
  return record
    ? NextResponse.json({ data: record, adapter: postgresMock.adapter })
    : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
}