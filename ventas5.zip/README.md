This is a [Next.js](https://nextjs.org) project for the Ventas system.

## API modular

The API exposes CRUD endpoints for every module using its route path as the module key. Nested modules keep their path, for example `/api/solicitudes-compra`, `/api/reportes/ventas` and `/api/seguridad/usuarios`.

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/<modulo>?q=&page=1&limit=50` | List and search records |
| GET | `/api/<modulo>/<id>` | Read one record |
| POST | `/api/<modulo>` | Create a record |
| PUT or PATCH | `/api/<modulo>/<id>` | Update a record |
| DELETE | `/api/<modulo>/<id>` | Delete a record |

The catch-all module API now uses a PostgreSQL service with an explicit module-to-table/column allowlist in `src/services/module-records.service.ts`. It scopes company data with `DATABASE_EMPRESA_ID`, parameterizes values, supports search/pagination, and uses logical deactivation where the mapped table has a state column. The dedicated `/api/clientes` endpoint uses the same PostgreSQL pool and the relational `terceros` and `clientes` tables, matching `ventas3`.

The shared CRUD components `DomainCrud` and `TreasuryCrudPage` load and mutate mapped records in PostgreSQL. Categories, clients, providers, products, and site configuration have dedicated services. Product stock is calculated from `stock_bodega`; product creation and inventory movements update the related tables transactionally. Mappings also cover measurement units, warehouses, brands, cost centers, opportunities/prospects, activities, employees, periods, banks, cash registers, companies, roles, and payment/tax/branch catalogs. Reports and entities whose forms still lack required foreign-key selections remain read-only or return `501` rather than silently writing incomplete records.

To enable persistence, set `DATABASE_URL`, `DATABASE_SCHEMA`, and `DATABASE_EMPRESA_ID` in `.env.local` to the database values for the selected company, then restart Next.js. The database must contain the relational schema from `database/001_schema.sql`. Purchasing workflows, electronic documents, accounting reports, payroll, and other relationship-heavy modules still require dedicated services and cannot safely use a generic row mapping yet.

For an existing database, connect to the target database and run `psql -d <base_de_datos> -v ON_ERROR_STOP=1 -f database/003_empresa_configuracion_sitio.sql`. The script sets `search_path` to `sistema_ventas, public`; change that schema in the script if `DATABASE_SCHEMA` uses another name. It adds the site slug, business type, description, colors, online-store flag, and customer-account flag to `empresas`, and backfills unique slugs for existing rows. New databases get the same columns from `database/001_schema.sql`.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
