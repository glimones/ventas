'use client';
import React, { useCallback, useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

export interface TreasuryField { name: string; label: string; type?: string; }
type TreasuryRow = Record<string, unknown> & { id: number };
type TreasuryForm = Record<string, unknown>;
type TreasuryModalProps = {
  show: boolean;
  editando: boolean;
  values: TreasuryForm;
  onChange: (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (event: React.FormEvent) => void;
};
interface Props { title: string; searchPlaceholder: string; fields: TreasuryField[]; initialForm: TreasuryForm; initialData: TreasuryRow[]; Modal: React.ElementType; css: string; }

export default function TreasuryCrudPage({ title, searchPlaceholder, fields, initialForm, Modal }: Props) {
  const pathname = usePathname();
  const [data, setData] = useState<TreasuryRow[]>([]); const [query, setQuery] = useState(''); const [show, setShow] = useState(false); const [editId, setEditId] = useState<number | null>(null); const [form, setForm] = useState<TreasuryForm>(initialForm);
  const [loading, setLoading] = useState(true); const [saving, setSaving] = useState(false); const [error, setError] = useState('');
  const [writable, setWritable] = useState(false);
  const loadRows = useCallback(async () => {
    setLoading(true);
    setWritable(false);
    try {
      const response = await fetch(`/api${pathname}`, { cache: 'no-store' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudieron cargar los registros.');
      setData(result.data as TreasuryRow[]);
      setWritable(Boolean(result.capabilities?.create && result.capabilities?.update && result.capabilities?.delete));
      setError('');
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Error al cargar los registros.');
    } finally { setLoading(false); }
  }, [pathname]);
  useEffect(() => { void loadRows(); }, [loadRows]);
  const close = () => { setShow(false); setEditId(null); setForm(initialForm); };
  const edit = (item: TreasuryRow) => { setError(''); setEditId(item.id); setForm({ ...item }); setShow(true); };
  const change = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setForm((previous) => ({ ...previous, [e.target.name]: e.target.type === 'number' ? Number(e.target.value) : e.target.value }));
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setSaving(true); setError('');
    try {
      const response = await fetch(editId === null ? `/api${pathname}` : `/api${pathname}/${editId}`, {
        method: editId === null ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo guardar el registro.');
      await loadRows(); close();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Error al guardar el registro.');
    } finally { setSaving(false); }
  };
  const remove = async (id: number) => {
    if (!window.confirm('¿Deseas desactivar este registro?')) return;
    try {
      const response = await fetch(`/api${pathname}/${id}`, { method: 'DELETE' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo desactivar el registro.');
      await loadRows();
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : 'Error al desactivar el registro.');
    }
  };
  const rows = data.filter(item => Object.values(item).join(' ').toLowerCase().includes(query.toLowerCase()));
  const TypedModal = Modal as React.ComponentType<TreasuryModalProps>;
  return <div className="bootstrap-container" aria-busy={saving}><div className="content-wrapper"><h1 className="mb-4">{title}</h1><div className="d-flex justify-content-between mb-3"><input className="form-control w-50" placeholder={searchPlaceholder} value={query} onChange={e => setQuery(e.target.value)} />{writable && <button className="btn btn-primary" onClick={() => { setError(''); setShow(true); }} disabled={saving}><CirclePlus size={16} className="me-2" />Añadir</button>}</div>{error && <div className="alert alert-danger" role="alert">{error}</div>}<div className="table-responsive"><table className="table table-striped"><thead><tr>{fields.map(f => <th key={f.name}>{f.label}</th>)}{writable && <th>Acciones</th>}</tr></thead><tbody>{loading ? <tr><td colSpan={fields.length + (writable ? 1 : 0)} className="text-center">Cargando datos...</td></tr> : rows.length === 0 ? <tr><td colSpan={fields.length + (writable ? 1 : 0)} className="text-center">{error ? 'No se pudieron cargar los datos' : 'No hay registros'}</td></tr> : rows.map(item => <tr key={item.id}>{fields.map(f => <td key={f.name}>{typeof item[f.name] === 'number' && ['monto','saldo','importe','valor','balance'].some(x => f.name.includes(x)) ? `$${Number(item[f.name]).toFixed(2)}` : String(item[f.name] ?? '')}</td>)}{writable && <td><button className="btn btn-warning btn-sm me-1" onClick={() => edit(item)} disabled={saving}><SquarePen size={15} /></button><button className="btn btn-danger btn-sm" onClick={() => void remove(item.id)} disabled={saving}><Trash2 size={15} /></button></td>}</tr>)}</tbody></table></div>{writable && <TypedModal show={show} editando={editId !== null} values={form} onChange={change} onClose={close} onSubmit={submit} />}</div></div>;
}