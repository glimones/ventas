'use client';
import React, { useCallback, useEffect, useState } from 'react';
import { usePathname } from 'next/navigation';
import { CirclePlus, SquarePen, Trash2, X } from 'lucide-react';

export interface DomainField { name: string; label: string; type?: string; }
export interface DomainConfig { title: string; search: string; fields: DomainField[]; sample: Record<string, string | number>; }
type DomainRow = { id: number } & Record<string, string | number>;

export default function DomainCrud({ config }: { config: DomainConfig }) {
  const pathname = usePathname();
  const [rows, setRows] = useState<DomainRow[]>([]);
  const [query, setQuery] = useState(''); const [open, setOpen] = useState(false); const [editing, setEditing] = useState<number | null>(null); const [form, setForm] = useState<Record<string, string | number>>({ ...config.sample });
  const [loading, setLoading] = useState(true); const [saving, setSaving] = useState(false); const [error, setError] = useState('');
  const [writable, setWritable] = useState(false);
  const loadRows = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(`/api${pathname}`, { cache: 'no-store' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudieron cargar los registros.');
      setRows(result.data as DomainRow[]);
      setWritable(Boolean(result.capabilities?.create && result.capabilities?.update && result.capabilities?.delete));
      setError('');
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Error al cargar los registros.');
    } finally {
      setLoading(false);
    }
  }, [pathname]);
  useEffect(() => { void loadRows(); }, [loadRows]);
  const close = () => { setOpen(false); setEditing(null); setForm({ ...config.sample }); };
  const save = async (event: React.FormEvent) => {
    event.preventDefault(); setSaving(true); setError('');
    try {
      const response = await fetch(editing === null ? `/api${pathname}` : `/api${pathname}/${editing}`, {
        method: editing === null ? 'POST' : 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo guardar el registro.');
      await loadRows(); close();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : 'Error al guardar el registro.');
    } finally { setSaving(false); }
  };
  const remove = async (id: number) => {
    if (!window.confirm('¿Deseas desactivar este registro?')) return;
    try {
      const response = await fetch(`/api${pathname}/${id}`, { method: 'DELETE' });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'No se pudo desactivar el registro.');
      await loadRows();
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : 'Error al desactivar el registro.');
    }
  };
  const filtered = rows.filter(row => Object.values(row).join(' ').toLowerCase().includes(query.toLowerCase()));
  return <div className="bootstrap-container"><div className="content-wrapper"><h1 className="mb-4">{config.title}</h1><div className="d-flex justify-content-between mb-3"><input className="form-control w-50" placeholder={config.search} value={query} onChange={event => setQuery(event.target.value)} />{writable && <button className="btn btn-primary" onClick={() => { setError(''); setOpen(true); }}><CirclePlus size={16} className="me-2" />Añadir</button>}</div>{error && <div className="alert alert-danger" role="alert">{error}</div>}<div className="table-responsive"><table className="table table-striped table-hover"><thead><tr>{config.fields.map(field => <th key={field.name}>{field.label}</th>)}{writable && <th>Acciones</th>}</tr></thead><tbody>{loading ? <tr><td colSpan={config.fields.length + (writable ? 1 : 0)} className="text-center">Cargando datos...</td></tr> : filtered.length === 0 ? <tr><td colSpan={config.fields.length + (writable ? 1 : 0)} className="text-center">{error ? 'No se pudieron cargar los datos' : 'No hay registros'}</td></tr> : filtered.map(row => <tr key={row.id}>{config.fields.map(field => <td key={field.name}>{row[field.name] ?? ''}</td>)}{writable && <td><button className="btn btn-warning btn-sm me-1" onClick={() => { setError(''); setEditing(row.id); setForm({ ...row }); setOpen(true); }}><SquarePen size={15} /></button><button className="btn btn-danger btn-sm" onClick={() => void remove(row.id)}><Trash2 size={15} /></button></td>}</tr>)}</tbody></table></div>{open && writable && <div className="modal d-block" tabIndex={-1} role="dialog"><div className="modal-dialog modal-lg"><div className="modal-content"><form onSubmit={save}><div className="modal-header"><h5 className="modal-title">{editing === null ? `Nuevo ${config.title}` : `Editar ${config.title}`}</h5><button type="button" className="btn-close" onClick={close} disabled={saving}><X size={16} /></button></div><div className="modal-body row g-3">{error && <div className="col-12"><div className="alert alert-danger" role="alert">{error}</div></div>}{config.fields.map(field => <div className="col-md-6" key={field.name}><label className="form-label" htmlFor={field.name}>{field.label}</label><input className="form-control" id={field.name} name={field.name} type={field.type || 'text'} value={form[field.name] ?? ''} onChange={event => setForm(previous => ({ ...previous, [field.name]: field.type === 'number' ? Number(event.target.value) : event.target.value }))} required /></div>)}</div><div className="modal-footer"><button type="button" className="btn btn-secondary" onClick={close} disabled={saving}>Cancelar</button><button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Guardando...' : 'Guardar'}</button></div></form></div></div></div>}</div></div>;
}