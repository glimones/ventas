export interface UnidadesMedida {
  id: number;
  codigo: string;
  nombre: string;
  abreviatura: string;
  estado: string;
}

export interface UnidadesMedidaFormValues {
  codigo: string;
  nombre: string;
  abreviatura: string;
  estado: string;
}
