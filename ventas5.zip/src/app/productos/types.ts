export interface Producto {
  id: number;
  codigo: string;
  nombre: string;
  descripcion: string;
  categoria: string;
  categoria_id: number;
  precio_compra: number;
  precio_venta: number;
  costo: number;
  stock_actual: number;
  stock_minimo: number;
  stock_maximo: number;
  unidad_medida: string;
  unidad_medida_id: number;
  marca_id?: number | null;
  ubicacion_id?: number | null;
  proveedor_id?: number | null;
  marca?: string;
  proveedor?: string;
  ubicacion?: string;
  imagen_url?: string;
  estado: string;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface ProductoFormValues {
  codigo: string;
  nombre: string;
  descripcion: string;
  categoria: string;
  categoria_id: string;
  precio_compra: number;
  precio_venta: number;
  costo: number;
  stock_actual: number;
  stock_minimo: number;
  stock_maximo: number;
  unidad_medida: string;
  unidad_medida_id: string;
  marca_id: string;
  proveedor_id: string;
  ubicacion_id: string;
  bodega_id: string;
  imagen_url?: string;
  estado: string;
}

export interface MovimientoInventario {
  id: number;
  producto_id: number;
  tipo: 'Entrada' | 'Salida';
  bodega_id: number;
  cantidad: number;
  fecha: string;
  motivo: string;
  usuario: string;
  documento_referencia?: string;
}

export interface ProductoCatalogOption {
  id: number;
  codigo: string;
  nombre: string;
}

export interface UbicacionCatalogOption extends ProductoCatalogOption {
  bodega_id: number;
  pasillo?: string | null;
  estanteria?: string | null;
  nivel?: string | null;
}

export interface ProductoCatalogs {
  categorias: ProductoCatalogOption[];
  marcas: ProductoCatalogOption[];
  unidades: Array<ProductoCatalogOption & { abreviatura: string }>;
  bodegas: ProductoCatalogOption[];
  ubicaciones: UbicacionCatalogOption[];
  proveedores: ProductoCatalogOption[];
}