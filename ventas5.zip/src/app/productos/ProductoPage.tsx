"use client";

import React, { useState, useCallback, useEffect } from "react";
import { Producto, ProductoFormValues, MovimientoInventario, ProductoCatalogs } from "./types";
import ProductoModal from "./ProductoModal";
import MovimientoModal from "./MovimientoModal";
import "./bootstrap-producto.css";
import { CirclePlus, Package, Loader, ArrowUpDown, SquarePen, Trash2 } from 'lucide-react';

const initialForm: ProductoFormValues = {
  codigo: "",
  nombre: "",
  descripcion: "",
  categoria: "",
  categoria_id: "",
  precio_compra: 0,
  precio_venta: 0,
  costo: 0,
  stock_actual: 0,
  stock_minimo: 0,
  stock_maximo: 0,
  unidad_medida: "",
  unidad_medida_id: "",
  marca_id: "",
  proveedor_id: "",
  ubicacion_id: "",
  bodega_id: "",
  imagen_url: "",
  estado: "Activo",
};

export default function ProductosPage() {
  const [productos, setProductos] = useState<Producto[]>([]);
  const [filtro, setFiltro] = useState<string>("");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [showMovimientoModal, setShowMovimientoModal] = useState<boolean>(false);
  const [selectedProducto, setSelectedProducto] = useState<Producto | null>(null);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ProductoFormValues>(initialForm);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [guardando, setGuardando] = useState(false);
  const [catalogos, setCatalogos] = useState<ProductoCatalogs>({
    categorias: [], marcas: [], unidades: [], bodegas: [], ubicaciones: [], proveedores: [],
  });
  const [cargandoCatalogos, setCargandoCatalogos] = useState(true);

  const cargarProductos = useCallback(async () => {
    setCargando(true);
    try {
      const response = await fetch("/api/productos", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudieron cargar los productos.");
      setProductos(result.data as Producto[]);
      setError("");
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Error al cargar productos.");
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => { void cargarProductos(); }, [cargarProductos]);

  const cargarCatalogos = useCallback(async () => {
    setCargandoCatalogos(true);
    try {
      const response = await fetch("/api/productos/catalogos", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudieron cargar los catálogos.");
      setCatalogos(result as ProductoCatalogs);
    } catch (catalogError) {
      setError(catalogError instanceof Error ? catalogError.message : "Error al cargar catálogos.");
    } finally { setCargandoCatalogos(false); }
  }, []);

  useEffect(() => { void cargarCatalogos(); }, [cargarCatalogos]);

  const limpiarForm = useCallback(() => {
    setForm(initialForm);
    setEditandoId(null);
  }, []);

  const abrirModalNuevo = useCallback(() => {
    limpiarForm();
    setError("");
    setShowModal(true);
  }, [limpiarForm]);
  
  const abrirModalEditar = useCallback((producto: Producto) => {
    // Crear un nuevo objeto para evitar referencias
    setForm({
      codigo: producto.codigo || "",
      nombre: producto.nombre || "",
      descripcion: producto.descripcion || "",
      categoria: producto.categoria || "",
      categoria_id: String(producto.categoria_id || ""),
      precio_compra: producto.precio_compra || 0,
      precio_venta: producto.precio_venta || 0,
      costo: producto.costo || 0,
      stock_actual: producto.stock_actual || 0,
      stock_minimo: producto.stock_minimo || 0,
      stock_maximo: producto.stock_maximo || 0,
      unidad_medida: producto.unidad_medida || "",
      unidad_medida_id: String(producto.unidad_medida_id || ""),
      marca_id: producto.marca_id ? String(producto.marca_id) : "",
      proveedor_id: producto.proveedor_id ? String(producto.proveedor_id) : "",
      ubicacion_id: producto.ubicacion_id ? String(producto.ubicacion_id) : "",
      bodega_id: "",
      imagen_url: producto.imagen_url || "",
      estado: producto.estado || "Activo",
    });
    setEditandoId(producto.id);
    setError("");
    setShowModal(true);
  }, []);
  
  const abrirModalMovimiento = useCallback((producto: Producto) => {
    setSelectedProducto(producto);
    setTimeout(() => {
      setShowMovimientoModal(true);
      console.log("Modal de movimiento abierto para producto:", producto.id);
    }, 0);
  }, []);

  const cerrarModal = useCallback(() => {
    console.log("Cerrando modal");
    setShowModal(false);
    // Limpiar el formulario después de que el modal se haya cerrado
    setTimeout(limpiarForm, 300);
  }, [limpiarForm]);
  
  const cerrarModalMovimiento = useCallback(() => {
    console.log("Cerrando modal de movimiento");
    setShowMovimientoModal(false);
    setTimeout(() => setSelectedProducto(null), 300);
  }, []);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    console.log(`Campo ${name} cambiado a:`, value);
    
    setForm(prev => ({
      ...prev,
      [name]: value,
    }));
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setError("");
    const payload = {
      codigo: form.codigo,
      nombre: form.nombre,
      descripcion: form.descripcion,
      categoria_id: form.categoria_id,
      marca_id: form.marca_id,
      unidad_medida_id: form.unidad_medida_id,
      ubicacion_id: form.ubicacion_id,
      proveedor_id: form.proveedor_id,
      bodega_id: form.bodega_id,
      stock_actual: form.stock_actual,
      precio_compra: form.precio_compra,
      precio_venta: form.precio_venta,
      costo: form.costo,
      stock_minimo: form.stock_minimo,
      stock_maximo: form.stock_maximo,
      imagen_url: form.imagen_url,
      estado: form.estado,
    };
    if (editandoId) {
      delete (payload as Partial<ProductoFormValues>).stock_actual;
    }
    try {
      const response = await fetch(editandoId ? `/api/productos/${editandoId}` : "/api/productos", {
        method: editandoId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo guardar el producto.");
      await cargarProductos();
      cerrarModal();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Error al guardar el producto.");
    } finally { setGuardando(false); }
  }, [form, editandoId, cerrarModal, cargarProductos]);
  
  const handleMovimientoSubmit = useCallback(async (movimiento: Partial<MovimientoInventario>) => {
    if (!selectedProducto) return;
    setGuardando(true);
    setError("");
    try {
      const response = await fetch(`/api/productos/${selectedProducto.id}/movimientos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(movimiento),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo registrar el movimiento.");
      await cargarProductos();
      cerrarModalMovimiento();
    } catch (movementError) {
      setError(movementError instanceof Error ? movementError.message : "Error al registrar el movimiento.");
    } finally { setGuardando(false); }
  }, [selectedProducto, cerrarModalMovimiento, cargarProductos]);

  const eliminarProducto = useCallback(async (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar este producto?")) {
      try {
        const response = await fetch(`/api/productos/${id}`, { method: "DELETE" });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "No se pudo desactivar el producto.");
        await cargarProductos();
      } catch (deleteError) {
        setError(deleteError instanceof Error ? deleteError.message : "Error al desactivar el producto.");
      }
    }
  }, [cargarProductos]);

  const productosFiltrados = productos.filter(producto =>
    Object.values(producto)
      .join(" ")
      .toLowerCase()
      .includes(filtro.toLowerCase())
  );

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-0">Stock de Productos</h1>
        
        <div className="d-flex justify-content-between align-items-center mb-4">          
          <p className="text-muted mb-0">Registro de productos y movimientos</p>
          <div className="ms-auto">
            <button 
              className="btn btn-primary d-flex align-items-center" 
              onClick={abrirModalNuevo}
              type="button"
              disabled={cargandoCatalogos || guardando}
            >
              <CirclePlus className="me-2" size={16} />
              <span>Añadir Producto</span>
            </button>
          </div>
        </div>
        {error && <div className="alert alert-warning" role="alert">{error}</div>}
        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        
        <div className="card mb-4">
          <div className="card-body">
            <div className="row align-items-center">
              <div className="col-md-6">
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="bi bi-search"></i>
                  </span>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Buscar por código, nombre, categoría..."
                    value={filtro}
                    onChange={(e) => setFiltro(e.target.value)}
                  />
                </div>
              </div>
              <div className="col-md-6 text-md-end mt-3 mt-md-0">
                <span className="badge bg-info me-2">
                  <Package size={14} className="me-1" />
                  Total de productos: {productos.length}
                </span>
                <span className="badge bg-warning me-2">
                  <Loader size={14} className="me-1" />
                  Stock bajo: {productos.filter(p => p.stock_actual <= p.stock_minimo).length}
                </span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Categoría</th>
                <th>Marca</th>
                <th>Precio Compra</th>
                <th>Precio Venta</th>
                <th>Costo</th>
                <th>Stock</th>
                <th>U.M.</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && <tr><td colSpan={11} className="text-center">Cargando productos...</td></tr>}
              {!cargando && productosFiltrados.length === 0 && (
                <tr>
                  <td colSpan={11} className="text-center">
                    <div className="alert alert-info mb-0">
                      {error ? "No se pudieron cargar los productos" : "No se encontraron productos"}
                    </div>
                  </td>
                </tr>
              )}
              {productosFiltrados.map((producto) => (
                <tr key={producto.id}>
                  <td>{producto.codigo}</td>
                  <td>
                    <div className="d-flex align-items-center">
                      {producto.imagen_url && !producto.imagen_url.toLowerCase().endsWith("placeholder.png") ? (
                        <img
                          src={producto.imagen_url.startsWith("http") || producto.imagen_url.startsWith("/")
                            ? producto.imagen_url
                            : `/img/${producto.imagen_url}`}
                          alt={producto.nombre}
                          className="me-2"
                          style={{ width: '30px', height: '30px', objectFit: 'cover' }}
                          onError={(event) => { event.currentTarget.style.display = "none"; }}
                        />
                      ) : <Package className="me-2" size={24} aria-hidden="true" />}
                      <div>{producto.nombre}</div>
                    </div>
                  </td>
                  <td>{producto.categoria}</td>
                  <td>{producto.marca}</td>
                  <td>${producto.precio_compra.toFixed(2)}</td>
                  <td>${producto.precio_venta.toFixed(2)}</td>
                  <td>${producto.costo?.toFixed(2) ?? "0.00"}</td>
                  <td>
                    <span className={
                      producto.stock_actual <= producto.stock_minimo / 2 ? "stock-danger" :
                      producto.stock_actual <= producto.stock_minimo ? "stock-warning" : "stock-ok"
                    }>
                      {producto.stock_actual}
                      {producto.stock_actual <= producto.stock_minimo && (
                        <span className="ms-2 badge bg-warning">¡Bajo!</span>
                      )}
                    </span>
                  </td>
                  <td>{producto.unidad_medida}</td>
                  <td>
                    <span
                      className={`badge bg-${
                        producto.estado === "Activo"
                          ? "success"
                          : producto.estado === "Inactivo"
                          ? "secondary"
                          : "danger"
                      }`}
                    >
                      {producto.estado}
                    </span>
                  </td>
                  <td>
                    <div className="btn-group btn-group-sm opciones-btn-group">
                      <button
                        className="btn btn-primary"
                        onClick={() => abrirModalMovimiento(producto)}
                        title="Registrar movimiento"
                        type="button"
                        disabled={guardando}
                      >
                        <ArrowUpDown size={16} />
                      </button>
                      <button
                        className="btn btn-warning"
                        onClick={() => abrirModalEditar(producto)}
                        title="Editar producto"
                        type="button"
                        disabled={guardando}
                      >
                        <SquarePen size={16} />
                      </button>
                      <button
                        className="btn btn-danger"
                        onClick={() => eliminarProducto(producto.id)}
                        title="Eliminar producto"
                        type="button"
                        disabled={guardando}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <ProductoModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          catalogs={catalogos}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          saving={guardando}
          submitError={error}
        />
        
        <MovimientoModal
          show={showMovimientoModal}
          producto={selectedProducto}
          bodegas={catalogos.bodegas}
          onClose={cerrarModalMovimiento}
          onSubmit={handleMovimientoSubmit}
          error={error}
          saving={guardando}
        />
      </div>
    </div>
  );
}