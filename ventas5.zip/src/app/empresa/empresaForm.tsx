import React from "react";
import { EmpresaFormValues } from "./types";

interface Props {
  values: EmpresaFormValues;
  onChange: (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const paisesOptions = [
  { value: "", label: "Seleccione un país" },
  { value: "es", label: "España" },
  { value: "mx", label: "México" },
  { value: "co", label: "Colombia" },
  { value: "ar", label: "Argentina" },
  { value: "cl", label: "Chile" },
  { value: "pe", label: "Perú" },
  { value: "ec", label: "Ecuador" },
  { value: "ve", label: "Venezuela" },
  { value: "us", label: "Estados Unidos" },
  { value: "ca", label: "Canadá" },
];

const monedasOptions = [
  { value: "", label: "Seleccione una moneda" },
  { value: "USD", label: "Dólar estadounidense (USD)" },
  { value: "EUR", label: "Euro (EUR)" },
  { value: "MXN", label: "Peso mexicano (MXN)" },
  { value: "COP", label: "Peso colombiano (COP)" },
  { value: "ARS", label: "Peso argentino (ARS)" },
  { value: "CLP", label: "Peso chileno (CLP)" },
  { value: "PEN", label: "Sol peruano (PEN)" },
  { value: "VES", label: "Bolívar venezolano (VES)" },
  { value: "GBP", label: "Libra esterlina (GBP)" },
];

export default function EmpresaForm({ values, onChange }: Props) {
  return (
    <div className="row g-3">
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="nombre_comercial" className="form-label">Nombre comercial *</label>
          <input type="text" className="form-control" id="nombre_comercial" name="nombre_comercial" value={values.nombre_comercial} onChange={onChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="nombre_legal" className="form-label">Razón social *</label>
          <input type="text" className="form-control" id="nombre_legal" name="nombre_legal" value={values.nombre_legal} onChange={onChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="ruc" className="form-label">RUC/CIF/NIT *</label>
          <input type="text" className="form-control" id="ruc" name="ruc" value={values.ruc} onChange={onChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="direccion" className="form-label">Dirección *</label>
          <textarea className="form-control" id="direccion" name="direccion" value={values.direccion} onChange={onChange} rows={3} required />
        </div>
        <div className="mb-3">
          <label htmlFor="ciudad" className="form-label">Ciudad *</label>
          <input type="text" className="form-control" id="ciudad" name="ciudad" value={values.ciudad} onChange={onChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="provincia" className="form-label">Provincia/Estado</label>
          <input type="text" className="form-control" id="provincia" name="provincia" value={values.provincia ?? ""} onChange={onChange} />
        </div>
        <div className="mb-3">
          <label htmlFor="pais" className="form-label">País *</label>
          <select className="form-select" id="pais" name="pais" value={values.pais} onChange={onChange} required>
            {paisesOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          </select>
        </div>
      </div>

      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="email" className="form-label">Correo electrónico *</label>
          <input type="email" className="form-control" id="email" name="email" value={values.email} onChange={onChange} required />
        </div>
        <div className="mb-3">
          <label htmlFor="telefono" className="form-label">Teléfono</label>
          <input type="tel" className="form-control" id="telefono" name="telefono" value={values.telefono ?? ""} onChange={onChange} />
        </div>
        <div className="mb-3">
          <label htmlFor="logo_url" className="form-label">URL del logo</label>
          <input type="url" className="form-control" id="logo_url" name="logo_url" value={values.logo_url ?? ""} onChange={onChange} />
        </div>
        <div className="mb-3">
          <label htmlFor="moneda" className="form-label">Moneda principal *</label>
          <select className="form-select" id="moneda" name="moneda" value={values.moneda} onChange={onChange} required>
            {monedasOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="estado" className="form-label">Estado</label>
          <select className="form-select" id="estado" name="estado" value={values.estado} onChange={onChange}>
            <option value="Activa">Activa</option>
            <option value="Inactiva">Inactiva</option>
          </select>
        </div>

        <hr />
        <h6>Configuración del sitio público</h6>
        <div className="mb-3">
          <label htmlFor="slug" className="form-label">Dirección del sitio *</label>
          <div className="input-group">
            <span className="input-group-text">/sitio/</span>
            <input type="text" className="form-control" id="slug" name="slug" value={values.slug} onChange={onChange} pattern="[a-z0-9]+(-[a-z0-9]+)*" required />
          </div>
        </div>
        <div className="mb-3">
          <label htmlFor="giro_negocio" className="form-label">Giro del negocio *</label>
          <select className="form-select" id="giro_negocio" name="giro_negocio" value={values.giro_negocio} onChange={onChange} required>
            <option value="alimentos">Alimentos y restaurantes</option>
            <option value="comercio">Comercio y productos</option>
            <option value="servicios">Servicios profesionales</option>
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="descripcion_web" className="form-label">Descripción para el sitio</label>
          <textarea className="form-control" id="descripcion_web" name="descripcion_web" value={values.descripcion_web} onChange={onChange} rows={3} />
        </div>
        <div className="row g-2 mb-3">
          <div className="col-6">
            <label htmlFor="color_primario" className="form-label">Color principal</label>
            <input type="color" className="form-control form-control-color w-100" id="color_primario" name="color_primario" value={values.color_primario} onChange={onChange} />
          </div>
          <div className="col-6">
            <label htmlFor="color_secundario" className="form-label">Color secundario</label>
            <input type="color" className="form-control form-control-color w-100" id="color_secundario" name="color_secundario" value={values.color_secundario} onChange={onChange} />
          </div>
        </div>
        <div className="form-check mb-2">
          <input type="checkbox" className="form-check-input" id="tienda_online" name="tienda_online" checked={values.tienda_online} onChange={onChange} />
          <label className="form-check-label" htmlFor="tienda_online">Activar catálogo y carrito de compras</label>
        </div>
        <div className="form-check mb-3">
          <input type="checkbox" className="form-check-input" id="cuenta_clientes_habilitada" name="cuenta_clientes_habilitada" checked={values.cuenta_clientes_habilitada} onChange={onChange} />
          <label className="form-check-label" htmlFor="cuenta_clientes_habilitada">Permitir registro de clientes</label>
        </div>
      </div>
    </div>
  );
}
