"use client";

import React, { useState, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import { CirclePlus, ShoppingCart, SquarePen, Trash2 } from "lucide-react";
import { SolicitudCompra, SolicitudesCompraFormValues } from "./types";
import SolicitudesCompraModal from "./SolicitudesCompraModal";
import { ORDENES_COMPRA_INITIAL, readOrdenesCompra, readSolicitudesCompra, saveOrdenesCompra, saveSolicitudesCompra } from "../compras-store";
import type { OrdenCompra } from "../ordenes-compra/types";
import "./solicitudes-compra.css";

const INITIAL: SolicitudesCompraFormValues = {
  numero_solicitud: "",
  fecha_solicitud: "",
  solicitante: "",
  departamento: "",
  centro_costo: "",
  prioridad: "NORMAL",
  estado: "BORRADOR",
  total_estimado: 0,
  justificacion: "",
};

const SAMPLE: SolicitudCompra[] = [
  { id: 1, numero_solicitud: "SC-2025-001", fecha_solicitud: "2025-01-03", solicitante: "Mar�a Garc�a", departamento: "TI", centro_costo: "CC-TI-001", prioridad: "ALTA", estado: "CONVERTIDA_OC", items_solicitados: 5, total_estimado: 8500.00, justificacion: "Renovaci�n de equipos de c�mputo", fecha_creacion: "2025-01-03" },
  { id: 2, numero_solicitud: "SC-2025-002", fecha_solicitud: "2025-02-15", solicitante: "Carlos L�pez", departamento: "MANTENIMIENTO", centro_costo: "CC-MANT-003", prioridad: "NORMAL", estado: "APROBADA", items_solicitados: 12, total_estimado: 3200.00, justificacion: "Materiales de mantenimiento preventivo", fecha_creacion: "2025-02-15" },
  { id: 3, numero_solicitud: "SC-2025-003", fecha_solicitud: "2025-03-05", solicitante: "Ana Rojas", departamento: "ADMINISTRACION", centro_costo: "CC-ADM-001", prioridad: "URGENTE", estado: "PENDIENTE_APROBACION", items_solicitados: 3, total_estimado: 1500.00, justificacion: "Suministros de oficina urgentes", fecha_creacion: "2025-03-05" },
];

const ESTADOS: Record<string, string> = {
  BORRADOR: "#6c757d", PENDIENTE_APROBACION: "#ffc107", APROBADA: "#0d6efd",
  RECHAZADA: "#dc3545", CONVERTIDA_OC: "#198754", CANCELADA: "#343a40",
};

const PRIORIDADES: Record<string, string> = {
  BAJA: "#198754", NORMAL: "#0d6efd", ALTA: "#fd7e14", URGENTE: "#dc3545",
};

export default function SolicitudesCompraPage() {
  const router = useRouter();
  const [data, setData] = useState<SolicitudCompra[]>(SAMPLE);
  const [storageReady, setStorageReady] = useState(false);
  const [storageError, setStorageError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editando, setEditando] = useState(false);
  const [currentId, setCurrentId] = useState<number | null>(null);
  const [form, setForm] = useState<SolicitudesCompraFormValues>(INITIAL);
  const [filtro, setFiltro] = useState("");
  const [estadoFiltro, setEstadoFiltro] = useState("");
  const nextId = Math.max(0, ...data.map((solicitud) => solicitud.id)) + 1;

  useEffect(() => {
    try {
      setData(readSolicitudesCompra(SAMPLE));
      setStorageReady(true);
    } catch {
      setStorageError("No se pudieron cargar las solicitudes guardadas. Revisa el almacenamiento del navegador.");
    }
  }, []);

  useEffect(() => {
    if (!storageReady) return;
    try {
      saveSolicitudesCompra(data);
      setStorageError("");
    } catch {
      setStorageError("No se pudieron guardar los cambios de las solicitudes en este navegador.");
    }
  }, [data, storageReady]);

  const filtered = data.filter(
    (s) =>
      (!filtro || s.solicitante.toLowerCase().includes(filtro.toLowerCase()) || s.numero_solicitud.toLowerCase().includes(filtro.toLowerCase()) || s.departamento.toLowerCase().includes(filtro.toLowerCase())) &&
      (!estadoFiltro || s.estado === estadoFiltro)
  );

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setForm((prev) => ({ ...prev, [name]: type === "number" ? parseFloat(value) || 0 : value }));
  }, []);

  const openNew = () => {
    setEditando(false);
    setCurrentId(null);
    setForm({
      ...INITIAL,
      numero_solicitud: `SC-${new Date().getFullYear()}-${String(nextId).padStart(3, "0")}`,
      fecha_solicitud: today(),
    });
    setModalOpen(true);
  };

  const openEdit = (s: SolicitudCompra) => {
    setEditando(true);
    setCurrentId(s.id);
    setForm({
      numero_solicitud: s.numero_solicitud,
      fecha_solicitud: s.fecha_solicitud,
      solicitante: s.solicitante,
      departamento: s.departamento,
      centro_costo: s.centro_costo,
      prioridad: s.prioridad,
      estado: s.estado,
      total_estimado: s.total_estimado,
      justificacion: s.justificacion,
    });
    setModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storageReady) return;
    if (editando && currentId !== null) {
      setData((prev) =>
        prev.map((s) =>
          s.id === currentId
            ? { ...s, ...form, estado: form.estado, prioridad: form.prioridad }
            : s
        )
      );
    } else {
      const nuevo: SolicitudCompra = {
        id: nextId,
        ...form,
        estado: form.estado,
        prioridad: form.prioridad,
        items_solicitados: 0,
        fecha_creacion: new Date().toISOString().split("T")[0],
      };
      setData((prev) => [...prev, nuevo]);
      setFiltro("");
      setEstadoFiltro("");
    }
    setModalOpen(false);
  };

  const handleBuy = (solicitud: SolicitudCompra) => {
    if (!storageReady || solicitud.estado !== "APROBADA") return;

    try {
      const ordenes = readOrdenesCompra(ORDENES_COMPRA_INITIAL);
      const ordenExistente = ordenes.find((orden) => orden.solicitud_compra_id === solicitud.id);
      const hoy = today();
      const numeroOrden = ordenExistente?.numero_orden ?? `OC-${new Date().getFullYear()}-${String(Math.max(0, ...ordenes.map((orden) => orden.id)) + 1).padStart(3, "0")}`;
      const orden: OrdenCompra = ordenExistente ?? {
        id: Math.max(0, ...ordenes.map((item) => item.id)) + 1,
        numero_orden: numeroOrden,
        fecha_orden: hoy,
        fecha_entrega_requerida: dateAfterDays(30),
        estado: "BORRADOR",
        tipo_orden: "ORDEN_DIRECTA",
        prioridad: solicitud.prioridad,
        proveedor: "Pendiente de asignar",
        identificacion_proveedor: "PENDIENTE",
        subtotal: solicitud.total_estimado,
        iva: 0,
        total: solicitud.total_estimado,
        observaciones: `Generada desde la solicitud ${solicitud.numero_solicitud}. ${solicitud.justificacion}`,
        solicitud_compra_id: solicitud.id,
        fecha_creacion: hoy,
      };
      if (!ordenExistente) saveOrdenesCompra([...ordenes, orden]);

      const nuevasSolicitudes = data.map((item) =>
        item.id === solicitud.id ? { ...item, estado: "CONVERTIDA_OC" } : item,
      );
      saveSolicitudesCompra(nuevasSolicitudes);
      setData(nuevasSolicitudes);
      setStorageError("");
      router.push("/ordenes-compra");
    } catch {
      setStorageError("No se pudo enviar la solicitud a Órdenes de Compra. Intenta nuevamente.");
    }
  };

  const handleDelete = (id: number) => {
    if (window.confirm("Eliminar esta solicitud?")) {
      setData((prev) => prev.filter((s) => s.id !== id));
    }
  };

  return (
    <div className="container-fluid p-4">
      <h4 className="mb-4">Solicitudes de Compra</h4>
      {storageError && <div className="alert alert-danger" role="alert">{storageError}</div>}

      <div className="d-flex justify-content-between align-items-center mb-3 gap-2 flex-wrap">
        <div className="d-flex gap-2 align-items-center flex-wrap">
          <input type="text" className="form-control" style={{ width: "280px" }} placeholder="Buscar por solicitante, N# o depto..." value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <select className="form-select" style={{ width: "220px" }} value={estadoFiltro} onChange={(e) => setEstadoFiltro(e.target.value)}>
            <option value="">Todos los estados</option>
            {Object.keys(ESTADOS).map((e) => <option key={e} value={e}>{e.replace(/_/g, " ")}</option>)}
          </select>
        </div>
        <button className="btn text-white d-flex align-items-center gap-1" style={{ background: "#fd7e14" }} onClick={openNew} disabled={!storageReady}>
          <CirclePlus size={18} /> Nueva Solicitud
        </button>
      </div>

      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead className="table-light">
            <tr>
              <th>N# Solicitud</th>
              <th>Fecha</th>
              <th>Solicitante</th>
              <th>Departamento</th>
              <th>Total Estimado</th>
              <th>Prioridad</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {!storageReady ? (
              <tr><td colSpan={8} className="text-center text-muted py-4">Cargando solicitudes...</td></tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center text-muted py-4">Sin solicitudes registradas</td>
              </tr>
            ) : (
              filtered.map((s) => (
                <tr key={s.id}>
                  <td><strong>{s.numero_solicitud}</strong></td>
                  <td>{s.fecha_solicitud}</td>
                  <td>{s.solicitante}</td>
                  <td><span className="badge bg-secondary">{s.departamento}</span></td>
                  <td className="fw-bold">${s.total_estimado.toFixed(2)}</td>
                  <td>
                    <span style={{ backgroundColor: PRIORIDADES[s.prioridad] || "#6c757d", color: "white", padding: "4px 10px", borderRadius: "20px", fontSize: "0.75rem", fontWeight: 600 }}>
                      {s.prioridad}
                    </span>
                  </td>
                  <td>
                    <span style={{ backgroundColor: ESTADOS[s.estado] || "#6c757d", color: "white", padding: "4px 10px", borderRadius: "20px", fontSize: "0.75rem", fontWeight: 600 }}>
                      {s.estado.replace(/_/g, " ")}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      {s.estado === "APROBADA" && <button className="btn btn-sm btn-outline-success" title="Comprar" onClick={() => handleBuy(s)}><ShoppingCart size={16} /></button>}
                      <button className="btn btn-sm btn-outline-primary" title="Editar" onClick={() => openEdit(s)}><SquarePen size={16} /></button>
                      <button className="btn btn-sm btn-outline-danger" title="Eliminar" onClick={() => handleDelete(s.id)}><Trash2 size={16} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <p className="text-muted small mt-2">Mostrando {filtered.length} de {data.length} registros</p>

      <SolicitudesCompraModal show={modalOpen} editando={editando} values={form} onChange={handleChange} onClose={() => setModalOpen(false)} onSubmit={handleSubmit} />
    </div>
  );
}

function today(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}

function dateAfterDays(days: number): string {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}