export type CustomerProfile = {
  companyId: number;
  slug: string;
  name: string;
  email: string;
  phone: string;
};

export type CustomerOrderLine = {
  productId: string;
  name: string;
  quantity: number;
  unitPrice: number;
};

export type CustomerOrder = {
  id: string;
  date: string;
  customerEmail: string | null;
  status: "PENDIENTE" | "COMPLETADA";
  paymentReference?: string;
  items: CustomerOrderLine[];
  total: number;
};

export type CustomerCart = Record<string, number>;

const profileKey = (slug: string) => `customer-profile:${slug}`;
const cartKey = (slug: string) => `customer-cart:${slug}`;
const ordersKey = (slug: string) => `customer-orders:${slug}`;

function readJson(key: string): unknown {
  const value = window.localStorage.getItem(key);
  return value === null ? null : JSON.parse(value);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function readCustomerProfile(slug: string): CustomerProfile | null {
  const value = readJson(profileKey(slug));
  if (value === null) return null;
  if (
    !isRecord(value) ||
    typeof value.companyId !== "number" ||
    typeof value.slug !== "string" ||
    typeof value.name !== "string" ||
    typeof value.email !== "string" ||
    typeof value.phone !== "string"
  ) {
    throw new Error("El perfil guardado tiene un formato inválido.");
  }
  return {
    companyId: value.companyId,
    slug: value.slug,
    name: value.name,
    email: value.email,
    phone: value.phone,
  };
}

export function saveCustomerProfile(profile: CustomerProfile): void {
  window.localStorage.setItem(profileKey(profile.slug), JSON.stringify(profile));
}

export function removeCustomerProfile(slug: string): void {
  window.localStorage.removeItem(profileKey(slug));
}

export function readCustomerCart(slug: string): CustomerCart {
  const value = readJson(cartKey(slug));
  if (value === null) return {};
  if (!isRecord(value)) {
    throw new Error("El carrito guardado tiene un formato inválido.");
  }

  const cart: CustomerCart = {};
  for (const [id, quantity] of Object.entries(value)) {
    if (typeof quantity !== "number" || !Number.isInteger(quantity) || quantity < 1) {
      throw new Error("El carrito guardado tiene cantidades inválidas.");
    }
    cart[id] = quantity;
  }
  return cart;
}

export function saveCustomerCart(slug: string, cart: CustomerCart): void {
  window.localStorage.setItem(cartKey(slug), JSON.stringify(cart));
}

export function readCustomerOrders(slug: string): CustomerOrder[] {
  const value = readJson(ordersKey(slug));
  if (value === null) return [];
  if (!Array.isArray(value)) throw new Error("El historial de pedidos tiene un formato inválido.");

  return value.map((order): CustomerOrder => {
    if (
      !isRecord(order) ||
      typeof order.id !== "string" ||
      typeof order.date !== "string" ||
      (order.customerEmail !== undefined && order.customerEmail !== null && typeof order.customerEmail !== "string") ||
      (order.status !== "PENDIENTE" && order.status !== "COMPLETADA") ||
      (order.paymentReference !== undefined && typeof order.paymentReference !== "string") ||
      typeof order.total !== "number" ||
      !Number.isFinite(order.total) ||
      !Array.isArray(order.items)
    ) {
      throw new Error("El historial contiene un pedido inválido.");
    }

    const items = order.items.map((item) => {
      if (
        !isRecord(item) ||
        typeof item.productId !== "string" ||
        typeof item.name !== "string" ||
        typeof item.quantity !== "number" ||
        !Number.isInteger(item.quantity) ||
        item.quantity < 1 ||
        typeof item.unitPrice !== "number" ||
        !Number.isFinite(item.unitPrice) ||
        item.unitPrice < 0
      ) {
        throw new Error("El historial contiene un producto inválido.");
      }

      return {
        productId: item.productId,
        name: item.name,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
      };
    });

    return {
      id: order.id,
      date: order.date,
      customerEmail: typeof order.customerEmail === "string" ? order.customerEmail : null,
      status: order.status,
      paymentReference: typeof order.paymentReference === "string" ? order.paymentReference : undefined,
      items,
      total: order.total,
    };
  });
}

export function saveCustomerOrders(slug: string, orders: CustomerOrder[]): void {
  window.localStorage.setItem(ordersKey(slug), JSON.stringify(orders));
  window.dispatchEvent(new Event("customer-orders-updated"));
}
