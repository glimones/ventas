import { notFound } from "next/navigation";
import { buscarEmpresaPorSlug } from "@/services/empresas.service";
import BusinessSite from "./site-page";

export const dynamic = "force-dynamic";

export default async function BusinessSiteRoute({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const company = await buscarEmpresaPorSlug(slug);

  if (!company) notFound();

  return <BusinessSite company={company} />;
}