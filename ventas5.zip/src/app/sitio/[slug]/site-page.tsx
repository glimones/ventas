"use client";

import { useEffect, useRef, useState, type CSSProperties } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, Check, Mail, MapPin, Minus, Phone, Plus, ShoppingBag, Sparkles, UserRound, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Empresa } from "@/app/empresa/types";
import {
  readCustomerCart,
  readCustomerOrders,
  readCustomerProfile,
  saveCustomerCart,
  saveCustomerOrders,
  type CustomerOrder,
} from "./customer-store";
import { siteTemplates } from "../template-data";
import CustomerAccountContent from "./cuenta/cuenta-content";
import "./cuenta/cuenta.css";
import "./site.css";

export default function BusinessSite({ company }: { company: Empresa }) {
  const template = siteTemplates[company.giro_negocio];
  const [cart, setCart] = useState<Record<string, number>>({});
  const [cartReady, setCartReady] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const accountDialogRef = useRef<HTMLDialogElement>(null);
  const [orderSent, setOrderSent] = useState(false);
  const [storageError, setStorageError] = useState("");
  const cartCount = Object.values(cart).reduce((total, quantity) => total + quantity, 0);
  const cartTotal = template.items.reduce((total, item) => total + item.price * (cart[item.id] ?? 0), 0);
  const formatter = new Intl.NumberFormat(company.pais === "ec" ? "es-EC" : "es", {
    style: "currency",
    currency: company.moneda || "USD",
  });
  const theme = {
    "--company-primary": company.color_primario,
    "--company-secondary": company.color_secundario,
  } as CSSProperties;

  useEffect(() => {
    try {
      setCart(readCustomerCart(company.slug));
      setCartReady(true);
    } catch {
      setStorageError("No pudimos recuperar el carrito guardado en este navegador.");
    }

  }, [company.slug]);

  useEffect(() => {
    const dialog = accountDialogRef.current;
    if (!dialog) return;
    if (accountModalOpen && !dialog.open) dialog.showModal();
    if (!accountModalOpen && dialog.open) dialog.close();
  }, [accountModalOpen]);

  useEffect(() => {
    if (!accountModalOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [accountModalOpen]);

  useEffect(() => {
    if (!cartReady) return;
    try {
      saveCustomerCart(company.slug, cart);
    } catch {
      setStorageError("No pudimos guardar los cambios del carrito en este navegador.");
    }
  }, [cart, cartReady, company.slug]);

  function changeQuantity(id: string, amount: number) {
    setCart((current) => {
      const nextQuantity = (current[id] ?? 0) + amount;
      if (nextQuantity <= 0) {
        const next = { ...current };
        delete next[id];
        return next;
      }
      return { ...current, [id]: nextQuantity };
    });
    setOrderSent(false);
  }

  function savePendingOrder(): boolean {
    if (cartCount === 0) return false;

    try {
      const order: CustomerOrder = {
        id: `PED-${Date.now()}`,
        date: new Date().toISOString(),
        customerEmail: readCustomerProfile(company.slug)?.email ?? null,
        status: "PENDIENTE",
        items: template.items
          .filter((item) => cart[item.id])
          .map((item) => ({
            productId: item.id,
            name: item.name,
            quantity: cart[item.id],
            unitPrice: item.price,
          })),
        total: cartTotal,
      };

      saveCustomerOrders(company.slug, [...readCustomerOrders(company.slug), order]);
      setCart({});
      setOrderSent(true);
      setStorageError("");
      return true;
    } catch {
      setStorageError("No pudimos guardar el pedido. El carrito se conserva para que puedas intentarlo de nuevo.");
      return false;
    }
  }

  const whatsappNumber = company.telefono?.replace(/\D/g, "");
  const whatsappHref = whatsappNumber ? `https://wa.me/${whatsappNumber}` : null;
  const orderMessage = encodeURIComponent(
    `Hola, quiero realizar un pedido en ${company.nombre_comercial}:\n${template.items
      .filter((item) => cart[item.id])
      .map((item) => `${cart[item.id]} x ${item.name}`)
      .join("\n")}\nTotal: ${formatter.format(cartTotal)}.`,
  );

  return (
    <main className={`company-site template-${company.giro_negocio}`} style={theme}>
      <header className="company-header">
        <Link href={`/sitio/${company.slug}`} className="company-brand">
          {company.logo_url
            ? <Image className="company-brand-logo" src={company.logo_url} alt="" width={38} height={38} unoptimized />
            : <span className="company-brand-mark">{company.nombre_comercial.slice(0, 1).toUpperCase()}</span>}
          <span><strong>{company.nombre_comercial}</strong><small>{company.ciudad}</small></span>
        </Link>
        <nav className="company-nav" aria-label="Navegación del sitio">
          <a href="#coleccion">{company.giro_negocio === "alimentos" ? "Menú" : company.giro_negocio === "servicios" ? "Servicios" : "Productos"}</a>
          <a href="#nosotros">Nosotros</a>
          {company.cuenta_clientes_habilitada && (
            <button
              className="company-account-trigger"
              type="button"
              aria-haspopup="dialog"
              aria-expanded={accountModalOpen}
              onClick={() => setAccountModalOpen(true)}
            >
              <UserRound size={15} /> Mi cuenta
            </button>
          )}
          {company.tienda_online && (
            <Button className="company-cart-button" variant="outline" onClick={() => setCartOpen(true)}>
              <ShoppingBag size={16} /> Mi carrito <span>{cartCount}</span>
            </Button>
          )}
        </nav>
      </header>

      <section className="company-hero">
        <div className="company-hero-copy">
          <span className="company-eyebrow"><i /> {template.eyebrow}</span>
          <h1>{template.headline}</h1>
          <p>{company.descripcion_web || template.description}</p>
          {company.tienda_online ? (
            <a className="company-primary-link" href="#coleccion">{company.giro_negocio === "alimentos" ? "Explorar el menú" : company.giro_negocio === "servicios" ? "Conocer servicios" : "Ver selección"}<ArrowRight size={16} /></a>
          ) : (
            <a className="company-primary-link" href="#contacto">Conversemos<ArrowRight size={16} /></a>
          )}
          <span className="company-location"><MapPin size={14} /> {company.ciudad}{company.provincia ? `, ${company.provincia}` : ""}</span>
          <span className="company-hero-note"><Sparkles size={14} /> Conoce lo que hacemos y encuentra algo para ti.</span>
        </div>
        <div className="company-hero-image" role="img" aria-label={`${company.giro_negocio} de ${company.nombre_comercial}`} style={{ backgroundImage: `url("${template.heroImage}")` }}>
          <span>{company.giro_negocio === "alimentos" ? "FRESCO · LOCAL · DE TEMPORADA" : company.giro_negocio === "comercio" ? "DISEÑO PARA TODOS LOS DÍAS" : "TRABAJO HECHO EN EQUIPO"}</span>
        </div>
      </section>

      <section className="company-highlights" aria-label="Lo que ofrecemos">
        {template.highlights.map((highlight) => (
          <div className="company-highlight" key={highlight}><span><Check size={15} /></span>{highlight}</div>
        ))}
      </section>

      <section className="company-collection" id="coleccion">
        <div className="company-section-heading">
          <div><span className="company-eyebrow"><i /> NUESTRA PROPUESTA</span><h2>{template.sectionTitle}</h2></div>
          <p>{template.sectionDescription}</p>
        </div>
        <div className="company-product-grid">
          {template.items.map((item, index) => (
            <article className="company-product" key={item.id}>
              <div className="company-product-image">
                <Image src={item.image} alt={item.name} fill sizes="(max-width: 680px) 90vw, (max-width: 1000px) 45vw, 30vw" unoptimized />
                <span>0{index + 1}</span>
              </div>
              <div className="company-product-info">
                <div><h3>{item.name}</h3><p>{item.description}</p></div>
                <div className="company-product-action">
                  {company.tienda_online && item.price > 0 && <strong>{formatter.format(item.price)}</strong>}
                  {company.tienda_online && item.price > 0 ? (
                    <Button className="company-add-button" variant="outline" aria-label={`Agregar ${item.name} al carrito`} onClick={() => changeQuantity(item.id, 1)}>
                      <Plus size={15} /><span>{cart[item.id] ? `Agregar (${cart[item.id]})` : "Agregar"}</span>
                    </Button>
                  ) : (
                    <a className="company-inquire-link" href={`mailto:${company.email}?subject=${encodeURIComponent(`Consulta: ${item.name}`)}`}>Consultar <ArrowUpRight size={14} /></a>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="company-about" id="nosotros">
        <div className="company-about-copy">
          <span className="company-eyebrow"><i /> CONÓCENOS</span>
          <h2>{template.aboutTitle}</h2>
          <p>{template.aboutDescription}</p>
        </div>
        <div className="company-contact-card" id="contacto">
          <span className="company-eyebrow">HABLEMOS</span>
          <h3>{template.contactPrompt}</h3>
          <div className="company-contact-details">
            <a href={`mailto:${company.email}`}><Mail size={15} /><span>{company.email}</span><ArrowUpRight size={14} /></a>
            {company.telefono && <a href={whatsappHref ? `${whatsappHref}?text=${encodeURIComponent(`Hola, quisiera más información sobre ${company.nombre_comercial}.`)}` : `tel:${company.telefono}`} target={whatsappHref ? "_blank" : undefined} rel={whatsappHref ? "noreferrer" : undefined}>
              <Phone size={15} /><span>{company.telefono}</span><ArrowUpRight size={14} />
            </a>}
            <div><MapPin size={15} /><span>{company.direccion}, {company.ciudad}{company.provincia ? `, ${company.provincia}` : ""}</span></div>
          </div>
          {company.tienda_online && <a className="company-contact-cta" href="#coleccion">Explorar {company.giro_negocio === "alimentos" ? "el menú" : company.giro_negocio === "servicios" ? "los servicios" : "los productos"} <ArrowRight size={15} /></a>}
        </div>
      </section>

      <footer className="company-footer">
        <Link href={`/sitio/${company.slug}`} className="company-footer-brand">
          {company.logo_url
            ? <Image className="company-brand-logo" src={company.logo_url} alt="" width={30} height={30} unoptimized />
            : <span className="company-brand-mark">{company.nombre_comercial.slice(0, 1).toUpperCase()}</span>}
          <strong>{company.nombre_comercial}</strong>
        </Link>
        <span>{company.ciudad}{company.provincia ? `, ${company.provincia}` : ""}</span>
        <span>© {new Date().getFullYear()} {company.nombre_comercial}</span>
      </footer>

      {company.cuenta_clientes_habilitada && (
        <dialog
          ref={accountDialogRef}
          className="company-account-dialog"
          aria-labelledby="company-account-dialog-title"
          onClose={() => setAccountModalOpen(false)}
          onClick={(event) => {
            if (event.target === event.currentTarget) setAccountModalOpen(false);
          }}
        >
          <div className="company-account-dialog-content">
            <header className="company-account-dialog-header">
              <div>
                <span className="customer-account-kicker">CLIENTES DE {company.nombre_comercial.toUpperCase()}</span>
                <h2 id="company-account-dialog-title">Mi cuenta</h2>
              </div>
              <button className="company-account-dialog-close" type="button" aria-label="Cerrar mi cuenta" onClick={() => setAccountModalOpen(false)}><X size={19} /></button>
            </header>
            <section className="customer-account-panel customer-account-dashboard-panel customer-account-modal-panel">
              <CustomerAccountContent company={company} />
            </section>
          </div>
        </dialog>
      )}

      {company.tienda_online && cartOpen && (
        <div className="company-cart-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setCartOpen(false); }}>
          <aside className="company-cart" aria-label="Tu pedido">
            <div className="company-cart-heading"><div><span className="company-eyebrow">{company.nombre_comercial}</span><h2>Tu pedido <span>{cartCount}</span></h2></div><Button variant="ghost" size="icon" aria-label="Cerrar pedido" onClick={() => setCartOpen(false)}><X size={19} /></Button></div>
            {cartCount === 0 ? <p className="company-cart-empty">Todavía no agregas productos.</p> : (
              <div className="company-cart-lines">
                {template.items.filter((item) => cart[item.id]).map((item) => (
                  <div className="company-cart-line" key={item.id}>
                    <div><strong>{item.name}</strong><small>{formatter.format(item.price)} c/u</small></div>
                    <div className="company-quantity"><Button variant="outline" size="icon" aria-label={`Quitar ${item.name}`} onClick={() => changeQuantity(item.id, -1)}><Minus size={13} /></Button><span>{cart[item.id]}</span><Button variant="outline" size="icon" aria-label={`Agregar ${item.name}`} onClick={() => changeQuantity(item.id, 1)}><Plus size={13} /></Button></div>
                  </div>
                ))}
              </div>
            )}
            {storageError && <p className="company-storage-error" role="alert">{storageError}</p>}
            <div className="company-cart-total"><span>Total estimado</span><strong>{formatter.format(cartTotal)}</strong></div>
            {orderSent && <p className="company-order-sent">Pedido preparado. La empresa confirmará disponibilidad y entrega.</p>}
            {whatsappNumber ? (
              <a className="company-checkout" href={cartCount ? `https://wa.me/${whatsappNumber}?text=${orderMessage}` : undefined} aria-disabled={cartCount === 0} target="_blank" rel="noreferrer" onClick={(event) => { if (!savePendingOrder()) event.preventDefault(); }}>Enviar pedido <ArrowUpRight size={16} /></a>
            ) : (
              <Button className="company-checkout" disabled={cartCount === 0} onClick={savePendingOrder}>Solicitar pedido <ArrowUpRight size={16} /></Button>
            )}
          </aside>
        </div>
      )}
    </main>
  );
}