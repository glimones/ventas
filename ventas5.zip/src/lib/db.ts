import { Pool } from "pg";

declare global {
  var ventasDatabasePool: Pool | undefined;
}

export class DatabaseConfigurationError extends Error {}

export function getDatabasePool(): Pool {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new DatabaseConfigurationError("Falta configurar DATABASE_URL.");
  }

  const schema = process.env.DATABASE_SCHEMA || "ventas";
  if (!/^[a-z_][a-z0-9_]*$/.test(schema)) {
    throw new DatabaseConfigurationError(
      "DATABASE_SCHEMA debe ser un identificador PostgreSQL en minúsculas.",
    );
  }

  globalThis.ventasDatabasePool ??= new Pool({
    connectionString,
    options: `-c search_path=${schema},public`,
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
  });

  return globalThis.ventasDatabasePool;
}

export function getEmpresaId(): number {
  const empresaId = Number(process.env.DATABASE_EMPRESA_ID);
  if (!Number.isSafeInteger(empresaId) || empresaId <= 0) {
    throw new DatabaseConfigurationError(
      "DATABASE_EMPRESA_ID debe ser un entero positivo.",
    );
  }

  return empresaId;
}