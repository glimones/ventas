import { empresasDemo } from "@/data/empresas-demo";

export type ModuleRecord = {
  id: number;
  created_at: string;
  updated_at: string;
  [key: string]: unknown;
};

type ModuleTable = Map<number, ModuleRecord>;

type MockDatabaseState = {
  tables: Map<string, ModuleTable>;
  sequences: Map<string, number>;
};

declare global {
  var __ventasPostgresMock: MockDatabaseState | undefined;
}

const state = (globalThis.__ventasPostgresMock ??= {
  tables: new Map<string, ModuleTable>(),
  sequences: new Map<string, number>(),
});

if (!state.tables.has("empresas")) {
  const seededCompanies = new Map<number, ModuleRecord>();

  for (const company of empresasDemo) {
    seededCompanies.set(company.id, {
      ...company,
      created_at: company.fecha_creacion ?? new Date().toISOString(),
      updated_at: company.fecha_actualizacion ?? new Date().toISOString(),
    });
  }

  state.tables.set("empresas", seededCompanies);
  state.sequences.set("empresas", Math.max(...empresasDemo.map((company) => company.id)));
}

function getTable(moduleKey: string): ModuleTable {
  let table = state.tables.get(moduleKey);

  if (!table) {
    table = new Map<number, ModuleRecord>();
    state.tables.set(moduleKey, table);
  }

  return table;
}

function getNextId(moduleKey: string): number {
  const nextId = (state.sequences.get(moduleKey) ?? 0) + 1;
  state.sequences.set(moduleKey, nextId);
  return nextId;
}

export class PostgresMockAdapter {
  readonly adapter = "postgresql-mock";

  async list(
    moduleKey: string,
    options: { search?: string; page?: number; pageSize?: number } = {},
  ) {
    const table = getTable(moduleKey);
    const search = options.search?.trim().toLocaleLowerCase();
    const page = Math.max(1, options.page ?? 1);
    const pageSize = Math.min(100, Math.max(1, options.pageSize ?? 50));
    const matchingRecords = [...table.values()].filter((record) =>
      !search || JSON.stringify(record).toLocaleLowerCase().includes(search),
    );
    const offset = (page - 1) * pageSize;

    return {
      data: matchingRecords.slice(offset, offset + pageSize),
      pagination: {
        page,
        pageSize,
        total: matchingRecords.length,
        totalPages: Math.ceil(matchingRecords.length / pageSize),
      },
      adapter: this.adapter,
    };
  }

  async find(moduleKey: string, id: number): Promise<ModuleRecord | undefined> {
    return getTable(moduleKey).get(id);
  }

  async create(
    moduleKey: string,
    values: Record<string, unknown>,
  ): Promise<ModuleRecord> {
    const now = new Date().toISOString();
    const record: ModuleRecord = {
      ...values,
      id: getNextId(moduleKey),
      created_at: now,
      updated_at: now,
    };

    getTable(moduleKey).set(record.id, record);
    return record;
  }

  async update(
    moduleKey: string,
    id: number,
    values: Record<string, unknown>,
  ): Promise<ModuleRecord | undefined> {
    const table = getTable(moduleKey);
    const current = table.get(id);

    if (!current) return undefined;

    const updated: ModuleRecord = {
      ...current,
      ...values,
      id,
      created_at: current.created_at,
      updated_at: new Date().toISOString(),
    };

    table.set(id, updated);
    return updated;
  }

  async delete(moduleKey: string, id: number): Promise<ModuleRecord | undefined> {
    const table = getTable(moduleKey);
    const current = table.get(id);

    if (!current) return undefined;

    table.delete(id);
    return current;
  }
}

export const postgresMock = new PostgresMockAdapter();