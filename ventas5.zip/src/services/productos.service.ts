import { getDatabasePool, getEmpresaId } from "@/lib/db";
import type { PoolClient } from "pg";

export class ProductoValidationError extends Error {}

export type ProductoInput = {
  codigo: string;
  nombre: string;
  descripcion?: string;
  categoria_id: number;
  marca_id?: number | null;
  unidad_medida_id: number;
  ubicacion_id?: number | null;
  proveedor_id?: number | null;
  bodega_id?: number | null;
  stock_actual?: number;
  precio_compra: number;
  precio_venta: number;
  costo: number;
  stock_minimo: number;
  stock_maximo: number;
  imagen_url?: string;
  estado: string;
};

function toPositiveId(value: unknown, label: string, optional = false): number | null {
  if (optional && (value === undefined || value === null || value === "")) return null;
  const id = Number(value);
  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new ProductoValidationError(`${label} no es válido.`);
  }
  return id;
}

function toNonNegative(value: unknown, label: string) {
  const number = Number(value ?? 0);
  if (!Number.isFinite(number) || number < 0) {
    throw new ProductoValidationError(`${label} debe ser un número igual o mayor que cero.`);
  }
  return number;
}

function normalizeProducto(input: unknown): ProductoInput {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new ProductoValidationError("Los datos del producto no son válidos.");
  }
  const data = input as Record<string, unknown>;
  if (typeof data.codigo !== "string" || !data.codigo.trim() ||
      typeof data.nombre !== "string" || !data.nombre.trim()) {
    throw new ProductoValidationError("El código y el nombre del producto son obligatorios.");
  }
  const state = String(data.estado ?? "Activo").toLowerCase();
  if (state !== "activo" && state !== "inactivo") {
    throw new ProductoValidationError("El estado del producto debe ser Activo o Inactivo.");
  }
  return {
    codigo: data.codigo.trim(),
    nombre: data.nombre.trim(),
    descripcion: typeof data.descripcion === "string" ? data.descripcion.trim() : "",
    categoria_id: toPositiveId(data.categoria_id, "La categoría") as number,
    marca_id: toPositiveId(data.marca_id, "La marca", true),
    unidad_medida_id: toPositiveId(data.unidad_medida_id, "La unidad de medida") as number,
    ubicacion_id: toPositiveId(data.ubicacion_id, "La ubicación", true),
    proveedor_id: toPositiveId(data.proveedor_id, "El proveedor", true),
    bodega_id: toPositiveId(data.bodega_id, "La bodega", true),
    stock_actual: toNonNegative(data.stock_actual, "El stock inicial"),
    precio_compra: toNonNegative(data.precio_compra, "El precio de compra"),
    precio_venta: toNonNegative(data.precio_venta, "El precio de venta"),
    costo: toNonNegative(data.costo, "El costo"),
    stock_minimo: toNonNegative(data.stock_minimo, "El stock mínimo"),
    stock_maximo: toNonNegative(data.stock_maximo, "El stock máximo"),
    imagen_url: typeof data.imagen_url === "string" ? data.imagen_url.trim() : "",
    estado: state === "inactivo" ? "INACTIVO" : "ACTIVO",
  };
}

async function validateForeignKeys(client: PoolClient, companyId: number, form: ProductoInput) {
  const references: Array<[string, number | null, string]> = [
    ["categorias_productos", form.categoria_id, "La categoría"],
    ["marcas", form.marca_id, "La marca"],
    ["unidades_medida", form.unidad_medida_id, "La unidad de medida"],
    ["ubicaciones_bodega", form.ubicacion_id, "La ubicación"],
    ["proveedores", form.proveedor_id, "El proveedor"],
    ["bodegas", form.bodega_id, "La bodega"],
  ];
  for (const [table, id, label] of references) {
    if (id === null) continue;
    const key = table === "proveedores" ? "tercero_id" : "id";
    const result = await client.query(
      `SELECT 1 FROM ${table} WHERE ${key} = $1 AND empresa_id = $2 LIMIT 1`,
      [id, companyId],
    );
    if (!result.rowCount) throw new ProductoValidationError(`${label} no existe para esta empresa.`);
  }
}

async function rollbackQuietly(client: PoolClient) {
  await client.query("ROLLBACK").catch(() => undefined);
}

export async function listarCatalogosProducto() {
  const empresaId = getEmpresaId();
  const pool = getDatabasePool();
  const [categorias, marcas, unidades, bodegas, ubicaciones, proveedores] = await Promise.all([
    pool.query("SELECT id, codigo, nombre FROM categorias_productos WHERE empresa_id = $1 AND estado = 'ACTIVA' ORDER BY nombre", [empresaId]),
    pool.query("SELECT id, codigo, nombre FROM marcas WHERE empresa_id = $1 AND estado = 'ACTIVA' ORDER BY nombre", [empresaId]),
    pool.query("SELECT id, codigo, nombre, abreviatura FROM unidades_medida WHERE empresa_id = $1 AND estado = 'ACTIVA' ORDER BY nombre", [empresaId]),
    pool.query("SELECT id, codigo, nombre FROM bodegas WHERE empresa_id = $1 AND estado = 'ACTIVA' ORDER BY nombre", [empresaId]),
    pool.query("SELECT id, bodega_id, codigo, pasillo, estanteria, nivel FROM ubicaciones_bodega WHERE empresa_id = $1 ORDER BY codigo", [empresaId]),
    pool.query("SELECT p.tercero_id AS id, p.codigo_proveedor AS codigo, t.razon_social AS nombre FROM proveedores p JOIN terceros t ON t.id = p.tercero_id AND t.empresa_id = p.empresa_id WHERE p.empresa_id = $1 AND t.estado = 'ACTIVO' ORDER BY t.razon_social", [empresaId]),
  ]);
  return {
    categorias: categorias.rows,
    marcas: marcas.rows,
    unidades: unidades.rows,
    bodegas: bodegas.rows,
    ubicaciones: ubicaciones.rows,
    proveedores: proveedores.rows,
  };
}

export async function listarProductos(search = "") {
  const params: unknown[] = [getEmpresaId()];
  const searchText = search.trim();
  const searchClause = searchText
    ? (params.push(`%${searchText}%`), `AND (p.codigo ILIKE $2 OR p.nombre ILIKE $2 OR COALESCE(p.descripcion, '') ILIKE $2)`)
    : "";
  const result = await getDatabasePool().query<Record<string, unknown>>(
        `SELECT p.id::text, p.codigo, p.nombre, p.descripcion,
          p.categoria_id, p.marca_id, p.unidad_medida_id, p.ubicacion_id,
            proveedor.proveedor_id AS proveedor_id,
            COALESCE(c.nombre, '') AS categoria,
            COALESCE(m.nombre, '') AS marca,
            COALESCE(u.nombre, '') AS unidad_medida,
            p.precio_compra, p.precio_venta, p.costo,
            p.stock_minimo, p.stock_maximo, p.imagen_url,
            CASE WHEN p.estado = 'ACTIVO' THEN 'Activo' ELSE 'Inactivo' END AS estado,
            COALESCE(SUM(sb.cantidad), 0)::numeric AS stock_actual
     FROM productos p
     LEFT JOIN categorias_productos c
       ON c.id = p.categoria_id AND c.empresa_id = p.empresa_id
     LEFT JOIN marcas m
       ON m.id = p.marca_id AND m.empresa_id = p.empresa_id
     LEFT JOIN unidades_medida u
       ON u.id = p.unidad_medida_id AND u.empresa_id = p.empresa_id
     LEFT JOIN stock_bodega sb
       ON sb.producto_id = p.id AND sb.empresa_id = p.empresa_id
     LEFT JOIN LATERAL (
       SELECT pp.proveedor_id FROM productos_proveedores pp
       WHERE pp.producto_id = p.id AND pp.empresa_id = p.empresa_id
       ORDER BY pp.proveedor_id LIMIT 1
     ) proveedor ON TRUE
     WHERE p.empresa_id = $1 ${searchClause}
     GROUP BY p.id, c.nombre, m.nombre, u.nombre, proveedor.proveedor_id
     ORDER BY p.nombre, p.id`,
    params,
  );

  return result.rows.map((row) => ({
    ...row,
    id: Number(row.id),
    categoria_id: Number(row.categoria_id),
    marca_id: row.marca_id == null ? null : Number(row.marca_id),
    unidad_medida_id: Number(row.unidad_medida_id),
    ubicacion_id: row.ubicacion_id == null ? null : Number(row.ubicacion_id),
    proveedor_id: row.proveedor_id == null ? null : Number(row.proveedor_id),
    precio_compra: Number(row.precio_compra),
    precio_venta: Number(row.precio_venta),
    costo: Number(row.costo),
    stock_actual: Number(row.stock_actual),
    stock_minimo: Number(row.stock_minimo),
    stock_maximo: Number(row.stock_maximo),
  }));
}

export async function crearProducto(input: unknown) {
  const form = normalizeProducto(input);
  const empresaId = getEmpresaId();
  if (form.stock_actual > 0 && form.bodega_id === null) {
    throw new ProductoValidationError("Selecciona la bodega para registrar el stock inicial.");
  }
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    await validateForeignKeys(client, empresaId, form);
    const result = await client.query<{ id: string }>(
      `INSERT INTO productos (
         empresa_id, codigo, nombre, descripcion, categoria_id, marca_id,
         unidad_medida_id, ubicacion_id, precio_compra, precio_venta, costo,
         stock_minimo, stock_maximo, imagen_url, estado
       ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
       RETURNING id::text`,
      [empresaId, form.codigo, form.nombre, form.descripcion || null, form.categoria_id, form.marca_id,
        form.unidad_medida_id, form.ubicacion_id, form.precio_compra, form.precio_venta, form.costo,
        form.stock_minimo, form.stock_maximo, form.imagen_url || null, form.estado],
    );
    const productId = Number(result.rows[0].id);
    if (form.proveedor_id !== null) {
      await client.query(
        `INSERT INTO productos_proveedores (empresa_id, producto_id, proveedor_id, costo_referencia)
         VALUES ($1, $2, $3, $4)`,
        [empresaId, productId, form.proveedor_id, form.costo],
      );
    }
    if (form.stock_actual > 0 && form.bodega_id !== null) {
      await client.query(
        `INSERT INTO stock_bodega (empresa_id, producto_id, bodega_id, cantidad)
         VALUES ($1, $2, $3, $4)`,
        [empresaId, productId, form.bodega_id, form.stock_actual],
      );
      await client.query(
        `INSERT INTO movimientos_inventario
           (empresa_id, producto_id, bodega_id, tipo, cantidad, motivo, documento_referencia)
         VALUES ($1, $2, $3, 'ENTRADA', $4, 'STOCK_INICIAL', 'ALTA_PRODUCTO')`,
        [empresaId, productId, form.bodega_id, form.stock_actual],
      );
    }
    await client.query("COMMIT");
    return productId;
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function actualizarProducto(id: number, input: unknown) {
  const form = normalizeProducto(input);
  const empresaId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    await validateForeignKeys(client, empresaId, form);
    const result = await client.query(
      `UPDATE productos SET
         codigo=$3, nombre=$4, descripcion=$5, categoria_id=$6, marca_id=$7,
         unidad_medida_id=$8, ubicacion_id=$9, precio_compra=$10,
         precio_venta=$11, costo=$12, stock_minimo=$13, stock_maximo=$14,
         imagen_url=$15, estado=$16, actualizado_en=now()
       WHERE id=$1 AND empresa_id=$2`,
      [id, empresaId, form.codigo, form.nombre, form.descripcion || null, form.categoria_id,
        form.marca_id, form.unidad_medida_id, form.ubicacion_id, form.precio_compra,
        form.precio_venta, form.costo, form.stock_minimo, form.stock_maximo,
        form.imagen_url || null, form.estado],
    );
    if (!result.rowCount) {
      await rollbackQuietly(client);
      return false;
    }
    await client.query("DELETE FROM productos_proveedores WHERE empresa_id=$1 AND producto_id=$2", [empresaId, id]);
    if (form.proveedor_id !== null) {
      await client.query(
        `INSERT INTO productos_proveedores (empresa_id, producto_id, proveedor_id, costo_referencia)
         VALUES ($1, $2, $3, $4)`,
        [empresaId, id, form.proveedor_id, form.costo],
      );
    }
    await client.query("COMMIT");
    return true;
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function desactivarProducto(id: number) {
  const result = await getDatabasePool().query(
    `UPDATE productos SET estado='INACTIVO', actualizado_en=now()
     WHERE id=$1 AND empresa_id=$2`,
    [id, getEmpresaId()],
  );
  return (result.rowCount ?? 0) > 0;
}

export async function registrarMovimientoProducto(productoId: number, input: unknown) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new ProductoValidationError("Los datos del movimiento no son válidos.");
  }
  const data = input as Record<string, unknown>;
  const warehouseId = toPositiveId(data.bodega_id, "La bodega") as number;
  const quantity = Number(data.cantidad);
  const type = String(data.tipo).toUpperCase();
  if (!Number.isFinite(quantity) || quantity <= 0) throw new ProductoValidationError("La cantidad debe ser mayor que cero.");
  if (type !== "ENTRADA" && type !== "SALIDA") throw new ProductoValidationError("El tipo debe ser entrada o salida.");
  const date = typeof data.fecha === "string" && data.fecha ? data.fecha : new Date().toISOString();
  const companyId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const product = await client.query(
      "SELECT id FROM productos WHERE id=$1 AND empresa_id=$2 AND estado='ACTIVO' FOR UPDATE",
      [productoId, companyId],
    );
    const warehouse = await client.query(
      "SELECT id FROM bodegas WHERE id=$1 AND empresa_id=$2 AND estado='ACTIVA'",
      [warehouseId, companyId],
    );
    if (!product.rowCount || !warehouse.rowCount) {
      throw new ProductoValidationError("El producto o la bodega no existe o está inactivo.");
    }
    const current = await client.query<{ cantidad: string }>(
      `SELECT cantidad FROM stock_bodega WHERE producto_id=$1 AND bodega_id=$2 FOR UPDATE`,
      [productoId, warehouseId],
    );
    const currentQuantity = Number(current.rows[0]?.cantidad ?? 0);
    if (type === "SALIDA" && currentQuantity < quantity) {
      throw new ProductoValidationError("La salida excede el stock disponible en esa bodega.");
    }
    const nextQuantity = currentQuantity + (type === "ENTRADA" ? quantity : -quantity);
    await client.query(
      `INSERT INTO stock_bodega (empresa_id, producto_id, bodega_id, cantidad)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (producto_id, bodega_id)
       DO UPDATE SET cantidad=EXCLUDED.cantidad, actualizado_en=now()`,
      [companyId, productoId, warehouseId, nextQuantity],
    );
    await client.query(
      `INSERT INTO movimientos_inventario
         (empresa_id, producto_id, bodega_id, tipo, cantidad, fecha, motivo, documento_referencia)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [companyId, productoId, warehouseId, type, quantity, date, String(data.motivo ?? ""), String(data.documento_referencia ?? "") || null],
    );
    await client.query("COMMIT");
    return { producto_id: productoId, bodega_id: warehouseId, cantidad: nextQuantity };
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}
