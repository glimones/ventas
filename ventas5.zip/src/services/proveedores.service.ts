import type { PoolClient } from "pg";
import { getDatabasePool, getEmpresaId } from "@/lib/db";

export type ProveedorInput = {
  codigo: string;
  razon_social: string;
  nombre_comercial: string;
  tipo_identificacion: string;
  identificacion: string;
  categoria: string;
  email: string;
  telefono: string;
  ciudad: string;
  dias_credito: number;
  estado: string;
};

export class ProveedorValidationError extends Error {}

function mapProveedor(row: Record<string, unknown>) {
  const days = Number(row.dias_credito ?? 0);
  return {
    id: Number(row.id),
    codigo: String(row.codigo ?? ""),
    razon_social: String(row.razon_social ?? ""),
    nombre_comercial: String(row.nombre_comercial ?? ""),
    tipo_identificacion: String(row.tipo_identificacion ?? ""),
    identificacion: String(row.identificacion ?? ""),
    categoria: String(row.categoria ?? ""),
    email: String(row.email ?? ""),
    telefono: String(row.telefono ?? ""),
    ciudad: String(row.ciudad ?? ""),
    condiciones_pago: days > 0 ? "CREDITO" : "CONTADO",
    dias_credito: days,
    estado: String(row.estado).startsWith("INACT") ? "Inactivo" : "Activo",
  };
}

function validate(input: unknown): ProveedorInput {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new ProveedorValidationError("Los datos del proveedor no son válidos.");
  }
  const data = input as Record<string, unknown>;
  const required = ["codigo", "razon_social", "nombre_comercial", "tipo_identificacion", "identificacion", "categoria"];
  if (required.some((field) => typeof data[field] !== "string" || !String(data[field]).trim())) {
    throw new ProveedorValidationError("Completa los campos obligatorios del proveedor.");
  }
  const days = Number(data.dias_credito ?? 0);
  if (!Number.isInteger(days) || days < 0) {
    throw new ProveedorValidationError("Los días de crédito deben ser un entero igual o mayor que cero.");
  }
  return {
    codigo: String(data.codigo).trim(),
    razon_social: String(data.razon_social).trim(),
    nombre_comercial: String(data.nombre_comercial).trim(),
    tipo_identificacion: String(data.tipo_identificacion).trim(),
    identificacion: String(data.identificacion).trim(),
    categoria: String(data.categoria).trim(),
    email: typeof data.email === "string" ? data.email.trim() : "",
    telefono: typeof data.telefono === "string" ? data.telefono.trim() : "",
    ciudad: typeof data.ciudad === "string" ? data.ciudad.trim() : "",
    dias_credito: days,
    estado: String(data.estado ?? "Activo"),
  };
}

async function rollbackQuietly(client: PoolClient) {
  await client.query("ROLLBACK").catch(() => undefined);
}

export async function listarProveedores(search = "") {
  const values: unknown[] = [getEmpresaId()];
  const searchValue = search.trim();
  const searchClause = searchValue
    ? (values.push(`%${searchValue}%`), `AND (t.nombre ILIKE $2 OR t.razon_social ILIKE $2 OR t.documento ILIKE $2 OR p.codigo_proveedor ILIKE $2)`)
    : "";
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `SELECT t.id::text, p.codigo_proveedor AS codigo, t.razon_social,
            t.nombre AS nombre_comercial, t.tipo_documento AS tipo_identificacion,
            t.documento AS identificacion, p.categoria, t.email, t.telefono,
            t.ciudad, p.dias_credito, t.estado
     FROM terceros t
     JOIN proveedores p ON p.tercero_id = t.id AND p.empresa_id = t.empresa_id
     WHERE t.empresa_id = $1 AND t.tipo IN ('PROVEEDOR', 'AMBOS') ${searchClause}
     ORDER BY t.razon_social, t.nombre, t.id`,
    values,
  );
  return result.rows.map(mapProveedor);
}

export async function crearProveedor(input: unknown) {
  const form = validate(input);
  const empresaId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const inserted = await client.query<{ id: string }>(
      `INSERT INTO terceros (
         empresa_id, tipo, tipo_documento, documento, nombre, razon_social,
         email, telefono, ciudad, estado
       ) VALUES ($1, 'PROVEEDOR', $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING id::text`,
      [
        empresaId, form.tipo_identificacion, form.identificacion,
        form.nombre_comercial, form.razon_social, form.email || null,
        form.telefono || null, form.ciudad || null,
        form.estado.toLowerCase() === "inactivo" ? "INACTIVO" : "ACTIVO",
      ],
    );
    const id = inserted.rows[0].id;
    await client.query(
      `INSERT INTO proveedores (tercero_id, empresa_id, codigo_proveedor, dias_credito, categoria)
       VALUES ($1, $2, $3, $4, $5)`,
      [id, empresaId, form.codigo, form.dias_credito, form.categoria],
    );
    await client.query("COMMIT");
    return Number(id);
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function actualizarProveedor(id: number, input: unknown) {
  const form = validate(input);
  const empresaId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const updated = await client.query(
      `UPDATE terceros SET tipo_documento = $3, documento = $4,
         nombre = $5, razon_social = $6, email = $7, telefono = $8,
         ciudad = $9, estado = $10, actualizado_en = now()
       WHERE id = $1 AND empresa_id = $2 AND tipo IN ('PROVEEDOR', 'AMBOS')`,
      [
        id, empresaId, form.tipo_identificacion, form.identificacion,
        form.nombre_comercial, form.razon_social, form.email || null,
        form.telefono || null, form.ciudad || null,
        form.estado.toLowerCase() === "inactivo" ? "INACTIVO" : "ACTIVO",
      ],
    );
    if (!updated.rowCount) {
      await rollbackQuietly(client);
      return false;
    }
    await client.query(
      `UPDATE proveedores SET codigo_proveedor = $3, dias_credito = $4, categoria = $5
       WHERE tercero_id = $1 AND empresa_id = $2`,
      [id, empresaId, form.codigo, form.dias_credito, form.categoria],
    );
    await client.query("COMMIT");
    return true;
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function desactivarProveedor(id: number) {
  const result = await getDatabasePool().query(
    `UPDATE terceros SET estado = 'INACTIVO', actualizado_en = now()
     WHERE id = $1 AND empresa_id = $2 AND tipo IN ('PROVEEDOR', 'AMBOS')`,
    [id, getEmpresaId()],
  );
  return (result.rowCount ?? 0) > 0;
}
