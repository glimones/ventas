import type { Empresa } from "@/app/empresa/types";
import { getDatabasePool } from "@/lib/db";

type EmpresaRow = {
  id: string;
  nombre_comercial: string;
  nombre_legal: string;
  ruc: string;
  direccion: string;
  ciudad: string;
  provincia: string | null;
  pais: string;
  email: string;
  telefono: string | null;
  logo_url: string | null;
  moneda: string;
  estado: string;
  slug: string;
  giro_negocio: Empresa["giro_negocio"];
  descripcion_web: string;
  color_primario: string;
  color_secundario: string;
  tienda_online: boolean;
  cuenta_clientes_habilitada: boolean;
  fecha_creacion: Date;
  fecha_actualizacion: Date;
};

function mapEmpresa(row: EmpresaRow): Empresa {
  return {
    ...row,
    id: Number(row.id),
    provincia: row.provincia ?? undefined,
    telefono: row.telefono ?? undefined,
    logo_url: row.logo_url ?? undefined,
    estado: row.estado === "ACTIVA" ? "Activa" : "Inactiva",
    fecha_creacion: row.fecha_creacion.toISOString(),
    fecha_actualizacion: row.fecha_actualizacion.toISOString(),
  };
}

const empresaColumns = `id::text, nombre_comercial, nombre_legal, ruc, direccion,
  ciudad, provincia, pais, email, telefono, logo_url, moneda_base AS moneda,
  estado, slug, giro_negocio, descripcion_web, color_primario, color_secundario,
  tienda_online, cuenta_clientes_habilitada, creado_en AS fecha_creacion,
  actualizado_en AS fecha_actualizacion`;

export async function buscarEmpresaPorSlug(slug: string): Promise<Empresa | undefined> {
  const result = await getDatabasePool().query<EmpresaRow>(
    `SELECT ${empresaColumns} FROM empresas WHERE slug = $1 AND estado = 'ACTIVA' LIMIT 1`,
    [slug],
  );
  return result.rows[0] ? mapEmpresa(result.rows[0]) : undefined;
}

export async function listarEmpresasActivas(): Promise<Empresa[]> {
  const result = await getDatabasePool().query<EmpresaRow>(
    `SELECT ${empresaColumns} FROM empresas WHERE estado = 'ACTIVA' ORDER BY nombre_comercial, id`,
  );
  return result.rows.map(mapEmpresa);
}
