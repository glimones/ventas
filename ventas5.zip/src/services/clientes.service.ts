import type { PoolClient } from "pg";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import type { ClienteFormValues } from "@/app/cliente/types";

type ClienteDbRow = {
  id: string;
  nombre: string;
  apellido: string | null;
  empresa: string | null;
  tipo_documento: string;
  documento: string;
  direccion: string | null;
  ciudad: string | null;
  provincia: string | null;
  pais: string;
  codigo_postal: string | null;
  email: string | null;
  telefono: string | null;
  celular: string | null;
  notas: string | null;
  estado: string;
  fecha_creacion: Date;
  fecha_actualizacion: Date;
};

function toCliente(row: ClienteDbRow) {
  return {
    id: Number(row.id),
    nombre: row.nombre,
    apellido: row.apellido ?? "",
    empresa: row.empresa ?? undefined,
    tipo_documento: row.tipo_documento,
    documento: row.documento,
    direccion: row.direccion ?? "",
    ciudad: row.ciudad ?? "",
    provincia: row.provincia ?? undefined,
    pais: row.pais,
    codigo_postal: row.codigo_postal ?? undefined,
    email: row.email ?? "",
    telefono: row.telefono ?? "",
    celular: row.celular ?? undefined,
    notas: row.notas ?? undefined,
    estado: row.estado === "ACTIVO" ? "Activo" : "Inactivo",
    fecha_creacion: row.fecha_creacion.toISOString(),
    fecha_actualizacion: row.fecha_actualizacion.toISOString(),
  };
}

async function rollbackQuietly(client: PoolClient) {
  await client.query("ROLLBACK").catch(() => undefined);
}

export async function listarClientes() {
  const result = await getDatabasePool().query<ClienteDbRow>(
    `SELECT id::text, nombre, apellido, razon_social AS empresa,
            tipo_documento, documento, direccion, ciudad, provincia, pais,
            codigo_postal, email, telefono, celular, notas, estado,
            creado_en AS fecha_creacion, actualizado_en AS fecha_actualizacion
     FROM terceros
     WHERE empresa_id = $1 AND tipo = 'CLIENTE'
     ORDER BY nombre, apellido, id`,
    [getEmpresaId()],
  );

  return result.rows.map(toCliente);
}

export async function crearCliente(form: ClienteFormValues) {
  const empresaId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const result = await client.query<{ id: string }>(
      `INSERT INTO terceros (
         empresa_id, tipo, tipo_documento, documento, nombre, apellido,
         razon_social, email, telefono, celular, direccion, ciudad,
         provincia, pais, codigo_postal, notas, estado
       ) VALUES (
         $1, 'CLIENTE', $2, $3, $4, $5, $6, $7, $8, $9,
         $10, $11, $12, $13, $14, $15, $16
       ) RETURNING id::text`,
      [
        empresaId,
        form.tipo_documento,
        form.documento,
        form.nombre,
        form.apellido,
        form.empresa ?? null,
        form.email,
        form.telefono,
        form.celular ?? null,
        form.direccion,
        form.ciudad,
        form.provincia ?? null,
        form.pais,
        form.codigo_postal ?? null,
        form.notas ?? null,
        form.estado === "Inactivo" ? "INACTIVO" : "ACTIVO",
      ],
    );
    const id = result.rows[0].id;

    await client.query(
      `INSERT INTO clientes (tercero_id, empresa_id)
       VALUES ($1, $2)`,
      [id, empresaId],
    );
    await client.query("COMMIT");
    return Number(id);
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function actualizarCliente(id: number, form: ClienteFormValues) {
  const empresaId = getEmpresaId();
  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const updated = await client.query(
      `UPDATE terceros SET
         tipo_documento = $3, documento = $4, nombre = $5, apellido = $6,
         razon_social = $7, email = $8, telefono = $9, celular = $10,
         direccion = $11, ciudad = $12, provincia = $13, pais = $14,
         codigo_postal = $15, notas = $16, estado = $17,
         actualizado_en = now()
       WHERE id = $1 AND empresa_id = $2 AND tipo = 'CLIENTE'`,
      [
        id,
        empresaId,
        form.tipo_documento,
        form.documento,
        form.nombre,
        form.apellido,
        form.empresa ?? null,
        form.email,
        form.telefono,
        form.celular ?? null,
        form.direccion,
        form.ciudad,
        form.provincia ?? null,
        form.pais,
        form.codigo_postal ?? null,
        form.notas ?? null,
        form.estado === "Inactivo" ? "INACTIVO" : "ACTIVO",
      ],
    );

    if (updated.rowCount === 0) {
      await rollbackQuietly(client);
      return false;
    }

    await client.query(
      `INSERT INTO clientes (tercero_id, empresa_id)
       VALUES ($1, $2)
       ON CONFLICT (tercero_id) DO NOTHING`,
      [id, empresaId],
    );
    await client.query("COMMIT");
    return true;
  } catch (error) {
    await rollbackQuietly(client);
    throw error;
  } finally {
    client.release();
  }
}

export async function desactivarCliente(id: number) {
  const result = await getDatabasePool().query(
    `UPDATE terceros
     SET estado = 'INACTIVO', actualizado_en = now()
     WHERE id = $1 AND empresa_id = $2 AND tipo = 'CLIENTE'`,
    [id, getEmpresaId()],
  );

  return (result.rowCount ?? 0) > 0;
}