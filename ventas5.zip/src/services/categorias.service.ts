import { getDatabasePool, getEmpresaId } from "@/lib/db";

export type CategoriaInput = {
  codigo: string;
  nombre: string;
  categoria_padre: string;
  margen_objetivo: number;
  estado: string;
};

export class CategoriaValidationError extends Error {}

function normalizeEstado(value: string) {
  return value.toLowerCase() === "inactivo" ? "INACTIVA" : "ACTIVA";
}

function mapCategoria(row: Record<string, unknown>) {
  return {
    id: Number(row.id),
    codigo: String(row.codigo),
    nombre: String(row.nombre),
    categoria_padre: String(row.categoria_padre ?? ""),
    margen_objetivo: Number(row.margen_objetivo ?? 0),
    estado: String(row.estado).startsWith("INACT") ? "Inactivo" : "Activo",
  };
}

export async function listarCategorias(search = "") {
  const empresaId = getEmpresaId();
  const searchValue = search.trim();
  const values: unknown[] = [empresaId];
  const searchClause = searchValue
    ? (values.push(`%${searchValue}%`), `AND (c.codigo ILIKE $2 OR c.nombre ILIKE $2)`)
    : "";
  const result = await getDatabasePool().query<Record<string, unknown>>(
    `SELECT c.id::text, c.codigo, c.nombre, p.nombre AS categoria_padre,
            c.margen_objetivo, c.estado
     FROM categorias_productos c
     LEFT JOIN categorias_productos p
       ON p.id = c.categoria_padre_id AND p.empresa_id = c.empresa_id
     WHERE c.empresa_id = $1 ${searchClause}
     ORDER BY c.codigo, c.id`,
    values,
  );
  return result.rows.map(mapCategoria);
}

function validateInput(input: unknown): CategoriaInput {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new CategoriaValidationError("Los datos de la categoría no son válidos.");
  }
  const value = input as Record<string, unknown>;
  if (typeof value.codigo !== "string" || !value.codigo.trim() ||
      typeof value.nombre !== "string" || !value.nombre.trim()) {
    throw new CategoriaValidationError("El código y el nombre son obligatorios.");
  }
  const margin = Number(value.margen_objetivo ?? 0);
  if (!Number.isFinite(margin) || margin < 0 || margin > 100) {
    throw new CategoriaValidationError("El margen objetivo debe estar entre 0 y 100.");
  }
  return {
    codigo: value.codigo.trim(),
    nombre: value.nombre.trim(),
    categoria_padre: typeof value.categoria_padre === "string" ? value.categoria_padre.trim() : "",
    margen_objetivo: margin,
    estado: typeof value.estado === "string" ? value.estado : "Activo",
  };
}

async function resolveParentId(name: string, empresaId: number, excludeId?: number) {
  if (!name) return null;
  const result = await getDatabasePool().query<{ id: string }>(
    `SELECT id::text FROM categorias_productos
     WHERE empresa_id = $1 AND nombre = $2 AND ($3::bigint IS NULL OR id <> $3)
     LIMIT 1`,
    [empresaId, name, excludeId ?? null],
  );
  if (!result.rows[0]) {
    throw new CategoriaValidationError("La categoría padre indicada no existe en esta empresa.");
  }
  return Number(result.rows[0].id);
}

export async function crearCategoria(input: unknown) {
  const form = validateInput(input);
  const empresaId = getEmpresaId();
  const parentId = await resolveParentId(form.categoria_padre, empresaId);
  const result = await getDatabasePool().query<{ id: string }>(
    `INSERT INTO categorias_productos
       (empresa_id, codigo, nombre, categoria_padre_id, margen_objetivo, estado)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id::text`,
    [empresaId, form.codigo, form.nombre, parentId, form.margen_objetivo, normalizeEstado(form.estado)],
  );
  return Number(result.rows[0].id);
}

export async function actualizarCategoria(id: number, input: unknown) {
  const form = validateInput(input);
  const empresaId = getEmpresaId();
  const parentId = await resolveParentId(form.categoria_padre, empresaId, id);
  const result = await getDatabasePool().query(
    `UPDATE categorias_productos
     SET codigo = $3, nombre = $4, categoria_padre_id = $5,
         margen_objetivo = $6, estado = $7
     WHERE id = $1 AND empresa_id = $2`,
    [id, empresaId, form.codigo, form.nombre, parentId, form.margen_objetivo, normalizeEstado(form.estado)],
  );
  return (result.rowCount ?? 0) > 0;
}

export async function desactivarCategoria(id: number) {
  const result = await getDatabasePool().query(
    `UPDATE categorias_productos SET estado = 'INACTIVA'
     WHERE id = $1 AND empresa_id = $2`,
    [id, getEmpresaId()],
  );
  return (result.rowCount ?? 0) > 0;
}
