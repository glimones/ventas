BEGIN;

SET LOCAL search_path TO sistema_ventas, public;

ALTER TABLE empresas
    ADD COLUMN IF NOT EXISTS slug VARCHAR(180),
    ADD COLUMN IF NOT EXISTS giro_negocio VARCHAR(20) NOT NULL DEFAULT 'comercio',
    ADD COLUMN IF NOT EXISTS descripcion_web TEXT NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS color_primario VARCHAR(7) NOT NULL DEFAULT '#212529',
    ADD COLUMN IF NOT EXISTS color_secundario VARCHAR(7) NOT NULL DEFAULT '#fd7e14',
    ADD COLUMN IF NOT EXISTS tienda_online BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS cuenta_clientes_habilitada BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE empresas
SET slug = COALESCE(
    NULLIF(trim(both '-' from regexp_replace(lower(nombre_comercial), '[^a-z0-9]+', '-', 'g')), ''),
    'empresa'
) || '-' || id::text
WHERE slug IS NULL OR btrim(slug) = '';

ALTER TABLE empresas
    ALTER COLUMN slug SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS empresas_slug_unique_idx
    ON empresas (slug);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'empresas_giro_negocio_check'
          AND conrelid = 'empresas'::regclass
    ) THEN
        ALTER TABLE empresas
            ADD CONSTRAINT empresas_giro_negocio_check
            CHECK (giro_negocio IN ('alimentos', 'comercio', 'servicios'));
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'empresas_slug_format_check'
          AND conrelid = 'empresas'::regclass
    ) THEN
        ALTER TABLE empresas
            ADD CONSTRAINT empresas_slug_format_check
            CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$');
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'empresas_color_primario_check'
          AND conrelid = 'empresas'::regclass
    ) THEN
        ALTER TABLE empresas
            ADD CONSTRAINT empresas_color_primario_check
            CHECK (color_primario ~ '^#[0-9A-Fa-f]{6}$');
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'empresas_color_secundario_check'
          AND conrelid = 'empresas'::regclass
    ) THEN
        ALTER TABLE empresas
            ADD CONSTRAINT empresas_color_secundario_check
            CHECK (color_secundario ~ '^#[0-9A-Fa-f]{6}$');
    END IF;
END;
$$;

COMMIT;