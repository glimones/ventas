import { NextRequest, NextResponse } from "next/server";
import { createHash, randomBytes } from "crypto";
import { getDatabasePool } from "@/lib/db";
import { findCompanyBySlug } from "@/services/clientes-web.service";

const sessionCookie = "cliente_web_session";
const waEmoji = {
  bag: String.fromCodePoint(0x1f6cd),
  package: String.fromCodePoint(0x1f4e6),
  store: String.fromCodePoint(0x1f3ea),
  person: String.fromCodePoint(0x1f464),
  mail: String.fromCodePoint(0x2709, 0xfe0f),
  phone: String.fromCodePoint(0x1f4f1),
  money: String.fromCodePoint(0x1f4b0),
  pin: String.fromCodePoint(0x1f4cc),
  check: String.fromCodePoint(0x2705),
  cart: String.fromCodePoint(0x1f6d2),
  smile: String.fromCodePoint(0x1f60a),
};

async function getSessionClient(request: NextRequest, empresaId: number) {
  const token = request.cookies.get(sessionCookie)?.value;
  if (!token) return null;
  const tokenHash = createHash("sha256").update(token).digest("hex");
  const result = await getDatabasePool().query<{ id: string }>(
    `SELECT t.id::text
     FROM cliente_web_sesiones s
     JOIN terceros t ON t.id = s.cliente_id AND t.empresa_id = s.empresa_id
     WHERE s.empresa_id = $1 AND s.token_hash = $2
       AND s.expira_en > now() AND t.estado = 'ACTIVO'
     LIMIT 1`,
    [empresaId, tokenHash],
  );
  return result.rows[0]?.id ?? null;
}

function normalizeWhatsappNumber(value: string | null | undefined) {
  const digits = String(value ?? "").replace(/\D/g, "");
  if (!digits) return null;
  if (digits.startsWith("593")) return digits;
  if (digits.startsWith("0") && digits.length === 10) return `593${digits.slice(1)}`;
  return digits;
}

async function sendCloudWhatsAppMessage(
  phone: string,
  header: string,
  body: string,
  footer: string,
  acceptanceUrl: string,
  images: string[],
) {
  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneNumberId) return false;
  let acceptanceUrlValid = false;
  try {
    const acceptanceUrlParsed = new URL(acceptanceUrl);
    acceptanceUrlValid = acceptanceUrlParsed.protocol === "https:"
      && !["localhost", "127.0.0.1", "0.0.0.0"].includes(acceptanceUrlParsed.hostname);
  } catch {
    acceptanceUrlValid = false;
  }
  const endpoint = `https://graph.facebook.com/v22.0/${phoneNumberId}/messages`;
  const interactiveResponse = acceptanceUrlValid ? await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: phone,
      type: "interactive",
      interactive: {
        type: "cta_url",
        header: { type: "text", text: header },
        body: { text: body },
        footer: { text: footer },
        action: {
          name: "cta_url",
          parameters: {
            display_text: "Aceptar pedido",
            url: acceptanceUrl,
          },
        },
      },
    }),
  }) : null;
  if (!interactiveResponse?.ok) {
    const textResponse = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: phone,
        type: "text",
        text: {
          preview_url: true,
          body: `${header}\n\n${body}\n\n${footer}\n\n${waEmoji.check} Aceptar pedido:\n${acceptanceUrl}`,
        },
      }),
    });
    if (!textResponse.ok) return false;
  }

  const publicImages = images
    .filter((value): value is string => /^https?:\/\//i.test(value))
    .filter((value, index, values) => values.indexOf(value) === index)
    .slice(0, 5);
  for (const imageUrl of publicImages) {
    await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to: phone,
        type: "image",
        image: { link: imageUrl },
      }),
    });
  }
  return true;
}

export async function GET(request: NextRequest, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const company = await findCompanyBySlug(slug);
  if (!company) return NextResponse.json({ error: "Empresa no encontrada." }, { status: 404 });
  const clientId = await getSessionClient(request, company.id);
  if (!clientId) return NextResponse.json({ error: "Debes iniciar sesión." }, { status: 401 });

  const result = await getDatabasePool().query(
    `SELECT pw.codigo AS id, pw.fecha_pedido AS date, pw.estado,
            pw.referencia_pago AS "paymentReference", pw.items,
            pw.total::float AS total, t.email AS "customerEmail"
     FROM pedidos_web pw
     JOIN terceros t ON t.id = pw.cliente_id AND t.empresa_id = pw.empresa_id
     WHERE pw.empresa_id = $1 AND pw.cliente_id = $2
     ORDER BY pw.creado_en DESC`,
    [company.id, clientId],
  );
  return NextResponse.json({ data: result.rows.map((row) => ({
    id: row.id,
    date: row.date,
    customerEmail: typeof row.customerEmail === "string" ? row.customerEmail : null,
    status: row.estado === "COMPLETADA" ? "COMPLETADA" : row.estado === "ACEPTADO" ? "ACEPTADO" : "PENDIENTE",
    paymentReference: row.paymentReference ?? undefined,
    items: row.items,
    total: Number(row.total),
  })) });
}

export async function POST(request: NextRequest, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const company = await findCompanyBySlug(slug);
  if (!company) return NextResponse.json({ error: "Empresa no encontrada." }, { status: 404 });
  const clientId = await getSessionClient(request, company.id);
  if (!clientId) return NextResponse.json({ error: "Debes iniciar sesión para enviar un pedido." }, { status: 401 });

  const body = await request.json();
  const items = Array.isArray(body.items) ? body.items : [];
  const requestedItems = items
    .map((item: Record<string, unknown>) => ({
      productId: String(item.productId ?? ""),
      quantity: Number(item.quantity),
    }))
    .filter((item: { productId: string; quantity: number }) =>
      item.productId && Number.isInteger(item.quantity) && item.quantity > 0);
  if (!requestedItems.length) {
    return NextResponse.json({ error: "El pedido debe contener al menos un producto válido." }, { status: 400 });
  }

  const mergedQuantities = new Map<string, number>();
  for (const item of requestedItems) {
    mergedQuantities.set(item.productId, (mergedQuantities.get(item.productId) ?? 0) + item.quantity);
  }

  const client = await getDatabasePool().connect();
  const code = `PED-${Date.now()}`;
  const acceptanceToken = randomBytes(24).toString("hex");
  const normalizedItems: Array<{ productId: string; name: string; quantity: number; unitPrice: number; image: string }> = [];
  try {
    await client.query("BEGIN");
    for (const [productId, quantity] of mergedQuantities) {
      const productResult = await client.query<{
        id: string;
        nombre: string;
        precio_venta: string;
        imagen_url: string | null;
        stock: string;
      }>(
        `SELECT p.id::text, p.nombre, p.precio_venta::text, p.imagen_url,
                COALESCE(SUM(sb.cantidad), 0)::text AS stock
         FROM productos p
         LEFT JOIN stock_bodega sb ON sb.producto_id = p.id AND sb.empresa_id = p.empresa_id
         WHERE p.id = $1 AND p.empresa_id = $2 AND upper(p.estado) = 'ACTIVO'
         GROUP BY p.id, p.nombre, p.precio_venta, p.imagen_url`,
        [productId, company.id],
      );
      const product = productResult.rows[0];
      if (!product) {
        await client.query("ROLLBACK");
        return NextResponse.json({ error: "El producto ya no está disponible." }, { status: 409 });
      }
      const stock = Number(product.stock);
      if (!Number.isFinite(stock) || stock <= 0 || quantity > stock) {
        await client.query("ROLLBACK");
        return NextResponse.json({
          error: stock > 0
            ? `Solo quedan ${stock} unidades disponibles de ${product.nombre}.`
            : `${product.nombre} ya no tiene stock disponible.`,
        }, { status: 409 });
      }

      normalizedItems.push({
        productId: product.id,
        name: product.nombre,
        quantity,
        unitPrice: Number(product.precio_venta),
        image: product.imagen_url || "",
      });
    }
    const total = normalizedItems.reduce((sum, item) =>
      sum + item.quantity * item.unitPrice, 0);
    await client.query(
      `INSERT INTO pedidos_web
         (empresa_id, cliente_id, codigo, items, subtotal, total, estado, token_aceptacion, aceptado_en)
       VALUES ($1, $2, $3, $4::jsonb, $5, $5, 'PENDIENTE', $6, NULL)`,
      [company.id, clientId, code, JSON.stringify(normalizedItems), total, acceptanceToken],
    );
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
  if (!normalizedItems.length) {
    return NextResponse.json({ error: "El pedido debe contener al menos un producto." }, { status: 400 });
  }
  const total = normalizedItems.reduce((sum: number, item: { quantity: number; unitPrice: number }) =>
    sum + item.quantity * item.unitPrice, 0);
  const customerResult = await getDatabasePool().query<{
    nombre: string;
    apellido: string | null;
    email: string | null;
    telefono: string | null;
    celular: string | null;
  }>(
    `SELECT nombre, apellido, email, telefono, celular
     FROM terceros
     WHERE id = $1 AND empresa_id = $2 AND tipo = 'CLIENTE'
     LIMIT 1`,
    [clientId, company.id],
  );
  const customer = customerResult.rows[0];
  const customerName = customer
    ? `${customer.nombre}${customer.apellido ? ` ${customer.apellido}` : ""}`.trim()
    : "Cliente registrado";

  const publicBaseUrl = (
    process.env.NEXT_PUBLIC_APP_URL ||
    process.env.APP_URL ||
    request.nextUrl.origin
  ).replace(/\/$/, "");
  const acceptanceUrl = new URL(
    `/api/clientes-web/${encodeURIComponent(slug)}/pedidos/aceptar?code=${encodeURIComponent(code)}&token=${acceptanceToken}`,
    publicBaseUrl,
  ).toString();
  const productLines = normalizedItems.map((item: { name: string; quantity: number; unitPrice: number }) =>
    `${waEmoji.pin} ${item.quantity} × ${item.name}\n   ${new Intl.NumberFormat("es-EC", { style: "currency", currency: "USD" }).format(item.quantity * item.unitPrice)}`,
  ).join("\n\n");
  const whatsappText = [
    `${waEmoji.bag} 😍 *NUEVO PEDIDO WEB*`,
    "",
    `${waEmoji.package} Pedido: *${code}*`,
    `${waEmoji.store} Empresa: ${company.nombre_comercial || company.nombre_legal}`,
    `${waEmoji.person} Cliente: ${customerName}`,
    ...(customer?.email ? [`${waEmoji.mail} Correo: ${customer.email}`] : []),
    ...(customer?.telefono ? [`${waEmoji.phone} Celular: ${customer.telefono}`] : []),
    ...(customer?.celular && customer.celular !== customer.telefono
      ? [`${waEmoji.phone} Móvil: ${customer.celular}`]
      : []),
    "",
    productLines,
    "",
    `${waEmoji.money} *TOTAL: ${new Intl.NumberFormat("es-EC", { style: "currency", currency: "USD" }).format(total)}*`,
    "",
    "Un cliente realizó esta compra desde la página web.",
    "",
    `${waEmoji.smile} Gracias por atender este pedido.`,
  ].join("\n");
  const whatsappPhone = normalizeWhatsappNumber(
    process.env.WHATSAPP_NOTIFICATION_NUMBER || company.telefono,
  );
  const whatsappCardBody = [
    `${waEmoji.cart} *NUEVO PEDIDO WEB*`,
    `${waEmoji.package} Pedido: *${code}*`,
    `${waEmoji.store} Empresa: ${company.nombre_comercial || company.nombre_legal}`,
    "",
    `${waEmoji.person} Cliente: ${customerName}`,
    ...(customer?.telefono || customer?.celular
      ? [`${waEmoji.phone} Contacto: ${customer.celular || customer.telefono}`]
      : []),
    "",
    productLines.replaceAll("\n   ", "\n"),
    "",
    `${waEmoji.money} *TOTAL: ${new Intl.NumberFormat("es-EC", { style: "currency", currency: "USD" }).format(total)}*`,
  ].join("\n");
  // WhatsApp se omite temporalmente: se conserva la integración para reactivarla después.
  const cloudSent = false;

  return NextResponse.json({
    data: {
      id: code,
      date: new Date().toISOString(),
      customerEmail: null,
      status: "PENDIENTE",
      items: normalizedItems,
      total,
      acceptanceUrl,
      whatsappText,
      whatsappSent: cloudSent,
      whatsappPhone,
    },
  }, { status: 201 });
}

export async function PATCH(request: NextRequest, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const company = await findCompanyBySlug(slug);
  if (!company) return NextResponse.json({ error: "Empresa no encontrada." }, { status: 404 });
  const clientId = await getSessionClient(request, company.id);
  if (!clientId) return NextResponse.json({ error: "Debes iniciar sesión." }, { status: 401 });

  const body = await request.json();
  const code = typeof body.orderId === "string" ? body.orderId.trim() : "";
  if (!code) return NextResponse.json({ error: "Pedido inválido." }, { status: 400 });

  if (Array.isArray(body.items)) {
    const items = body.items;
    const total = items.reduce((sum: number, item: { quantity: number; unitPrice: number }) =>
      sum + Number(item.quantity) * Number(item.unitPrice), 0);
    await getDatabasePool().query(
      `UPDATE pedidos_web SET items = $4::jsonb, subtotal = $5, total = $5, actualizado_en = now()
       WHERE empresa_id = $1 AND cliente_id = $2 AND codigo = $3 AND estado = 'PENDIENTE'`,
      [company.id, clientId, code, JSON.stringify(items), total],
    );
    return NextResponse.json({ data: { id: code, items, total } });
  }

  if (body.status === "COMPLETADA") {
    const reference = typeof body.paymentReference === "string" ? body.paymentReference : null;
    const client = await getDatabasePool().connect();
    try {
      await client.query("BEGIN");
      const orderResult = await client.query<{ items: unknown }>(
        `SELECT items FROM pedidos_web
         WHERE empresa_id = $1 AND cliente_id = $2 AND codigo = $3 AND estado = 'PENDIENTE'
         FOR UPDATE`,
        [company.id, clientId, code],
      );
      if (!orderResult.rows[0]) {
        await client.query("ROLLBACK");
        return NextResponse.json({ error: "El pedido pendiente ya no existe." }, { status: 409 });
      }

      const rawItems = orderResult.rows[0].items;
      const orderItems = (Array.isArray(rawItems)
        ? rawItems
        : typeof rawItems === "string"
          ? JSON.parse(rawItems)
          : []) as Array<{ productId?: unknown; quantity?: unknown }>;

      const quantities = new Map<string, number>();
      for (const item of orderItems) {
        const productId = String(item.productId ?? "");
        const quantity = Number(item.quantity);
        if (!productId || !Number.isInteger(quantity) || quantity <= 0) {
          await client.query("ROLLBACK");
          return NextResponse.json({ error: "El pedido contiene productos inválidos." }, { status: 400 });
        }
        quantities.set(productId, (quantities.get(productId) ?? 0) + quantity);
      }

      for (const [productId, quantity] of quantities) {
        const productResult = await client.query<{ id: string; nombre: string; stock: string }>(
          `SELECT p.id::text, p.nombre, COALESCE(SUM(sb.cantidad), 0)::text AS stock
           FROM productos p
           LEFT JOIN stock_bodega sb ON sb.producto_id = p.id AND sb.empresa_id = p.empresa_id
            WHERE p.id = $1 AND p.empresa_id = $2 AND upper(p.estado) = 'ACTIVO'
            GROUP BY p.id, p.nombre`,
          [productId, company.id],
        );
        const product = productResult.rows[0];
        if (!product) {
          await client.query("ROLLBACK");
          return NextResponse.json({ error: "Uno de los productos ya no está disponible." }, { status: 409 });
        }

        const stock = Number(product.stock);
        if (!Number.isFinite(stock) || quantity > stock) {
          await client.query("ROLLBACK");
          return NextResponse.json({
            error: stock > 0
              ? `Solo quedan ${stock} unidades disponibles de ${product.nombre}.`
              : `${product.nombre} ya no tiene stock disponible.`,
          }, { status: 409 });
        }

        const stockRows = await client.query<{ bodega_id: string; cantidad: string }>(
          `SELECT bodega_id::text, cantidad::text
           FROM stock_bodega
           WHERE empresa_id = $1 AND producto_id = $2 AND cantidad > 0
           ORDER BY bodega_id
           FOR UPDATE`,
          [company.id, productId],
        );

        let remaining = quantity;
        for (const stockRow of stockRows.rows) {
          if (remaining <= 0) break;
          const available = Number(stockRow.cantidad);
          const deducted = Math.min(available, remaining);
          await client.query(
            `UPDATE stock_bodega
             SET cantidad = cantidad - $1, actualizado_en = now()
             WHERE empresa_id = $2 AND producto_id = $3 AND bodega_id = $4`,
            [deducted, company.id, productId, stockRow.bodega_id],
          );
          await client.query(
            `INSERT INTO movimientos_inventario
               (empresa_id, producto_id, bodega_id, tipo, cantidad, motivo, documento_tipo, documento_referencia)
             VALUES ($1, $2, $3, 'SALIDA', $4, 'Compra desde la tienda web', 'PEDIDO_WEB', $5)`,
            [company.id, productId, stockRow.bodega_id, deducted, code],
          );
          remaining -= deducted;
        }
      }

      await client.query(
        `UPDATE pedidos_web SET estado = 'COMPLETADA', referencia_pago = $4, actualizado_en = now()
         WHERE empresa_id = $1 AND cliente_id = $2 AND codigo = $3 AND estado = 'PENDIENTE'`,
        [company.id, clientId, code, reference],
      );
      await client.query("COMMIT");
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }
  return NextResponse.json({ data: { id: code } });
}

export async function DELETE(request: NextRequest, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const company = await findCompanyBySlug(slug);
  if (!company) return NextResponse.json({ error: "Empresa no encontrada." }, { status: 404 });
  const clientId = await getSessionClient(request, company.id);
  if (!clientId) return NextResponse.json({ error: "Debes iniciar sesión." }, { status: 401 });

  const body = await request.json();
  const code = typeof body.orderId === "string" ? body.orderId.trim() : "";
  if (!code) return NextResponse.json({ error: "Pedido inválido." }, { status: 400 });
  await getDatabasePool().query(
    `DELETE FROM pedidos_web
     WHERE empresa_id = $1 AND cliente_id = $2 AND codigo = $3 AND estado = 'PENDIENTE'`,
    [company.id, clientId, code],
  );
  return NextResponse.json({ data: { id: code } });
}
