import { NextRequest, NextResponse } from "next/server";
import { getDatabasePool } from "@/lib/db";
import { findCompanyBySlug } from "@/services/clientes-web.service";

export const runtime = "nodejs";
const iconCheck = String.fromCodePoint(0x2705);
const iconBag = String.fromCodePoint(0x1f6cd);

async function findOrder(request: NextRequest, slug: string) {
  const company = await findCompanyBySlug(slug);
  if (!company) return null;
  const code = request.nextUrl.searchParams.get("code")?.trim() ?? "";
  const token = request.nextUrl.searchParams.get("token")?.trim() ?? "";
  if (!code || !token) return { company, code, token, invalid: true };
  const result = await getDatabasePool().query(
    `SELECT estado FROM pedidos_web
     WHERE empresa_id = $1 AND codigo = $2 AND token_aceptacion = $3 LIMIT 1`,
    [company.id, code, token],
  );
  return { company, code, token, invalid: false, status: result.rows[0]?.estado ?? null };
}

export async function GET(request: NextRequest, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const order = await findOrder(request, slug);
  if (!order) return NextResponse.json({ error: "Empresa no encontrada." }, { status: 404 });
  if (order.invalid || order.status === null) {
    return NextResponse.json({ error: "El enlace de aceptación no es válido." }, { status: 400 });
  }
  const accepted = order.status === "ACEPTADO";
  const completed = order.status === "COMPLETADA";
  const html = `<!doctype html>
<html lang="es">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Confirmar pedido</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:linear-gradient(135deg,#edf5ff,#f7fafc);font-family:Inter,Arial,sans-serif;color:#17233c}
.card{width:min(440px,calc(100% - 32px));text-align:center;background:white;border-radius:24px;padding:36px 28px;box-shadow:0 20px 60px rgba(20,35,70,.14)}
.icon{width:72px;height:72px;margin:0 auto 18px;border-radius:50%;display:grid;place-items:center;background:${accepted || completed ? "#dcfce7" : "#eef3ff"};font-size:36px;color:#168a4b}
h1{margin:0 0 10px;font-size:25px}.code{display:inline-block;margin-top:18px;border-radius:999px;background:#eef3ff;color:#3157a4;padding:9px 14px;font-weight:800}
button{border:0;width:100%;margin-top:24px;border-radius:14px;padding:16px 20px;background:#16a34a;color:white;font-size:16px;font-weight:800;cursor:pointer;box-shadow:0 10px 24px rgba(22,163,74,.24)}
button:disabled{background:#98a4b3;box-shadow:none;cursor:default}
</style></head>
<body><main class="card"><div class="icon">${accepted || completed ? iconCheck : iconBag}</div>
<h1>${accepted ? "Pedido aceptado" : completed ? "Pedido completado" : "Confirmar pedido"}</h1>
<p>${accepted || completed ? "El pedido ya fue procesado correctamente." : "Confirma que puedes preparar este pedido para el cliente."}</p>
<span class="code">${order.code}</span>
${accepted || completed
  ? `<button disabled>${iconCheck} Pedido ya aceptado</button>`
  : `<form method="post"><button type="submit">${iconCheck} Aceptar pedido</button></form>`}
</main></body></html>`;

  return new NextResponse(html, {
    status: 200,
    headers: { "Content-Type": "text/html; charset=utf-8" },
  });
}

export async function POST(request: NextRequest, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const order = await findOrder(request, slug);
  if (!order || order.invalid || order.status === null) {
    return NextResponse.json({ error: "El enlace de aceptación no es válido." }, { status: 400 });
  }
  const redirectUrl = new URL(request.url);
  if (order.status !== "PENDIENTE") {
    return NextResponse.redirect(redirectUrl, 303);
  }
  const result = await getDatabasePool().query(
    `UPDATE pedidos_web SET estado='ACEPTADO', aceptado_en=now(), actualizado_en=now()
     WHERE empresa_id=$1 AND codigo=$2 AND token_aceptacion=$3 AND estado='PENDIENTE'
     RETURNING codigo`,
    [order.company.id, order.code, order.token],
  );
  if ((result.rowCount ?? 0) === 0) {
    return NextResponse.json({ error: "El pedido ya fue procesado." }, { status: 409 });
  }
  return NextResponse.redirect(redirectUrl, 303);
}
