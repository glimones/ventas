import { NextRequest, NextResponse } from "next/server";
import { randomBytes, createHash } from "crypto";
import { getDatabasePool } from "@/lib/db";
import {
  findCompanyBySlug,
  findOrCreateGeneralCustomer,
  hashPassword,
  verifyPassword,
} from "@/services/clientes-web.service";

export const runtime = "nodejs";

const sessionCookie = "cliente_web_session";

function tokenHash(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

async function readSession(request: NextRequest, empresaId: number) {
  const token = request.cookies.get(sessionCookie)?.value;
  if (!token) return null;
  const result = await getDatabasePool().query<{
    id: string;
    nombre: string;
    apellido: string | null;
    documento: string;
    email: string;
    telefono: string | null;
    ciudad: string | null;
    direccion: string | null;
  }>(
    `SELECT t.id::text, t.nombre, t.apellido, t.documento, t.email,
            t.telefono, t.ciudad, t.direccion
     FROM cliente_web_sesiones s
     JOIN terceros t ON t.id = s.cliente_id AND t.empresa_id = s.empresa_id
     WHERE s.empresa_id = $1 AND s.token_hash = $2
       AND s.expira_en > now() AND t.estado = 'ACTIVO'
     LIMIT 1`,
    [empresaId, tokenHash(token)],
  );
  return result.rows[0] ?? null;
}

export async function GET(request: NextRequest, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const company = await findCompanyBySlug(slug);
  if (!company) return NextResponse.json({ error: "Empresa no encontrada." }, { status: 404 });
  const session = await readSession(request, company.id);
  return NextResponse.json({ data: session ? {
    companyId: company.id,
    slug,
    name: session.nombre,
    surname: session.apellido ?? "",
    identification: session.documento,
    email: session.email,
    phone: session.telefono ?? "",
    city: session.ciudad ?? "",
    address: session.direccion ?? "",
  } : null });
}

export async function POST(request: NextRequest, context: { params: Promise<{ slug: string }> }) {
  const { slug } = await context.params;
  const company = await findCompanyBySlug(slug);
  if (!company || !company.cuentasHabilitadas) {
    return NextResponse.json({ error: "Las cuentas de clientes no están habilitadas." }, { status: 403 });
  }

  const body = await request.json();
  const action = body.action as string;
  if (action === "logout") {
    const token = request.cookies.get(sessionCookie)?.value;
    if (token) {
      await getDatabasePool().query(
        `DELETE FROM cliente_web_sesiones WHERE empresa_id = $1 AND token_hash = $2`,
        [company.id, tokenHash(token)],
      );
    }
    const response = NextResponse.json({ data: null });
    response.cookies.set(sessionCookie, "", { path: "/", httpOnly: true, expires: new Date(0) });
    return response;
  }

  const name = typeof body.name === "string" ? body.name.trim() : "";
  const surname = typeof body.surname === "string" ? body.surname.trim() : "";
  const identification = typeof body.identification === "string" ? body.identification.trim() : "";
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const phone = typeof body.phone === "string" ? body.phone.trim() : "";
  const city = typeof body.city === "string" ? body.city.trim() : "";
  const address = typeof body.address === "string" ? body.address.trim() : "";
  const password = typeof body.password === "string" ? body.password : "";
  if (!email || password.length < 6 || (action === "register" && (
    name.length < 2 || surname.length < 2 || identification.length < 5 ||
    city.length < 2 || address.length < 5
  ))) {
    return NextResponse.json({
      error: "Completa nombre, apellido, identificación, ciudad, dirección y usa una contraseña de al menos 6 caracteres.",
    }, { status: 400 });
  }

  const pool = getDatabasePool();
  let clientId: string;
  let profileName = name;

  if (action === "register") {
    clientId = String(await findOrCreateGeneralCustomer({
      empresaId: company.id,
      name,
      surname,
      identification,
      email,
      phone,
      city,
      address,
    }));
    await pool.query(
      `INSERT INTO cliente_web_cuentas (empresa_id, cliente_id, password_hash)
       VALUES ($1, $2, $3)
       ON CONFLICT (empresa_id, cliente_id)
       DO UPDATE SET password_hash = excluded.password_hash, actualizado_en = now()`,
      [company.id, clientId, hashPassword(password)],
    );
    const profile = await pool.query<{
      nombre: string;
      apellido: string | null;
      documento: string;
      telefono: string | null;
      ciudad: string | null;
      direccion: string | null;
    }>(
      `SELECT nombre, apellido, documento, telefono, ciudad, direccion FROM terceros
       WHERE id = $1 AND empresa_id = $2 AND tipo = 'CLIENTE' LIMIT 1`,
      [clientId, company.id],
    );
    profileName = profile.rows[0]?.nombre || name;
  } else {
    const result = await pool.query<{
      id: string;
      nombre: string;
      apellido: string | null;
      documento: string;
      telefono: string | null;
      ciudad: string | null;
      direccion: string | null;
      password_hash: string;
    }>(
      `SELECT t.id::text, t.nombre, t.apellido, t.documento, t.telefono,
              t.ciudad, t.direccion, c.password_hash
       FROM terceros t
       JOIN clientes cl ON cl.tercero_id = t.id AND cl.empresa_id = t.empresa_id
       JOIN cliente_web_cuentas c ON c.empresa_id = t.empresa_id AND c.cliente_id = t.id
       WHERE t.empresa_id = $1 AND lower(t.email) = lower($2) AND t.tipo = 'CLIENTE' AND t.estado = 'ACTIVO'
       LIMIT 1`,
      [company.id, email],
    );
    const account = result.rows[0];
    if (!account || !verifyPassword(password, account.password_hash)) {
      return NextResponse.json({ error: "Correo o contraseña incorrectos." }, { status: 401 });
    }
    clientId = account.id;
    profileName = account.nombre;
  }

  const token = randomBytes(32).toString("hex");
  await pool.query(
    `INSERT INTO cliente_web_sesiones (cliente_id, empresa_id, token_hash, expira_en)
     VALUES ($1, $2, $3, now() + interval '30 days')`,
    [clientId, company.id, tokenHash(token)],
  );
  const profileResult = await pool.query<{
    nombre: string;
    apellido: string | null;
    documento: string;
    email: string | null;
    telefono: string | null;
    ciudad: string | null;
    direccion: string | null;
  }>(
    `SELECT nombre, apellido, documento, email, telefono, ciudad, direccion
     FROM terceros
     WHERE id = $1 AND empresa_id = $2 AND tipo = 'CLIENTE'
     LIMIT 1`,
    [clientId, company.id],
  );
  const savedProfile = profileResult.rows[0];
  const response = NextResponse.json({
    data: {
      companyId: company.id,
      slug,
      name: savedProfile?.nombre || profileName,
      surname: savedProfile?.apellido ?? "",
      identification: savedProfile?.documento ?? "",
      email: savedProfile?.email ?? email,
      phone: savedProfile?.telefono ?? phone,
      city: savedProfile?.ciudad ?? "",
      address: savedProfile?.direccion ?? "",
    },
  });
  response.cookies.set(sessionCookie, token, {
    path: "/",
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 30,
  });
  return response;
}
