import { NextRequest, NextResponse } from "next/server";
import { getAccessClaims, getActiveAccessClaims } from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { getMockMenu, isMockClaims } from "@/lib/auth-mock";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  if (isMockAuthEnabled()) {
    const claims = getAccessClaims(request);
    if (!isMockClaims(claims)) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
    return NextResponse.json({ data: getMockMenu(claims.permissions), mode: "mock" });
  }

  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });

  const result = await getDatabasePool().query<{
    id: string;
    nombre: string;
    grupo: string;
    ruta: string;
    icono: string;
    orden: number;
    acciones: string[];
  }>(
    `SELECT opcion.id::text, opcion.nombre, opcion.grupo, opcion.ruta, opcion.icono, opcion.orden,
            array_agg(DISTINCT permiso.accion) AS acciones
     FROM opciones AS opcion
     JOIN permisos AS permiso ON permiso.modulo = opcion.ruta
     JOIN roles_permisos AS rol_permiso ON rol_permiso.permiso_id = permiso.id
     JOIN usuarios_roles AS usuario_rol ON usuario_rol.rol_id = rol_permiso.rol_id
       AND usuario_rol.empresa_id = opcion.empresa_id
     JOIN roles AS rol ON rol.id = usuario_rol.rol_id
       AND rol.empresa_id = usuario_rol.empresa_id AND rol.estado = 'ACTIVO'
     WHERE opcion.empresa_id = $1 AND opcion.estado = 'ACTIVO'
       AND usuario_rol.usuario_id = $2 AND permiso.accion = 'leer'
     GROUP BY opcion.id, opcion.nombre, opcion.grupo, opcion.ruta, opcion.icono, opcion.orden
     ORDER BY opcion.orden, opcion.nombre`,
    [claims.empresaId, claims.sub],
  );
  return NextResponse.json({
    data: result.rows.map((row) => ({
      ...row,
      id: Number(row.id),
      actions: claims.permissions[row.ruta] ?? claims.permissions["*"] ?? 0,
    })),
  });
}
