import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const routePattern = /^\/[a-z0-9-]+(?:\/[a-z0-9-]+)*$/;
const codePattern = /^[A-Za-z0-9._-]{2,120}$/;

function readOption(body: unknown) {
  if (body === null || typeof body !== "object" || Array.isArray(body)) return null;
  const input = body as Record<string, unknown>;
  const codigo = typeof input.codigo === "string" ? input.codigo.trim() : "";
  const nombre = typeof input.nombre === "string" ? input.nombre.trim() : "";
  const grupo = typeof input.grupo === "string" ? input.grupo.trim() : "";
  const ruta = typeof input.ruta === "string" ? input.ruta.trim() : "";
  const icono = typeof input.icono === "string" ? input.icono.trim() : "Folder";
  const orden = Number(input.orden);
  const estado = typeof input.estado === "string" && input.estado.toLowerCase().startsWith("inact") ? "INACTIVO" : "ACTIVO";
  if (!codePattern.test(codigo) || !nombre || nombre.length > 120 || !grupo || grupo.length > 100 ||
      !routePattern.test(ruta) || !icono || icono.length > 60 || !Number.isSafeInteger(orden)) return null;
  return { codigo, nombre, grupo, ruta, icono, orden, estado };
}

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const page = Math.max(1, Number(request.nextUrl.searchParams.get("page") || 1));
  const limit = Math.min(100, Math.max(1, Number(request.nextUrl.searchParams.get("limit") || 50)));
  const search = (request.nextUrl.searchParams.get("q") || "").trim();
  const result = await getDatabasePool().query(
    `SELECT id, codigo, nombre, grupo, ruta, icono, orden,
            CASE WHEN estado = 'ACTIVO' THEN 'Activo' ELSE 'Inactivo' END AS estado
     FROM opciones
     WHERE empresa_id = $1
       AND ($2 = '' OR concat_ws(' ', codigo, nombre, grupo, ruta) ILIKE '%' || $2 || '%')
     ORDER BY orden, nombre
     LIMIT $3 OFFSET $4`,
    [claims.empresaId, search, limit, (page - 1) * limit],
  );
  const count = await getDatabasePool().query<{ total: string; active: string; inactive: string }>(
    `SELECT count(*)::text AS total,
            count(*) FILTER (WHERE estado = 'ACTIVO')::text AS active,
            count(*) FILTER (WHERE estado = 'INACTIVO')::text AS inactive
     FROM opciones
     WHERE empresa_id = $1 AND ($2 = '' OR concat_ws(' ', codigo, nombre, grupo, ruta) ILIKE '%' || $2 || '%')`,
    [claims.empresaId, search],
  );
  const total = Number(count.rows[0]?.total ?? 0);
  const active = Number(count.rows[0]?.active ?? 0);
  const inactive = Number(count.rows[0]?.inactive ?? 0);
  return NextResponse.json({
    data: result.rows,
    pagination: { page, pageSize: limit, total, totalPages: Math.ceil(total / limit) },
    counts: { total, active, inactive },
    capabilities: { create: true, update: true, delete: true },
  });
}

export async function POST(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  const option = readOption(body);
  if (!option) return NextResponse.json({ error: "Revisa el código, nombre, grupo, ruta, ícono y orden de la opción." }, { status: 400 });

  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const inserted = await client.query<{ id: number }>(
      `INSERT INTO opciones (empresa_id, codigo, nombre, grupo, ruta, icono, orden, estado)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id`,
      [claims.empresaId, option.codigo, option.nombre, option.grupo, option.ruta, option.icono, option.orden, option.estado],
    );
    const permissions = await client.query<{ id: number }>(
      `INSERT INTO permisos (codigo, modulo, accion)
       SELECT 'menu:' || $1 || ':' || accion, $1, accion
       FROM unnest(ARRAY['leer', 'escribir', 'eliminar']) AS accion
       ON CONFLICT (codigo) DO UPDATE SET modulo = excluded.modulo
       RETURNING id`,
      [option.ruta],
    );
    await client.query(
      `INSERT INTO roles_permisos (rol_id, permiso_id)
       SELECT rol.id, permiso.id FROM roles rol
       CROSS JOIN unnest($2::bigint[]) AS permiso(id)
       WHERE rol.empresa_id = $1 AND rol.codigo = 'SYS_ADMIN'
       ON CONFLICT DO NOTHING`,
      [claims.empresaId, permissions.rows.map((permission) => permission.id)],
    );
    await client.query("COMMIT");
    return NextResponse.json({ data: { id: inserted.rows[0].id, ...option } }, { status: 201 });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
