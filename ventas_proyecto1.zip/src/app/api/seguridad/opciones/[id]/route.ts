import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function PUT(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const { id: rawId } = await context.params;
  const id = Number(rawId);
  if (!Number.isSafeInteger(id) || id <= 0) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  if (body === null || typeof body !== "object" || Array.isArray(body)) return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
  const input = body as Record<string, unknown>;
  const nombre = typeof input.nombre === "string" ? input.nombre.trim() : "";
  const grupo = typeof input.grupo === "string" ? input.grupo.trim() : "";
  const icono = typeof input.icono === "string" ? input.icono.trim() : "Folder";
  const orden = Number(input.orden);
  const estado = typeof input.estado === "string" && input.estado.toLowerCase().startsWith("inact") ? "INACTIVO" : "ACTIVO";
  if (!nombre || nombre.length > 120 || !grupo || grupo.length > 100 || !icono || icono.length > 60 || !Number.isSafeInteger(orden)) {
    return NextResponse.json({ error: "Revisa el nombre, grupo, ícono y orden de la opción." }, { status: 400 });
  }
  const result = await getDatabasePool().query(
    `UPDATE opciones SET nombre = $1, grupo = $2, icono = $3, orden = $4, estado = $5, actualizado_en = now()
     WHERE id = $6 AND empresa_id = $7
     RETURNING id, codigo, nombre, grupo, ruta, icono, orden,
       CASE WHEN estado = 'ACTIVO' THEN 'Activo' ELSE 'Inactivo' END AS estado`,
    [nombre, grupo, icono, orden, estado, id, claims.empresaId],
  );
  return result.rows[0]
    ? NextResponse.json({ data: result.rows[0] })
    : NextResponse.json({ error: "Opción no encontrada." }, { status: 404 });
}

export async function DELETE(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const { id: rawId } = await context.params;
  const id = Number(rawId);
  if (!Number.isSafeInteger(id) || id <= 0) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  const result = await getDatabasePool().query(
    `UPDATE opciones SET estado = 'INACTIVO', actualizado_en = now()
     WHERE id = $1 AND empresa_id = $2 RETURNING id`,
    [id, claims.empresaId],
  );
  return result.rows[0]
    ? NextResponse.json({ data: result.rows[0] })
    : NextResponse.json({ error: "Opción no encontrada." }, { status: 404 });
}
