import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const result = await getDatabasePool().query<{ codigo: string | null }>(
    `SELECT max((regexp_match(codigo, '^OPC-([0-9]+)$'))[1]::bigint)::text AS codigo
     FROM opciones WHERE empresa_id = $1 AND codigo ~ '^OPC-[0-9]+$'`,
    [claims.empresaId],
  );
  const next = Number(result.rows[0]?.codigo ?? 0) + 1;
  return NextResponse.json({ codigo: `OPC-${String(next).padStart(5, "0")}` });
}
