import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };
type Action = "leer" | "escribir" | "eliminar";
type PermissionInput = { optionId: number; leer: boolean; escribir: boolean; eliminar: boolean };
const actions: Action[] = ["leer", "escribir", "eliminar"];

function parsePermissions(body: unknown): PermissionInput[] | null {
  if (body === null || typeof body !== "object" || Array.isArray(body)) return null;
  const options = (body as Record<string, unknown>).options;
  if (!Array.isArray(options)) return null;
  const parsed: PermissionInput[] = [];
  for (const candidate of options) {
    if (candidate === null || typeof candidate !== "object" || Array.isArray(candidate)) return null;
    const input = candidate as Record<string, unknown>;
    const optionId = Number(input.optionId);
    if (!Number.isSafeInteger(optionId) || optionId <= 0 || actions.some((action) => typeof input[action] !== "boolean")) return null;
    parsed.push({
      optionId,
      leer: input.leer as boolean,
      escribir: input.escribir as boolean,
      eliminar: input.eliminar as boolean,
    });
  }
  return new Set(parsed.map((item) => item.optionId)).size === parsed.length ? parsed : null;
}

export async function GET(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const roleId = Number((await context.params).id);
  if (!Number.isSafeInteger(roleId) || roleId <= 0) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  const result = await getDatabasePool().query(
    `SELECT opcion.id::text AS "optionId", opcion.nombre, opcion.grupo, opcion.ruta, opcion.orden,
       bool_or(permiso.accion = 'leer' AND rol_permiso.permiso_id IS NOT NULL) AS leer,
       bool_or(permiso.accion = 'escribir' AND rol_permiso.permiso_id IS NOT NULL) AS escribir,
       bool_or(permiso.accion = 'eliminar' AND rol_permiso.permiso_id IS NOT NULL) AS eliminar
     FROM opciones opcion
     CROSS JOIN LATERAL (
       SELECT id, accion FROM permisos WHERE modulo = opcion.ruta AND accion = ANY(ARRAY['leer','escribir','eliminar'])
     ) permiso
     LEFT JOIN roles_permisos rol_permiso ON rol_permiso.permiso_id = permiso.id AND rol_permiso.rol_id = $1
     WHERE opcion.empresa_id = $2 AND opcion.estado = 'ACTIVO'
       AND EXISTS (SELECT 1 FROM roles WHERE id = $1 AND empresa_id = $2)
     GROUP BY opcion.id, opcion.nombre, opcion.grupo, opcion.ruta, opcion.orden
     ORDER BY opcion.orden, opcion.nombre`,
    [roleId, claims.empresaId],
  );
  return NextResponse.json({ data: result.rows });
}

export async function PUT(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const roleId = Number((await context.params).id);
  if (!Number.isSafeInteger(roleId) || roleId <= 0) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  const options = parsePermissions(body);
  if (!options) return NextResponse.json({ error: "Las opciones de permisos no son válidas." }, { status: 400 });

  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const role = await client.query<{ codigo: string }>(
      `SELECT codigo FROM roles WHERE id = $1 AND empresa_id = $2 AND estado = 'ACTIVO' FOR UPDATE`,
      [roleId, claims.empresaId],
    );
    if (!role.rows[0]) {
      await client.query("ROLLBACK");
      return NextResponse.json({ error: "Rol no encontrado." }, { status: 404 });
    }
    if (role.rows[0].codigo === "SYS_ADMIN") {
      await client.query("ROLLBACK");
      return NextResponse.json({ error: "No se pueden modificar los permisos del rol inicial de administración." }, { status: 403 });
    }
    const validOptions = await client.query<{ id: string; ruta: string }>(
      `SELECT id::text, ruta FROM opciones
       WHERE empresa_id = $1 AND estado = 'ACTIVO' AND id = ANY($2::bigint[])`,
      [claims.empresaId, options.map((option) => option.optionId)],
    );
    if (validOptions.rows.length !== options.length) {
      await client.query("ROLLBACK");
      return NextResponse.json({ error: "Una o más opciones no existen o están inactivas." }, { status: 400 });
    }

    await client.query(`DELETE FROM roles_permisos WHERE rol_id = $1`, [roleId]);
    for (const option of options) {
      const selectedActions = actions.filter((action) => option[action]);
      if (!selectedActions.length) continue;
      const route = validOptions.rows.find((row) => Number(row.id) === option.optionId)?.ruta;
      if (!route) continue;
      await client.query(
        `INSERT INTO roles_permisos (rol_id, permiso_id)
         SELECT $1, id FROM permisos WHERE modulo = $2 AND accion = ANY($3::text[])
         ON CONFLICT DO NOTHING`,
        [roleId, route, selectedActions],
      );
    }
    await client.query("COMMIT");
    return NextResponse.json({ data: { roleId, options: options.length } });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
