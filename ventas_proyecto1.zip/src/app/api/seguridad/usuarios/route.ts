import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const result = await getDatabasePool().query(
    `SELECT usuario.id::text, usuario.nombre, usuario.usuario, usuario.email,
            COALESCE(json_agg(json_build_object('id', rol.id, 'nombre', rol.nombre))
              FILTER (WHERE rol.id IS NOT NULL), '[]'::json) AS roles
     FROM usuarios AS usuario
     LEFT JOIN usuarios_roles AS usuario_rol
       ON usuario_rol.usuario_id = usuario.id AND usuario_rol.empresa_id = usuario.empresa_id
     LEFT JOIN roles AS rol
       ON rol.id = usuario_rol.rol_id AND rol.empresa_id = usuario_rol.empresa_id AND rol.estado = 'ACTIVO'
     WHERE usuario.empresa_id = $1 AND usuario.estado = 'ACTIVO'
     GROUP BY usuario.id, usuario.nombre, usuario.usuario, usuario.email
     ORDER BY usuario.nombre, usuario.usuario`,
    [claims.empresaId],
  );
  return NextResponse.json({ data: result.rows });
}
