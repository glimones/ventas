import { NextRequest, NextResponse } from "next/server";
import { getActiveAccessClaims } from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";

export const runtime = "nodejs";

type Context = { params: Promise<{ id: string }> };

export async function PUT(request: NextRequest, context: Context) {
  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
  const userId = Number((await context.params).id);
  if (!Number.isSafeInteger(userId) || userId <= 0) return NextResponse.json({ error: "Identificador inválido." }, { status: 400 });
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 }); }
  if (body === null || typeof body !== "object" || Array.isArray(body) || !Array.isArray((body as Record<string, unknown>).roleIds)) {
    return NextResponse.json({ error: "roleIds debe ser una lista de roles." }, { status: 400 });
  }
  const roleIds = (body as { roleIds: unknown[] }).roleIds.map(Number);
  if (roleIds.some((id) => !Number.isSafeInteger(id) || id <= 0) || new Set(roleIds).size !== roleIds.length) {
    return NextResponse.json({ error: "La lista contiene identificadores de rol inválidos o repetidos." }, { status: 400 });
  }

  const client = await getDatabasePool().connect();
  try {
    await client.query("BEGIN");
    const user = await client.query(
      `SELECT 1 FROM usuarios WHERE id = $1 AND empresa_id = $2 AND estado = 'ACTIVO' FOR UPDATE`,
      [userId, claims.empresaId],
    );
    if (!user.rows[0]) {
      await client.query("ROLLBACK");
      return NextResponse.json({ error: "Usuario no encontrado." }, { status: 404 });
    }
    const systemRole = await client.query<{ id: string }>(
      `SELECT id::text FROM roles WHERE empresa_id = $1 AND codigo = 'SYS_ADMIN'`,
      [claims.empresaId],
    );
    if (systemRole.rows[0]) {
      const systemRoleId = Number(systemRole.rows[0].id);
      const currentSystemAssignment = await client.query(
        `SELECT 1 FROM usuarios_roles
         WHERE empresa_id = $1 AND usuario_id = $2 AND rol_id = $3`,
        [claims.empresaId, userId, systemRoleId],
      );
      const isSystemAssigned = currentSystemAssignment.rowCount === 1;
      if (isSystemAssigned !== roleIds.includes(systemRoleId)) {
        await client.query("ROLLBACK");
        return NextResponse.json({ error: "La asignación del rol inicial de administración no se puede cambiar." }, { status: 403 });
      }
    }
    if (roleIds.length) {
      const roles = await client.query<{ total: string }>(
        `SELECT count(*)::text AS total FROM roles
         WHERE empresa_id = $1 AND estado = 'ACTIVO' AND id = ANY($2::bigint[])`,
        [claims.empresaId, roleIds],
      );
      if (Number(roles.rows[0]?.total) !== roleIds.length) {
        await client.query("ROLLBACK");
        return NextResponse.json({ error: "Uno o más roles no existen o están inactivos." }, { status: 400 });
      }
    }
    await client.query(
      `DELETE FROM usuarios_roles WHERE usuario_id = $1 AND empresa_id = $2`,
      [userId, claims.empresaId],
    );
    if (roleIds.length) {
      await client.query(
        `INSERT INTO usuarios_roles (empresa_id, usuario_id, rol_id)
         SELECT $1, $2, unnest($3::bigint[])`,
        [claims.empresaId, userId, roleIds],
      );
    }
    await client.query("COMMIT");
    return NextResponse.json({ data: { userId, roleIds } });
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}
