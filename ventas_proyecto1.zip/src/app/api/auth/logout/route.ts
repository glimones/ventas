import { createHash } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { AUTH_COOKIE, getAccessClaims } from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { isMockClaims } from "@/lib/auth-mock";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const claims = getAccessClaims(request);
  if (claims && !(isMockAuthEnabled() && isMockClaims(claims))) {
    await getDatabasePool().query(
      `DELETE FROM usuarios_sesiones
       WHERE usuario_id = $1 AND empresa_id = $2
         AND token_hash = $3`,
      [claims.sub, claims.empresaId, createHash("sha256").update(claims.sid).digest("hex")],
    );
  }
  const response = NextResponse.json({ data: null });
  response.cookies.set(AUTH_COOKIE, "", { path: "/", httpOnly: true, expires: new Date(0) });
  return response;
}
