import { NextResponse } from "next/server";
import { isMockAuthEnabled } from "@/lib/auth-mode";

export const dynamic = "force-dynamic";

export async function GET() {
  const mode = isMockAuthEnabled()
    ? "mock"
    : process.env.DATABASE_URL
      ? "database"
      : "unavailable";
  return NextResponse.json({ mode });
}
