import { createHash, randomUUID } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { verifyPassword } from "@/services/clientes-web.service";
import { AUTH_COOKIE, AUTH_SESSION_SECONDS, loadUserAccess, signAccessToken } from "@/lib/auth";
import { getDatabasePool, getEmpresaId } from "@/lib/db";
import { findMockAccount } from "@/lib/auth-mock";
import { isMockAuthEnabled } from "@/lib/auth-mode";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "El cuerpo debe ser JSON válido." }, { status: 400 });
  }
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return NextResponse.json({ error: "El cuerpo debe ser un objeto JSON." }, { status: 400 });
  }

  const input = body as Record<string, unknown>;
  const email = typeof input.email === "string" ? input.email.trim().toLowerCase() : "";
  const password = typeof input.password === "string" ? input.password : "";
  if (!email || !password || email.length > 254 || password.length > 256) {
    return NextResponse.json({ error: "Ingresa un correo y una contraseña válidos." }, { status: 400 });
  }

  if (isMockAuthEnabled()) {
    const account = findMockAccount(email, password);
    if (!account) return NextResponse.json({ error: "Correo o contraseña incorrectos." }, { status: 401 });

    const expiresAt = new Date(Date.now() + AUTH_SESSION_SECONDS * 1000);
    const token = signAccessToken({
      sub: account.id,
      empresaId: 0,
      name: account.name,
      sid: randomUUID(),
      exp: Math.floor(expiresAt.getTime() / 1000),
      permissions: account.permissions,
    });
    const response = NextResponse.json({
      data: { id: account.id, name: account.name },
      mode: "mock",
    });
    response.cookies.set(AUTH_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: AUTH_SESSION_SECONDS,
    });
    return response;
  }

  const empresaId = getEmpresaId();
  const result = await getDatabasePool().query<{
    id: string;
    nombre: string;
    password_hash: string;
  }>(
    `SELECT id::text, nombre, password_hash
     FROM usuarios
     WHERE empresa_id = $1 AND lower(email) = $2 AND estado = 'ACTIVO'
     LIMIT 1`,
    [empresaId, email],
  );
  const user = result.rows[0];
  if (!user || !verifyPassword(password, user.password_hash)) {
    return NextResponse.json({ error: "Correo o contraseña incorrectos." }, { status: 401 });
  }

  const userId = Number(user.id);
  const access = await loadUserAccess(userId, empresaId);
  if (!access || Object.keys(access.permissions).length === 0) {
    return NextResponse.json({ error: "La cuenta no tiene opciones asignadas. Contacta al administrador." }, { status: 403 });
  }

  const sid = randomUUID();
  const expiresAt = new Date(Date.now() + AUTH_SESSION_SECONDS * 1000);
  const token = signAccessToken({
    sub: String(userId),
    empresaId,
    name: access.name,
    sid,
    exp: Math.floor(expiresAt.getTime() / 1000),
    permissions: access.permissions,
  });
  if (Buffer.byteLength(token, "utf8") > 3500) {
    return NextResponse.json({ error: "Los permisos asignados exceden el tamaño permitido para la sesión." }, { status: 413 });
  }
  await getDatabasePool().query(
    `INSERT INTO usuarios_sesiones (empresa_id, usuario_id, token_hash, expira_en)
     VALUES ($1, $2, $3, $4)`,
    [empresaId, userId, createHash("sha256").update(sid).digest("hex"), expiresAt],
  );

  const response = NextResponse.json({ data: { id: user.id, name: access.name } });
  response.cookies.set(AUTH_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: AUTH_SESSION_SECONDS,
  });
  return response;
}
