import { createHash } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import {
  AUTH_COOKIE,
  AUTH_SESSION_SECONDS,
  getAccessClaims,
  getActiveAccessClaims,
  loadUserAccess,
  signAccessToken,
} from "@/lib/auth";
import { getDatabasePool } from "@/lib/db";
import { isMockAuthEnabled } from "@/lib/auth-mode";
import { isMockClaims } from "@/lib/auth-mock";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  if (isMockAuthEnabled()) {
    const claims = getAccessClaims(request);
    if (!isMockClaims(claims)) return NextResponse.json({ error: "La sesión no está activa." }, { status: 401 });

    const expiresAt = new Date(Date.now() + AUTH_SESSION_SECONDS * 1000);
    const token = signAccessToken({ ...claims, exp: Math.floor(expiresAt.getTime() / 1000) });
    const response = NextResponse.json({
      data: { id: claims.sub, name: claims.name, permissions: claims.permissions },
      mode: "mock",
    });
    response.cookies.set(AUTH_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: AUTH_SESSION_SECONDS,
    });
    return response;
  }

  const claims = await getActiveAccessClaims(request);
  if (!claims) return NextResponse.json({ error: "La sesión no está activa." }, { status: 401 });

  const access = await loadUserAccess(Number(claims.sub), claims.empresaId);
  if (!access) return NextResponse.json({ error: "La cuenta ya no está activa." }, { status: 401 });
  const expiresAt = new Date(Date.now() + AUTH_SESSION_SECONDS * 1000);
  const tokenHash = createHash("sha256").update(claims.sid).digest("hex");
  const token = signAccessToken({
    ...claims,
    name: access.name,
    permissions: access.permissions,
    exp: Math.floor(expiresAt.getTime() / 1000),
  });
  if (Buffer.byteLength(token, "utf8") > 3500) {
    return NextResponse.json({ error: "Los permisos asignados exceden el tamaño permitido para la sesión." }, { status: 413 });
  }

  const updated = await getDatabasePool().query(
    `UPDATE usuarios_sesiones SET expira_en = $1
     WHERE usuario_id = $2 AND empresa_id = $3 AND token_hash = $4`,
    [expiresAt, claims.sub, claims.empresaId, tokenHash],
  );
  if (updated.rowCount !== 1) return NextResponse.json({ error: "La sesión no está activa." }, { status: 401 });

  const response = NextResponse.json({
    data: { id: claims.sub, name: access.name, permissions: access.permissions },
  });
  response.cookies.set(AUTH_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: AUTH_SESSION_SECONDS,
  });
  return response;
}
