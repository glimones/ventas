import { NextRequest, NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import { crearProducto, listarProductos, obtenerSiguienteCodigoProducto, ProductoValidationError } from "@/services/productos.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const data = await listarProductos(request.nextUrl.searchParams.get("q") ?? "");
    console.log("[API:productos] SUCCESS", JSON.stringify({ operation: "listar", count: data.length }));
    return NextResponse.json({
      data,
      adapter: "postgresql",
      capabilities: { create: true, update: true, delete: true, inventoryMovements: true },
    });
  } catch (error) {
    return handleError(error);
  }
}

function handleError(error: unknown) {
  const pgError = error as { code?: string; detail?: string; constraint?: string; column?: string };
  console.error("[API:productos] ERROR", JSON.stringify({
    operation: "productos",
    code: pgError.code,
    detail: pgError.detail,
    constraint: pgError.constraint,
    column: pgError.column,
    message: error instanceof Error ? error.message : String(error),
  }));
  if (error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: error.message }, { status: 503 });
  }
  if (error instanceof ProductoValidationError) {
    console.error("[API:productos] VALIDATION_ERROR", JSON.stringify({ detail: error.message }));
    return NextResponse.json({ error: error.message, detalle: error.message }, { status: 400 });
  }
  const code = (error as { code?: string })?.code;
  if (code === "23505") return NextResponse.json({ error: "Ya existe un producto con ese código." }, { status: 409 });
  if (code === "23503" || code === "23502" || code === "22P02") {
    return NextResponse.json({
      error: "Los datos no cumplen las relaciones o reglas de la base.",
      detalle: pgError.detail || pgError.column || undefined,
      columna: pgError.column || undefined,
      constraint: pgError.constraint || undefined,
    }, { status: 400 });
  }
  return NextResponse.json({
    error: "No se pudo completar la operación de productos.",
    detalle: pgError.detail || (error instanceof Error ? error.message : undefined),
  }, { status: 500 });
}

export async function POST(request: NextRequest) {
  try {
    const payload = await request.json();
    console.log("[API:productos] REQUEST", JSON.stringify({ operation: "crear", codigo: payload.codigo }));
    const id = await crearProducto(payload);
    console.log("[API:productos] SUCCESS", JSON.stringify({ operation: "crear", id }));
    return NextResponse.json({ id }, { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}
