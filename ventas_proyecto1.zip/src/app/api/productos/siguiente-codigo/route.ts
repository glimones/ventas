import { NextResponse } from "next/server";
import { obtenerSiguienteCodigoProducto } from "@/services/productos.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const codigo = await obtenerSiguienteCodigoProducto();
    console.log("[API:productos] SUCCESS", JSON.stringify({ operation: "siguiente-codigo", codigo }));
    return NextResponse.json({ codigo });
  } catch (error) {
    console.error("[API:productos] ERROR", JSON.stringify({
      operation: "siguiente-codigo",
      code: error instanceof Error ? error.name : "UnknownError",
      message: error instanceof Error ? error.message : String(error),
    }));
    return NextResponse.json({ error: "No se pudo generar el código del producto." }, { status: 500 });
  }
}
