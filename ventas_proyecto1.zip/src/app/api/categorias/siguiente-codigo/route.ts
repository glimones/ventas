import { NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import { obtenerSiguienteCodigoCategoria } from "@/services/categorias.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    return NextResponse.json({ codigo: await obtenerSiguienteCodigoCategoria() });
  } catch (error) {
    if (error instanceof DatabaseConfigurationError) {
      return NextResponse.json({ error: error.message }, { status: 503 });
    }
    return NextResponse.json({ error: "No se pudo generar el código de categoría." }, { status: 500 });
  }
}
