import { NextRequest, NextResponse } from "next/server";
import { listarProductosPorEmpresa } from "@/services/productos.service";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest, context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const empresaId = Number(id);

  if (!Number.isSafeInteger(empresaId) || empresaId <= 0) {
    return NextResponse.json({ error: "Empresa inválida." }, { status: 400 });
  }

  try {
    const search = request.nextUrl.searchParams.get("q") ?? "";
    const data = await listarProductosPorEmpresa(empresaId, search);
    return NextResponse.json({ data });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "No se pudieron cargar los productos." },
      { status: 500 },
    );
  }
}
