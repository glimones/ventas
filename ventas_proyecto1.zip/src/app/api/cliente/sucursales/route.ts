import { NextResponse } from "next/server";
import { DatabaseConfigurationError } from "@/lib/db";
import {
  actualizarSucursalCliente,
  crearSucursalCliente,
  desactivarSucursalCliente,
  listarSucursalesCliente,
  type ClienteSucursalInput,
} from "@/services/cliente-sucursales.service";

export const runtime = "nodejs";

function handleError(error: unknown) {
  if (DatabaseConfigurationError && error instanceof DatabaseConfigurationError) {
    return NextResponse.json({ error: "El servicio de datos no está disponible." }, { status: 503 });
  }
  const code = typeof error === "object" && error !== null && "code" in error
    ? String(error.code)
    : "";
  if (code === "23505") {
    return NextResponse.json({ error: "Ese código ya existe para el cliente seleccionado." }, { status: 409 });
  }
  if (code === "23503") {
    return NextResponse.json({ error: "Selecciona un cliente perteneciente a la empresa activa." }, { status: 400 });
  }
  console.error("Error en API de sucursales de clientes:", error);
  return NextResponse.json({ error: "No se pudo completar la operación de sucursales." }, { status: 500 });
}

function normalizeInput(input: unknown): ClienteSucursalInput | null {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const data = input as Record<string, unknown>;
  const clienteId = Number(data.cliente_id);
  const text = (field: string) => typeof data[field] === "string" ? data[field].trim() : "";
  const codigo = text("codigo");
  const nombre = text("nombre");
  const direccion = text("direccion");
  const ciudad = text("ciudad");
  const responsable = text("responsable");
  const telefono = text("telefono");
  const email = text("email");

  if (
    !Number.isSafeInteger(clienteId) || clienteId <= 0 ||
    !codigo || codigo.length > 20 || !nombre || nombre.length > 120 ||
    !direccion || direccion.length > 250 || !ciudad || ciudad.length > 100 ||
    !responsable || responsable.length > 160 || telefono.length > 40 ||
    email.length > 254 || (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
  ) return null;

  return {
    cliente_id: clienteId,
    codigo,
    nombre,
    direccion,
    ciudad,
    responsable,
    telefono: telefono || null,
    email: email || null,
    estado: data.estado === "Inactivo" || data.estado === "INACTIVA" ? "INACTIVA" : "ACTIVA",
  };
}

export async function GET() {
  try {
    return NextResponse.json(await listarSucursalesCliente());
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: Request) {
  try {
    const input = normalizeInput(await request.json());
    if (!input) return NextResponse.json({ error: "Revisa los datos obligatorios de la sucursal." }, { status: 400 });
    return NextResponse.json(await crearSucursalCliente(input), { status: 201 });
  } catch (error) {
    return handleError(error);
  }
}

export async function PUT(request: Request) {
  try {
    const body: unknown = await request.json();
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      return NextResponse.json({ error: "Los datos de la sucursal no son válidos." }, { status: 400 });
    }
    const data = body as Record<string, unknown>;
    const id = Number(data.id);
    const input = normalizeInput(data);
    if (!Number.isSafeInteger(id) || id <= 0 || !input) {
      return NextResponse.json({ error: "Revisa los datos obligatorios de la sucursal." }, { status: 400 });
    }
    const updated = await actualizarSucursalCliente(id, input);
    return updated
      ? NextResponse.json(updated)
      : NextResponse.json({ error: "Sucursal no encontrada." }, { status: 404 });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: Request) {
  try {
    const body: unknown = await request.json();
    const id = body && typeof body === "object" && !Array.isArray(body)
      ? Number((body as Record<string, unknown>).id)
      : Number.NaN;
    if (!Number.isSafeInteger(id) || id <= 0) {
      return NextResponse.json({ error: "El ID de la sucursal no es válido." }, { status: 400 });
    }
    const updated = await desactivarSucursalCliente(id);
    return updated
      ? NextResponse.json(updated)
      : NextResponse.json({ error: "Sucursal no encontrada." }, { status: 404 });
  } catch (error) {
    return handleError(error);
  }
}