import { randomUUID } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import {
  actualizarRegistro,
  buscarRegistro,
  crearRegistro,
  eliminarRegistro,
  obtenerSiguienteCodigoModulo,
  InvalidRecordError,
  listarRegistros,
  UnsupportedFieldError,
  UnsupportedModuleError,
} from "@/services/module-records.service";
import { DatabaseConfigurationError } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_PAGE_SIZE = 100;
const MAX_SEARCH_LENGTH = 100;
const MAX_BODY_BYTES = 1_048_576;
const REQUEST_ID_PATTERN = /^[A-Za-z0-9._-]{1,128}$/;

type RouteContext = {
  params: Promise<{ module: string[] }>;
};

type ApiTarget = {
  moduleKey: string;
  id?: number;
};

type ListOptions = {
  search?: string;
  page: number;
  pageSize: number;
};

async function getTarget(context: RouteContext): Promise<ApiTarget | null> {
  const { module: segments } = await context.params;

  if (!segments?.length || segments.some((segment) => !/^[a-z0-9-]+$/i.test(segment))) {
    return null;
  }

  const lastSegment = segments.at(-1);
  const id = lastSegment && /^\d+$/.test(lastSegment) ? Number(lastSegment) : undefined;
  const moduleSegments = id === undefined ? segments : segments.slice(0, -1);

  if (
    !moduleSegments.length ||
    (id !== undefined && (!Number.isSafeInteger(id) || id <= 0))
  ) {
    return null;
  }

  return { moduleKey: moduleSegments.join("/").toLowerCase(), id };
}

function invalidTarget() {
  return NextResponse.json({ error: "Módulo o identificador inválido." }, { status: 400 });
}

function invalidBody(message = "El cuerpo debe ser un objeto JSON válido.") {
  return NextResponse.json({ error: message }, { status: 400 });
}

function getErrorCode(error: unknown): string | undefined {
  if (typeof error !== "object" || error === null || !("code" in error)) {
    return undefined;
  }
  return typeof error.code === "string" ? error.code : undefined;
}

function logApiError(error: unknown, requestId: string) {
  const errorName = error instanceof Error ? error.name : "UnknownError";
  const message = error instanceof Error ? error.message.slice(0, 500) : "Error no identificado";
  console.error(JSON.stringify({
    event: "api.module.error",
    requestId,
    errorName,
    errorCode: getErrorCode(error),
    message,
  }));
}

function handleError(error: unknown, requestId: string) {
  if (error instanceof DatabaseConfigurationError) {
    logApiError(error, requestId);
    return NextResponse.json(
      { error: "El servicio de datos no está disponible." },
      { status: 503 },
    );
  }
  if (error instanceof UnsupportedModuleError) {
    return NextResponse.json({ error: error.message }, { status: 501 });
  }
  if (error instanceof UnsupportedFieldError || error instanceof InvalidRecordError) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  const code = getErrorCode(error);
  if (code === "23505") {
    return NextResponse.json({ error: "Ya existe un registro con esos datos." }, { status: 409 });
  }
  if (code === "23503" || code === "23502" || code === "23514" || code === "22P02") {
    const pgError = error as { detail?: string; constraint?: string; column?: string };
    console.error("[API:modulo] ERROR", JSON.stringify({ requestId, code, detail: pgError.detail, constraint: pgError.constraint, column: pgError.column }));
    return NextResponse.json({
      error: "Los datos no cumplen las reglas de la base de datos.",
      detalle: pgError.detail || undefined,
      columna: pgError.column || undefined,
      constraint: pgError.constraint || undefined,
    }, { status: 400 });
  }

  logApiError(error, requestId);
  return NextResponse.json({ error: "No se pudo completar la operación." }, { status: 500 });
}

function getRequestId(request: NextRequest) {
  const providedId = request.headers.get("x-request-id");
  return providedId && REQUEST_ID_PATTERN.test(providedId) ? providedId : randomUUID();
}

async function execute(
  request: NextRequest,
  operation: () => Promise<NextResponse>,
): Promise<NextResponse> {
  const requestId = getRequestId(request);
  let response: NextResponse;

  try {
    response = await operation();
  } catch (error) {
    response = handleError(error, requestId);
  }

  response.headers.set("x-request-id", requestId);
  return response;
}

function parsePositiveInteger(value: string | null, fallback: number): number | null {
  if (value === null) return fallback;
  if (!/^\d+$/.test(value)) return null;

  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : null;
}

function parseListOptions(searchParams: URLSearchParams):
  | { options: ListOptions }
  | { error: string } {
  const page = parsePositiveInteger(searchParams.get("page"), 1);
  if (page === null) {
    return { error: "El parámetro page debe ser un entero positivo." };
  }

  const pageSize = parsePositiveInteger(searchParams.get("limit"), 50);
  if (pageSize === null || pageSize > MAX_PAGE_SIZE) {
    return { error: `El parámetro limit debe ser un entero entre 1 y ${MAX_PAGE_SIZE}.` };
  }

  const search = searchParams.get("q")?.trim();
  if (search && search.length > MAX_SEARCH_LENGTH) {
    return { error: `El parámetro q no puede superar ${MAX_SEARCH_LENGTH} caracteres.` };
  }

  return { options: { search: search || undefined, page, pageSize } };
}

async function readBody(
  request: NextRequest,
): Promise<{ body: Record<string, unknown> } | { error: string }> {
  const contentType = request.headers.get("content-type")?.split(";")[0].trim().toLowerCase();
  if (contentType && contentType !== "application/json" && !contentType.endsWith("+json")) {
    return { error: "El Content-Type debe ser application/json." };
  }

  const contentLength = Number(request.headers.get("content-length"));
  if (Number.isFinite(contentLength) && contentLength > MAX_BODY_BYTES) {
    return { error: "El cuerpo supera el tamaño máximo permitido." };
  }

  let rawBody: string;
  try {
    rawBody = await request.text();
  } catch {
    return { error: "No se pudo leer el cuerpo de la solicitud." };
  }

  if (new TextEncoder().encode(rawBody).byteLength > MAX_BODY_BYTES) {
    return { error: "El cuerpo supera el tamaño máximo permitido." };
  }

  let body: unknown;
  try {
    body = JSON.parse(rawBody);
  } catch {
    return { error: "El cuerpo debe contener JSON válido." };
  }

  return body !== null && typeof body === "object" && !Array.isArray(body)
    ? { body: body as Record<string, unknown> }
    : { error: "El cuerpo debe ser un objeto JSON." };
}

export async function GET(request: NextRequest, context: RouteContext) {
  return execute(request, async () => {
    const { module: segments } = await context.params;
    if (segments?.at(-1)?.toLowerCase() === "siguiente-codigo") {
      const moduleKey = segments.slice(0, -1).join("/").toLowerCase();
      if (!moduleKey) return invalidTarget();
      return NextResponse.json({
        codigo: await obtenerSiguienteCodigoModulo(moduleKey),
      });
    }
    const target = await getTarget(context);
    if (!target) return invalidTarget();

    if (target.id !== undefined) {
      const record = await buscarRegistro(target.moduleKey, target.id);
      return record
        ? NextResponse.json({ data: record, adapter: "postgresql" })
        : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
    }

    const parsedOptions = parseListOptions(request.nextUrl.searchParams);
    if ("error" in parsedOptions) {
      return NextResponse.json({ error: parsedOptions.error }, { status: 400 });
    }

    return NextResponse.json(
      await listarRegistros(target.moduleKey, parsedOptions.options),
    );
  });
}

export async function POST(request: NextRequest, context: RouteContext) {
  return execute(request, async () => {
    const target = await getTarget(context);
    if (!target || target.id !== undefined) return invalidTarget();

    const parsedBody = await readBody(request);
    if ("error" in parsedBody) return invalidBody(parsedBody.error);

    const record = await crearRegistro(target.moduleKey, parsedBody.body);
    console.log("[API:modulo] SUCCESS", JSON.stringify({ operation: "crear", module: target.moduleKey, id: record.id }));
    return NextResponse.json({ data: record, adapter: "postgresql" }, { status: 201 });
  });
}

export async function PUT(request: NextRequest, context: RouteContext) {
  return updateRecord(request, context);
}

export async function PATCH(request: NextRequest, context: RouteContext) {
  return updateRecord(request, context);
}

async function updateRecord(request: NextRequest, context: RouteContext) {
  return execute(request, async () => {
    const target = await getTarget(context);
    if (!target || target.id === undefined) return invalidTarget();

    const parsedBody = await readBody(request);
    if ("error" in parsedBody) return invalidBody(parsedBody.error);

    const record = await actualizarRegistro(target.moduleKey, target.id, parsedBody.body);
    if (record) console.log("[API:modulo] SUCCESS", JSON.stringify({ operation: "actualizar", module: target.moduleKey, id: target.id }));
    return record
      ? NextResponse.json({ data: record, adapter: "postgresql" })
      : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
  });
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  return execute(request, async () => {
    const target = await getTarget(context);
    if (!target || target.id === undefined) return invalidTarget();

    const record = await eliminarRegistro(target.moduleKey, target.id);
    if (record) console.log("[API:modulo] SUCCESS", JSON.stringify({ operation: "desactivar", module: target.moduleKey, id: target.id }));
    return record
      ? NextResponse.json({ data: record, adapter: "postgresql" })
      : NextResponse.json({ error: "Registro no encontrado." }, { status: 404 });
  });
}
