'use client';
import React from 'react';
import { ClasificacionFormValues } from './types';
import { getCategoriaProveedorOptions } from '@/data/categorias-proveedores';

interface Props {
  values: ClasificacionFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const ClasificacionForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control' id='codigo' name='codigo' value={values.codigo || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre' className='form-label'>Nombre *</label>
          <input type='text' className='form-control' id='nombre' name='nombre' value={values.nombre || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-12'>
        <div className='mb-3'>
          <label htmlFor='nivel_riesgo' className='form-label'>Nivel de riesgo *</label>
          <select className='form-select' id='nivel_riesgo' name='nivel_riesgo' value={values.nivel_riesgo || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='BAJO'>Bajo</option>
            <option value='MEDIO'>Medio</option>
            <option value='ALTO'>Alto</option>
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='categoria_compra' className='form-label'>Categoría de compra *</label>
          <select className='form-select' id='categoria_compra' name='categoria_compra' value={values.categoria_compra || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione una categoría...</option>
            {getCategoriaProveedorOptions(values.categoria_compra || '').map((categoria) => (
              <option key={categoria.value} value={categoria.value}>{categoria.label}</option>
            ))}
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='criticidad' className='form-label'>Criticidad del suministro *</label>
          <select className='form-select' id='criticidad' name='criticidad' value={values.criticidad || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='ESTRATEGICO'>Estratégico</option>
            <option value='IMPORTANTE'>Importante</option>
            <option value='NO_CRITICO'>No crítico</option>
          </select>
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='dias_credito' className='form-label'>Días de crédito</label>
          <input type='number' min='0' className='form-control' id='dias_credito' name='dias_credito' value={values.dias_credito || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='proveedores_asignados' className='form-label'>Proveedores asignados</label>
          <input type='number' min='0' className='form-control' id='proveedores_asignados' name='proveedores_asignados' value={values.proveedores_asignados || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default ClasificacionForm;
