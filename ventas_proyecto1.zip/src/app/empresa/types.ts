export type GiroNegocio = "alimentos" | "comercio" | "servicios";

export interface SitioProducto {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  images?: string[];
}

export interface ContenidoSitio {
  eyebrow: string;
  headline: string;
  description: string;
  heroImage: string;
  highlights: string[];
  sectionEyebrow: string;
  sectionTitle: string;
  sectionDescription: string;
  productos_publicados_ids: string[];
  items: SitioProducto[];
  aboutEyebrow: string;
  aboutTitle: string;
  aboutDescription: string;
  missionTitle: string;
  mission: string;
  visionTitle: string;
  vision: string;
  contactEyebrow: string;
  contactPrompt: string;
}

export interface Empresa {
  id: number;
  nombre_comercial: string;
  nombre_legal: string;
  ruc: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  email: string;
  telefono?: string;
  logo_url?: string;
  sitio_web_habilitado?: boolean;
  titulo_web?: string;
  imagen_portada_url?: string;
  contenido_sitio?: ContenidoSitio | null;
  moneda: string;
  estado: string;
  slug: string;
  giro_negocio: GiroNegocio;
  descripcion_web: string;
  color_primario: string;
  color_secundario: string;
  tienda_online: boolean;
  cuenta_clientes_habilitada: boolean;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface EmpresaFormValues {
  nombre_comercial: string;
  nombre_legal: string;
  ruc: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  email: string;
  telefono: string;
  logo_url?: string;
  sitio_web_habilitado: boolean;
  titulo_web: string;
  imagen_portada_url: string;
  contenido_sitio: ContenidoSitio;
  moneda: string;
  estado: string;
  slug: string;
  giro_negocio: GiroNegocio;
  descripcion_web: string;
  color_primario: string;
  color_secundario: string;
  tienda_online: boolean;
  cuenta_clientes_habilitada: boolean;
}
  