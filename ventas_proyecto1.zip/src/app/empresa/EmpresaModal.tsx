import React, { useEffect } from "react";
import { Building2 } from "lucide-react";
import { EmpresaFormValues } from "./types";
import EmpresaForm from "./empresaForm";
import type { Producto } from "@/app/productos/types";

interface Props {
  show: boolean;
  editando: boolean;
  values: EmpresaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
  saving: boolean;
  submitError: string;
  productosInventario: Producto[];
  onProductoPublicadoChange: (productoId: number, publicado: boolean) => void;
  onTodosProductosChange: (seleccionados: boolean) => void;
}

const EmpresaModal: React.FC<Props> = ({
  show,
  editando,
  values,
  onChange,
  onClose,
  onSubmit,
  saving,
  submitError,
  productosInventario,
  onProductoPublicadoChange,
  onTodosProductosChange,
}) => {
  // Bloquear el scroll del body cuando el modal está abierto
  useEffect(() => {
    if (show) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = ''; 
    };
  }, [show]);

  if (!show) return null;

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Solo cerrar si se hace clic directamente en el backdrop, no en el contenido
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="modal-overlay empresa-modal-overlay"
      onClick={handleBackdropClick}
      role="presentation"
    >
      <div 
        className="modal-container empresa-modal-container"
        role="dialog"
        aria-modal="true"
        aria-labelledby="empresa-modal-title"
      >
        <form onSubmit={onSubmit}>
          <div className="modal-header text-white">
            <h5 className="modal-title d-flex align-items-center gap-2" id="empresa-modal-title">
              <Building2 size={21} aria-hidden="true" />
              <span>{editando ? "Editar Empresa" : "Nueva Empresa"}</span>
            </h5>
            <button
              type="button"
              className="btn-close btn-close-white"
              onClick={onClose}
              disabled={saving}
              aria-label="Cerrar"
            />
          </div>
          
          <div className="modal-body">
            <p className="text-muted mb-3">Los campos marcados con * son obligatorios</p>
            {submitError && <div className="alert alert-danger" role="alert">{submitError}</div>}
            <EmpresaForm values={values} onChange={onChange} productosInventario={productosInventario} onProductoPublicadoChange={onProductoPublicadoChange} onTodosProductosChange={onTodosProductosChange} />
          </div>
          
          <div className="modal-footer">
            <button
              type="button"
              className="btn btn-secondary me-2"
              onClick={onClose}
              disabled={saving}
            >
              Cancelar
            </button>
            <button type="submit" className="btn btn-success" disabled={saving}>
              {saving ? "Guardando..." : "Guardar"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EmpresaModal;