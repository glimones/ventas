import React from "react";
import { EmpresaFormValues } from "./types";
import type { Producto } from "@/app/productos/types";

interface Props {
  values: EmpresaFormValues;
  onChange: (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  productosInventario: Producto[];
  onProductoPublicadoChange: (productoId: number, publicado: boolean) => void;
  onTodosProductosChange: (seleccionados: boolean) => void;
}

const paisesOptions = [
  { value: "", label: "Seleccione un país" },
  { value: "es", label: "España" },
  { value: "mx", label: "México" },
  { value: "co", label: "Colombia" },
  { value: "ar", label: "Argentina" },
  { value: "cl", label: "Chile" },
  { value: "pe", label: "Perú" },
  { value: "ec", label: "Ecuador" },
  { value: "ve", label: "Venezuela" },
  { value: "us", label: "Estados Unidos" },
  { value: "ca", label: "Canadá" },
];

const monedasOptions = [
  { value: "", label: "Seleccione una moneda" },
  { value: "USD", label: "Dólar estadounidense (USD)" },
  { value: "EUR", label: "Euro (EUR)" },
  { value: "MXN", label: "Peso mexicano (MXN)" },
  { value: "COP", label: "Peso colombiano (COP)" },
  { value: "ARS", label: "Peso argentino (ARS)" },
  { value: "CLP", label: "Peso chileno (CLP)" },
  { value: "PEN", label: "Sol peruano (PEN)" },
  { value: "VES", label: "Bolívar venezolano (VES)" },
  { value: "GBP", label: "Libra esterlina (GBP)" },
];

export default function EmpresaForm({ values, onChange, productosInventario, onProductoPublicadoChange, onTodosProductosChange }: Props) {
  return (
    <div className="empresa-form">
      <section className="empresa-form-section">
        <div className="empresa-form-section__heading">
          <h6>Datos de la empresa</h6>
          <p>Identificación comercial y fiscal.</p>
        </div>
        <div className="empresa-form-grid empresa-form-grid--three">
          <div className="empresa-form-field">
            <label htmlFor="nombre_comercial" className="form-label">Nombre comercial *</label>
            <input type="text" className="form-control" id="nombre_comercial" name="nombre_comercial" value={values.nombre_comercial} onChange={onChange} required />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="nombre_legal" className="form-label">Razón social *</label>
            <input type="text" className="form-control" id="nombre_legal" name="nombre_legal" value={values.nombre_legal} onChange={onChange} required />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="ruc" className="form-label">RUC/CIF/NIT *</label>
            <input type="text" className="form-control" id="ruc" name="ruc" value={values.ruc} onChange={onChange} required />
          </div>
        </div>
      </section>

      <section className="empresa-form-section">
        <div className="empresa-form-section__heading">
          <h6>Contacto y ubicación</h6>
          <p>Datos para comunicaciones y documentos.</p>
        </div>
        <div className="empresa-form-grid empresa-form-grid--two">
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="direccion" className="form-label">Dirección *</label>
            <textarea className="form-control" id="direccion" name="direccion" value={values.direccion} onChange={onChange} rows={2} required />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="ciudad" className="form-label">Ciudad *</label>
            <input type="text" className="form-control" id="ciudad" name="ciudad" value={values.ciudad} onChange={onChange} required />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="provincia" className="form-label">Provincia/Estado</label>
            <input type="text" className="form-control" id="provincia" name="provincia" value={values.provincia ?? ""} onChange={onChange} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="pais" className="form-label">País *</label>
            <select className="form-select" id="pais" name="pais" value={values.pais} onChange={onChange} required>
              {paisesOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
            </select>
          </div>
          <div className="empresa-form-field">
            <label htmlFor="email" className="form-label">Correo electrónico *</label>
            <input type="email" className="form-control" id="email" name="email" value={values.email} onChange={onChange} required />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="telefono" className="form-label">Teléfono</label>
            <input type="tel" className="form-control" id="telefono" name="telefono" value={values.telefono ?? ""} onChange={onChange} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="logo_url" className="form-label">Logo de la empresa</label>
            <input
              type="file"
              className="form-control"
              id="logo_url"
              name="logo_url"
              accept="image/png,image/jpeg,image/webp,image/svg+xml"
              onChange={onChange}
            />
            {values.logo_url && (
              <div className="empresa-logo-preview">
                <img src={values.logo_url} alt="Vista previa del logo" />
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="empresa-form-section">
        <div className="empresa-form-section__heading">
          <h6>Preferencias generales</h6>
          <p>Moneda y estado de operación.</p>
        </div>
        <div className="empresa-form-grid empresa-form-grid--two">
          <div className="empresa-form-field">
            <label htmlFor="moneda" className="form-label">Moneda principal *</label>
            <select className="form-select" id="moneda" name="moneda" value={values.moneda} onChange={onChange} required>
              {monedasOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
            </select>
          </div>
          <div className="empresa-form-field">
            <label htmlFor="estado" className="form-label">Estado</label>
            <select className="form-select" id="estado" name="estado" value={values.estado} onChange={onChange}>
              <option value="Activa">Activa</option>
              <option value="Inactiva">Inactiva</option>
            </select>
          </div>
        </div>
      </section>

      <section className="empresa-form-section">
        <div className="empresa-form-section__heading">
          <h6>Configuración del sitio público</h6>
          <p>Personaliza la dirección, contenido y apariencia del sitio.</p>
        </div>
        <div className="empresa-form-options empresa-form-options--standalone">
          <div className="form-check">
            <input type="checkbox" className="form-check-input" id="sitio_web_habilitado" name="sitio_web_habilitado" checked={values.sitio_web_habilitado} onChange={onChange} />
            <label className="form-check-label" htmlFor="sitio_web_habilitado">Crear sitio web público para esta empresa</label>
          </div>
        </div>
        {values.sitio_web_habilitado && <div className="empresa-form-grid empresa-form-grid--two">
          <div className="empresa-form-field">
            <label htmlFor="slug" className="form-label">Dirección del sitio *</label>
            <div className="input-group">
              <span className="input-group-text">/sitio/</span>
              <input type="text" className="form-control" id="slug" name="slug" value={values.slug} onChange={onChange} pattern="[a-z0-9]+(-[a-z0-9]+)*" required />
            </div>
          </div>
          <div className="empresa-form-field">
            <label htmlFor="giro_negocio" className="form-label">Giro del negocio *</label>
            <select className="form-select" id="giro_negocio" name="giro_negocio" value={values.giro_negocio} onChange={onChange} required>
              <option value="alimentos">Alimentos y restaurantes</option>
              <option value="comercio">Comercio y productos</option>
              <option value="servicios">Servicios profesionales</option>
            </select>
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="titulo_web" className="form-label">Título principal *</label>
            <input type="text" className="form-control" id="titulo_web" name="titulo_web" value={values.titulo_web} onChange={onChange} required />
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="descripcion_web" className="form-label">Descripción para el sitio *</label>
            <textarea className="form-control" id="descripcion_web" name="descripcion_web" value={values.descripcion_web} onChange={onChange} rows={2} required />
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="contenido_sitio.eyebrow" className="form-label">Texto superior destacado</label>
            <input type="text" className="form-control" id="contenido_sitio.eyebrow" name="contenido_sitio.eyebrow" value={values.contenido_sitio.eyebrow} onChange={onChange} />
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="contenido_sitio.headline" className="form-label">Titular principal del sitio</label>
            <input type="text" className="form-control" id="contenido_sitio.headline" name="contenido_sitio.headline" value={values.contenido_sitio.headline} onChange={onChange} />
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="contenido_sitio.description" className="form-label">Texto principal de presentación</label>
            <textarea className="form-control" id="contenido_sitio.description" name="contenido_sitio.description" value={values.contenido_sitio.description} onChange={onChange} rows={2} />
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="contenido_sitio.heroImage" className="form-label">Imagen de portada</label>
            <input type="file" className="form-control" id="contenido_sitio.heroImage" name="contenido_sitio.heroImage" accept="image/png,image/jpeg,image/webp,image/svg+xml" onChange={onChange} />
            {values.contenido_sitio.heroImage && <div className="empresa-logo-preview empresa-logo-preview--wide"><img src={values.contenido_sitio.heroImage} alt="Vista previa de portada" /></div>}
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="contenido_sitio.sectionEyebrow" className="form-label">Texto superior de productos</label>
            <input type="text" className="form-control" id="contenido_sitio.sectionEyebrow" name="contenido_sitio.sectionEyebrow" value={values.contenido_sitio.sectionEyebrow} onChange={onChange} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="contenido_sitio.sectionTitle" className="form-label">Título de productos</label>
            <input type="text" className="form-control" id="contenido_sitio.sectionTitle" name="contenido_sitio.sectionTitle" value={values.contenido_sitio.sectionTitle} onChange={onChange} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="contenido_sitio.sectionDescription" className="form-label">Descripción de productos</label>
            <input type="text" className="form-control" id="contenido_sitio.sectionDescription" name="contenido_sitio.sectionDescription" value={values.contenido_sitio.sectionDescription} onChange={onChange} />
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label className="form-label">Destacados</label>
            <div className="empresa-form-grid empresa-form-grid--three">
              {[0, 1, 2].map((index) => (
                <input key={index} type="text" className="form-control" name={`contenido_sitio.highlights.${index}`} value={values.contenido_sitio.highlights[index] ?? ""} onChange={onChange} aria-label={`Destacado ${index + 1}`} />
              ))}
            </div>
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="imagen_portada_url" className="form-label">Imagen principal del sitio *</label>
            <input type="file" className="form-control" id="imagen_portada_url" name="imagen_portada_url" accept="image/png,image/jpeg,image/webp,image/svg+xml" onChange={onChange} required={!values.imagen_portada_url} />
            {values.imagen_portada_url && (
              <div className="empresa-logo-preview empresa-logo-preview--wide">
                <img src={values.imagen_portada_url} alt="Vista previa de la imagen principal" />
              </div>
            )}
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label className="form-label">Productos o servicios mostrados</label>
            <p className="text-muted small mb-2">Marca los productos del inventario que deseas publicar en el sitio web.</p>
            <div className="empresa-form-product-grid">
              {productosInventario.length === 0 ? (
                <p className="text-muted mb-0">Esta empresa no tiene productos configurados en el inventario.</p>
              ) : (
                <>
                  <label className="empresa-form-product--select-all">
                    <input
                      type="checkbox"
                      checked={productosInventario.length > 0 && productosInventario.every((producto) => (values.contenido_sitio.productos_publicados_ids ?? []).includes(String(producto.id)))}
                      onChange={(event) => onTodosProductosChange(event.target.checked)}
                    />
                    Seleccionar todos los productos
                  </label>
                  {productosInventario.map((producto) => {
                const publicado = (values.contenido_sitio.productos_publicados_ids ?? []).includes(String(producto.id));
                return (
                  <label className={`empresa-form-product empresa-form-product--inventory ${publicado ? "is-selected" : ""}`} key={producto.id}>
                    <input type="checkbox" checked={publicado} onChange={(event) => onProductoPublicadoChange(producto.id, event.target.checked)} />
                    {producto.imagen_url && <img className="empresa-form-product__image" src={producto.imagen_url} alt="" />}
                    <span className="empresa-form-product__copy">
                      <strong>{producto.nombre}</strong>
                      <small>{producto.descripcion || "Sin descripción"}</small>
                      <b>${producto.precio_venta.toFixed(2)}</b>
                    </span>
                  </label>
                );
              })}
                </>
              )}
            </div>
          </div>
          <div className="empresa-form-field">
            <label htmlFor="contenido_sitio.aboutEyebrow" className="form-label">Texto superior de Conócenos</label>
            <input type="text" className="form-control" id="contenido_sitio.aboutEyebrow" name="contenido_sitio.aboutEyebrow" value={values.contenido_sitio.aboutEyebrow} onChange={onChange} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="contenido_sitio.aboutTitle" className="form-label">Título de Conócenos</label>
            <input type="text" className="form-control" id="contenido_sitio.aboutTitle" name="contenido_sitio.aboutTitle" value={values.contenido_sitio.aboutTitle} onChange={onChange} />
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="contenido_sitio.aboutDescription" className="form-label">Texto de Conócenos</label>
            <textarea className="form-control" id="contenido_sitio.aboutDescription" name="contenido_sitio.aboutDescription" value={values.contenido_sitio.aboutDescription} onChange={onChange} rows={3} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="contenido_sitio.missionTitle" className="form-label">Título de Misión</label>
            <input type="text" className="form-control" id="contenido_sitio.missionTitle" name="contenido_sitio.missionTitle" value={values.contenido_sitio.missionTitle} onChange={onChange} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="contenido_sitio.visionTitle" className="form-label">Título de Visión</label>
            <input type="text" className="form-control" id="contenido_sitio.visionTitle" name="contenido_sitio.visionTitle" value={values.contenido_sitio.visionTitle} onChange={onChange} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="contenido_sitio.mission" className="form-label">Misión</label>
            <textarea className="form-control" id="contenido_sitio.mission" name="contenido_sitio.mission" value={values.contenido_sitio.mission} onChange={onChange} rows={3} />
          </div>
          <div className="empresa-form-field">
            <label htmlFor="contenido_sitio.vision" className="form-label">Visión</label>
            <textarea className="form-control" id="contenido_sitio.vision" name="contenido_sitio.vision" value={values.contenido_sitio.vision} onChange={onChange} rows={3} />
          </div>
          <div className="empresa-form-field empresa-form-field--full">
            <label htmlFor="contenido_sitio.contactPrompt" className="form-label">Texto para Hablemos</label>
            <textarea className="form-control" id="contenido_sitio.contactPrompt" name="contenido_sitio.contactPrompt" value={values.contenido_sitio.contactPrompt} onChange={onChange} rows={2} />
          </div>
          <div className="empresa-form-colors">
            <div className="empresa-form-field">
              <label htmlFor="color_primario" className="form-label">Color principal</label>
              <input type="color" className="form-control form-control-color w-100" id="color_primario" name="color_primario" value={values.color_primario} onChange={onChange} />
            </div>
            <div className="empresa-form-field">
              <label htmlFor="color_secundario" className="form-label">Color secundario</label>
              <input type="color" className="form-control form-control-color w-100" id="color_secundario" name="color_secundario" value={values.color_secundario} onChange={onChange} />
            </div>
          </div>
          <div className="empresa-form-options">
            <div className="form-check">
              <input type="checkbox" className="form-check-input" id="tienda_online" name="tienda_online" checked={values.tienda_online} onChange={onChange} />
              <label className="form-check-label" htmlFor="tienda_online">Activar catálogo y carrito de compras</label>
            </div>
            <div className="form-check">
              <input type="checkbox" className="form-check-input" id="cuenta_clientes_habilitada" name="cuenta_clientes_habilitada" checked={values.cuenta_clientes_habilitada} onChange={onChange} />
              <label className="form-check-label" htmlFor="cuenta_clientes_habilitada">Permitir registro de clientes</label>
            </div>
          </div>
        </div>}
      </section>
    </div>
  );
}
