"use client";

import React, { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Empresa, EmpresaFormValues } from "./types";
import EmpresaModal from "./EmpresaModal";
import RegistroResumen, { type FiltroEstadoRegistro } from "@/components/registro-resumen";
import "./empresa.css";
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';
import type { Producto } from '@/app/productos/types';

const initialSiteContent: EmpresaFormValues["contenido_sitio"] = {
  eyebrow: "OBJETOS PARA VIVIR MEJOR",
  headline: "Tu casa, a tu manera.",
  description: "Piezas funcionales y duraderas, elegidas para acompañarte todos los días.",
  heroImage: "",
  highlights: ["Piezas para todos los días", "Selección con intención", "Atención personalizada"],
  sectionEyebrow: "NUESTRA PROPUESTA",
  sectionTitle: "Selección de la casa",
  sectionDescription: "Diseño cotidiano, materiales honestos y detalles que duran.",
  productos_publicados_ids: [],
  items: [
    { id: "item-1", name: "Vajilla de cerámica", description: "Juego artesanal de cuatro piezas, hecho en Ecuador.", price: 38, image: "https://images.unsplash.com/photo-1490312278390-ab64016e0aa9?auto=format&fit=crop&w=1200&q=85" },
    { id: "item-2", name: "Manta de algodón", description: "Tejido suave de producción responsable.", price: 42.5, image: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85" },
    { id: "item-3", name: "Canasto tejido", description: "Fibra natural trenzada a mano para cada espacio.", price: 24, image: "https://images.unsplash.com/photo-1593085260707-5377ba37f868?auto=format&fit=crop&w=1200&q=85" },
  ],
  aboutEyebrow: "CONÓCENOS",
  aboutTitle: "Objetos que hacen tu espacio más tuyo.",
  aboutDescription: "Elegimos piezas funcionales y con carácter para acompañar tu día a día. Nos importa el diseño que se disfruta, se usa y se queda contigo.",
  missionTitle: "Misión",
  mission: "Brindar soluciones y productos de calidad que aporten valor y confianza a nuestros clientes.",
  visionTitle: "Visión",
  vision: "Ser una empresa reconocida por su cercanía, excelencia y crecimiento sostenible.",
  contactEyebrow: "HABLEMOS",
  contactPrompt: "¿Buscas una pieza especial? Escríbenos y te ayudamos a encontrarla.",
};

const initialForm: EmpresaFormValues = {
  nombre_comercial: "",
  nombre_legal: "",
  ruc: "",
  direccion: "", 
  ciudad: "",
  provincia: "",
  pais: "",
  email: "",
  telefono: "",
  logo_url: "",
  sitio_web_habilitado: false,
  titulo_web: "",
  imagen_portada_url: "",
  contenido_sitio: initialSiteContent,
  moneda: "",
  estado: "Activa",
  slug: "",
  giro_negocio: "alimentos",
  descripcion_web: "",
  color_primario: "#212529",
  color_secundario: "#fd7e14",
  tienda_online: false,
  cuenta_clientes_habilitada: true,
};

export default function EmpresasPage() {
  const [empresas, setEmpresas] = useState<Empresa[]>([]);
  const [filtro, setFiltro] = useState<string>("");
  const [filtroEstado, setFiltroEstado] = useState<FiltroEstadoRegistro>("TODOS");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<EmpresaFormValues>(initialForm);
  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState("");
  const [productosInventario, setProductosInventario] = useState<Producto[]>([]);

  const cargarProductosInventario = useCallback(async (empresaId: number) => {
    try {
      const response = await fetch(`/api/empresas/${empresaId}/productos`, { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) return;
      const productos = Array.isArray(result.data) ? result.data as Producto[] : [];
      setProductosInventario(productos.filter((producto) => producto.estado === "Activo"));
    } catch {
      setProductosInventario([]);
    }
  }, []);

  const cargarEmpresas = useCallback(async () => {
    setCargando(true);
    try {
      const response = await fetch("/api/empresas", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudieron cargar las empresas.");
      const records = Array.isArray(result.data) ? result.data as Record<string, unknown>[] : [];
      setEmpresas(records.map((record) => ({
        ...initialForm,
        ...record,
        id: Number(record.id),
        estado: record.estado === "Inactivo" || record.estado === "Inactiva" ? "Inactiva" : "Activa",
        giro_negocio: (record.giro_negocio as Empresa["giro_negocio"]) || "comercio",
        color_primario: typeof record.color_primario === "string" ? record.color_primario : "#212529",
        color_secundario: typeof record.color_secundario === "string" ? record.color_secundario : "#fd7e14",
        tienda_online: Boolean(record.tienda_online),
        cuenta_clientes_habilitada: record.cuenta_clientes_habilitada !== false,
      })));
      setError("");
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Error al cargar empresas.");
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => { void cargarEmpresas(); }, [cargarEmpresas]);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setProductosInventario([]);
    setError("");
    setShowModal(true);
  };
  
  const abrirModalEditar = (empresa: Empresa) => {
    setForm({
      nombre_legal: empresa.nombre_legal ?? "",
      nombre_comercial: empresa.nombre_comercial ?? "",
      ruc: empresa.ruc ?? "",
      direccion: empresa.direccion ?? "",
      ciudad: empresa.ciudad ?? "",
      provincia: empresa.provincia ?? "",
      pais: empresa.pais ?? "",
      email: empresa.email ?? "",
      telefono: empresa.telefono ?? "",
      logo_url: empresa.logo_url ?? "",
      sitio_web_habilitado: empresa.sitio_web_habilitado ?? Boolean(empresa.slug),
      titulo_web: empresa.titulo_web ?? "",
      imagen_portada_url: empresa.imagen_portada_url ?? "",
      contenido_sitio: empresa.contenido_sitio
        ? {
            ...initialSiteContent,
            ...empresa.contenido_sitio,
            highlights: empresa.contenido_sitio.highlights?.length ? empresa.contenido_sitio.highlights : initialSiteContent.highlights,
            productos_publicados_ids: empresa.contenido_sitio.productos_publicados_ids ?? [],
            items: empresa.contenido_sitio.items?.length ? empresa.contenido_sitio.items : initialSiteContent.items,
          }
        : initialSiteContent,
      moneda: empresa.moneda ?? "",
      estado: empresa.estado ?? "Activa",
      slug: empresa.slug ?? "",
      giro_negocio: empresa.giro_negocio ?? "alimentos",
      descripcion_web: empresa.descripcion_web ?? "",
      color_primario: empresa.color_primario ?? "#212529",
      color_secundario: empresa.color_secundario ?? "#fd7e14",
      tienda_online: empresa.tienda_online ?? false,
      cuenta_clientes_habilitada: empresa.cuenta_clientes_habilitada ?? true,
    });
    setEditandoId(empresa.id);
    setProductosInventario([]);
    void cargarProductosInventario(empresa.id);
    setShowModal(true);
    setError("");
  };

  const handleProductoPublicado = (productoId: number, publicado: boolean) => {
    setForm((prev) => {
      const currentIds = prev.contenido_sitio.productos_publicados_ids ?? [];
      const id = String(productoId);
      const ids = publicado
        ? [...new Set([...currentIds, id])]
        : currentIds.filter((currentId) => currentId !== id);
      return {
        ...prev,
        contenido_sitio: { ...prev.contenido_sitio, productos_publicados_ids: ids },
      };
    });
  };

  const handleTodosProductos = (seleccionados: boolean) => {
    setForm((prev) => ({
      ...prev,
      contenido_sitio: {
        ...prev.contenido_sitio,
        productos_publicados_ids: seleccionados ? productosInventario.map((producto) => String(producto.id)) : [],
      },
    }));
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type, checked } = e.target as HTMLInputElement;

    const updateNested = (previous: EmpresaFormValues, path: string, nextValue: unknown): EmpresaFormValues => {
      const next = JSON.parse(JSON.stringify(previous)) as EmpresaFormValues & Record<string, unknown>;
      const parts = path.split(".");
      const indexed = next as unknown as Record<string, unknown>;
      let cursor = indexed;
      parts.forEach((part, index) => {
        if (index === parts.length - 1) {
          cursor[part] = path.endsWith(".price") ? Number(nextValue) || 0 : nextValue;
          return;
        }
        const nextPartIsIndex = /^\d+$/.test(parts[index + 1]);
        const existing = cursor[part];
        if (!existing || typeof existing !== "object") {
          cursor[part] = nextPartIsIndex ? [] : {};
        }
        cursor = cursor[part] as Record<string, unknown>;
      });
      return next;
    };

    if (type === "file") {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = () => {
        const fileValue = typeof reader.result === "string" ? reader.result : "";
        setForm((prev) => name.includes(".")
          ? updateNested(prev, name, fileValue)
          : { ...prev, [name]: fileValue });
      };
      reader.readAsDataURL(file);
      return;
    }

    setForm((prev) => name.includes(".")
      ? updateNested(prev, name, type === "checkbox" ? checked : value)
      : { ...prev, [name]: type === "checkbox" ? checked : value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setError("");
    try {
      const productosPublicadosIds = [...new Set(
        (form.contenido_sitio.productos_publicados_ids ?? [])
          .map((id) => String(id))
          .filter((id) => /^\d+$/.test(id)),
      )];
      const updatePayload = {
        nombre_comercial: form.nombre_comercial,
        nombre_legal: form.nombre_legal,
        ruc: form.ruc,
        direccion: form.direccion,
        ciudad: form.ciudad,
        provincia: form.provincia,
        pais: form.pais,
        email: form.email,
        telefono: form.telefono,
        logo_url: form.logo_url,
        moneda: form.moneda,
        estado: form.estado,
        sitio_web_habilitado: form.sitio_web_habilitado,
        ...(form.sitio_web_habilitado ? {
          titulo_web: form.titulo_web.trim(),
          imagen_portada_url: form.imagen_portada_url,
          contenido_sitio: {
            ...form.contenido_sitio,
            productos_publicados_ids: productosPublicadosIds,
          },
          slug: form.slug.trim(),
          giro_negocio: form.giro_negocio,
          descripcion_web: form.descripcion_web,
          color_primario: form.color_primario,
          color_secundario: form.color_secundario,
          tienda_online: form.tienda_online,
          cuenta_clientes_habilitada: form.cuenta_clientes_habilitada,
        } : {}),
      };

      const response = await fetch(editandoId ? `/api/empresas/${editandoId}` : "/api/empresas", {
        method: editandoId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatePayload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo guardar la empresa.");
      await cargarEmpresas();
      cerrarModal();
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "Error al guardar la empresa.");
    } finally {
      setGuardando(false);
    }
  };

  const eliminarEmpresa = async (id: number) => {
    if (window.confirm("¿Seguro que deseas eliminar esta empresa?")) {
      try {
        const response = await fetch(`/api/empresas/${id}`, { method: "DELETE" });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "No se pudo desactivar la empresa.");
        await cargarEmpresas();
      } catch (deleteError) {
        setError(deleteError instanceof Error ? deleteError.message : "Error al desactivar la empresa.");
      }
    }
  };

  const empresasActivas = empresas.filter((empresa) =>
    (empresa.estado || "").toLocaleLowerCase().startsWith("activ"),
  ).length;
  const empresasInactivas = empresas.filter((empresa) =>
    (empresa.estado || "").toLocaleLowerCase().startsWith("inactiv"),
  ).length;
  const empresasFiltradas = empresas.filter((empresa) => {
    const coincideBusqueda = Object.values(empresa)
      .join(" ")
      .toLocaleLowerCase()
      .includes(filtro.toLocaleLowerCase());
    const estado = (empresa.estado || "").toLocaleLowerCase();
    const coincideEstado =
      filtroEstado === "TODOS" ||
      (filtroEstado === "ACTIVOS" && estado.startsWith("activ")) ||
      (filtroEstado === "INACTIVOS" && estado.startsWith("inactiv"));
    return coincideBusqueda && coincideEstado;
  });

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
            <h1 className="mb-4">Empresas</h1>
            <p className="text-muted mb-0">Creación de nuevas empresas</p>
        <br></br>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar empresa..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className="btn btn-primary d-flex align-items-center" onClick={abrirModalNueva}>
            <CirclePlus className="me-2" size={16} />
            <span>Añadir Empresa</span>
          </button>
        </div>
        <RegistroResumen
          total={empresas.length}
          activos={empresasActivas}
          inactivos={empresasInactivas}
          activosLabel="Activas"
          inactivosLabel="Inactivas"
          filtro={filtroEstado}
          cargando={cargando}
          onChange={setFiltroEstado}
        />
        {!cargando && (
          <p className="entity-result-count" role="status">
            Mostrando {empresasFiltradas.length} de {empresas.length} empresas
          </p>
        )}
        {error && !showModal && <div className="alert alert-danger" role="alert">{error}</div>}
         <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Nombre Legal</th>
                <th>Nombre Comercial</th>
                <th>Giro</th>
                <th>RUC/NIT</th>
                <th>Teléfono</th>
                <th>Email</th>
                <th>Estado</th>
                <th>Sitio</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && <tr><td colSpan={9} className="text-center">Cargando empresas...</td></tr>}
              {!cargando && empresasFiltradas.length === 0 && (
                <tr>
                  <td colSpan={9} className="text-center">
                    {error ? "No se pudieron cargar las empresas" : "No se encontraron empresas"}
                  </td>
                </tr>
              )}
              {empresasFiltradas.map((empresa) => (
                <tr key={empresa.id}>
                  <td>{empresa.nombre_legal}</td>
                  <td>{empresa.nombre_comercial}</td>
                  <td className="text-capitalize">{empresa.giro_negocio}</td>
                  <td>{empresa.ruc}</td>
                  <td>{empresa.telefono}</td>
                  <td>{empresa.email}</td>
                  <td>
                    <span
                      className={`badge bg-${
                        empresa.estado === "Activa"
                          ? "success"
                          : empresa.estado === "Inactiva"
                          ? "secondary"
                          : "warning"
                      }`}
                    >
                      {empresa.estado}
                    </span>
                  </td>
                  <td>{empresa.sitio_web_habilitado && empresa.slug ? <Link href={`/sitio/${empresa.slug}`} target="_blank">Ver sitio</Link> : "Sin sitio"}</td>
                  <td>
                    <div className="d-flex align-items-center">
                    <button
                      className="btn btn-warning d-flex align-items-center me-1"
                      onClick={() => abrirModalEditar(empresa)}>
                       <SquarePen  className="me-2" size={16}/>
                       <span>Editar</span>
                    </button>
                   
                    <button className="btn btn-danger d-flex align-items-center me-2" onClick={() => eliminarEmpresa(empresa.id)}>
                      <Trash2 className="me-2" size={16} />
                      <span>Eliminar</span>
                    </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <EmpresaModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          saving={guardando}
          submitError={error}
          productosInventario={productosInventario}
          onProductoPublicadoChange={handleProductoPublicado}
          onTodosProductosChange={handleTodosProductos}
        />
      </div>
    </div>
  );
}