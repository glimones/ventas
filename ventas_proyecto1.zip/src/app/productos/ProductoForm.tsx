import React from "react";
import { ProductoCatalogs, ProductoFormValues } from "./types";

interface Props {
  values: ProductoFormValues;
  catalogs: ProductoCatalogs;
  editando: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onNumberChange: (name: string, value: number) => void;
  onImagesChange: (images: string[]) => void;
}

const ProductoForm: React.FC<Props> = ({ values, catalogs, editando, onChange, onNumberChange, onImagesChange }) => {
  // Manejador de eventos para asegurar que los cambios se registren
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    //e.stopPropagation();
    onChange(e);
  };

  // Manejador especial para campos numéricos
  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const numericValue = e.target.value === "" ? 0 : Number(e.target.value);
    onNumberChange(e.target.name, Number.isFinite(numericValue) ? numericValue : 0);
  };

  const handleImagesChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    const availableSlots = 4 - (values.imagenes_urls?.length ?? 0);
    if (availableSlots <= 0) return;
    Promise.all(files.slice(0, availableSlots).map((file) => new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    }))).then((newImages) => {
      const images = [...(values.imagenes_urls ?? []), ...newImages.filter(Boolean)].slice(0, 4);
      onImagesChange(images);
    }).catch(() => undefined);
  };

  const removeImage = (index: number) => {
    const images = (values.imagenes_urls ?? []).filter((_, currentIndex) => currentIndex !== index);
    onImagesChange(images);
  };

  return (
    <div className="row g-3">
      {/* Primera columna */}
      <div className="col-md-6">
        <div className="mb-3">
          <label htmlFor="codigo" className="form-label">
            Código *
          </label>
          <input
            type="text"
            className="form-control bg-light"
            id="codigo"
            name="codigo"
            value={values.codigo || ""}
            readOnly
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label">
            Nombre *
          </label>
          <input
            type="text"
            className="form-control"
            id="nombre"
            name="nombre"
            value={values.nombre || ""}
            onChange={handleInputChange}
            required
            autoComplete="off"
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="descripcion" className="form-label">
            Descripción
          </label>
          <textarea
            className="form-control"
            id="descripcion"
            name="descripcion"
            value={values.descripcion || ""}
            onChange={handleInputChange}
            rows={3}
          />
        </div>
        
        <div className="mb-3">
          <label htmlFor="categoria" className="form-label">
            Categoría *
          </label>
          <select
            className="form-select"
            id="categoria"
            name="categoria_id"
            value={values.categoria_id || ""}
            onChange={handleInputChange}
            required
          >
            <option value="">Seleccione una categoría</option>
            {catalogs.categorias.map((option) => (
              <option key={option.id} value={option.id}>
                {option.nombre}
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="marca" className="form-label">
            Marca
          </label>
          <select
            className="form-select"
            id="marca"
            name="marca_id"
            value={values.marca_id || ""}
            onChange={handleInputChange}
          >
            <option value="">Seleccione una marca</option>
            {catalogs.marcas.map((marca) => (
              <option key={marca.id} value={marca.id}>
                {marca.nombre}
              </option>
            ))}
          </select>
        </div>

        <div className="mb-3">
          <label htmlFor="proveedor_id" className="form-label">Proveedor</label>
          <select className="form-select" id="proveedor_id" name="proveedor_id" value={values.proveedor_id || ""} onChange={handleInputChange}>
            <option value="">Sin proveedor asignado</option>
            {catalogs.proveedores.map((supplier) => <option key={supplier.id} value={supplier.id}>{supplier.nombre}</option>)}
          </select>
        </div>
      </div>
      
      {/* Segunda columna */}
      <div className="col-md-6">
        <div className="row">
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="precio_compra" className="form-label">
                Precio de compra *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-control"
                id="precio_compra"
                name="precio_compra"
                value={values.precio_compra || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="precio_venta" className="form-label">
                Precio de venta *
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-control"
                id="precio_venta"
                name="precio_venta"
                value={values.precio_venta || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="costo" className="form-label">
                Costo
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-control"
                id="costo"
                name="costo"
                value={values.costo || ""}
                onChange={handleNumberChange}
              />
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="stock_actual" className="form-label">{editando ? "Stock actual (solo lectura)" : "Stock inicial"}</label>
              <input
                type="number"
                step="1"
                min="0"
                className="form-control"
                id="stock_actual"
                name="stock_actual"
                value={values.stock_actual || ""}
                onChange={handleNumberChange}
                readOnly={editando}
              />
            </div>
          </div>
          {!editando && <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="bodega_id" className="form-label">Bodega para stock inicial</label>
              <select className="form-select" id="bodega_id" name="bodega_id" value={values.bodega_id || ""} onChange={handleInputChange}>
                <option value="">Seleccione bodega si ingresa stock</option>
                {catalogs.bodegas.map((warehouse) => <option key={warehouse.id} value={warehouse.id}>{warehouse.nombre}</option>)}
              </select>
            </div>
          </div>}
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="stock_minimo" className="form-label">
                Stock mínimo *
              </label>
              <input
                type="number"
                step="1"
                min="0"
                className="form-control"
                id="stock_minimo"
                name="stock_minimo"
                value={values.stock_minimo || ""}
                onChange={handleNumberChange}
                required
              />
            </div>
          </div>
          <div className="col-md-4">
            <div className="mb-3">
              <label htmlFor="stock_maximo" className="form-label">
                Stock máximo
              </label>
              <input
                type="number"
                step="1"
                min="0"
                className="form-control"
                id="stock_maximo"
                name="stock_maximo"
                value={values.stock_maximo || ""}
                onChange={handleNumberChange}
              />
            </div>
          </div>
        </div>
        
        <div className="mb-3">
          <label htmlFor="unidad_medida" className="form-label">
            Unidad de medida *
          </label>
          <select
            className="form-select"
            id="unidad_medida"
            name="unidad_medida_id"
            value={values.unidad_medida_id || ""}
            onChange={handleInputChange}
            required
          >
            <option value="">Seleccione unidad</option>
            {catalogs.unidades.map((unit) => (
              <option key={unit.id} value={unit.id}>
                {unit.nombre} ({unit.abreviatura})
              </option>
            ))}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="ubicacion_id" className="form-label">Ubicación en almacén</label>
          <select className="form-select" id="ubicacion_id" name="ubicacion_id" value={values.ubicacion_id || ""} onChange={handleInputChange}>
            <option value="">Sin ubicación</option>
            {catalogs.ubicaciones.map((location) => <option key={location.id} value={location.id}>{location.codigo} · {location.pasillo || ""}-{location.estanteria || ""}-{location.nivel || ""}</option>)}
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="estado" className="form-label">
            Estado
          </label>
          <select
            className="form-select"
            id="estado"
            name="estado"
            value={values.estado || "Activo"}
            onChange={handleInputChange}
          >
            <option value="Activo">Activo</option>
            <option value="Inactivo">Inactivo</option>
          </select>
        </div>
        
        <div className="mb-3">
          <label htmlFor="imagenes_urls" className="form-label">Imágenes del producto * (mínimo 2, máximo 4)</label>
          <input
            type="file"
            className="form-control"
            id="imagenes_urls"
            name="imagenes_urls"
            accept="image/png,image/jpeg,image/webp,image/svg+xml"
            multiple
            onChange={handleImagesChange}
            disabled={(values.imagenes_urls?.length ?? 0) >= 4}
          />
          <small className="text-muted d-block mt-1">
            {(values.imagenes_urls?.length ?? 0)} de 4 imágenes seleccionadas.
          </small>
          {(values.imagenes_urls?.length ?? 0) > 0 && (values.imagenes_urls?.length ?? 0) < 2 && (
            <small className="text-danger d-block mt-1">Selecciona al menos 2 imágenes.</small>
          )}
          {(values.imagenes_urls?.length ?? 0) > 0 && (
            <div className="d-flex flex-wrap gap-2 mt-2">
              {values.imagenes_urls?.map((image, index) => (
                <div key={`${image.slice(0, 40)}-${index}`} className="position-relative">
                  <img src={image} alt={`Imagen ${index + 1}`} style={{ width: 88, height: 88, objectFit: "cover", borderRadius: 6 }} />
                  <button type="button" className="btn btn-sm btn-danger position-absolute top-0 end-0" aria-label={`Eliminar imagen ${index + 1}`} onClick={() => removeImage(index)}>×</button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductoForm;