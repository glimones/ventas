import React from "react";
import { CategoriaFormValues } from "./types";

interface Props {
  values: CategoriaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const CategoriaForm: React.FC<Props> = ({ values, onChange }) => (
  <div className="row g-3">
    <div className="col-md-6"><label htmlFor="codigo" className="form-label">Código *</label><input type="text" className="form-control bg-light" id="codigo" name="codigo" value={values.codigo} readOnly required /></div>
    <div className="col-md-6"><label htmlFor="nombre" className="form-label">Nombre *</label><input type="text" className="form-control" id="nombre" name="nombre" value={values.nombre} onChange={onChange} required /></div>
    <div className="col-md-6"><label htmlFor="margen_objetivo" className="form-label">Margen objetivo (%)</label><input type="number" min="0" max="100" step="0.01" className="form-control" id="margen_objetivo" name="margen_objetivo" value={values.margen_objetivo} onChange={onChange} /></div>
    <div className="col-md-6"><label htmlFor="estado" className="form-label">Estado *</label><select className="form-select" id="estado" name="estado" value={values.estado} onChange={onChange} required><option value="Activo">Activo</option><option value="Inactivo">Inactivo</option></select></div>
  </div>
);

export default CategoriaForm;
