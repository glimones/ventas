export interface Categoria {
  id: number;
  codigo: string;
  nombre: string;
  margen_objetivo: number;
  estado: string;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface CategoriaFormValues {
  codigo: string;
  nombre: string;
  margen_objetivo: number;
  estado: string;
}
