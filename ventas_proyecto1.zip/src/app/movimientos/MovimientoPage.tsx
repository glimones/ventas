﻿'use client';

import React, { useState, useCallback, useMemo } from 'react';
import { ESTADOS_MOVIMIENTO_INVENTARIO, MovimientoInventario, MovimientoFormValues } from './types';
import MovimientoModal from './MovimientoModal';
import './bootstrap-movimientos.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: MovimientoFormValues = {
  producto: '',
  tipo: '',
  cantidad: '',
  bodega_origen: '',
  bodega_destino: '',
  fecha: '',
  motivo: '',
  responsable: '',
  estado: 'Pendiente',
  documento_referencia: '',
  notas: '',
};

const initialMovimientos: MovimientoInventario[] = [
  {
    id: 1,
    producto: 'Laptop Pro X1',
    tipo: 'Entrada',
    cantidad: 10,
    bodega_origen: '',
    bodega_destino: 'BOD-001 - Bodega Principal',
    fecha: '2025-03-15',
    motivo: 'Compra a proveedor',
    responsable: 'Carlos Ramírez',
    estado: 'Completado',
    documento_referencia: 'FAC-001-001-000000123',
  },
  {
    id: 2,
    producto: 'Monitor 27 4K',
    tipo: 'Transferencia',
    cantidad: 5,
    bodega_origen: 'BOD-001 - Bodega Principal',
    bodega_destino: 'BOD-002 - Bodega Materia Prima',
    fecha: '2025-03-16',
    motivo: 'Reubicación de inventario',
    responsable: 'Ana Lucía Torres',
    estado: 'Pendiente',
  },
];

export default function MovimientosPage() {
  const [movimientos, setMovimientos] = useState<MovimientoInventario[]>(initialMovimientos);
  const [filtro, setFiltro] = useState<string>('');
  const [estadoFiltro, setEstadoFiltro] = useState('TODOS');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<MovimientoFormValues>(initialForm);

  const limpiarForm = useCallback(() => {
    setForm(initialForm);
    setEditandoId(null);
  }, []);

  const abrirModalNueva = useCallback(() => {
    limpiarForm();
    setTimeout(() => setShowModal(true), 0);
  }, [limpiarForm]);

  const abrirModalEditar = useCallback((mov: MovimientoInventario) => {
    setForm({
      producto: mov.producto || '',
      tipo: mov.tipo || '',
      cantidad: String(mov.cantidad || ''),
      bodega_origen: mov.bodega_origen || '',
      bodega_destino: mov.bodega_destino || '',
      fecha: mov.fecha || '',
      motivo: mov.motivo || '',
      responsable: mov.responsable || '',
      estado: mov.estado || 'Pendiente',
      documento_referencia: mov.documento_referencia || '',
      notas: mov.notas || '',
    });
    setEditandoId(mov.id);
    setTimeout(() => setShowModal(true), 0);
  }, []);

  const cerrarModal = useCallback(() => {
    setShowModal(false);
    setTimeout(limpiarForm, 300);
  }, [limpiarForm]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId) {
      setMovimientos(prev =>
        prev.map(mov =>
          mov.id === editandoId
            ? { ...mov, ...form, cantidad: Number(form.cantidad), id: editandoId }
            : mov
        )
      );
    } else {
      const nuevoId = Date.now();
      setMovimientos(prev => [
        ...prev,
        { ...form, id: nuevoId, cantidad: Number(form.cantidad) } as MovimientoInventario,
      ]);
    }
    cerrarModal();
  }, [form, editandoId, cerrarModal]);

  const eliminarMovimiento = useCallback((id: number) => {
    if (window.confirm('¿Seguro que deseas eliminar este movimiento?')) {
      setMovimientos(prev => prev.filter(mov => mov.id !== id));
    }
  }, []);

  const conteosPorEstado = useMemo(() => {
    const counts: Record<string, number> = Object.fromEntries(
      ESTADOS_MOVIMIENTO_INVENTARIO.map((estado) => [estado.value, 0]),
    );
    for (const movimiento of movimientos) {
      counts[movimiento.estado] = (counts[movimiento.estado] ?? 0) + 1;
    }
    return counts;
  }, [movimientos]);

  const movimientosFiltrados = movimientos.filter(mov =>
    (estadoFiltro === 'TODOS' || mov.estado === estadoFiltro) &&
    Object.values(mov).join(' ').toLowerCase().includes(filtro.toLowerCase())
  );

  const badgeColor = (estado: string) => {
    if (estado === 'Completado') return 'success';
    if (estado === 'Pendiente') return 'warning';
    return 'secondary';
  };

  const tipoBadgeColor = (tipo: string) => {
    if (tipo === 'Entrada') return 'success';
    if (tipo === 'Salida') return 'danger';
    if (tipo === 'Transferencia') return 'info';
    return 'secondary';
  };

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Movimientos de Inventario</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input type='text' className='form-control w-50' placeholder='Buscar movimiento...' value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva} type='button'>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir Movimiento</span>
          </button>
        </div>
        <div className='entity-summary-grid inventory-status-summary-grid' role='region' aria-label='Movimientos de inventario por estado' tabIndex={0}>
          <button
            type='button'
            className={`entity-summary-card${estadoFiltro === 'TODOS' ? ' is-selected' : ''}`}
            aria-pressed={estadoFiltro === 'TODOS'}
            onClick={() => setEstadoFiltro('TODOS')}
          >
            <span>Todos</span>
            <strong>{movimientos.length}</strong>
          </button>
          {ESTADOS_MOVIMIENTO_INVENTARIO.map((estado) => (
            <button
              key={estado.value}
              type='button'
              className={`entity-summary-card${estadoFiltro === estado.value ? ' is-selected' : ''}`}
              aria-pressed={estadoFiltro === estado.value}
              onClick={() => setEstadoFiltro(estado.value)}
            >
              <span>{estado.label}</span>
              <strong>{conteosPorEstado[estado.value]}</strong>
            </button>
          ))}
        </div>
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>Producto</th>
                <th>Tipo</th>
                <th>Cantidad</th>
                <th>Origen</th>
                <th>Destino</th>
                <th>Fecha</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {movimientosFiltrados.length === 0 && (
                <tr><td colSpan={8} className='text-center'>No se encontraron movimientos</td></tr>
              )}
              {movimientosFiltrados.map((mov) => (
                <tr key={mov.id}>
                  <td>{mov.producto}</td>
                  <td><span className={`badge bg-${tipoBadgeColor(mov.tipo)}`}>{mov.tipo}</span></td>
                  <td>{mov.cantidad}</td>
                  <td>{mov.bodega_origen || '-'}</td>
                  <td>{mov.bodega_destino || '-'}</td>
                  <td>{mov.fecha}</td>
                  <td><span className={`badge bg-${badgeColor(mov.estado)}`}>{mov.estado}</span></td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(mov)} type='button'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminarMovimiento(mov.id)} type='button'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <MovimientoModal show={showModal} editando={!!editandoId} values={form} onChange={handleChange} onClose={cerrarModal} onSubmit={handleSubmit} />
      </div>
    </div>
  );
}
