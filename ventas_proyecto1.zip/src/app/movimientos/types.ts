﻿export const ESTADOS_MOVIMIENTO_INVENTARIO = [
  { value: 'Pendiente', label: 'Pendiente' },
  { value: 'Completado', label: 'Completado' },
  { value: 'Anulado', label: 'Anulado' },
] as const;

export interface MovimientoInventario {
  id: number;
  producto: string;
  tipo: string;
  cantidad: number;
  bodega_origen: string;
  bodega_destino: string;
  fecha: string;
  motivo: string;
  responsable: string;
  estado: string;
  documento_referencia?: string;
  notas?: string;
}

export interface MovimientoFormValues {
  producto: string;
  tipo: string;
  cantidad: string;
  bodega_origen: string;
  bodega_destino: string;
  fecha: string;
  motivo: string;
  responsable: string;
  estado: string;
  documento_referencia?: string;
  notas?: string;
}
