import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import HomeDashboard from "@/components/home-dashboard";
import { AUTH_COOKIE, getActiveAccessClaimsFromToken } from "@/lib/auth";

export default async function Home() {
  const token = (await cookies()).get(AUTH_COOKIE)?.value;
  const claims = await getActiveAccessClaimsFromToken(token);
  if (!claims) redirect("/login");

  return (
    <AppShell showFooter={false}>
      <HomeDashboard />
    </AppShell>
  );
}