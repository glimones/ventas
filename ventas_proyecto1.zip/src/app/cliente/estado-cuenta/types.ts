export const TIPOS_DOCUMENTO_ESTADO_CUENTA = [
  { value: 'FACTURA', label: 'Factura' },
  { value: 'NOTA_CREDITO', label: 'Nota de crédito' },
  { value: 'RECIBO', label: 'Recibo' },
] as const;

export interface EstadoCuenta {
  id: number;
  codigo: string;
  cliente: string;
  tipo_documento: string;
  fecha_emision: string;
  fecha_vencimiento: string;
  total: number;
  saldo: number;
  dias_mora: number;
  estado: string;
}

export interface EstadoCuentaFormValues {
  codigo: string;
  cliente: string;
  tipo_documento: string;
  fecha_emision: string;
  fecha_vencimiento: string;
  total: number;
  saldo: number;
  dias_mora: number;
  estado: string;
}
