'use client';
import React, { useState } from 'react';
import { TiposCliente, TiposClienteFormValues } from './types';
import TiposClienteModal from './TiposClienteModal';
import RegistroResumen, { contarRegistrosPorEstado } from '@/components/registro-resumen';
import './bootstrap-tipos-cliente.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: TiposClienteFormValues = {
  codigo: '',
  nombre: '',
  segmento: '',
  limite_credito: 0,
  dias_credito: 0,
  descuento_maximo: 0,
  estado: 'Activo',
};

const initialData: TiposCliente[] = [
  { id: 1, codigo: 'TCL-00000000001', nombre: 'Persona frecuente', segmento: 'PERSONA NATURAL', limite_credito: 2500, dias_credito: 15, descuento_maximo: 5, estado: 'Activo' },
  { id: 2, codigo: 'TCL-00000000002', nombre: 'Empresa corporativa', segmento: 'PERSONA JURIDICA', limite_credito: 15000, dias_credito: 30, descuento_maximo: 10, estado: 'Activo' },
];

function siguienteCodigoTipos(data: TiposCliente[]) {
  const maximo = data.reduce((maximo, item) => {
    const coincidencia = /^TCL-([0-9]+)$/.exec(item.codigo);
    return coincidencia ? Math.max(maximo, Number(coincidencia[1]) || 0) : maximo;
  }, 0);
  return `TCL-${String(maximo + 1).padStart(11, '0')}`;
}

export default function TiposClientePage() {
  const [data, setData] = useState<TiposCliente[]>(initialData);
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<TiposClienteFormValues>(initialForm);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    setForm({ ...initialForm, codigo: siguienteCodigoTipos(data) });
    setEditandoId(null);
    setShowModal(true);
  };

  const abrirModalEditar = (item: TiposCliente) => {
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      nombre: item.nombre || '',
      segmento: item.segmento || '',
      limite_credito: item.limite_credito || 0,
      dias_credito: item.dias_credito || 0,
      descuento_maximo: item.descuento_maximo || 0,
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const numericFields = ['limite_credito', 'dias_credito', 'descuento_maximo'];
    setForm(prev => ({ ...prev, [e.target.name]: numericFields.includes(e.target.name) ? Number(e.target.value) : e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editandoId !== null) {
      setData(prev => prev.map(item =>
        item.id === editandoId
          ? { ...item, ...form }
          : item
      ));
    } else {
      const nuevo: TiposCliente = {
        id: Math.max(0, ...data.map(d => d.id)) + 1,
        ...form,
      };
      setData(prev => [...prev, nuevo]);
    }
    cerrarModal();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de eliminar este registro?')) {
      setData(prev => prev.filter(item => item.id !== id));
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre.toLowerCase().includes(filtro.toLowerCase()) ||
    item.segmento.toLowerCase().includes(filtro.toLowerCase())
  );
  const resumen = contarRegistrosPorEstado(data);

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Tipos de Cliente</h1>
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        <RegistroResumen total={data.length} activos={resumen.activos} inactivos={resumen.inactivos} filtro='TODOS' />
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Nombre</th>
                <th>Segmento</th>
                <th>Límite de crédito</th>
                <th>Plazo</th>
                <th>Descuento máximo</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={10} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.nombre}</td>
                  <td>{item.segmento}</td>
                  <td>${item.limite_credito.toFixed(2)}</td>
                  <td>{item.dias_credito} días</td>
                  <td>{item.descuento_maximo}%</td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <TiposClienteModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
