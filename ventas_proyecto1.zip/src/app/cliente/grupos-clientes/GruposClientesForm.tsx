'use client';
import React from 'react';
import { GruposClientesFormValues } from './types';

interface Props {
  values: GruposClientesFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
}

const GruposClientesForm: React.FC<Props> = ({ values, onChange }) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    e.stopPropagation();
    onChange(e);
  };

  return (
    <div className='row g-3'>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='codigo' className='form-label'>Código *</label>
          <input type='text' className='form-control bg-light' id='codigo' name='codigo' value={values.codigo || ''} readOnly required />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='nombre' className='form-label'>Nombre *</label>
          <input type='text' className='form-control' id='nombre' name='nombre' value={values.nombre || ''} onChange={handleInputChange} required autoComplete='off' />
        </div>
      </div>
      <div className='col-md-12'>
        <div className='mb-3'>
          <label htmlFor='criterio' className='form-label'>Criterio de pertenencia *</label>
          <input type='text' className='form-control' id='criterio' name='criterio' value={values.criterio || ''} onChange={handleInputChange} required placeholder='Ej. Clientes mayoristas de Quito' autoComplete='off' />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='descuento' className='form-label'>Descuento (%)</label>
          <input type='number' min='0' max='100' step='0.01' className='form-control' id='descuento' name='descuento' value={values.descuento || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='limite_credito' className='form-label'>Límite de crédito</label>
          <input type='number' min='0' step='0.01' className='form-control' id='limite_credito' name='limite_credito' value={values.limite_credito || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='clientes_asignados' className='form-label'>Clientes asignados</label>
          <input type='number' min='0' className='form-control' id='clientes_asignados' name='clientes_asignados' value={values.clientes_asignados || 0} onChange={handleInputChange} />
        </div>
      </div>
      <div className='col-md-6'>
        <div className='mb-3'>
          <label htmlFor='estado' className='form-label'>Estado *</label>
          <select className='form-select' id='estado' name='estado' value={values.estado || ''} onChange={handleInputChange} required>
            <option value=''>Seleccione...</option>
            <option value='Activo'>Activo</option>
            <option value='Inactivo'>Inactivo</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default GruposClientesForm;
