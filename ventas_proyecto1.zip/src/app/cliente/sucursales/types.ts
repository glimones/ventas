export interface Sucursales {
  id: number;
  empresa_id: number;
  cliente_id: number;
  cliente: string;
  codigo: string;
  nombre: string;
  direccion: string;
  ciudad: string;
  responsable: string;
  telefono: string;
  email: string;
  estado: string;
}

export interface SucursalesFormValues {
  cliente_id: string;
  codigo: string;
  nombre: string;
  direccion: string;
  ciudad: string;
  responsable: string;
  telefono: string;
  email: string;
  estado: string;
}

export interface ClienteOption {
  id: number;
  nombre: string;
  apellido: string;
  codigo_cliente: string;
  estado: string;
}
