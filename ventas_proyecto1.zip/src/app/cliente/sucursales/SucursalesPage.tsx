'use client';
import React, { useCallback, useEffect, useState } from 'react';
import { ClienteOption, Sucursales, SucursalesFormValues } from './types';
import SucursalesModal from './SucursalesModal';
import RegistroResumen, { contarRegistrosPorEstado } from '@/components/registro-resumen';
import './bootstrap-sucursales.css';
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: SucursalesFormValues = {
  cliente_id: '',
  codigo: '',
  nombre: '',
  direccion: '',
  ciudad: '',
  responsable: '',
  telefono: '',
  email: '',
  estado: 'Activo',
};

export default function SucursalesPage() {
  const [data, setData] = useState<Sucursales[]>([]);
  const [clientes, setClientes] = useState<ClienteOption[]>([]);
  const [cargando, setCargando] = useState(true);
  const [cargandoClientes, setCargandoClientes] = useState(false);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState('');
  const [errorFormulario, setErrorFormulario] = useState('');
  const [filtro, setFiltro] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<SucursalesFormValues>(initialForm);

  const cargarDatos = useCallback(async () => {
    setCargando(true);
    setCargandoClientes(true);
    try {
      const [sucursalesResponse, clientesResponse] = await Promise.all([
        fetch('/api/cliente/sucursales', { cache: 'no-store' }),
        fetch('/api/clientes', { cache: 'no-store' }),
      ]);
      const [sucursalesResult, clientesResult] = await Promise.all([
        sucursalesResponse.json(),
        clientesResponse.json(),
      ]);
      if (!sucursalesResponse.ok) throw new Error(sucursalesResult.error || 'No se pudieron cargar las sucursales.');
      if (!clientesResponse.ok) throw new Error(clientesResult.error || 'No se pudieron cargar los clientes.');
      setData(sucursalesResult as Sucursales[]);
      setClientes(clientesResult as ClienteOption[]);
      setError('');
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : 'Error al cargar los datos.');
    } finally {
      setCargando(false);
      setCargandoClientes(false);
    }
  }, []);

  useEffect(() => {
    void cargarDatos();
  }, [cargarDatos]);

  const limpiarForm = () => {
    setForm(initialForm);
    setEditandoId(null);
  };

  const abrirModalNueva = () => {
    limpiarForm();
    setErrorFormulario('');
    setShowModal(true);
  };

  const abrirModalEditar = (item: Sucursales) => {
    setErrorFormulario('');
    setEditandoId(item.id);
    setForm({
      codigo: item.codigo || '',
      cliente_id: String(item.cliente_id),
      nombre: item.nombre || '',
      direccion: item.direccion || '',
      ciudad: item.ciudad || '',
      responsable: item.responsable || '',
      telefono: item.telefono || '',
      email: item.email || '',
      estado: item.estado || '',
    });
    setShowModal(true);
  };

  const cerrarModal = () => {
    setShowModal(false);
    setErrorFormulario('');
    limpiarForm();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setErrorFormulario('');
    void (async () => {
      try {
        const response = await fetch('/api/cliente/sucursales', {
          method: editandoId !== null ? 'PUT' : 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...form, cliente_id: Number(form.cliente_id), ...(editandoId !== null ? { id: editandoId } : {}) }),
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'No se pudo guardar la sucursal.');
        await cargarDatos();
        cerrarModal();
      } catch (saveError) {
        setErrorFormulario(saveError instanceof Error ? saveError.message : 'Error al guardar la sucursal.');
      } finally {
        setGuardando(false);
      }
    })();
  };

  const eliminar = (id: number) => {
    if (window.confirm('¿Está seguro de desactivar esta sucursal?')) {
      void fetch('/api/cliente/sucursales', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      }).then(async (response) => {
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || 'No se pudo desactivar la sucursal.');
        await cargarDatos();
      }).catch((deleteError: unknown) => {
        setError(deleteError instanceof Error ? deleteError.message : 'Error al desactivar la sucursal.');
      });
    }
  };

  const filtered = data.filter(item =>
    !filtro ||
    item.codigo.toLowerCase().includes(filtro.toLowerCase()) ||
    item.cliente.toLowerCase().includes(filtro.toLowerCase()) ||
    item.nombre.toLowerCase().includes(filtro.toLowerCase()) ||
    item.direccion.toLowerCase().includes(filtro.toLowerCase()) ||
    item.ciudad.toLowerCase().includes(filtro.toLowerCase()) ||
    item.responsable.toLowerCase().includes(filtro.toLowerCase())
  );
  const resumen = contarRegistrosPorEstado(data);

  return (
    <div className='bootstrap-container'>
      <div className='content-wrapper'>
        <h1 className='mb-4'>Sucursales</h1>
        {error && <div className='alert alert-danger' role='alert'>{error}<button type='button' className='btn btn-link' onClick={() => void cargarDatos()}>Reintentar</button></div>}
        <div className='d-flex justify-content-between align-items-center mb-3'>
          <input
            type='text'
            className='form-control w-50'
            placeholder='Buscar...'
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button className='btn btn-primary d-flex align-items-center' onClick={abrirModalNueva}>
            <CirclePlus className='me-2' size={16} />
            <span>Añadir</span>
          </button>
        </div>
        {!error && <RegistroResumen total={data.length} activos={resumen.activos} inactivos={resumen.inactivos} filtro='TODOS' cargando={cargando} />}
        <div className='table-responsive'>
          <table className='table table-striped table-hover'>
            <thead className='table-light'>
              <tr>
                <th>ID</th>
                <th>Código</th>
                <th>Cliente</th>
                <th>Nombre</th>
                <th>Dirección</th>
                <th>Ciudad</th>
                <th>Responsable</th>
                <th>Contacto</th>
                <th>Estado</th>
                <th style={{ width: '180px' }}>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && (
                <tr>
                  <td colSpan={10} className='text-center text-muted py-4'>Cargando sucursales...</td>
                </tr>
              )}
              {!cargando && filtered.length === 0 && (
                <tr>
                  <td colSpan={10} className='text-center text-muted py-4'>
                    No se encontraron registros
                  </td>
                </tr>
              )}
              {filtered.map(item => (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>{item.codigo}</td>
                  <td>{item.cliente}</td>
                  <td>{item.nombre}</td>
                  <td>{item.direccion}</td>
                  <td>{item.ciudad}</td>
                  <td>{item.responsable}</td>
                  <td>{item.telefono}<br /><small className='text-muted'>{item.email}</small></td>
                  <td>
                    <span className={`badge bg-${item.estado === 'Activo' ? 'success' : 'secondary'}`}>
                      {item.estado}
                    </span>
                  </td>
                  <td>
                    <button className='btn btn-warning btn-sm me-1' onClick={() => abrirModalEditar(item)} title='Editar'>
                      <SquarePen size={16} className='me-1' />Editar
                    </button>
                    <button className='btn btn-danger btn-sm' onClick={() => eliminar(item.id)} title='Eliminar'>
                      <Trash2 size={16} className='me-1' />Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <SucursalesModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          clientes={clientes}
          cargandoClientes={cargandoClientes}
          guardando={guardando}
          errorFormulario={errorFormulario}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
        />
      </div>
    </div>
  );
}
