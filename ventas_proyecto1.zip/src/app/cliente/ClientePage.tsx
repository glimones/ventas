"use client";

import React, { useState, useCallback, useEffect } from "react";
import { Cliente, ClienteFormValues } from "./types";
import ClienteModal from "./ClienteModal";
import RegistroResumen, { type FiltroEstadoRegistro } from "@/components/registro-resumen";
import "./bootstrap-cliente.css";
import { CirclePlus, SquarePen, Trash2 } from 'lucide-react';

const initialForm: ClienteFormValues = {
  codigo_cliente: "",
  nombre: "",
  apellido: "",
  empresa: "",
  grupo_cliente: "",
  tipo_cliente: "",
  tipo_documento: "",
  documento: "",
  direccion: "",
  ciudad: "",
  provincia: "",
  pais: "Ecuador",
  codigo_postal: "",
  email: "",
  telefono: "",
  celular: "",
  notas: "",
  estado: "Activo",
};

export default function ClientesPage() {
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [filtro, setFiltro] = useState<string>("");
  const [filtroEstado, setFiltroEstado] = useState<FiltroEstadoRegistro>("TODOS");
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [form, setForm] = useState<ClienteFormValues>(initialForm);
  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState("");
  const [errorFormulario, setErrorFormulario] = useState("");

  const cargarClientes = useCallback(async () => {
    setCargando(true);
    try {
      const response = await fetch("/api/clientes", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No se pudieron cargar los clientes.");
      setClientes(data as Cliente[]);
      setError("");
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Error al cargar clientes.");
    } finally {
      setCargando(false);
    }
  }, []);

  useEffect(() => {
    void cargarClientes();
  }, [cargarClientes]);

  useEffect(() => {
    if (!showModal || editandoId) return;
    void fetch("/api/clientes/siguiente-codigo", { cache: "no-store" })
      .then((response) => response.json())
      .then((result: { codigo?: string }) => {
        if (result.codigo) {
          setForm((previous) => ({ ...previous, codigo_cliente: result.codigo as string }));
        }
      });
  }, [showModal, editandoId]);

  const limpiarForm = useCallback(() => {
    setForm(initialForm);
    setEditandoId(null);
  }, []);

  const abrirModalNueva = useCallback(() => {
    limpiarForm();
    setErrorFormulario("");
    setShowModal(true);
  }, [limpiarForm]);
  
  const abrirModalEditar = useCallback((cliente: Cliente) => {
    setForm({
      codigo_cliente: cliente.codigo_cliente || "",
      nombre: cliente.nombre || "",
      apellido: cliente.apellido || "",
      empresa: cliente.empresa || "",
      grupo_cliente: cliente.grupo_cliente || "",
      tipo_cliente: cliente.tipo_cliente || "",
      tipo_documento: cliente.tipo_documento || "",
      documento: cliente.documento || "",
      direccion: cliente.direccion || "",
      ciudad: cliente.ciudad || "",
      provincia: cliente.provincia || "",
      pais: cliente.pais || "",
      codigo_postal: cliente.codigo_postal || "",
      email: cliente.email || "",
      telefono: cliente.telefono || "",
      celular: cliente.celular || "",
      notas: cliente.notas || "",
      estado: cliente.estado || "Activo",
    });
    setEditandoId(cliente.id);
    setErrorFormulario("");
    setShowModal(true);
  }, []);

  const cerrarModal = useCallback(() => {
    setShowModal(false);
    setTimeout(limpiarForm, 300);
  }, [limpiarForm]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value,
    }));
  }, []);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setGuardando(true);
    setErrorFormulario("");

    try {
      const response = await fetch("/api/clientes", {
        method: editandoId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editandoId ? { ...form, id: editandoId } : form),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No se pudo guardar el cliente.");

      await cargarClientes();
      cerrarModal();
    } catch (saveError) {
      setErrorFormulario(saveError instanceof Error ? saveError.message : "Error al guardar el cliente.");
    } finally {
      setGuardando(false);
    }
  }, [form, editandoId, cerrarModal, cargarClientes]);

  const eliminarCliente = useCallback(async (id: number) => {
    if (window.confirm("¿Seguro que deseas desactivar este cliente?")) {
      try {
        const response = await fetch("/api/clientes", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id }),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "No se pudo desactivar el cliente.");
        setClientes((previous) => previous.map((cliente) =>
          cliente.id === id ? { ...cliente, estado: "Inactivo" } : cliente,
        ));
      } catch (deleteError) {
        setError(deleteError instanceof Error ? deleteError.message : "Error al desactivar el cliente.");
      }
    }
  }, []);

  const clientesActivos = clientes.filter((cliente) =>
    (cliente.estado || "").toLocaleLowerCase().startsWith("activ"),
  ).length;
  const clientesInactivos = clientes.filter((cliente) =>
    (cliente.estado || "").toLocaleLowerCase().startsWith("inactiv"),
  ).length;
  const clientesFiltrados = clientes.filter((cliente) => {
    const coincideBusqueda = Object.values(cliente)
      .join(" ")
      .toLocaleLowerCase()
      .includes(filtro.toLocaleLowerCase());
    const estado = (cliente.estado || "").toLocaleLowerCase();
    const coincideEstado =
      filtroEstado === "TODOS" ||
      (filtroEstado === "ACTIVOS" && estado.startsWith("activ")) ||
      (filtroEstado === "INACTIVOS" && estado.startsWith("inactiv"));
    return coincideBusqueda && coincideEstado;
  });

  return (
    <div className="bootstrap-container">
      <div className="content-wrapper">
        <h1 className="mb-4">Clientes</h1>
        <p className="text-muted mb-0">Creación de nuevos clientes</p>
        <br></br>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <input
            type="text"
            className="form-control w-50"
            placeholder="Buscar cliente..."
            value={filtro}
            onChange={(e) => setFiltro(e.target.value)}
          />
          <button 
            className="btn btn-primary d-flex align-items-center" 
            onClick={abrirModalNueva}
            type="button"
          >
            <CirclePlus className="me-2" size={16} />
            <span>Añadir Cliente</span>
          </button>
        </div>
        <RegistroResumen
          total={clientes.length}
          activos={clientesActivos}
          inactivos={clientesInactivos}
          filtro={filtroEstado}
          cargando={cargando}
          onChange={setFiltroEstado}
        />
        {!cargando && (
          <p className="entity-result-count" role="status">
            Mostrando {clientesFiltrados.length} de {clientes.length} clientes
          </p>
        )}
        {error && <div className="alert alert-danger" role="alert">{error}</div>}
        <div className="table-responsive">
          <table className="table table-striped table-hover">
            <thead className="table-dark">
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Empresa</th>
                <th>Grupo</th>
                <th>Tipo</th>
                <th>Documento</th>
                <th>Ciudad</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Estado</th>
                <th>Opciones</th>
              </tr>
            </thead>
            <tbody>
              {cargando && (
                <tr>
                  <td colSpan={12} className="text-center">Cargando clientes...</td>
                </tr>
              )}
              {!cargando && clientesFiltrados.length === 0 && (
                <tr>
                  <td colSpan={12} className="text-center">
                    {error ? "No se pudieron cargar los clientes" : "No se encontraron clientes"}
                  </td>
                </tr>
              )}
              {clientesFiltrados.map((cliente) => (
                <tr key={cliente.id}>
                  <td>{cliente.codigo_cliente || "-"}</td>
                  <td>{cliente.nombre}</td>
                  <td>{cliente.apellido}</td>
                  <td>{cliente.empresa || "Persona natural"}</td>
                  <td>{cliente.grupo_cliente || "-"}</td>
                  <td>{cliente.tipo_cliente || "-"}</td>
                  <td>{cliente.tipo_documento}: {cliente.documento}</td>
                  <td>{cliente.ciudad}</td>
                  <td>{cliente.email}</td>
                  <td>{cliente.telefono}</td>
                  <td>
                    <span
                      className={`badge bg-${
                        cliente.estado === "Activo"
                          ? "success"
                          : "secondary"
                      }`}
                    >
                      {cliente.estado}
                    </span>
                  </td>
                  <td>
                    <button
                      className="btn btn-warning btn-sm me-1"
                      onClick={() => abrirModalEditar(cliente)}
                      type="button"
                    >
                      <SquarePen size={16} className="me-1" />
                      Editar
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => eliminarCliente(cliente.id)}
                      type="button"
                    >
                      <Trash2 size={16} className="me-1" />
                      Desactivar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <ClienteModal
          show={showModal}
          editando={!!editandoId}
          values={form}
          onChange={handleChange}
          onClose={cerrarModal}
          onSubmit={handleSubmit}
          saving={guardando}
          submitError={errorFormulario}
        />
      </div>
    </div>
  );
}