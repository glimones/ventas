export interface Cliente {
  id: number;
  codigo_cliente: string;
  nombre: string;
  apellido: string;
  empresa?: string;
  grupo_cliente: string;
  tipo_cliente: string;
  tipo_documento: string;
  documento: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  codigo_postal?: string;
  email: string;
  telefono: string;
  celular?: string;
  notas?: string;
  estado: string;
  fecha_creacion?: string;
  fecha_actualizacion?: string;
}

export interface ClienteFormValues {
  codigo_cliente: string;
  nombre: string;
  apellido: string;
  empresa?: string;
  grupo_cliente: string;
  tipo_cliente: string;
  tipo_documento: string;
  documento: string;
  direccion: string;
  ciudad: string;
  provincia?: string;
  pais: string;
  codigo_postal?: string;
  email: string;
  telefono: string;
  celular?: string;
  notas?: string;
  estado: string;
}