"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ArrowUpRight,
  Eye,
  EyeOff,
  FileText,
  LockKeyhole,
  Mail,
  ShieldCheck,
  Wallet,
} from "lucide-react";
import "./login.css";

const transactions = [
  { name: "Factura FV-00482", detail: "Comercial Andina", amount: "+ $1,240.00", kind: "income" },
  { name: "Pago a proveedor", detail: "Suministros del Norte", amount: "- $385.50", kind: "expense" },
  { name: "Factura FV-00481", detail: "Inversiones Rivera", amount: "+ $860.00", kind: "income" },
];

function AccountingPreview() {
  return (
    <div className="accounting-preview" aria-label="Vista previa del panel contable">
      <div className="preview-sidebar">
        <div className="preview-mark"><Wallet size={16} strokeWidth={2.2} /></div>
        <span className="preview-side-line active" />
        <span className="preview-side-line" />
        <span className="preview-side-line short" />
        <span className="preview-side-line" />
        <span className="preview-side-line short" />
      </div>
      <div className="preview-main">
        <div className="preview-topbar">
          <span>Resumen financiero</span>
          <span className="preview-period">Este mes <span aria-hidden="true">⌄</span></span>
        </div>
        <div className="preview-heading">
          <div>
            <span className="preview-eyebrow">MARTES, 21 DE OCTUBRE</span>
            <strong>Buenos días, Ana</strong>
          </div>
          <span className="preview-avatar">AT</span>
        </div>
        <div className="preview-metrics">
          <div className="preview-metric">
            <span>Ingresos del mes</span>
            <strong>$24,860</strong>
            <small><span>↗ 12.8%</span> vs. mes anterior</small>
          </div>
          <div className="preview-metric">
            <span>Cuentas por cobrar</span>
            <strong>$8,420</strong>
            <small>12 facturas pendientes</small>
          </div>
        </div>
        <div className="preview-chart">
          <div className="preview-chart-copy">
            <span>Flujo de caja</span>
            <strong>$18,240.50</strong>
          </div>
          <div className="preview-chart-area" aria-hidden="true">
            <span className="chart-gridline one" />
            <span className="chart-gridline two" />
            <span className="chart-gridline three" />
            <div className="chart-bars">
              {[34, 47, 39, 62, 51, 76, 58, 88, 66, 80, 57, 72].map((height, index) => (
                <span key={index} style={{ height: `${height}%` }} />
              ))}
            </div>
          </div>
          <div className="preview-chart-labels"><span>01 OCT</span><span>10 OCT</span><span>21 OCT</span><span>31 OCT</span></div>
        </div>
        <div className="preview-transactions">
          <div className="preview-transactions-title"><strong>Movimientos recientes</strong><span>Ver todos <ArrowUpRight size={12} /></span></div>
          {transactions.map((transaction) => (
            <div className="preview-transaction" key={transaction.name}>
              <span className={`preview-transaction-icon ${transaction.kind}`}><FileText size={13} /></span>
              <span className="preview-transaction-copy"><strong>{transaction.name}</strong><small>{transaction.detail}</small></span>
              <strong className={transaction.kind}>{transaction.amount}</strong>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function LoginPage() {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [authMode, setAuthMode] = useState<"loading" | "mock" | "database" | "unavailable">("loading");

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/auth/mode", { cache: "no-store", signal: controller.signal })
      .then(async (response) => {
        if (!response.ok) throw new Error("No se pudo consultar el modo de acceso.");
        const result = await response.json();
        if (result.mode !== "mock" && result.mode !== "database") {
          setAuthMode("unavailable");
          return;
        }
        setAuthMode(result.mode);
      })
      .catch(() => {
        if (!controller.signal.aborted) setAuthMode("unavailable");
      });
    return () => controller.abort();
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setIsSubmitting(true);
    const formData = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: formData.get("email"),
          password: formData.get("password"),
        }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "No se pudo iniciar sesión.");
      router.replace("/");
    } catch (loginError) {
      setError(loginError instanceof Error ? loginError.message : "No se pudo iniciar sesión.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="login-page">
      <section className="login-showcase" aria-label="Vista del sistema contable">
        <div className="showcase-topline">
          <Link className="login-brand" href="/" aria-label="GLM, inicio">
            <span className="brand-symbol"><Wallet size={19} strokeWidth={2.1} /></span>
            <span><strong>GLM</strong><small>GESTIÓN EMPRESARIAL</small></span>
          </Link>
          <span className="showcase-status"><span /> SISTEMA CONTABLE</span>
        </div>

        <div className="showcase-copy">
          <span className="showcase-kicker">TODO TU NEGOCIO, EN CLARO</span>
          <h1>Los números cuentan.<br /><em>Tenlos de tu lado.</em></h1>
          <p>Ventas, inventario y finanzas conectados para que puedas decidir con confianza.</p>
        </div>

        <AccountingPreview />

        <div className="showcase-footer">
          <span><ShieldCheck size={15} /> Información organizada en un solo lugar</span>
          <span>01 / 03</span>
        </div>
      </section>

      <section className="login-form-panel">
        <div className="login-form-wrap">
          <div className="mobile-brand login-brand">
            <span className="brand-symbol"><Wallet size={19} strokeWidth={2.1} /></span>
            <span><strong>GLM</strong><small>GESTIÓN EMPRESARIAL</small></span>
          </div>

          <div className="login-heading">
            <span className="login-kicker">TU ESPACIO DE TRABAJO</span>
            <h2>Bienvenido de nuevo</h2>
            <p>Ingresa tus datos para continuar con tu gestión.</p>
          </div>

          <form className="login-form" onSubmit={handleSubmit}>
            <label htmlFor="email">Correo electrónico</label>
            <div className="login-input-wrap">
              <Mail size={17} aria-hidden="true" />
              <Input id="email" name="email" type="email" placeholder="nombre@empresa.com" autoComplete="username" className="h-11 pl-10 text-sm" required />
            </div>

            <div className="password-label-row">
              <label htmlFor="password">Contraseña</label>
              <span>Acceso seguro</span>
            </div>
            <div className="login-input-wrap">
              <LockKeyhole size={17} aria-hidden="true" />
              <Input id="password" name="password" type={showPassword ? "text" : "password"} placeholder="Ingresa tu contraseña" autoComplete="current-password" className="h-11 pl-10 pr-11 text-sm" required />
              <Button
                className="password-toggle absolute right-1 top-1/2 size-8 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                variant="ghost"
                size="icon"
                type="button"
                onClick={() => setShowPassword((visible) => !visible)}
                aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                title={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
              >
                {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
              </Button>
            </div>

            <div className="login-options">
              <label className="remember-option"><input type="checkbox" name="remember" className="size-4 accent-primary" /> <span>Recordar este equipo</span></label>
              <span className="help-link">¿Necesitas ayuda?</span>
            </div>

            {error && <p className="text-sm text-red-700" role="alert">{error}</p>}
            <Button className="login-submit h-11 w-full justify-between px-4" variant="outline" type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Validando..." : "Ingresar"} <ArrowUpRight size={17} />
            </Button>
          </form>

          <div className="demo-notice">
            <span className="demo-dot" />
            <span>
              {authMode === "mock" ? (
                <>Modo de prueba local, sin base de datos.<br />Admin: <strong>admin@glm.local / Demo123!</strong><br />Ventas: <strong>ventas@glm.local / Ventas123!</strong></>
              ) : authMode === "database" ? (
                "Acceso real: utiliza el correo y la contraseña de un usuario activo de la empresa."
              ) : authMode === "unavailable" ? (
                "No se pudo determinar el modo de acceso. Revisa la configuración del servidor."
              ) : (
                "Consultando el modo de acceso..."
              )}
            </span>
          </div>
          {authMode === "database" && <p className="login-support">¿No tienes una cuenta? <span>Contacta al administrador de tu empresa.</span></p>}
        </div>

        <footer className="login-legal"><span>© 2026 GLM Gestión Empresarial</span><span>Privacidad <i /> Seguridad</span></footer>
      </section>
    </main>
  );
}