﻿'use client';

import React, { useEffect, useRef } from 'react';
import { BodegaFormValues } from './types';
import BodegaForm from './BodegaForm';
import './bodegas.css';

interface Props {
  show: boolean;
  editando: boolean;
  values: BodegaFormValues;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onClose: () => void;
  onSubmit: (e: React.FormEvent) => void;
}

const BodegaModal: React.FC<Props> = ({ show, editando, values, onChange, onClose, onSubmit }) => {
  const dialogRef = useRef<HTMLDivElement>(null);
  const previousFocusedElement = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!show) return;

    const dialog = dialogRef.current;
    previousFocusedElement.current = document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null;
    const selector = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
    const getFocusableElements = () => Array.from(dialog?.querySelectorAll<HTMLElement>(selector) ?? []);
    const initialFocus = dialog?.querySelector<HTMLElement>('input:not([readonly]):not([disabled]), select:not([disabled]), textarea:not([disabled])')
      ?? dialog?.querySelector<HTMLElement>('button:not([disabled])');
    const focusFrame = window.requestAnimationFrame(() => initialFocus?.focus());

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key === 'Tab') {
        const focusableElements = getFocusableElements();
        const first = focusableElements[0];
        const last = focusableElements.at(-1);
        if (!first || !last) {
          e.preventDefault();
        } else if (e.shiftKey && (document.activeElement === first || !dialog?.contains(document.activeElement))) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && (document.activeElement === last || !dialog?.contains(document.activeElement))) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    document.body.classList.add('modal-open');
    document.body.style.overflow = 'hidden';
    document.body.style.paddingRight = '15px';
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.classList.remove('modal-open');
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
      document.removeEventListener('keydown', handleKeyDown);
      window.cancelAnimationFrame(focusFrame);
      previousFocusedElement.current?.focus();
    };
  }, [show, onClose]);

  if (!show) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onSubmit(e);
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <>
      <div className='modal fade show d-block' tabIndex={-1} role='dialog' aria-modal='true' aria-labelledby='bodega-modal-title' aria-describedby='bodega-modal-description' style={{ zIndex: 1050 }}>
        <div className='modal-dialog modal-lg' role='document' ref={dialogRef} style={{ zIndex: 1060 }}>
          <div className='modal-content'>
            <form onSubmit={handleSubmit}>
              <div className='modal-header bg-primary text-white'>
                <h5 className='modal-title' id='bodega-modal-title'>{editando ? 'Editar Bodega' : 'Nueva Bodega'}</h5>
                <button type='button' className='btn-close btn-close-white' onClick={onClose} aria-label='Cerrar' />
              </div>
              <div className='modal-body'>
                <p className='text-muted mb-3' id='bodega-modal-description'>Los campos marcados con * son obligatorios</p>
                <BodegaForm values={values} onChange={onChange} />
              </div>
              <div className='modal-footer'>
                <button type='button' className='btn btn-secondary' onClick={onClose}>Cancelar</button>
                <button type='submit' className='btn btn-success'>Guardar</button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div className='modal-backdrop fade show' onClick={handleBackdropClick} style={{ zIndex: 1040 }}></div>
    </>
  );
};

export default BodegaModal;
