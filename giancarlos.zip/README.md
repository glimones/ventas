This is a [Next.js](https://nextjs.org) project for the Ventas system.

## API modular

The security module uses company-scoped menu options, role assignments, and
read/write/delete permissions. Users sign in with their database account; the
menu only displays options with read access, and middleware checks permissions
on application routes and API requests. Sessions last 15 minutes and are
refreshed while the application is open.

Apply `database/010_opciones_permisos.sql` to existing databases with
`psql -d <database> -v ON_ERROR_STOP=1 -f database/010_opciones_permisos.sql`.
Before running it, change its `SET LOCAL search_path` to match `DATABASE_SCHEMA`
if that value is not `ventas`. It creates menu options and sessions, adds
permissions, and gives the `adminGeneral` account the initial `SYS_ADMIN` role
when that account exists in the configured company.
Historical audit tables and their data are retained; the unused audit,
bitacora, and security-configuration screens have been removed.

Set `AUTH_SECRET` in `.env.local` to a private random value of at least 32
characters (for example, generate one with
`node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"`).
After applying the migration, set the administrator's password interactively
with `node scripts/reset-admin-password.mjs adminGeneral`; the password is
entered without terminal echo and stored as a scrypt hash. The reset revokes
that account's existing sessions.

When running locally without `DATABASE_URL`, the login automatically uses
development-only mock accounts so the permission-filtered menu can be checked:
`admin@glm.local` / `Demo123!` (all options) and `ventas@glm.local` /
`Ventas123!` (read-only sales options). This mock is disabled in production and
as soon as `DATABASE_URL` is configured; then login, options, permissions, and
records are read from PostgreSQL. Do not configure a database connection that
is unavailable and expect a mock fallback: database connection/configuration
errors are surfaced instead of silently switching authentication modes.

For local delivery validation, sign in as the demo administrator, publish a
delivery request, and then sign in as `delivery@glm.local` / `Delivery123!`
in the **same browser profile**. The general `/deliveries/portal` shows that
driver's published assignments and unassigned routes across companies;
company-specific portals show only that company's routes. Demo requests include
published and available examples. Assignments, orders, and tracking are stored
in the browser, so they are not synchronized to other browsers, profiles, or
devices. Delivery login is available only in the local mock authentication mode.

The API exposes CRUD endpoints for every module using its route path as the module key. Nested modules keep their path, for example `/api/solicitudes-compra`, `/api/reportes/ventas` and `/api/seguridad/usuarios`.

Treasury branches and cash boxes are company-scoped in the database but are
managed across registered companies by users authorized for those screens.
Create branches under **Parámetros > Sucursales** before registering cash
boxes. Each active branch can have one active cash box; apply
`database/011_cajas_por_sucursal.sql` to existing databases (set its
`search_path` to `DATABASE_SCHEMA` if it is not `ventas`). The migration stops
with an error if existing data already has multiple active boxes for a branch,
so resolve those duplicates before retrying.
Cash box codes are generated sequentially across companies as `CAJA-` plus 14
digits. Apply `database/012_caja_codigo_secuencial.sql` to existing databases;
it advances the sequence to the highest existing code in that format and leaves
legacy codes unchanged.

Bank institutions and company bank accounts are managed separately. New
databases create the global `bancos` catalog and relate `cuentas_bancarias` to
it. On an existing database, apply `database/013_bancos_cuentas_bancarias.sql`
with `psql -d <base_de_datos> -v ON_ERROR_STOP=1 -f database/013_bancos_cuentas_bancarias.sql`
after setting its `search_path` to
`DATABASE_SCHEMA`; it creates the catalog, backfills institutions from the
legacy bank-name field, and adds account holder, bank branch, opening-balance
date, and optional chart-account association. The bank account list masks
account numbers, and its displayed current balance is calculated from the
opening balance and treasury movements dated on or after the opening-balance
date. The mock endpoints use in-memory demo banks and accounts when no database
is configured.

| Method | Endpoint | Purpose |
| --- | --- | --- |
| GET | `/api/<modulo>?q=&page=1&limit=50` | List and search records |
| GET | `/api/<modulo>/<id>` | Read one record |
| POST | `/api/<modulo>` | Create a record |
| PUT or PATCH | `/api/<modulo>/<id>` | Update a record |
| DELETE | `/api/<modulo>/<id>` | Delete a record |

The catch-all module API now uses a PostgreSQL service with an explicit module-to-table/column allowlist in `src/services/module-records.service.ts`. It scopes company data with `DATABASE_EMPRESA_ID`, parameterizes values, supports search/pagination, and uses logical deactivation where the mapped table has a state column. The dedicated `/api/clientes` endpoint uses the same PostgreSQL pool and the relational `terceros` and `clientes` tables, matching `ventas3`.

The banking screen uses dedicated `/api/bancos` endpoints for the bank catalog,
`/api/cuentas-bancarias` endpoints for company accounts, and
`/api/cuentas-bancarias/catalogos` for company, currency, bank, and chart-account
choices. These endpoints use the demo state only when mock authentication is
enabled; with `DATABASE_URL` configured they read and write PostgreSQL.

Bank transfers are persisted through dedicated `/api/transferencias-bancarias`
endpoints. Apply `database/014_transferencias_bancarias.sql` to existing
databases after migration 013, changing its `search_path` if
`DATABASE_SCHEMA` is not `ventas`. Transfers use active accounts belonging to
the same company and currency; codes are generated sequentially as
`TRF-` plus 12 digits. Completing a transfer locks both accounts, rechecks the
available balance, and records the outgoing and incoming treasury movements in
one transaction. Completed transfers cannot be edited or deleted; a reversal
requires a reason and writes compensating movements plus an audit-history event.
An optional PNG, JPEG, or WebP receipt image (up to 5 MB) is stored as raw
Base64 in `comprobante_base64` with its MIME type in `comprobante_mime_type`,
previewed in the form, and shown as a table thumbnail.
Without `DATABASE_URL`, the same workflow runs against the in-memory demo
treasury data.

Bank reconciliation, issued checks, and bank deposits use dedicated endpoints
and in-memory demo data when mock authentication is enabled. Apply
`database/015_conciliacion_cheques_depositos.sql` after migration 014 on existing
databases (change its `search_path` when `DATABASE_SCHEMA` is not `ventas`).
Reconciliations are monthly and immutable after closing: book balance is
calculated from the account opening balance and movements through period end,
while users mark which period movements appear on the bank statement. A
non-zero difference requires a reason. Check issuance records an outgoing
treasury movement and stores both the check image and payment receipt as raw
Base64 with separate MIME types. Deposits are assigned sequential
`DEP-` codes, store the deposit receipt the same way, and record an incoming
treasury movement in the same transaction.
Run the migration with
`psql -d <base_de_datos> -v ON_ERROR_STOP=1 -f database/015_conciliacion_cheques_depositos.sql`.

The shared CRUD components `DomainCrud` and `TreasuryCrudPage` load and mutate mapped records in PostgreSQL. Categories, clients, providers, products, and site configuration have dedicated services. Product stock is calculated from `stock_bodega`; product creation and inventory movements update the related tables transactionally. Mappings also cover measurement units, warehouses, brands, cost centers, opportunities/prospects, activities, employees, periods, banks, cash registers, companies, roles, and payment/tax/branch catalogs. Reports and entities whose forms still lack required foreign-key selections remain read-only or return `501` rather than silently writing incomplete records.

To enable persistence, set `DATABASE_URL`, `DATABASE_SCHEMA`, and `DATABASE_EMPRESA_ID` in `.env.local` to the database values for the selected company, then restart Next.js. The database must contain the relational schema from `database/001_schema.sql` and the HR tables from `database/009_rrhh_services.sql`. The employee, payroll-period, vacation, loan, thirteenth/fourteenth bonus, and settlement modules support company-scoped CRUD; employee references are validated by composite foreign keys. Vacation days and settlement totals are calculated by the database. Payroll currently persists period headers and summary totals; calculating payroll details and Ecuador-specific benefits remains a separate workflow.

Run the HR migration for existing and new databases with `psql -d <base_de_datos> -v ON_ERROR_STOP=1 -f database/009_rrhh_services.sql`. The migration creates the vacation, employee-loan, bonus, and settlement tables. Change its `search_path` from `ventas` if `DATABASE_SCHEMA` uses another schema.

For an existing database, connect to the target database and run `psql -d <base_de_datos> -v ON_ERROR_STOP=1 -f database/003_empresa_configuracion_sitio.sql`. The script sets `search_path` to `sistema_ventas, public`; change that schema in the script if `DATABASE_SCHEMA` uses another name. It adds the site slug, business type, description, colors, online-store flag, and customer-account flag to `empresas`, and backfills unique slugs for existing rows. New databases get the same columns from `database/001_schema.sql`.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/app/building-your-application/optimizing/fonts) to automatically optimize and load [Geist](https://vercel.com/font), a new font family for Vercel.

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js) - your feedback and contributions are welcome!

## Deploy on Vercel

The easiest way to deploy your Next.js app is to use the [Vercel Platform](https://vercel.com/new?utm_medium=default-template&filter=next.js&utm_source=create-next-app&utm_campaign=create-next-app-readme) from the creators of Next.js.

Check out our [Next.js deployment documentation](https://nextjs.org/docs/app/building-your-application/deploying) for more details.
