import { NextRequest, NextResponse } from "next/server";
import { getAuthSecret } from "@/lib/auth-mode";

type Claims = {
  exp: number;
  permissions: Record<string, number>;
};

function decodeBase64Url(value: string) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(base64.padEnd(Math.ceil(base64.length / 4) * 4, "="));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

async function readClaims(request: NextRequest): Promise<Claims | null> {
  const token = request.cookies.get("ventas_session")?.value;
  const secret = getAuthSecret();
  if (!token || !secret) return null;
  const [payload, signature, extra] = token.split(".");
  if (!payload || !signature || extra) return null;
  try {
    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"],
    );
    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      decodeBase64Url(signature),
      new TextEncoder().encode(payload),
    );
    if (!valid) return null;
    const claims = JSON.parse(new TextDecoder().decode(decodeBase64Url(payload))) as Claims;
    return Number.isSafeInteger(claims.exp) &&
      claims.exp > Math.floor(Date.now() / 1000) &&
      claims.permissions !== null &&
      typeof claims.permissions === "object"
      ? claims
      : null;
  } catch {
    return null;
  }
}

function getPermissionRoute(pathname: string) {
  if (pathname.startsWith("/api/")) {
    let route = pathname.slice(4);
    if (route === "/clientes" || route.startsWith("/clientes/")) route = `/cliente${route.slice("/clientes".length)}`;
    if (route === "/empresas" || route.startsWith("/empresas/")) route = `/empresa${route.slice("/empresas".length)}`;
    if (route.startsWith("/seguridad/roles/")) route = "/seguridad/permisos-usuarios";
    if (route.startsWith("/seguridad/usuarios/")) route = "/seguridad/usuarios";
    if (route.startsWith("/compras/")) route = "/solicitudes-compra";
    return route;
  }
  return pathname;
}

function getAction(method: string) {
  if (method === "GET" || method === "HEAD") return 1;
  if (method === "DELETE") return 4;
  return 2;
}

function hasPermission(claims: Claims, route: string, action: number) {
  if (((claims.permissions["*"] ?? 0) & action) === action) return true;
  let bestMatch = "";
  for (const candidate of Object.keys(claims.permissions)) {
    if ((route === candidate || route.startsWith(`${candidate}/`)) && candidate.length > bestMatch.length) {
      bestMatch = candidate;
    }
  }
  return bestMatch.length > 0 && (claims.permissions[bestMatch] & action) === action;
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  if (
    pathname === "/login" ||
    pathname.startsWith("/sitio/") ||
    pathname.startsWith("/api/clientes-web/") ||
    pathname === "/api/auth/login" ||
    pathname === "/api/auth/logout" ||
    pathname === "/api/auth/session" ||
    pathname === "/api/auth/mode" ||
    pathname === "/api/menu"
  ) return NextResponse.next();

  const claims = await readClaims(request);
  if (!claims) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "Se requiere iniciar sesión." }, { status: 401 });
    }
    const login = new URL("/login", request.url);
    login.searchParams.set("next", pathname);
    return NextResponse.redirect(login);
  }

  if (pathname === "/") return NextResponse.next();
  if (
    pathname === "/seguridad" &&
    (claims.permissions["*"] !== undefined ||
      Object.keys(claims.permissions).some((route) => route.startsWith("/seguridad/")))
  ) {
    return NextResponse.next();
  }
  const route = getPermissionRoute(pathname);
  if (!hasPermission(claims, route, getAction(request.method))) {
    if (pathname.startsWith("/api/")) {
      return NextResponse.json({ error: "No tienes permiso para realizar esta acción." }, { status: 403 });
    }
    return new NextResponse("No tienes permiso para acceder a esta opción.", { status: 403 });
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:png|jpg|jpeg|gif|svg|ico|css|js)$).*)"],
};
