import assert from "node:assert/strict";
import fs from "node:fs";
import Module, { createRequire } from "node:module";
import test from "node:test";
import ts from "typescript";

const loadModule = createRequire(import.meta.url);
let localOrders = [];
loadModule.extensions[".ts"] = (module, filename) => {
  const source = fs.readFileSync(filename, "utf8");
  module._compile(ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS } }).outputText, filename);
};
const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === "@/app/sitio/[slug]/customer-store") return { readAllCustomerDeliveryOrders: () => localOrders };
  if (request === "./deliveries-store") return { readDeliveryDrivers: () => [
    { id: "demo-delivery-1", estado: "ACTIVO", companySlugs: ["demo-cafe"] },
    { id: "external-driver", estado: "ACTIVO", companySlugs: [] },
    { id: "external-driver-2", estado: "ACTIVO", companySlugs: [] },
  ] };
  return originalLoad.call(this, request, parent, isMain);
};

const storage = new Map();
let rejectWrites = false;
global.window = {
  localStorage: {
    getItem: (key) => storage.get(key) ?? null,
    setItem: (key, value) => {
      if (rejectWrites) throw new Error("storage full");
      storage.set(key, value);
    },
  },
  dispatchEvent() {},
};
global.CustomEvent = class { constructor(type, options) { this.type = type; this.detail = options.detail; } };
Object.defineProperty(global, "navigator", {
  configurable: true,
  value: { locks: { request: async (_name, _options, action) => action() } },
});
const requests = loadModule("../src/app/deliveries/delivery-requests-store.ts");
const tracking = loadModule("../src/app/deliveries/delivery-tracking-store.ts");
const photo = "data:image/png;base64,iVBORw0KGgo=";
const slug = "demo-cafe";
const driver = "demo-delivery-1";
const firstKey = requests.deliveryRequestKey(slug, "CAFE-GYE-001");
const secondKey = requests.deliveryRequestKey(slug, "CAFE-GYE-002");
const availableKey = requests.deliveryRequestKey(slug, "CAFE-GYE-003");

test("published routes appear for the appropriate driver across companies and remain company-scoped in store portals", async () => {
  storage.clear();
  const directKey = requests.deliveryRequestKey("demo-cafe", "CAFE-GYE-002");
  const openKey = requests.deliveryRequestKey("demo", "WEB-GYE-002");
  const unpublishedKey = requests.deliveryRequestKey("demo", "WEB-GYE-003");
  const direct = requests.readDeliveryAssignments()[directKey];
  await requests.updateDeliveryAssignment(directKey, direct, { ...direct, published: false });
  await requests.updateDeliveryAssignment(openKey, { driverId: "", confirmed: false, published: false }, { driverId: "", confirmed: false, published: true });

  const snapshot = () => requests.getDeliveryPortalRoutes(
    requests.readDeliveryRequests().requests, requests.readDeliveryAssignments(), driver,
  );
  assert.ok(!snapshot().assigned.some((route) => route.requestKey === directKey));
  assert.ok(snapshot().available.some((route) => route.requestKey === openKey));
  assert.ok(!snapshot().available.some((route) => route.requestKey === unpublishedKey));

  await requests.updateDeliveryAssignment(directKey, { ...direct, published: false }, direct);
  assert.ok(snapshot().assigned.some((route) => route.requestKey === directKey));
  const otherDriver = requests.getDeliveryPortalRoutes(requests.readDeliveryRequests().requests, requests.readDeliveryAssignments(), "external-driver");
  assert.ok(!otherDriver.assigned.some((route) => route.requestKey === directKey));
  assert.ok(otherDriver.available.some((route) => route.requestKey === openKey));
  const companyRoutes = requests.getDeliveryPortalRoutes(requests.readDeliveryRequests().requests, requests.readDeliveryAssignments(), driver, "demo");
  assert.ok(!companyRoutes.assigned.some((route) => route.requestKey === directKey));
  assert.ok(companyRoutes.available.some((route) => route.requestKey === openKey));
});

test("company price prevails and an affiliated driver can claim the route", async () => {
  storage.clear();
  await requests.setDeliveryPrice(availableKey, 450, "company");
  assert.equal(await requests.claimDeliveryRequest(slug, availableKey, driver, 900), "assigned");
  const assignment = requests.readDeliveryAssignments()[availableKey];
  assert.equal(assignment.driverId, driver);
  assert.equal(assignment.priceCents, 450);
  assert.equal(assignment.priceSource, "company");
  await assert.rejects(() => requests.setDeliveryPrice(availableKey, 100, "driver", driver), /empresa/);
});

test("demo store publishes several routes and lets the customer accept a courier offer", async () => {
  storage.clear();
  const demoSlug = "demo";
  const demoRequests = requests.readDeliveryRequests().requests;
  const demoRoutes = requests.getDeliveryPortalRoutes(
    demoRequests,
    requests.readDeliveryAssignments(),
    "external-driver",
    demoSlug,
  );
  assert.equal(demoRoutes.available.filter((route) => route.orderId.includes("-TEST-")).length, 3);

  const key = demoRoutes.available.find((route) => route.orderId.endsWith("11")).requestKey;
  await requests.claimDeliveryRequest(demoSlug, key, "external-driver", 550);
  await requests.claimDeliveryRequest(demoSlug, key, "external-driver-2", 450);
  const offers = requests.readDeliveryAssignments()[key].offers;
  assert.deepEqual(offers.map((offer) => offer.priceCents), [550, 450]);
  const acceptedOffer = offers[1];
  await requests.respondDeliveryOffer(demoSlug, key, acceptedOffer, true);

  const assignment = requests.readDeliveryAssignments()[key];
  assert.equal(assignment.driverId, acceptedOffer.driverId);
  assert.equal(assignment.priceCents, 450);
  assert.equal(assignment.customerAccepted, true);
  assert.equal(assignment.offers?.length ?? 0, 0);

  const cafeRoutes = requests.getDeliveryPortalRoutes(
    demoRequests,
    requests.readDeliveryAssignments(),
    "demo-delivery-1",
    "demo-cafe",
  );
  assert.equal(cafeRoutes.available.filter((route) => route.orderId.includes("-TEST-")).length, 3);
  const cafeRouteKey = cafeRoutes.available.find((route) => route.orderId.includes("-TEST-")).requestKey;
  assert.equal(await requests.claimDeliveryRequest("demo-cafe", cafeRouteKey, "demo-delivery-1", 500), "offered");
});

test("customers can compare offers and only the accepted driver is assigned", async () => {
  storage.clear();
  const external = "external-driver";
  assert.equal(await requests.claimDeliveryRequest(slug, availableKey, external, 625), "offered");
  assert.equal(await requests.claimDeliveryRequest(slug, availableKey, "external-driver-2", 425), "offered");
  const offers = requests.readDeliveryAssignments()[availableKey].offers;
  assert.deepEqual(offers.map(({ driverId, priceCents }) => ({ driverId, priceCents })), [{ driverId: external, priceCents: 625 }, { driverId: "external-driver-2", priceCents: 425 }]);
  await assert.rejects(() => requests.claimDeliveryRequest(slug, availableKey, external, 300), /oferta/i);
  await assert.rejects(() => requests.startAssignedDeliveryTracking(slug, availableKey, external), /publicada/);
  await assert.rejects(() => requests.respondDeliveryOffer(slug, availableKey, { ...offers[1], priceCents: 1 }, true), /disponible/);
  await requests.respondDeliveryOffer(slug, availableKey, offers[1], true);
  const accepted = requests.readDeliveryAssignments()[availableKey];
  assert.equal(accepted.driverId, "external-driver-2");
  assert.equal(accepted.priceCents, 425);
  assert.equal(accepted.customerAccepted, true);
  assert.equal(accepted.offers?.length ?? 0, 0);
  await assert.rejects(() => requests.setDeliveryPrice(availableKey, 500, "company"), /aceptada/);
  await assert.rejects(() => requests.respondDeliveryOffer(slug, availableKey, offers[0], true), /disponible/);
});

test("rejection removes only that offer; an affiliated driver may still directly claim", async () => {
  storage.clear();
  await requests.claimDeliveryRequest(slug, availableKey, "external-driver", 500);
  await requests.claimDeliveryRequest(slug, availableKey, "external-driver-2", 400);
  const offers = requests.readDeliveryAssignments()[availableKey].offers;
  await requests.respondDeliveryOffer(slug, availableKey, offers[0], false);
  assert.deepEqual(requests.readDeliveryAssignments()[availableKey].offers, [offers[1]]);
  await requests.claimDeliveryRequest(slug, availableKey, driver, 300);
  const assignment = requests.readDeliveryAssignments()[availableKey];
  assert.equal(assignment.driverId, driver);
  assert.equal(assignment.offers?.length ?? 0, 0);
  await assert.rejects(() => requests.respondDeliveryOffer(slug, availableKey, offers[1], true), /disponible/);
});

test("migrates a previously saved single offer without losing it", () => {
  storage.clear();
  const previous = { driverId: "", confirmed: false, published: true, offer: { driverId: "external-driver", priceCents: 250 } };
  storage.set("ventas:delivery-assignments:v2", JSON.stringify({ [availableKey]: previous }));
  const [offer] = requests.readDeliveryAssignments()[availableKey].offers;
  assert.equal(offer.driverId, previous.offer.driverId);
  assert.equal(offer.priceCents, previous.offer.priceCents);
  assert.ok(offer.id);
});

test("external offers respect a company price and invalid amounts are rejected", async () => {
  storage.clear();
  for (const value of ["", "-1", "1.234", "abc", "1000000.01"]) {
    assert.throws(() => requests.parseDeliveryPrice(value));
  }
  assert.equal(requests.parseDeliveryPrice("3,25"), 325);
  await requests.setDeliveryPrice(availableKey, 250, "company");
  await requests.claimDeliveryRequest(slug, availableKey, "external-driver", 500);
  assert.equal(requests.readDeliveryAssignments()[availableKey].offers[0].priceCents, 250);
  await assert.rejects(() => requests.setDeliveryPrice(availableKey, 600, "company"), /pendiente/);
});

test("requires evidence and blocks switching until the active delivery is confirmed", async () => {
  storage.clear();
  const first = await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
  assert.match(first.verificationCode, /^\d{6}$/);
  await assert.rejects(() => requests.startAssignedDeliveryTracking(slug, secondKey, driver), /Finaliza la ruta/);
  const otherCompanyKey = requests.deliveryRequestKey("demo-market", "MARKET-GYE-001");
  await assert.rejects(() => requests.startAssignedDeliveryTracking("demo-market", otherCompanyKey, driver), /Finaliza la ruta/);
  await assert.rejects(() => requests.finishAssignedDeliveryTracking(first, driver, "", first.verificationCode), /foto/);
  await assert.rejects(() => requests.finishAssignedDeliveryTracking(first, driver, photo, "incorrecto"), /código/i);
  const incorrect = first.verificationCode === "000000" ? "000001" : "000000";
  await assert.rejects(() => requests.finishAssignedDeliveryTracking(first, driver, photo, incorrect), /código/i);
  assert.equal(tracking.readDeliveryTracking(slug, first.orderId).endedAt, null);
  await requests.finishAssignedDeliveryTracking(first, driver, photo, first.verificationCode);
  const delivered = requests.readDeliveryRequests().requests.find((order) => order.requestKey === firstKey);
  assert.equal(delivered.status, "ENTREGADO");
  assert.equal(delivered.proofPhoto, photo);
  assert.notEqual(tracking.readDeliveryTracking(slug, first.orderId).endedAt, null);
  assert.equal(tracking.readDeliveryTracking(slug, first.orderId).verificationCode, undefined);
  assert.equal(tracking.readDeliveryTracking("demo-market", first.orderId), null);
  await assert.rejects(() => requests.startAssignedDeliveryTracking(slug, firstKey, driver), /entregado/);
  await requests.startAssignedDeliveryTracking(slug, secondKey, driver);
});

test("storage failure leaves the route active and the order undelivered", async () => {
  storage.clear();
  const first = await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
  rejectWrites = true;
  await assert.rejects(() => requests.finishAssignedDeliveryTracking(first, driver, photo, first.verificationCode), /storage full/);
  rejectWrites = false;
  assert.equal(tracking.readDeliveryTracking(slug, first.orderId).endedAt, null);
  assert.notEqual(requests.readDeliveryRequests().requests.find((order) => order.requestKey === firstKey).status, "ENTREGADO");
});

test("accepts legacy completed tracking without treating it as delivered", async () => {
  storage.clear();
  const first = await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
  const key = `ventas:delivery-tracking:v1:${firstKey}`;
  const legacy = { ...first };
  delete legacy.verificationCode;
  storage.set(key, JSON.stringify({ ...legacy, endedAt: first.startedAt + 1000 }));
  assert.notEqual(requests.readDeliveryRequests().requests.find((order) => order.requestKey === firstKey).status, "ENTREGADO");
  await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
});

test("adds a stable code to an existing active route without resetting its progress", async () => {
  storage.clear();
  const first = await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
  const legacy = { ...first };
  delete legacy.verificationCode;
  storage.set(`ventas:delivery-tracking:v1:${firstKey}`, JSON.stringify(legacy));
  const migrated = await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
  assert.match(migrated.verificationCode, /^\d{6}$/);
  assert.equal(migrated.startedAt, first.startedAt);
  const reloaded = await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
  assert.equal(reloaded.verificationCode, migrated.verificationCode);
});

test("generic code confirms only demo orders and still requires a photo", async () => {
  storage.clear();
  localOrders = [];
  const first = await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
  await assert.rejects(() => requests.finishAssignedDeliveryTracking(first, driver, "", "123456"), /foto/);
  await requests.finishAssignedDeliveryTracking(first, driver, photo, "123456");
  assert.equal(requests.readDeliveryRequests().requests.find((order) => order.requestKey === firstKey).status, "ENTREGADO");

  storage.clear();
  localOrders = [{ slug, order: {
    id: "CAFE-GYE-001", date: "2026-01-01", customerEmail: "cliente@example.invalid",
    status: "ACEPTADO", items: [], total: 0,
    fulfillment: { method: "DELIVERY", direccion: "demo", ciudad: "Guayaquil", referencia: "" },
  } }];
  const local = await requests.startAssignedDeliveryTracking(slug, firstKey, driver);
  const storedKey = `ventas:delivery-tracking:v1:${firstKey}`;
  const state = JSON.parse(storage.get(storedKey));
  state.verificationCode = "654321";
  storage.set(storedKey, JSON.stringify(state));
  await assert.rejects(() => requests.finishAssignedDeliveryTracking(local, driver, photo, "123456"), /código/i);
  assert.equal(tracking.readDeliveryTracking(slug, local.orderId).endedAt, null);
  await requests.finishAssignedDeliveryTracking(local, driver, photo, "654321");
  assert.equal(requests.readDeliveryRequests().requests.find((order) => order.requestKey === firstKey).status, "ENTREGADO");
  localOrders = [];
});
