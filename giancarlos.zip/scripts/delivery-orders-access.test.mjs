import assert from "node:assert/strict";
import fs from "node:fs";
import Module, { createRequire } from "node:module";
import test from "node:test";
import ts from "typescript";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";

const loadModule = createRequire(import.meta.url);
loadModule.extensions[".tsx"] = (module, filename) => {
  const source = fs.readFileSync(filename, "utf8");
  module._compile(ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX },
  }).outputText, filename);
};

let access;
const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
  if (request === "@/components/access-menu-context") return { useAccessMenu: () => access };
  if (request === "./delivery-requests-store") return {};
  if (request === "./deliveries-store") return {};
  if (request === "./delivery-tracking-store") return {};
  if (request === "./deliveries.css") return {};
  if (request === "next/image") return () => null;
  return originalLoad.call(this, request, parent, isMain);
};
const DeliveryOrdersPage = loadModule("../src/app/deliveries/DeliveryOrdersPage.tsx").default;
Module._load = originalLoad;

function renderAccess(overrides) {
  access = { options: [], globalActions: 0, loading: false, error: "", ...overrides };
  return renderToStaticMarkup(React.createElement(DeliveryOrdersPage));
}

test("global administrator access does not depend on delivery menu entries", () => {
  const html = renderAccess({ globalActions: 7 });
  assert.match(html, /Solicitudes de entrega/);
  assert.doesNotMatch(html, /No tienes permiso para consultar pedidos de entrega/);
});

test("users without delivery or global access remain denied", () => {
  const html = renderAccess({});
  assert.match(html, /No tienes permiso para consultar pedidos de entrega/);
  assert.doesNotMatch(html, /Solicitudes de entrega/);
});

test("existing company permission still grants delivery access", () => {
  const html = renderAccess({ options: [{ ruta: "/empresa", actions: 1 }] });
  assert.match(html, /Solicitudes de entrega/);
});

test("access loading errors are not reported as missing permission", () => {
  const html = renderAccess({ error: "No se pudieron cargar las opciones autorizadas." });
  assert.match(html, /No se pudieron cargar las opciones autorizadas/);
  assert.doesNotMatch(html, /No tienes permiso para consultar pedidos de entrega/);
});
