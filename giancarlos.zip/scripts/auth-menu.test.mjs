import assert from "node:assert/strict";
import fs from "node:fs";
import { createRequire } from "node:module";
import test from "node:test";
import ts from "typescript";

const loadModule = createRequire(import.meta.url);
loadModule.extensions[".ts"] = (module, filename) => {
  const source = fs.readFileSync(filename, "utf8");
  module._compile(ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS },
  }).outputText, filename);
};

const { getMockMenu } = loadModule("../src/lib/auth-mock.ts");

test("full mock permissions keep the regular organization menu available", () => {
  const menu = getMockMenu({ "*": 7 });
  assert.ok(menu.length > 1);
  assert.ok(menu.some((option) => option.ruta === "/empresa"));
  assert.ok(menu.some((option) => option.ruta === "/deliveries"));
});

test("delivery mock permissions return the delivery portal instead of an empty menu", () => {
  const menu = getMockMenu({ "/deliveries/portal": 1 });
  assert.deepEqual(menu.map((option) => option.ruta), ["/deliveries/portal"]);
});

test("mock menu uses current account permissions instead of stale token claims", async () => {
  const nodeModule = loadModule("node:module");
  const originalLoad = nodeModule._load;
  const authMock = loadModule("../src/lib/auth-mock.ts");

  nodeModule._load = function (request, parent, isMain) {
    if (request === "next/server") return { NextResponse: { json: (body, options) => ({ ...body, status: options?.status ?? 200 }) } };
    if (request === "@/lib/auth") return { getAccessClaims: () => ({ sub: "mock:admin", permissions: {} }) };
    if (request === "@/lib/db") return { getDatabasePool: () => assert.fail("mock menu must not query the database") };
    if (request === "@/lib/auth-mode") return { isMockAuthEnabled: () => true };
    if (request === "@/lib/auth-mock") return authMock;
    return originalLoad.call(this, request, parent, isMain);
  };

  try {
    const { GET } = loadModule("../src/app/api/menu/route.ts");
    const response = await GET({});
    assert.equal(response.status, 200);
    assert.equal(response.mode, "mock");
    assert.ok(response.data.length > 1);
    assert.ok(response.data.some((option) => option.ruta === "/empresa"));
  } finally {
    nodeModule._load = originalLoad;
  }
});
