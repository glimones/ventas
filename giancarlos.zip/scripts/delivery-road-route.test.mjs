import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import ts from "typescript";

const source = readFileSync(new URL("../src/app/deliveries/delivery-road-route.ts", import.meta.url), "utf8");
const javascript = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.ESNext } }).outputText;
const { parseOsrmRoute, positionAlongRoute } = await import(`data:text/javascript;base64,${Buffer.from(javascript).toString("base64")}`);

test("moves along bends proportionally to segment length", () => {
  const { coordinates } = parseOsrmRoute({
    routes: [{ geometry: { coordinates: [[0, 0], [1, 0], [1, 0], [1, 3]] } }],
  });
  assert.deepEqual(positionAlongRoute(coordinates, 0), [0, 0]);
  const halfway = positionAlongRoute(coordinates, 0.5);
  assert.ok(Math.abs(halfway[0] - 1) < 0.00001);
  assert.equal(halfway[1], 1);
  assert.deepEqual(positionAlongRoute(coordinates, 1), [3, 1]);
});

test("handles zero-length segments and rejects invalid route responses", () => {
  assert.deepEqual(positionAlongRoute([[1, 2], [1, 2]], 0.5), [1, 2]);
  assert.throws(() => parseOsrmRoute({ routes: [] }));
  assert.throws(() => parseOsrmRoute({
    routes: [{ geometry: { coordinates: [[0, 0], [181, 2]] } }],
  }));
});
