import type { LatLngTuple } from "leaflet";

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function createOsrmRouteUrl(origin: LatLngTuple, destination: LatLngTuple): URL {
  const url = new URL(
    `https://router.project-osrm.org/route/v1/driving/${origin[1]},${origin[0]};${destination[1]},${destination[0]}`,
  );
  url.searchParams.set("overview", "full");
  url.searchParams.set("geometries", "geojson");
  url.searchParams.set("steps", "false");
  return url;
}

export function parseOsrmRoute(value: unknown): {
  coordinates: LatLngTuple[];
  distance?: number;
  duration?: number;
} {
  if (!isRecord(value) || !Array.isArray(value.routes) || !isRecord(value.routes[0])) {
    throw new Error("La respuesta de rutas no tiene un formato válido.");
  }
  const route = value.routes[0];
  if (!isRecord(route.geometry) || !Array.isArray(route.geometry.coordinates) || route.geometry.coordinates.length < 2) {
    throw new Error("La respuesta no contiene una geometría de ruta.");
  }
  const coordinates: LatLngTuple[] = [];
  for (const point of route.geometry.coordinates) {
    if (
      !Array.isArray(point) ||
      typeof point[0] !== "number" || !Number.isFinite(point[0]) || Math.abs(point[0]) > 180 ||
      typeof point[1] !== "number" || !Number.isFinite(point[1]) || Math.abs(point[1]) > 90
    ) {
      throw new Error("La ruta contiene coordenadas inválidas.");
    }
    coordinates.push([point[1], point[0]]);
  }
  return {
    coordinates,
    distance: typeof route.distance === "number" ? route.distance : undefined,
    duration: typeof route.duration === "number" ? route.duration : undefined,
  };
}

function distanceBetween(a: LatLngTuple, b: LatLngTuple): number {
  const radians = Math.PI / 180;
  const lat = (b[0] - a[0]) * radians;
  const lng = (b[1] - a[1]) * radians;
  const h = Math.sin(lat / 2) ** 2 +
    Math.cos(a[0] * radians) * Math.cos(b[0] * radians) * Math.sin(lng / 2) ** 2;
  return 2 * Math.asin(Math.sqrt(Math.min(1, h)));
}

export function positionAlongRoute(coordinates: LatLngTuple[], progress: number): LatLngTuple {
  const lengths = coordinates.slice(1).map((point, index) => distanceBetween(coordinates[index], point));
  const total = lengths.reduce((sum, length) => sum + length, 0);
  let remaining = total * Math.max(0, Math.min(1, progress));
  for (let index = 0; index < lengths.length; index += 1) {
    if (lengths[index] > 0 && remaining <= lengths[index]) {
      const ratio = remaining / lengths[index];
      return [
        coordinates[index][0] + (coordinates[index + 1][0] - coordinates[index][0]) * ratio,
        coordinates[index][1] + (coordinates[index + 1][1] - coordinates[index][1]) * ratio,
      ];
    }
    remaining -= lengths[index];
  }
  return coordinates[coordinates.length - 1];
}
