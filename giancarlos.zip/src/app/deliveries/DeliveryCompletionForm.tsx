"use client";

import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import Image from "next/image";

export default function DeliveryCompletionForm({
  orderId,
  demoCode,
  onCancel,
  onConfirm,
}: {
  orderId: string;
  demoCode?: string;
  onCancel: () => void;
  onConfirm: (photo: string, code: string) => Promise<boolean>;
}) {
  const [photo, setPhoto] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [reading, setReading] = useState(false);
  const [saving, setSaving] = useState(false);
  const readerRef = useRef<FileReader | null>(null);
  const selectionRef = useRef(0);

  useEffect(() => () => {
    selectionRef.current += 1;
    readerRef.current?.abort();
  }, []);

  function selectPhoto(event: ChangeEvent<HTMLInputElement>) {
    const selection = ++selectionRef.current;
    readerRef.current?.abort();
    setPhoto("");
    setError("");
    setReading(false);
    const file = event.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size === 0 || file.size > 1024 * 1024) {
      setError("Selecciona una foto JPG, PNG o WebP de máximo 1 MB.");
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    readerRef.current = reader;
    setReading(true);
    reader.onload = () => {
      if (typeof reader.result !== "string") {
        setError("No se pudo leer la foto seleccionada.");
        setReading(false);
        return;
      }
      const data = reader.result;
      const image = new window.Image();
      image.onload = () => {
        if (selection !== selectionRef.current) return;
        setPhoto(data);
        setReading(false);
      };
      image.onerror = () => {
        if (selection !== selectionRef.current) return;
        setError("El archivo seleccionado no es una imagen válida.");
        setReading(false);
      };
      image.src = data;
    };
    reader.onerror = () => {
      if (selection !== selectionRef.current) return;
      setError("No se pudo leer la foto seleccionada.");
      setReading(false);
    };
    reader.readAsDataURL(file);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!photo || !/^\d{6}$/.test(code) || saving) return;
    setSaving(true);
    const success = await onConfirm(photo, code);
    if (!success) setSaving(false);
  }

  return (
    <form className="delivery-completion-form" onSubmit={(event) => void submit(event)}>
      <strong>Confirmar entrega del pedido {orderId}</strong>
      <label>
        Código de verificación del cliente
        <input
          type="text"
          inputMode="numeric"
          autoComplete="off"
          maxLength={6}
          value={code}
          onChange={(event) => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))}
          disabled={saving}
        />
      </label>
      <small>Solicita al cliente el código de 6 dígitos que aparece en su pedido.</small>
      {demoCode && <small>Código de prueba para pedidos de demostración: <strong>{demoCode}</strong>.</small>}
      <label>
        Foto de recepción obligatoria
        <input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={selectPhoto} disabled={saving} />
      </label>
      <small>JPG, PNG o WebP, máximo 1 MB. Se guarda solo en este navegador.</small>
      {photo && <Image className="delivery-proof-photo" src={photo} alt="Vista previa de la recepción" width={300} height={220} unoptimized />}
      {error && <p className="deliveries-alert" role="alert">{error}</p>}
      <div className="delivery-completion-actions">
        <button type="submit" className="deliveries-primary-button" disabled={!photo || code.length !== 6 || reading || saving}>
          {saving ? "Guardando..." : "Confirmar entrega"}
        </button>
        <button type="button" className="deliveries-secondary-button" onClick={onCancel} disabled={saving}>Cancelar</button>
      </div>
    </form>
  );
}
