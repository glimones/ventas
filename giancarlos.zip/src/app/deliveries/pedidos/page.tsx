import { AppShell } from "@/components/app-shell";
import DeliveryOrdersPage from "../DeliveryOrdersPage";

export default function Page() {
  return (
    <AppShell>
      <DeliveryOrdersPage />
    </AppShell>
  );
}
