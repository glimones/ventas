import DeliveryPortalPage from "../DeliveryPortalPage";

export default function Page() {
  return <DeliveryPortalPage />;
}
