import { deliveryRequestKey } from "./delivery-requests-store";

const TRACKING_PREFIX = "ventas:delivery-tracking:v1:";
export const TRACKING_UPDATED_EVENT = "delivery-tracking-updated";
export const SIMULATION_DURATION_MS = 90000;

export type DeliveryTracking = {
  slug: string;
  orderId: string;
  driverId: string;
  startedAt: number;
  endedAt: number | null;
  proofPhoto?: string;
  verificationCode?: string;
};

function createVerificationCode(): string {
  if (!globalThis.crypto?.getRandomValues) {
    throw new Error("No se pudo generar el código de verificación en este navegador.");
  }
  const random = new Uint32Array(1);
  do {
    globalThis.crypto.getRandomValues(random);
  } while (random[0] >= 4_294_000_000);
  return String(random[0] % 1_000_000).padStart(6, "0");
}

export function isValidDeliveryPhoto(value: string): boolean {
  return value.length <= 1_398_130 &&
    /^data:image\/(?:jpeg|png|webp);base64,(?=.{4})(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value);
}

function trackingKey(slug: string, orderId: string): string {
  return `${TRACKING_PREFIX}${deliveryRequestKey(slug, orderId)}`;
}

export function readDeliveryTracking(slug: string, orderId: string): DeliveryTracking | null {
  const raw = window.localStorage.getItem(trackingKey(slug, orderId));
  if (raw === null) return null;
  const value: unknown = JSON.parse(raw);
  if (
    typeof value !== "object" || value === null || Array.isArray(value) ||
    !("slug" in value) || value.slug !== slug ||
    !("orderId" in value) || value.orderId !== orderId ||
    !("driverId" in value) || typeof value.driverId !== "string" || !value.driverId ||
    !("startedAt" in value) || typeof value.startedAt !== "number" || !Number.isFinite(value.startedAt) ||
    !("endedAt" in value) || (value.endedAt !== null &&
      (typeof value.endedAt !== "number" || !Number.isFinite(value.endedAt) || value.endedAt < value.startedAt)) ||
    ("proofPhoto" in value && value.proofPhoto !== undefined &&
      (typeof value.proofPhoto !== "string" || !isValidDeliveryPhoto(value.proofPhoto) || value.endedAt === null)) ||
    ("verificationCode" in value && value.verificationCode !== undefined &&
      (typeof value.verificationCode !== "string" || !/^\d{6}$/.test(value.verificationCode) || value.endedAt !== null))
  ) {
    throw new Error("El seguimiento guardado tiene un formato inválido.");
  }
  return {
    slug,
    orderId,
    driverId: value.driverId,
    startedAt: value.startedAt,
    endedAt: value.endedAt,
    proofPhoto: "proofPhoto" in value && typeof value.proofPhoto === "string" ? value.proofPhoto : undefined,
    verificationCode: "verificationCode" in value && typeof value.verificationCode === "string" ? value.verificationCode : undefined,
  };
}

function saveTracking(tracking: DeliveryTracking): void {
  window.localStorage.setItem(trackingKey(tracking.slug, tracking.orderId), JSON.stringify(tracking));
  window.dispatchEvent(new CustomEvent(TRACKING_UPDATED_EVENT, {
    detail: { slug: tracking.slug, orderId: tracking.orderId },
  }));
}

export function startDeliveryTracking(slug: string, orderId: string, driverId: string): DeliveryTracking {
  const current = readDeliveryTracking(slug, orderId);
  if (current?.proofPhoto) {
    throw new Error("Este pedido ya fue entregado.");
  }
  if (current && current.endedAt === null && current.driverId !== driverId) {
    throw new Error("Otro repartidor ya inició el seguimiento de este pedido.");
  }
  if (current && current.endedAt === null) {
    if (current.verificationCode) return current;
    const updated = { ...current, verificationCode: createVerificationCode() };
    saveTracking(updated);
    return updated;
  }
  const tracking: DeliveryTracking = { slug, orderId, driverId, startedAt: Date.now(), endedAt: null, verificationCode: createVerificationCode() };
  saveTracking(tracking);
  return tracking;
}

export function finishDeliveryTracking(slug: string, orderId: string, driverId: string, proofPhoto: string, verificationCode: string): DeliveryTracking {
  if (!isValidDeliveryPhoto(proofPhoto)) {
    throw new Error("Adjunta una foto válida JPG, PNG o WebP de máximo 1 MB.");
  }
  const current = readDeliveryTracking(slug, orderId);
  if (!current || current.endedAt !== null || current.driverId !== driverId) {
    throw new Error("El seguimiento ya no está activo para esta cuenta.");
  }
  if (!current.verificationCode || !/^\d{6}$/.test(verificationCode) || verificationCode !== current.verificationCode) {
    throw new Error("El código de verificación no coincide. Solicítalo al cliente e intenta nuevamente.");
  }
  const tracking = { ...current, endedAt: Math.max(Date.now(), current.startedAt), proofPhoto, verificationCode: undefined };
  saveTracking(tracking);
  return tracking;
}

export function getTrackingProgress(tracking: DeliveryTracking, now: number): number {
  const elapsed = (tracking.endedAt ?? now) - tracking.startedAt;
  return Math.max(0, Math.min(1, elapsed / SIMULATION_DURATION_MS));
}
