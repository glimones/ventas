"use client";

import dynamic from "next/dynamic";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Check, Clock3, MapPin, Package, Route, Truck } from "lucide-react";
import {
  claimDeliveryRequest,
  DEMO_DELIVERY_CODE,
  finishAssignedDeliveryTracking,
  formatDeliveryPrice,
  getDeliveryPortalRoutes,
  parseDeliveryPrice,
  readDeliveryAssignments,
  readDeliveryRequests,
  setDeliveryPrice,
  startAssignedDeliveryTracking,
  type DeliveryRequest,
  type PublishedDeliveryRoute,
} from "./delivery-requests-store";
import { readDeliveryDrivers, type DeliveryDriver } from "./deliveries-store";
import DeliveryCompletionForm from "./DeliveryCompletionForm";
import {
  readDeliveryTracking,
  TRACKING_UPDATED_EVENT,
  type DeliveryTracking,
} from "./delivery-tracking-store";
import "./deliveries.css";

const SimulatedDeliveryRouteMap = dynamic(() => import("./SimulatedDeliveryRouteMap"), {
  ssr: false,
  loading: () => <p className="delivery-map-loading" role="status">Cargando el mapa...</p>,
});

type PublishedRoute = PublishedDeliveryRoute;

export type DeliveryPortalPageProps =
  | { companySlug: string; companyName: string }
  | { companySlug?: never; companyName?: never };

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function getDestination(request: DeliveryRequest): string {
  const { fulfillment } = request;
  return [
    [fulfillment.sector, fulfillment.direccion, fulfillment.ciudad].filter(Boolean).join(" · "),
    fulfillment.referencia ? `Referencia: ${fulfillment.referencia}` : "",
  ].filter(Boolean).join(" · ");
}

function DeliveryRouteDetails({
  route,
  deliveryStatus = route.status,
}: {
  route: DeliveryRequest;
  deliveryStatus?: DeliveryRequest["status"] | "EN RUTA";
}) {
  return (
    <div className="delivery-route-item-details">
      <p><MapPin size={15} /><span><strong>Destino</strong>{getDestination(route)}</span></p>
      <p><Package size={15} /><span><strong>Pedido</strong>{route.items.map((item) => `${item.quantity} × ${item.name}`).join(", ")}</span></p>
      <p><Clock3 size={15} /><span><strong>Estado del viaje</strong>{deliveryStatus}</span></p>
    </div>
  );
}

export default function DeliveryPortalPage({ companySlug, companyName = "Rutas de entrega" }: DeliveryPortalPageProps) {
  const [driver, setDriver] = useState<DeliveryDriver | null>(null);
  const [routes, setRoutes] = useState<PublishedRoute[]>([]);
  const [availableRoutes, setAvailableRoutes] = useState<PublishedRoute[]>([]);
  const [pendingOffers, setPendingOffers] = useState<PublishedRoute[]>([]);
  const [prices, setPrices] = useState<Record<string, string>>({});
  const [activeRouteKey, setActiveRouteKey] = useState<string | null>(null);
  const [activeTracking, setActiveTracking] = useState<DeliveryTracking | null>(null);
  const [usingDemoOrders, setUsingDemoOrders] = useState(false);
  const [loading, setLoading] = useState(true);
  const [requiresLogin, setRequiresLogin] = useState(false);
  const [wrongAccount, setWrongAccount] = useState(false);
  const [error, setError] = useState("");
  const [actionError, setActionError] = useState("");
  const [actionNotice, setActionNotice] = useState("");
  const [claimingKey, setClaimingKey] = useState<string | null>(null);
  const [confirmingDelivery, setConfirmingDelivery] = useState(false);
  const [refreshVersion, setRefreshVersion] = useState(0);

  const companyUrl = companySlug ? `/sitio/${encodeURIComponent(companySlug)}` : "/deliveries/portal";
  const loginUrl = companySlug ? `${companyUrl}?acceso=repartidor` : "/login?next=%2Fdeliveries%2Fportal";
  const refresh = useCallback(() => setRefreshVersion((version) => version + 1), []);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError("");
    setRequiresLogin(false);
    setWrongAccount(false);

    void fetch("/api/auth/session", { cache: "no-store", signal: controller.signal })
      .then(async (response) => {
        const result: unknown = await response.json();
        if (response.status === 401) {
          setDriver(null);
          setRoutes([]);
          setAvailableRoutes([]);
          setPendingOffers([]);
          setRequiresLogin(true);
          return;
        }
        if (!response.ok) {
          throw new Error(isRecord(result) && typeof result.error === "string"
            ? result.error
            : "No se pudo validar la sesión.");
        }
        if (!isRecord(result) || !isRecord(result.data) || typeof result.data.id !== "string") {
          throw new Error("La sesión recibida no tiene un formato válido.");
        }
        const prefix = "mock:delivery:";
        if (!result.data.id.startsWith(prefix)) {
          setWrongAccount(true);
          throw new Error("Esta cuenta no está vinculada a un repartidor del portal.");
        }
        const driverId = result.data.id.slice(prefix.length);
        const activeDriver = readDeliveryDrivers().find((candidate) =>
          candidate.id === driverId && candidate.estado === "ACTIVO",
        );
        if (!activeDriver) {
          throw new Error("La cuenta no tiene un repartidor activo vinculado.");
        }

        const requestData = readDeliveryRequests();
        const assignments = readDeliveryAssignments();
        const { assigned: publishedRoutes, available, offers } = getDeliveryPortalRoutes(
          requestData.requests, assignments, activeDriver.id, companySlug,
        );
        const { assigned: allDriverRoutes } = getDeliveryPortalRoutes(
          requestData.requests, assignments, activeDriver.id,
        );
        const running = allDriverRoutes.flatMap((route) => {
          const tracking = readDeliveryTracking(route.slug, route.orderId);
          return tracking && tracking.endedAt === null && tracking.driverId === activeDriver.id
            ? [{ route, tracking }]
            : [];
        })[0];
        const runningTracking = running && !running.tracking.verificationCode
          ? await startAssignedDeliveryTracking(running.route.slug, running.route.requestKey, activeDriver.id)
          : running?.tracking ?? null;
        if (controller.signal.aborted) return;
        setDriver(activeDriver);
        setRoutes(publishedRoutes);
        setAvailableRoutes(available);
        setPendingOffers(offers);
        setUsingDemoOrders([...publishedRoutes, ...available, ...offers].some((route) => route.isDemo));
        setActiveRouteKey(running?.route.requestKey ?? null);
        setActiveTracking(runningTracking);
      })
      .catch((loadError: unknown) => {
        if (controller.signal.aborted) return;
        setDriver(null);
        setRoutes([]);
        setAvailableRoutes([]);
        setPendingOffers([]);
        setError(loadError instanceof Error ? loadError.message : "No se pudieron cargar las rutas publicadas.");
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });

    return () => controller.abort();
  }, [companySlug, refreshVersion]);

  useEffect(() => {
    window.addEventListener("customer-orders-updated", refresh);
    window.addEventListener("delivery-assignments-updated", refresh);
    window.addEventListener("delivery-drivers-updated", refresh);
    window.addEventListener(TRACKING_UPDATED_EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("customer-orders-updated", refresh);
      window.removeEventListener("delivery-assignments-updated", refresh);
      window.removeEventListener("delivery-drivers-updated", refresh);
      window.removeEventListener(TRACKING_UPDATED_EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, [refresh]);

  const activeRoute = useMemo(
    () => routes.find((route) => route.requestKey === activeRouteKey) ?? null,
    [activeRouteKey, routes],
  );

  async function startRoute(route: PublishedRoute) {
    if (!driver) return;
    setActionError("");
    if (activeRouteKey && activeRouteKey !== route.requestKey) {
      setActionError("Ya tienes un viaje abierto. Finalízalo antes de iniciar otra ruta.");
      return;
    }
    try {
      const tracking = await startAssignedDeliveryTracking(route.slug, route.requestKey, driver.id);
      setActiveRouteKey(route.requestKey);
      setActiveTracking(tracking);
    } catch (startError) {
      setActionError(startError instanceof Error ? startError.message : "No se pudo iniciar el seguimiento.");
      refresh();
    }
  }

  async function finishRoute(photo: string, code: string): Promise<boolean> {
    if (!driver || !activeTracking) return false;
    setActionError("");
    try {
      await finishAssignedDeliveryTracking(activeTracking, driver.id, photo, code);
      setActiveRouteKey(null);
      setActiveTracking(null);
      setConfirmingDelivery(false);
      setActionNotice(`El pedido ${activeTracking.orderId} fue marcado como entregado en este navegador.`);
      return true;
    } catch (finishError) {
      setActionError(finishError instanceof Error ? finishError.message : "No se pudo finalizar el seguimiento.");
      return false;
    }
  }

  async function claimRoute(route: PublishedRoute) {
    if (!driver || claimingKey) return;
    setClaimingKey(route.requestKey);
    setActionError("");
    setActionNotice("");
    try {
      const response = await fetch("/api/auth/session", { cache: "no-store" });
      const result: unknown = await response.json();
      if (!response.ok || !isRecord(result) || !isRecord(result.data) || result.data.id !== `mock:delivery:${driver.id}`) {
        throw new Error("Tu sesión de repartidor cambió o expiró. Inicia sesión nuevamente.");
      }
      const assignment = route.assignment;
      const price = assignment?.priceSource === "company" && assignment.priceCents !== undefined
        ? assignment.priceCents : parseDeliveryPrice(prices[route.requestKey] ?? "");
      const outcome = await claimDeliveryRequest(route.slug, route.requestKey, driver.id, price);
      setActionNotice(outcome === "offered"
        ? `Oferta enviada para ${route.orderId}. El cliente podrá elegir entre las ofertas recibidas en este navegador.`
        : `La ruta ${route.orderId} quedó asignada a tu cuenta.`);
    } catch (claimError) {
      refresh();
      setActionError(claimError instanceof Error ? claimError.message : "No se pudo asignar la ruta.");
    } finally {
      setClaimingKey(null);
    }
  }

  async function saveRoutePrice(route: PublishedRoute) {
    if (!driver || claimingKey) return;
    setClaimingKey(route.requestKey);
    setActionError("");
    try {
      await setDeliveryPrice(route.requestKey, parseDeliveryPrice(prices[route.requestKey] ?? ""), "driver", driver.id);
      setActionNotice(`Valor de envío del pedido ${route.orderId} guardado.`);
    } catch (saveError) {
      setActionError(saveError instanceof Error ? saveError.message : "No se pudo guardar el valor de envío.");
    } finally {
      setClaimingKey(null);
    }
  }

  return (
    <div className="delivery-company-site">
      <header className="delivery-company-site-header">
        <Link href={companyUrl} className="delivery-company-site-brand">
          <span>{companyName.slice(0, 1).toLocaleUpperCase()}</span>
          <strong>{companyName}<small>{companySlug ? "TIENDA EN LÍNEA" : "PORTAL DE REPARTIDORES"}</small></strong>
        </Link>
        {companySlug && <Link href={companyUrl} className="delivery-company-site-back">Volver al sitio de la empresa</Link>}
      </header>

      <main className="delivery-company-site-main">
        <div className="deliveries-page delivery-portal-page">
          <header className="deliveries-header">
            <div>
              <span className="deliveries-eyebrow"><Truck size={15} /> ENTREGAS · {companyName.toLocaleUpperCase()}</span>
              <h1>Portal de repartidor</h1>
              <p>{driver ? `Hola, ${driver.nombre}. Aquí están las rutas publicadas para ti.` : "Consulta las rutas asignadas a tu cuenta."}</p>
            </div>
            {!requiresLogin && !error && (
              <button type="button" className="deliveries-secondary-button" onClick={refresh} disabled={loading}>
                <Route size={15} /> Actualizar rutas
              </button>
            )}
          </header>

          {loading ? (
            <p className="deliveries-demo-note" role="status">Validando la cuenta y las rutas publicadas...</p>
          ) : requiresLogin ? (
            <section className="delivery-login-card">
              <span className="delivery-login-icon"><Truck size={20} /></span>
              <h2>Acceso para repartidores</h2>
              <p>Inicia sesión con tu cuenta de repartidor para consultar tus rutas.</p>
              <Link className="deliveries-primary-button" href={loginUrl}>Iniciar sesión como repartidor</Link>
              {companySlug === "demo" && (
                <small>Cuenta de demostración: delivery@glm.local · clave Delivery123!</small>
              )}
            </section>
          ) : error ? (
            <div className="deliveries-alert" role="alert">
              <p>{error}</p>
              {wrongAccount && <Link className="deliveries-primary-button" href={loginUrl}>Iniciar sesión como repartidor</Link>}
            </div>
          ) : (
            <>
              <p className="deliveries-demo-note" role="status">
                {usingDemoOrders && "Se muestran rutas de demostración. "}
                Las publicaciones y asignaciones se guardan solo en este navegador; no se comparten con otros dispositivos o perfiles.
              </p>
              {actionError && <div className="deliveries-alert" role="alert">{actionError}</div>}
              {actionNotice && <div className="deliveries-notice" role="status">{actionNotice}</div>}
              {activeTracking && !activeRoute && (
                <div className="deliveries-notice delivery-active-trip-notice" role="status">
                  Ya tienes un viaje abierto en otra tienda. Finalízalo antes de iniciar otra ruta.
                  <Link href="/deliveries/portal">Abrir el portal general para cerrar el viaje</Link>
                </div>
              )}
              {driver && (
                <section className="delivery-driver-account" aria-label="Cuenta de repartidor">
                  <span className="delivery-driver-avatar">{driver.nombre.slice(0, 1).toLocaleUpperCase()}</span>
                  <div><strong>{driver.nombre}</strong><small>{driver.accountEmail} · {driver.tipoVehiculo} {driver.placa}</small></div>
                  <span className="deliveries-status is-active">Cuenta activa</span>
                </section>
              )}

              {availableRoutes.some((route) => route.offerRequired) && (
                <section className="delivery-offer-guide" aria-label="Cómo enviar una oferta">
                  <div className="delivery-offer-guide-heading">
                    <span><Truck size={17} /></span>
                    <div><strong>Consigue esta entrega</strong><p>Envía tu propuesta; el cliente decide quién llevará su pedido.</p></div>
                  </div>
                  <ol>
                    <li><span>1</span><span>Revisa el destino y el pedido</span></li>
                    <li><span>2</span><span>Indica cuánto cobrarás</span></li>
                    <li><span>3</span><span>Espera la aceptación del cliente</span></li>
                  </ol>
                </section>
              )}

              <section className="deliveries-card delivery-portal-routes">
                <div className="deliveries-toolbar">
                  <div>
                    <h2>Rutas publicadas</h2>
                    <p>{routes.length} ruta{routes.length === 1 ? "" : "s"} asignada{routes.length === 1 ? "" : "s"} a tu cuenta</p>
                  </div>
                </div>
                {routes.length === 0 ? (
                  <p className="deliveries-empty delivery-portal-empty">Aún no tienes rutas publicadas. La empresa te mostrará aquí los pedidos confirmados.</p>
                ) : (
                  <div className="delivery-route-list">
                    {routes.map((route) => {
                      const isActive = route.requestKey === activeRouteKey;
                      const delivered = route.status === "ENTREGADO";
                      const waitingForActiveTrip = activeRouteKey !== null && !isActive && !delivered;
                      const deliveryStatus = delivered ? "ENTREGADO" : isActive ? "EN RUTA" : "PENDIENTE";
                      return (
                        <article className={`delivery-route-item${isActive ? " is-active" : ""}`} key={route.requestKey}>
                          <div className="delivery-route-item-heading">
                            <div>
                              <span className="deliveries-order-state">Pedido {route.orderId}</span>
                              {!companySlug && <small className="deliveries-table-subline">{route.companyName}</small>}
                              {route.isDemo && <small className="deliveries-table-subline">Pedido de demostración</small>}
                            </div>
                            {delivered ? <span className="deliveries-status is-active">Entregado</span> : <button
                              type="button"
                              className={isActive ? "deliveries-secondary-button" : "deliveries-primary-button"}
                              disabled={waitingForActiveTrip}
                              onClick={() => {
                                if (isActive) {
                                  setActionError("");
                                  setConfirmingDelivery(true);
                                } else {
                                  void startRoute(route);
                                }
                              }}
                            >
                              <Route size={15} /> {isActive ? "Finalizar ruta" : waitingForActiveTrip ? "En espera" : "Iniciar ruta"}
                            </button>}
                          </div>
                          <DeliveryRouteDetails route={route} deliveryStatus={deliveryStatus} />
                          {waitingForActiveTrip && <p className="delivery-route-waiting">Pendiente · finaliza el viaje abierto para habilitar esta ruta.</p>}
                          <p>Pago por entrega: {route.assignment.priceCents === undefined ? "Sin definir" : formatDeliveryPrice(route.assignment.priceCents)}{route.assignment.priceSource === "company" ? " · establecido por la empresa" : ""}</p>
                          {!delivered && !isActive && route.assignment.priceSource !== "company" && !route.assignment.customerAccepted && (
                            <div>
                              <label>Valor de la carrera (USD) <input type="number" min="0" max="1000000" step="0.01" value={prices[route.requestKey] ?? ""} onChange={(event) => setPrices((current) => ({ ...current, [route.requestKey]: event.target.value }))} /></label>{" "}
                              <button type="button" className="deliveries-secondary-button" disabled={claimingKey !== null} onClick={() => void saveRoutePrice(route)}>Guardar valor</button>
                            </div>
                          )}
                          {isActive && activeTracking && <p className="delivery-route-started">Ruta simulada iniciada a las {new Date(activeTracking.startedAt).toLocaleTimeString("es-EC", { hour: "2-digit", minute: "2-digit" })}. El seguimiento se guarda en este navegador.</p>}
                          {isActive && confirmingDelivery && <DeliveryCompletionForm orderId={route.orderId} demoCode={route.isDemo ? DEMO_DELIVERY_CODE : undefined} onCancel={() => setConfirmingDelivery(false)} onConfirm={finishRoute} />}
                        </article>
                      );
                    })}
                  </div>
                )}
              </section>

              <section className="deliveries-card delivery-portal-routes">
                <div className="deliveries-toolbar">
                  <div>
                    <h2>Rutas disponibles</h2>
                    <p>{availableRoutes.length} ruta{availableRoutes.length === 1 ? "" : "s"} sin asignar · propone tu valor para postular</p>
                  </div>
                </div>
                {availableRoutes.length === 0 ? (
                  <p className="deliveries-empty delivery-portal-empty">No hay rutas publicadas disponibles para asignarte.</p>
                ) : (
                  <div className="delivery-route-list">
                    {availableRoutes.map((route) => {
                      const assignment = route.assignment;
                      const fixedPrice = assignment?.priceSource === "company" ? assignment.priceCents : undefined;
                      const enrolled = driver?.companySlugs?.includes(route.slug);
                      const enteredPrice = (prices[route.requestKey] ?? "").trim();
                      return (
                      <article className="delivery-route-item" key={route.requestKey}>
                        <div className="delivery-route-item-heading">
                          <div>
                            <span className="deliveries-order-state">Pedido {route.orderId}</span>
                            {!companySlug && <small className="deliveries-table-subline">{route.companyName}</small>}
                            {route.isDemo && <small className="deliveries-table-subline">Pedido de demostración</small>}
                          </div>
                          <span className="delivery-route-availability">Disponible para postular</span>
                        </div>
                        <DeliveryRouteDetails route={route} />
                        {fixedPrice !== undefined ? (
                          <p className="delivery-route-fixed-price">Valor establecido por la empresa: <strong>{formatDeliveryPrice(fixedPrice)}</strong></p>
                        ) : (
                          <label className="delivery-offer-price">
                            <span>Tu valor de entrega</span>
                            <span className="delivery-offer-price-input">
                              <input
                                type="number"
                                min="0"
                                max="1000000"
                                step="0.01"
                                placeholder="Ej. 4,50"
                                value={prices[route.requestKey] ?? ""}
                                aria-label={`Tu valor de entrega para el pedido ${route.orderId} en USD`}
                                onChange={(event) => setPrices((current) => ({ ...current, [route.requestKey]: event.target.value }))}
                              />
                              <span>USD</span>
                            </span>
                            <small>El cliente verá este valor antes de aceptar tu oferta.</small>
                          </label>
                        )}
                        {(route.offerRequired || !enrolled) && <p className="delivery-route-offer-hint">Tu oferta no asigna la ruta automáticamente. El cliente debe aceptarla.</p>}
                        <button
                          type="button"
                          className="deliveries-primary-button delivery-route-offer-button"
                          disabled={claimingKey !== null || (fixedPrice === undefined && !enteredPrice)}
                          onClick={() => void claimRoute(route)}
                        >
                          <Truck size={15} /> {claimingKey === route.requestKey ? "Enviando oferta..." : route.offerRequired || !enrolled ? "Enviar oferta al cliente" : "Postular a la ruta"}
                        </button>
                      </article>
                    );})}
                  </div>
                )}
              </section>

              {pendingOffers.length > 0 && <section className="deliveries-card delivery-portal-routes">
                <div className="deliveries-toolbar">
                  <div><h2>Mis ofertas enviadas</h2><p>Te avisaremos aquí cuando el cliente responda.</p></div>
                </div>
                {pendingOffers.map((route) => {
                  const offer = route.assignment.offers?.find((item) => item.driverId === driver?.id);
                  return offer ? (
                    <article className="delivery-pending-offer" key={route.requestKey}>
                      <span className="delivery-pending-offer-icon"><Clock3 size={16} /></span>
                      <span><strong>Pedido {route.orderId}</strong><small>Oferta enviada · esperando respuesta</small></span>
                      <strong>{formatDeliveryPrice(offer.priceCents)}</strong>
                      <Check size={16} aria-hidden="true" />
                    </article>
                  ) : null;
                })}
              </section>}
              {activeRoute && activeTracking && <SimulatedDeliveryRouteMap tracking={activeTracking} sector={activeRoute.fulfillment.sector} />}
            </>
          )}
        </div>
      </main>

      <footer className="delivery-company-site-footer">
        <span>© {new Date().getFullYear()} {companyName}</span>
        {companySlug && <Link href={companyUrl}>Volver a la tienda</Link>}
      </footer>
    </div>
  );
}
