import {
  readAllCustomerDeliveryOrders,
  type CustomerOrder,
  type CustomerOrderFulfillment,
} from "@/app/sitio/[slug]/customer-store";
import { readDeliveryDrivers } from "./deliveries-store";
import {
  finishDeliveryTracking,
  readDeliveryTracking,
  startDeliveryTracking,
  type DeliveryTracking,
} from "./delivery-tracking-store";

const ASSIGNMENTS_KEY = "ventas:delivery-assignments:v2";
const LEGACY_ASSIGNMENTS_KEY = "ventas:delivery-assignments:v1";
const ASSIGNMENTS_LOCK = "ventas:delivery-assignments";
export const DEMO_DELIVERY_CODE = "123456";

export type DeliveryOffer = { id: string; driverId: string; priceCents: number };

export type DeliveryAssignment = {
  driverId: string;
  confirmed: boolean;
  published: boolean;
  priceCents?: number;
  priceSource?: "company" | "driver";
  offers?: DeliveryOffer[];
  customerAccepted?: boolean;
};

export type DeliveryRequest = {
  requestKey: string;
  orderId: string;
  slug: string;
  companyName: string;
  date: string;
  customer: string;
  items: CustomerOrder["items"];
  total: number;
  status: CustomerOrder["status"] | "ENTREGADO";
  proofPhoto?: string;
  fulfillment: Extract<CustomerOrderFulfillment, { method: "DELIVERY" }>;
  isDemo: boolean;
  offerRequired?: boolean;
};

export type PublishedDeliveryRoute = DeliveryRequest & { assignment: DeliveryAssignment };

export function getDeliveryPortalRoutes(
  requests: DeliveryRequest[],
  assignments: Record<string, DeliveryAssignment>,
  driverId: string,
  companySlug?: string,
): { assigned: PublishedDeliveryRoute[]; available: PublishedDeliveryRoute[]; offers: PublishedDeliveryRoute[] } {
  const assigned: PublishedDeliveryRoute[] = [];
  const available: PublishedDeliveryRoute[] = [];
  const offers: PublishedDeliveryRoute[] = [];
  for (const request of requests) {
    if (companySlug && request.slug !== companySlug) continue;
    const assignment = assignments[request.requestKey];
    if (!assignment?.published) continue;
    const route = { ...request, assignment };
    if (assignment.driverId === driverId && assignment.confirmed) {
      assigned.push(route);
    } else if (request.status !== "ENTREGADO" && !assignment.driverId && !assignment.confirmed) {
      if (assignment.offers?.some((offer) => offer.driverId === driverId)) offers.push(route);
      else available.push(route);
    }
  }
  return { assigned, available, offers };
}

const demoDeliveryRequests: DeliveryRequest[] = [
  {
    requestKey: deliveryRequestKey("demo", "WEB-GYE-001"),
    orderId: "WEB-GYE-001",
    slug: "demo",
    companyName: "Empresa Demo",
    date: "2026-11-16T10:35:00-05:00",
    customer: "María Demo · maria@demo.local",
    items: [
      { productId: "demo-cafe", name: "Café molido", quantity: 2, unitPrice: 5.5 },
      { productId: "demo-galletas", name: "Galletas artesanales", quantity: 1, unitPrice: 7.5 },
    ],
    total: 18.5,
    status: "PENDIENTE",
    fulfillment: {
      method: "DELIVERY",
      sector: "Alborada",
      direccion: "Av. Rodolfo Baquerizo Nazur 402",
      ciudad: "Guayaquil",
      referencia: "Junto al parque",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo", "WEB-GYE-002"),
    orderId: "WEB-GYE-002",
    slug: "demo",
    companyName: "Empresa Demo",
    date: "2026-11-16T12:10:00-05:00",
    customer: "Carlos Demo · carlos@demo.local",
    items: [{ productId: "demo-canasta", name: "Canasta familiar", quantity: 1, unitPrice: 32 }],
    total: 32,
    status: "ACEPTADO",
    fulfillment: {
      method: "DELIVERY",
      sector: "Urdesa",
      direccion: "Circunvalación Sur 118",
      ciudad: "Guayaquil",
      referencia: "Casa de dos pisos",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo", "WEB-GYE-003"),
    orderId: "WEB-GYE-003",
    slug: "demo",
    companyName: "Empresa Demo",
    date: "2026-11-17T09:20:00-05:00",
    customer: "Ana Demo · ana@demo.local",
    items: [{ productId: "demo-almuerzo", name: "Almuerzo ejecutivo", quantity: 3, unitPrice: 9 }],
    total: 27,
    status: "PENDIENTE",
    fulfillment: {
      method: "DELIVERY",
      sector: "Centro",
      direccion: "Chile y Luque",
      ciudad: "Guayaquil",
      referencia: "Edificio esquinero",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo-cafe", "CAFE-GYE-001"),
    orderId: "CAFE-GYE-001",
    slug: "demo-cafe",
    companyName: "Café del Estero",
    date: "2026-11-17T10:00:00-05:00",
    customer: "Cliente de demostración",
    items: [{ productId: "cafe-alfajores", name: "Caja de alfajores", quantity: 1, unitPrice: 9.5 }],
    total: 9.5,
    status: "ACEPTADO",
    fulfillment: {
      method: "DELIVERY",
      sector: "Urdesa",
      direccion: "Dirección de demostración",
      ciudad: "Guayaquil",
      referencia: "Entrega de ejemplo",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo-market", "MARKET-GYE-001"),
    orderId: "MARKET-GYE-001",
    slug: "demo-market",
    companyName: "Casa Verde Market",
    date: "2026-11-17T10:15:00-05:00",
    customer: "Cliente de demostración",
    items: [{ productId: "market-canasto", name: "Canasto tejido", quantity: 1, unitPrice: 24 }],
    total: 24,
    status: "ACEPTADO",
    fulfillment: {
      method: "DELIVERY",
      sector: "Kennedy",
      direccion: "Dirección de demostración",
      ciudad: "Guayaquil",
      referencia: "Entrega de ejemplo",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo-servicios", "SERVICIOS-GYE-001"),
    orderId: "SERVICIOS-GYE-001",
    slug: "demo-servicios",
    companyName: "Estudio Andino",
    date: "2026-11-17T10:30:00-05:00",
    customer: "Cliente de demostración",
    items: [{ productId: "servicios-material", name: "Material de presentación", quantity: 1, unitPrice: 0 }],
    total: 0,
    status: "ACEPTADO",
    fulfillment: {
      method: "DELIVERY",
      sector: "Centro",
      direccion: "Dirección de demostración",
      ciudad: "Guayaquil",
      referencia: "Entrega de ejemplo",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo", "WEB-GYE-004"),
    orderId: "WEB-GYE-004",
    slug: "demo",
    companyName: "Empresa Demo",
    date: "2026-11-17T11:00:00-05:00",
    customer: "Cliente de demostración",
    items: [{ productId: "demo-cafe", name: "Café molido", quantity: 1, unitPrice: 5.5 }],
    total: 5.5,
    status: "ACEPTADO",
    fulfillment: {
      method: "DELIVERY",
      sector: "Samanes",
      direccion: "Dirección de demostración",
      ciudad: "Guayaquil",
      referencia: "Entrega de ejemplo",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo-cafe", "CAFE-GYE-002"),
    orderId: "CAFE-GYE-002",
    slug: "demo-cafe",
    companyName: "Café del Estero",
    date: "2026-11-17T11:15:00-05:00",
    customer: "Cliente de demostración",
    items: [{ productId: "cafe-tostada", name: "Tostada de masa madre", quantity: 2, unitPrice: 6.75 }],
    total: 13.5,
    status: "ACEPTADO",
    fulfillment: {
      method: "DELIVERY",
      sector: "Alborada",
      direccion: "Dirección de demostración",
      ciudad: "Guayaquil",
      referencia: "Entrega de ejemplo",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo-market", "MARKET-GYE-002"),
    orderId: "MARKET-GYE-002",
    slug: "demo-market",
    companyName: "Casa Verde Market",
    date: "2026-11-17T11:30:00-05:00",
    customer: "Cliente de demostración",
    items: [{ productId: "market-manta", name: "Manta de algodón", quantity: 1, unitPrice: 42.5 }],
    total: 42.5,
    status: "ACEPTADO",
    fulfillment: {
      method: "DELIVERY",
      sector: "Ceibos",
      direccion: "Dirección de demostración",
      ciudad: "Guayaquil",
      referencia: "Entrega de ejemplo",
    },
    isDemo: true,
  },
  {
    requestKey: deliveryRequestKey("demo-servicios", "SERVICIOS-GYE-002"),
    orderId: "SERVICIOS-GYE-002",
    slug: "demo-servicios",
    companyName: "Estudio Andino",
    date: "2026-11-17T11:45:00-05:00",
    customer: "Cliente de demostración",
    items: [{ productId: "servicios-documentos", name: "Documentos del proyecto", quantity: 1, unitPrice: 0 }],
    total: 0,
    status: "ACEPTADO",
    fulfillment: {
      method: "DELIVERY",
      sector: "Kennedy",
      direccion: "Dirección de demostración",
      ciudad: "Guayaquil",
      referencia: "Entrega de ejemplo",
    },
    isDemo: true,
  },
];

const availableDemoIds: Record<string, string> = {
  "WEB-GYE-001": "WEB-GYE-006",
  "WEB-GYE-002": "WEB-GYE-007",
  "WEB-GYE-004": "WEB-GYE-005",
  "CAFE-GYE-002": "CAFE-GYE-003",
  "MARKET-GYE-002": "MARKET-GYE-003",
  "SERVICIOS-GYE-002": "SERVICIOS-GYE-003",
};

const availableDemoRequests = demoDeliveryRequests.flatMap((request) => {
  const orderId = availableDemoIds[request.orderId];
  return orderId ? [{ ...request, orderId, requestKey: deliveryRequestKey(request.slug, orderId) }] : [];
});

const demoPortalTemplates = ["demo", "demo-cafe", "demo-market", "demo-servicios"].map((slug) => {
  const template = demoDeliveryRequests.find((request) => request.slug === slug);
  if (!template) throw new Error(`No se encontró el pedido base de demostración para ${slug}.`);
  return template;
});

const demoPortalRequests: DeliveryRequest[] = demoPortalTemplates.flatMap((template, companyIndex) =>
  [1, 2, 3].map((routeIndex) => {
    const orderId = `${template.orderId.split("-").slice(0, 2).join("-")}-TEST-${companyIndex + 1}${routeIndex}`;
    const sectors = ["Alborada", "Urdesa", "Centro"];
    return {
      ...template,
      requestKey: deliveryRequestKey(template.slug, orderId),
      orderId,
      date: `2026-11-19T${String(10 + routeIndex).padStart(2, "0")}:00:00-05:00`,
      customer: `Cliente de prueba ${routeIndex} · cliente${routeIndex}@demo.local`,
      status: "PENDIENTE",
      fulfillment: {
        ...template.fulfillment,
        sector: sectors[routeIndex - 1],
        direccion: `Dirección de prueba ${routeIndex}`,
        referencia: "Ruta de prueba para recibir ofertas",
      },
      isDemo: true,
      offerRequired: true,
    };
  }),
);

export function deliveryRequestKey(slug: string, orderId: string): string {
  return `${encodeURIComponent(slug)}::${encodeURIComponent(orderId)}`;
}

function demoAssignments(): Record<string, DeliveryAssignment> {
  return {
    [deliveryRequestKey("demo", "WEB-GYE-001")]: {
      driverId: "demo-delivery-1",
      confirmed: true,
      published: true,
      priceCents: 350,
      priceSource: "company",
    },
    ...Object.fromEntries(demoDeliveryRequests
      .filter((request) => request.slug !== "demo" || request.orderId === "WEB-GYE-004")
      .map((request) => [
        request.requestKey,
        { driverId: "demo-delivery-1", confirmed: true, published: true, priceCents: 400, priceSource: "company" },
      ])),
    ...Object.fromEntries([...availableDemoRequests, ...demoPortalRequests].map((request) => [
      request.requestKey,
      { driverId: "", confirmed: false, published: true },
    ])),
  };
}

function parseAssignments(parsed: unknown): Record<string, DeliveryAssignment> {
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw new Error("Las asignaciones de Deliveries tienen un formato inválido.");
  }

  const assignments: Record<string, DeliveryAssignment> = {};
  for (const [requestKey, value] of Object.entries(parsed)) {
    if (!requestKey) {
      throw new Error("Las asignaciones de Deliveries tienen un formato inválido.");
    }
    if (typeof value === "string" && value) {
      assignments[requestKey] = { driverId: value, confirmed: false, published: false };
      continue;
    }
    if (
      typeof value !== "object" ||
      value === null ||
      !("driverId" in value) ||
      typeof value.driverId !== "string" ||
      !("confirmed" in value) ||
      typeof value.confirmed !== "boolean" ||
      (value.confirmed && !value.driverId) ||
      !("published" in value) ||
      typeof value.published !== "boolean"
    ) {
      throw new Error("Las asignaciones de Deliveries tienen un formato inválido.");
    }
    if (
      (value.priceCents !== undefined && !isValidPrice(value.priceCents)) ||
      (value.priceSource !== undefined && value.priceSource !== "company" && value.priceSource !== "driver") ||
      ((value.priceCents === undefined) !== (value.priceSource === undefined)) ||
      (value.customerAccepted !== undefined && typeof value.customerAccepted !== "boolean")
    ) throw new Error("Los valores de envío tienen un formato inválido.");
    if (value.offer !== undefined && value.offers !== undefined) throw new Error("Las ofertas de envío tienen un formato inválido.");
    const rawOffers: unknown = value.offer !== undefined ? [value.offer] : value.offers ?? [];
    if (!Array.isArray(rawOffers) || (rawOffers.length > 0 && (value.driverId || !value.published || value.confirmed))) {
      throw new Error("Las ofertas de envío tienen un formato inválido.");
    }
    const offers: DeliveryOffer[] = rawOffers.map((offer: unknown) => {
      if (typeof offer !== "object" || offer === null || !("driverId" in offer) ||
        typeof offer.driverId !== "string" || !offer.driverId || !("priceCents" in offer) ||
        !isValidPrice(offer.priceCents) || ("id" in offer && (typeof offer.id !== "string" || !offer.id))) {
        throw new Error("Las ofertas de envío tienen un formato inválido.");
      }
      if (!("id" in offer) && value.offer === undefined) throw new Error("La oferta no tiene un identificador válido.");
      return { id: "id" in offer ? offer.id as string : `legacy:${offer.driverId}`, driverId: offer.driverId, priceCents: offer.priceCents };
    });
    if (new Set(offers.map((offer) => offer.driverId)).size !== offers.length ||
      new Set(offers.map((offer) => offer.id)).size !== offers.length) {
      throw new Error("Las ofertas de envío contienen repartidores o identificadores duplicados.");
    }
    assignments[requestKey] = {
      driverId: value.driverId,
      confirmed: value.confirmed,
      published: value.published,
      ...(value.priceCents !== undefined ? { priceCents: value.priceCents as number, priceSource: value.priceSource as "company" | "driver" } : {}),
      ...(offers.length ? { offers } : {}),
      ...(value.customerAccepted === true ? { customerAccepted: true } : {}),
    };
  }
  return assignments;
}

function isValidPrice(value: unknown): value is number {
  return typeof value === "number" && Number.isSafeInteger(value) && value >= 0 && value <= 100000000;
}

export function parseDeliveryPrice(value: string): number {
  const text = value.trim();
  if (!/^\d+(?:[.,]\d{1,2})?$/.test(text)) throw new Error("Ingresa un valor de envío válido con hasta dos decimales.");
  const cents = Math.round(Number(text.replace(",", ".")) * 100);
  if (!isValidPrice(cents)) throw new Error("El valor de envío excede el máximo permitido.");
  return cents;
}

export function formatDeliveryPrice(cents: number): string {
  return new Intl.NumberFormat("es-EC", { style: "currency", currency: "USD" }).format(cents / 100);
}

export function readDeliveryAssignments(): Record<string, DeliveryAssignment> {
  const saved = window.localStorage.getItem(ASSIGNMENTS_KEY);
  if (saved !== null) return { ...demoAssignments(), ...parseAssignments(JSON.parse(saved)) };

  const legacy = window.localStorage.getItem(LEGACY_ASSIGNMENTS_KEY);
  if (legacy === null) return demoAssignments();
  return { ...demoAssignments(), ...parseAssignments(JSON.parse(legacy)) };
}

function saveDeliveryAssignments(assignments: Record<string, DeliveryAssignment>): void {
  window.localStorage.setItem(ASSIGNMENTS_KEY, JSON.stringify(assignments));
  window.dispatchEvent(new Event("delivery-assignments-updated"));
}

async function withAssignmentLock<T>(action: () => T): Promise<T> {
  if (!navigator.locks) {
    throw new Error("Este navegador no permite asignar rutas de forma segura. Usa un navegador compatible y una conexión segura.");
  }
  return navigator.locks.request(ASSIGNMENTS_LOCK, { mode: "exclusive" }, action);
}

export async function updateDeliveryAssignment(
  requestKey: string,
  expected: DeliveryAssignment,
  next: DeliveryAssignment,
): Promise<void> {
  await withAssignmentLock(() => {
    const assignments = readDeliveryAssignments();
    const current = assignments[requestKey] ?? { driverId: "", confirmed: false, published: false };
    if (JSON.stringify(current) !== JSON.stringify(expected)) {
      throw new Error("La asignación cambió. Actualiza la lista antes de volver a intentarlo.");
    }
    if (current.offers?.length) throw new Error("El cliente debe responder las ofertas pendientes antes de modificar la asignación.");
    if (current.customerAccepted && current.driverId !== next.driverId) throw new Error("No se puede cambiar el repartidor de una oferta aceptada.");
    if (next.driverId && current.driverId !== next.driverId) {
      const request = readDeliveryRequests().requests.find((candidate) => candidate.requestKey === requestKey);
      const driver = readDeliveryDrivers().find((candidate) => candidate.id === next.driverId);
      if (!request || !driver?.companySlugs?.includes(request.slug)) {
        throw new Error("El repartidor externo debe presentar una oferta desde el portal para que el cliente la acepte.");
      }
    }
    const request = readDeliveryRequests().requests.find((candidate) => candidate.requestKey === requestKey);
    if (request && (current.driverId !== next.driverId || current.confirmed !== next.confirmed || current.published !== next.published)) {
      if (request.status === "ENTREGADO") {
        throw new Error("No se puede modificar la asignación de un pedido entregado.");
      }
      const tracking = readDeliveryTracking(request.slug, request.orderId);
      if (tracking && tracking.endedAt === null) {
        throw new Error("Finaliza la ruta en el portal del repartidor antes de modificar su asignación o publicación.");
      }
    }
    saveDeliveryAssignments({ ...assignments, [requestKey]: next });
  });
}

export async function startAssignedDeliveryTracking(
  companySlug: string,
  requestKey: string,
  driverId: string,
): Promise<DeliveryTracking> {
  return withAssignmentLock(() => {
    const assignments = readDeliveryAssignments();
    const requests = readDeliveryRequests().requests;
    const route = requests.find((request) => request.requestKey === requestKey && request.slug === companySlug);
    const assignment = assignments[requestKey];
    if (!route || !assignment?.published || !assignment.confirmed || assignment.driverId !== driverId) {
      throw new Error("La ruta ya no está publicada para tu cuenta. Actualiza la lista.");
    }
    if (route.status === "ENTREGADO") throw new Error("Este pedido ya fue entregado.");
    const existing = readDeliveryTracking(route.slug, route.orderId);
    if (existing && existing.endedAt === null && existing.driverId !== driverId) {
      throw new Error("Otro repartidor ya inició el seguimiento de este pedido.");
    }
    for (const other of requests) {
      if (other.requestKey === requestKey) continue;
      const tracking = readDeliveryTracking(other.slug, other.orderId);
      if (tracking && tracking.endedAt === null && tracking.driverId === driverId) {
        throw new Error(`Finaliza la ruta ${other.orderId} con su foto antes de iniciar otra.`);
      }
    }
    return startDeliveryTracking(route.slug, route.orderId, driverId);
  });
}

export async function finishAssignedDeliveryTracking(tracking: DeliveryTracking, driverId: string, proofPhoto: string, verificationCode: string): Promise<void> {
  await withAssignmentLock(() => {
    const key = deliveryRequestKey(tracking.slug, tracking.orderId);
    const request = readDeliveryRequests().requests.find((candidate) => candidate.requestKey === key);
    const assignment = readDeliveryAssignments()[key];
    if (!request || !assignment?.published || !assignment.confirmed || assignment.driverId !== driverId) {
      throw new Error("La ruta ya no está publicada para tu cuenta.");
    }
    const current = readDeliveryTracking(tracking.slug, tracking.orderId);
    if (!current || current.startedAt !== tracking.startedAt) {
      throw new Error("La ruta cambió. Actualiza la lista antes de confirmar la entrega.");
    }
    const effectiveCode = request.isDemo && verificationCode === DEMO_DELIVERY_CODE
      ? current.verificationCode
      : verificationCode;
    if (!effectiveCode) throw new Error("El código de verificación no está disponible. Actualiza la ruta.");
    finishDeliveryTracking(tracking.slug, tracking.orderId, driverId, proofPhoto, effectiveCode);
  });
}

export async function claimDeliveryRequest(companySlug: string, requestKey: string, driverId: string, priceCents: number): Promise<"assigned" | "offered"> {
  return withAssignmentLock(() => {
    const request = readDeliveryRequests().requests.find((candidate) =>
      candidate.requestKey === requestKey && candidate.slug === companySlug,
    );
    const driver = readDeliveryDrivers().find((candidate) => candidate.id === driverId && candidate.estado === "ACTIVO");
    const assignments = readDeliveryAssignments();
    const current = assignments[requestKey];
    if (!request || request.status === "ENTREGADO" || !driver || !current?.published || current.driverId || current.confirmed) {
      throw new Error("La ruta ya no está disponible para asignación. Actualiza la lista.");
    }
    if (!isValidPrice(priceCents)) throw new Error("Ingresa un valor de envío válido.");
    const effectivePrice = current.priceSource === "company" ? current.priceCents! : priceCents;
    if (request.offerRequired || !driver.companySlugs?.includes(companySlug)) {
      if (current.offers?.some((offer) => offer.driverId === driverId)) throw new Error("Ya tienes una oferta pendiente para esta ruta.");
      const offer = { id: crypto.randomUUID(), driverId, priceCents: effectivePrice };
      saveDeliveryAssignments({ ...assignments, [requestKey]: { ...current, offers: [...(current.offers ?? []), offer] } });
      return "offered";
    }
    saveDeliveryAssignments({
      ...assignments,
      [requestKey]: { ...current, offers: undefined, driverId, confirmed: true, priceCents: effectivePrice, priceSource: current.priceSource === "company" ? "company" : "driver" },
    });
    return "assigned";
  });
}

export async function respondDeliveryOffer(companySlug: string, requestKey: string, expected: DeliveryOffer, accept: boolean): Promise<void> {
  await withAssignmentLock(() => {
    const assignments = readDeliveryAssignments();
    const current = assignments[requestKey];
    const request = readDeliveryRequests().requests.find((candidate) => candidate.requestKey === requestKey && candidate.slug === companySlug);
    const offer = current?.offers?.find((item) => item.id === expected.id && item.driverId === expected.driverId && item.priceCents === expected.priceCents);
    if (!request || request.status === "ENTREGADO" || !current?.published || current.driverId || !offer) {
      throw new Error("La oferta ya no está disponible. Actualiza el pedido.");
    }
    const { offers, ...remaining } = current;
    if (accept) {
      const driver = readDeliveryDrivers().find((candidate) => candidate.id === offer.driverId && candidate.estado === "ACTIVO");
      if (!driver) throw new Error("El repartidor ya no está disponible. Rechaza su oferta.");
      saveDeliveryAssignments({ ...assignments, [requestKey]: {
        ...remaining, driverId: driver.id, confirmed: true, priceCents: expected.priceCents,
        priceSource: current.priceSource === "company" ? "company" : "driver", customerAccepted: true,
      } });
    } else {
      const otherOffers = offers?.filter((item) => item.id !== offer.id) ?? [];
      saveDeliveryAssignments({ ...assignments, [requestKey]: { ...remaining, ...(otherOffers.length ? { offers: otherOffers } : {}) } });
    }
  });
}

export async function setDeliveryPrice(requestKey: string, priceCents: number, source: "company" | "driver", driverId?: string): Promise<void> {
  await withAssignmentLock(() => {
    if (!isValidPrice(priceCents)) throw new Error("Ingresa un valor de envío válido.");
    const assignments = readDeliveryAssignments();
    const current = assignments[requestKey] ?? { driverId: "", confirmed: false, published: false };
    const request = readDeliveryRequests().requests.find((candidate) => candidate.requestKey === requestKey);
    if (!request || request.status === "ENTREGADO") throw new Error("No se puede modificar el valor de este pedido.");
    if (current.offers?.length || current.customerAccepted) throw new Error("No se puede cambiar el valor de una oferta pendiente o aceptada.");
    const tracking = readDeliveryTracking(request.slug, request.orderId);
    if (tracking && tracking.endedAt === null) throw new Error("No se puede cambiar el valor durante una ruta activa.");
    if (source === "driver" && (!driverId || current.driverId !== driverId || !current.confirmed || !current.published)) {
      throw new Error("La ruta no está asignada a tu cuenta.");
    }
    if (source === "driver" && current.priceSource === "company") throw new Error("La empresa ya estableció el valor de envío.");
    saveDeliveryAssignments({ ...assignments, [requestKey]: { ...current, priceCents, priceSource: source } });
  });
}

export function readDeliveryRequests(): { requests: DeliveryRequest[]; usingDemo: boolean } {
  const localOrders = readAllCustomerDeliveryOrders();
  const localKeys = new Set(localOrders.map(({ slug, order }) => deliveryRequestKey(slug, order.id)));
  const demoRequests = [...demoDeliveryRequests, ...availableDemoRequests, ...demoPortalRequests]
    .filter((request) => !localKeys.has(request.requestKey));
  return {
    usingDemo: demoRequests.length > 0,
    requests: [...demoRequests, ...localOrders.map(({ slug, order }) => {
      const fulfillment = order.fulfillment;
      if (fulfillment?.method !== "DELIVERY") {
        throw new Error("El historial de pedidos cambió mientras se consultaban las entregas.");
      }
      return {
        requestKey: deliveryRequestKey(slug, order.id),
        orderId: order.id,
        slug,
        companyName: slug,
        date: order.date,
        customer: order.customerEmail || "Cliente web",
        items: order.items,
        total: order.total,
        status: order.status,
        fulfillment,
        isDemo: false,
      };
    })].map((request) => {
      const proofPhoto = readDeliveryTracking(request.slug, request.orderId)?.proofPhoto;
      return { ...request, status: proofPhoto ? "ENTREGADO" : request.status, proofPhoto };
    }),
  };
}
