export type DeliveryStatus = "ACTIVO" | "INACTIVO";
export type DeliveryVehicleType = "Motocicleta" | "Automóvil" | "Camioneta" | "Furgoneta" | "Otro";

export interface DeliveryDriver {
  id: string;
  nombre: string;
  identificacion: string;
  telefono: string;
  foto: string;
  estado: DeliveryStatus;
  tipoVehiculo: DeliveryVehicleType;
  marca: string;
  modelo: string;
  placa: string;
  color: string;
  licencia: string;
  licenciaVence: string;
  accountEmail?: string;
  companySlugs?: string[];
}

const STORAGE_KEY = "ventas:deliveries:v1";
const DEMO_MIGRATION_KEY = "ventas:deliveries:offer-demo-seeded:v1";

const demoDrivers: DeliveryDriver[] = [
  {
    id: "demo-delivery-1",
    nombre: "Repartidor de muestra",
    identificacion: "0000000000",
    telefono: "0990000000",
    foto: "",
    estado: "ACTIVO",
    tipoVehiculo: "Motocicleta",
    marca: "Ejemplo",
    modelo: "Urbana",
    placa: "DEMO-001",
    color: "Negro",
    licencia: "LIC-DEMO-001",
    licenciaVence: "2030-12-31",
    accountEmail: "delivery@glm.local",
    companySlugs: ["demo", "demo-cafe", "demo-market", "demo-servicios"],
  },
  {
    id: "demo-delivery-2", nombre: "Repartidor externo 1", identificacion: "DEMO-002",
    telefono: "0990000002", foto: "", estado: "ACTIVO", tipoVehiculo: "Motocicleta",
    marca: "Ejemplo", modelo: "Urbana", placa: "DEMO-002", color: "Azul",
    licencia: "LIC-DEMO-002", licenciaVence: "2030-12-31", accountEmail: "delivery2@glm.local", companySlugs: [],
  },
  {
    id: "demo-delivery-3", nombre: "Repartidor externo 2", identificacion: "DEMO-003",
    telefono: "0990000003", foto: "", estado: "ACTIVO", tipoVehiculo: "Motocicleta",
    marca: "Ejemplo", modelo: "Urbana", placa: "DEMO-003", color: "Rojo",
    licencia: "LIC-DEMO-003", licenciaVence: "2030-12-31", accountEmail: "delivery3@glm.local", companySlugs: [],
  },
];

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function parseDeliveryDriver(value: unknown): DeliveryDriver {
  if (
    !isRecord(value) ||
    typeof value.id !== "string" ||
    typeof value.nombre !== "string" ||
    typeof value.identificacion !== "string" ||
    typeof value.telefono !== "string" ||
    typeof value.foto !== "string" ||
    (value.estado !== "ACTIVO" && value.estado !== "INACTIVO") ||
    (value.tipoVehiculo !== "Motocicleta" &&
      value.tipoVehiculo !== "Automóvil" &&
      value.tipoVehiculo !== "Camioneta" &&
      value.tipoVehiculo !== "Furgoneta" &&
      value.tipoVehiculo !== "Otro") ||
    typeof value.marca !== "string" ||
    typeof value.modelo !== "string" ||
    typeof value.placa !== "string" ||
    typeof value.color !== "string" ||
    typeof value.licencia !== "string" ||
    typeof value.licenciaVence !== "string" ||
    (value.companySlugs !== undefined && (!Array.isArray(value.companySlugs) || !value.companySlugs.every((slug: unknown) => typeof slug === "string")))
  ) {
    throw new Error("Los datos guardados de Deliveries tienen un formato inválido.");
  }
  return {
    id: value.id,
    nombre: value.nombre,
    identificacion: value.identificacion,
    telefono: value.telefono,
    foto: value.foto,
    estado: value.estado,
    tipoVehiculo: value.tipoVehiculo,
    marca: value.marca,
    modelo: value.modelo,
    placa: value.placa,
    color: value.color,
    licencia: value.licencia,
    licenciaVence: value.licenciaVence,
    accountEmail: typeof value.accountEmail === "string"
      ? value.accountEmail
      : value.id === "demo-delivery-1" ? "delivery@glm.local" : undefined,
    companySlugs: Array.isArray(value.companySlugs)
      ? value.companySlugs
      : value.id === "demo-delivery-1" ? ["demo", "demo-cafe", "demo-market", "demo-servicios"] : [],
  };
}

export function readDeliveryDrivers(): DeliveryDriver[] {
  const saved = window.localStorage.getItem(STORAGE_KEY);
  if (saved === null) return demoDrivers.map((driver) => ({ ...driver }));
  const parsed: unknown = JSON.parse(saved);
  if (!Array.isArray(parsed)) {
    throw new Error("Los datos guardados de Deliveries no tienen un formato de lista.");
  }
  const drivers = parsed.map(parseDeliveryDriver);
  if (window.localStorage.getItem(DEMO_MIGRATION_KEY) !== "1") {
    const newDrivers = demoDrivers.slice(1).filter((driver) => !drivers.some((existing) => existing.id === driver.id));
    if (newDrivers.length) window.localStorage.setItem(STORAGE_KEY, JSON.stringify([...drivers, ...newDrivers]));
    window.localStorage.setItem(DEMO_MIGRATION_KEY, "1");
    return [...drivers, ...newDrivers];
  }
  return drivers;
}

export function saveDeliveryDrivers(drivers: DeliveryDriver[]): void {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(drivers));
  window.localStorage.setItem(DEMO_MIGRATION_KEY, "1");
  window.dispatchEvent(new Event("delivery-drivers-updated"));
}
