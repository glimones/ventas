import { AppShell } from "@/components/app-shell";
import DeliveriesPage from "./DeliveriesPage";

export default function Page() {
  return (
    <AppShell>
      <DeliveriesPage />
    </AppShell>
  );
}
