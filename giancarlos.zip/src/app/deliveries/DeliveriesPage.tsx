"use client";

import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import { CirclePlus, ImagePlus, SquarePen, Trash2, Truck, X } from "lucide-react";
import { useAccessMenu } from "@/components/access-menu-context";
import {
  readDeliveryDrivers,
  saveDeliveryDrivers,
  type DeliveryDriver,
  type DeliveryStatus,
  type DeliveryVehicleType,
} from "./deliveries-store";
import "./deliveries.css";

type DeliveryForm = Omit<DeliveryDriver, "id">;
type StatusFilter = "TODOS" | DeliveryStatus;
type EmployeeOption = {
  id: string;
  nombre: string;
  identificacion: string;
  telefono: string;
  cargo: string;
};

const demoMessagingEmployees: EmployeeOption[] = [
  { id: "demo-employee-1", nombre: "Alex Demo", identificacion: "DEMO-001", telefono: "0990000001", cargo: "Mensajería" },
  { id: "demo-employee-2", nombre: "Sam Demo", identificacion: "DEMO-002", telefono: "0990000002", cargo: "Mensajería" },
];

const emptyForm: DeliveryForm = {
  nombre: "",
  identificacion: "",
  telefono: "",
  foto: "",
  estado: "ACTIVO",
  tipoVehiculo: "Motocicleta",
  marca: "",
  modelo: "",
  placa: "",
  color: "",
  licencia: "",
  licenciaVence: "",
};

const vehicleTypes: DeliveryVehicleType[] = [
  "Motocicleta",
  "Automóvil",
  "Camioneta",
  "Furgoneta",
  "Otro",
];

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function toEmployeeOption(value: unknown): EmployeeOption | null {
  if (!isRecord(value)) return null;
  const id = typeof value.id === "number" || typeof value.id === "string" ? String(value.id) : "";
  const nombre = [value.nombres, value.apellidos]
    .filter((name): name is string => typeof name === "string")
    .map((name) => name.trim())
    .filter(Boolean)
    .join(" ");
  const cargo = typeof value.cargo === "string" ? value.cargo.trim() : "";
  if (!id || !nombre || !cargo) return null;
  return {
    id,
    nombre,
    identificacion: typeof value.identificacion === "string" ? value.identificacion : "",
    telefono: typeof value.telefono === "string" ? value.telefono : "",
    cargo,
  };
}

function hasMessagingRole(cargo: string): boolean {
  return cargo.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase().includes("mensajer");
}

async function fetchEmployeePage(page: number, signal: AbortSignal): Promise<{ data: unknown[]; totalPages: number }> {
  const response = await fetch(`/api/empleados?limit=100&page=${page}`, { cache: "no-store", signal });
  const result: unknown = await response.json();
  if (!response.ok) {
    throw new Error(isRecord(result) && typeof result.error === "string" ? result.error : "No se pudieron consultar los empleados.");
  }
  if (!isRecord(result) || !Array.isArray(result.data)) {
    throw new Error("La respuesta de empleados no tiene un formato válido.");
  }
  const pagination = isRecord(result.pagination) ? result.pagination : null;
  const totalPages = Number(pagination?.totalPages ?? 1);
  if (!Number.isSafeInteger(totalPages) || totalPages < 0 || totalPages > 1000) {
    throw new Error("La paginación de empleados no tiene un formato válido.");
  }
  return { data: result.data, totalPages: Math.max(1, totalPages) };
}

async function fetchMessagingEmployees(signal: AbortSignal): Promise<EmployeeOption[]> {
  const firstPage = await fetchEmployeePage(1, signal);
  const otherPages = await Promise.all(
    Array.from({ length: firstPage.totalPages - 1 }, (_, index) =>
      fetchEmployeePage(index + 2, signal),
    ),
  );
  return [firstPage, ...otherPages]
    .flatMap((page) => page.data)
    .map(toEmployeeOption)
    .filter((employee): employee is EmployeeOption => employee !== null && hasMessagingRole(employee.cargo));
}

export default function DeliveriesPage() {
  const { options } = useAccessMenu();
  const companyActions = options.find((option) => option.ruta === "/empresa")?.actions ?? 0;
  const actions = options.find((option) => option.ruta === "/deliveries")?.actions ?? companyActions;
  const canWrite = (actions & 2) === 2;
  const canDelete = (actions & 4) === 4;
  const [drivers, setDrivers] = useState<DeliveryDriver[]>([]);
  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("TODOS");
  const [form, setForm] = useState<DeliveryForm>(emptyForm);
  const [editId, setEditId] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [useRegisteredEmployee, setUseRegisteredEmployee] = useState(false);
  const [employeeOptions, setEmployeeOptions] = useState<EmployeeOption[]>([]);
  const [employeesLoading, setEmployeesLoading] = useState(false);
  const [employeeLoadMessage, setEmployeeLoadMessage] = useState("");
  const [employeeSource, setEmployeeSource] = useState<"database" | "demo" | null>(null);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState("");
  const [companySlugsInput, setCompanySlugsInput] = useState("");

  useEffect(() => {
    try {
      setDrivers(readDeliveryDrivers());
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "No se pudieron leer los datos de Deliveries.");
    } finally {
      setReady(true);
    }
  }, []);

  useEffect(() => {
    if (!dialogOpen) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setDialogOpen(false);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [dialogOpen]);

  useEffect(() => {
    if (!dialogOpen || !useRegisteredEmployee) return;
    const controller = new AbortController();
    setEmployeesLoading(true);
    setEmployeeOptions([]);
    setEmployeeLoadMessage("");
    setEmployeeSource(null);

    void fetchMessagingEmployees(controller.signal)
      .then((employees) => {
        if (controller.signal.aborted) return;
        setEmployeeOptions(employees);
        setEmployeeSource("database");
        if (employees.length === 0) setEmployeeLoadMessage("No hay empleados registrados con cargo de mensajería.");
      })
      .catch(() => {
        if (controller.signal.aborted) return;
        setEmployeeOptions(demoMessagingEmployees);
        setEmployeeSource("demo");
        setEmployeeLoadMessage("No se pudo acceder a la base de datos; se muestran empleados de demostración.");
      })
      .finally(() => {
        if (!controller.signal.aborted) setEmployeesLoading(false);
      });

    return () => controller.abort();
  }, [dialogOpen, useRegisteredEmployee]);

  const filteredDrivers = useMemo(() => {
    const search = query.trim().toLocaleLowerCase();
    return drivers.filter((driver) => {
      const matchesSearch = !search || [
        driver.nombre,
        driver.identificacion,
        driver.telefono,
        driver.tipoVehiculo,
        driver.marca,
        driver.modelo,
        driver.placa,
        driver.licencia,
        driver.accountEmail ?? "",
      ].join(" ").toLocaleLowerCase().includes(search);
      return matchesSearch && (statusFilter === "TODOS" || driver.estado === statusFilter);
    });
  }, [drivers, query, statusFilter]);
  const activeCount = drivers.filter((driver) => driver.estado === "ACTIVO").length;
  const inactiveCount = drivers.length - activeCount;

  function openCreate() {
    setEditId(null);
    setForm({ ...emptyForm });
    setCompanySlugsInput("");
    setUseRegisteredEmployee(false);
    setSelectedEmployeeId("");
    setError("");
    setNotice("");
    setDialogOpen(true);
  }

  function openEdit(driver: DeliveryDriver) {
    const { id: currentId, ...values } = driver;
    setEditId(currentId);
    setForm(values);
    setCompanySlugsInput((values.companySlugs ?? []).join(", "));
    setUseRegisteredEmployee(false);
    setSelectedEmployeeId("");
    setError("");
    setNotice("");
    setDialogOpen(true);
  }

  function handleEmployeeSelection(employeeId: string) {
    setSelectedEmployeeId(employeeId);
    const employee = employeeOptions.find((option) => option.id === employeeId);
    if (!employee) return;
    setForm((current) => ({
      ...current,
      nombre: employee.nombre,
      identificacion: employee.identificacion,
      telefono: employee.telefono,
    }));
    setError("");
  }

  function handlePhotoChange(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setError("La foto debe estar en formato JPG, PNG o WebP.");
      event.target.value = "";
      return;
    }
    if (file.size > 1024 * 1024) {
      setError("La foto no puede superar 1 MB para guardarse en el almacenamiento local de demostración.");
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result;
      if (typeof result !== "string") {
        setError("No se pudo leer la foto seleccionada.");
        return;
      }
      setForm((current) => ({ ...current, foto: result }));
      setError("");
    };
    reader.onerror = () => setError("No se pudo leer la foto seleccionada.");
    reader.readAsDataURL(file);
  }

  function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!form.foto && editId === null) {
      setError("Agrega una foto de la persona antes de guardar.");
      return;
    }

    const driver: DeliveryDriver = {
      ...form,
      nombre: form.nombre.trim(),
      identificacion: form.identificacion.trim(),
      telefono: form.telefono.trim(),
      marca: form.marca.trim(),
      modelo: form.modelo.trim(),
      placa: form.placa.trim().toLocaleUpperCase(),
      color: form.color.trim(),
      licencia: form.licencia.trim(),
      companySlugs: [...new Set(companySlugsInput.split(",").map((slug) => slug.trim().toLocaleLowerCase()).filter(Boolean))],
      id: editId ?? `delivery-${Date.now()}`,
    };
    const nextDrivers = editId === null
      ? [driver, ...drivers]
      : drivers.map((current) => current.id === editId ? driver : current);

    try {
      saveDeliveryDrivers(nextDrivers);
      setDrivers(nextDrivers);
      setDialogOpen(false);
      setError("");
      setNotice(editId === null ? "Repartidor agregado en este navegador." : "Datos del repartidor actualizados.");
    } catch {
      setError("No se pudieron guardar los datos en este navegador. Revisa el espacio disponible.");
    }
  }

  function deleteDriver(driver: DeliveryDriver) {
    if (!canDelete || !window.confirm(`¿Eliminar a ${driver.nombre} de la lista local de Deliveries?`)) return;
    const nextDrivers = drivers.filter((current) => current.id !== driver.id);
    try {
      saveDeliveryDrivers(nextDrivers);
      setDrivers(nextDrivers);
      setNotice("Repartidor eliminado de este navegador.");
      setError("");
    } catch {
      setError("No se pudo actualizar la lista local de Deliveries.");
    }
  }

  return (
    <div className="deliveries-page">
      <header className="deliveries-header">
        <div>
          <span className="deliveries-eyebrow"><Truck size={15} /> ORGANIZACIÓN</span>
          <h1>Deliveries</h1>
          <p>Administra a las personas repartidoras, su vehículo asignado y la licencia.</p>
        </div>
        {canWrite && (
          <button type="button" className="deliveries-primary-button" onClick={openCreate}>
            <CirclePlus size={17} /> Agregar persona
          </button>
        )}
      </header>

      <p className="deliveries-demo-note">Prototipo local: los cambios y las fotos se guardan únicamente en este navegador.</p>
      {error && !dialogOpen && <div className="deliveries-alert" role="alert">{error}</div>}
      {notice && <div className="deliveries-notice" role="status">{notice}</div>}

      <section className="deliveries-summary" aria-label="Resumen de repartidores">
        <button type="button" className={statusFilter === "TODOS" ? "is-selected" : ""} onClick={() => setStatusFilter("TODOS")}>
          <span>Total personas</span><strong>{ready ? drivers.length : "—"}</strong>
        </button>
        <button type="button" className={statusFilter === "ACTIVO" ? "is-selected" : ""} onClick={() => setStatusFilter("ACTIVO")}>
          <span>Activas</span><strong>{ready ? activeCount : "—"}</strong>
        </button>
        <button type="button" className={statusFilter === "INACTIVO" ? "is-selected" : ""} onClick={() => setStatusFilter("INACTIVO")}>
          <span>Inactivas</span><strong>{ready ? inactiveCount : "—"}</strong>
        </button>
      </section>

      <section className="deliveries-card">
        <div className="deliveries-toolbar">
          <div>
            <h2>Personas y vehículos</h2>
            <p>{filteredDrivers.length} resultado{filteredDrivers.length === 1 ? "" : "s"}</p>
          </div>
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar por nombre, placa o licencia..."
            aria-label="Buscar repartidores"
          />
        </div>

        <div className="deliveries-table-wrap">
          <table className="deliveries-table">
            <thead>
              <tr>
                <th scope="col">Persona</th>
                <th scope="col">Contacto</th>
                <th scope="col">Vehículo asignado</th>
                <th scope="col">Licencia</th>
                <th scope="col">Cuenta del portal</th>
                <th scope="col">Estado</th>
                {(canWrite || canDelete) && <th scope="col">Acciones</th>}
              </tr>
            </thead>
            <tbody>
              {!ready ? (
                <tr><td colSpan={canWrite || canDelete ? 7 : 6} className="deliveries-empty">Cargando datos locales...</td></tr>
              ) : filteredDrivers.length === 0 ? (
                <tr><td colSpan={canWrite || canDelete ? 7 : 6} className="deliveries-empty">No hay personas que coincidan con los filtros.</td></tr>
              ) : filteredDrivers.map((driver) => (
                <tr key={driver.id}>
                  <td>
                    <div className="deliveries-person">
                      {driver.foto
                        ? <img src={driver.foto} alt={`Foto de ${driver.nombre}`} />
                        : <span aria-hidden="true">{driver.nombre.slice(0, 1).toLocaleUpperCase()}</span>}
                      <div><strong>{driver.nombre}</strong><small>{driver.identificacion}</small></div>
                    </div>
                  </td>
                  <td>{driver.telefono}</td>
                  <td>
                    <strong>{driver.tipoVehiculo} · {driver.marca} {driver.modelo}</strong>
                    <small className="deliveries-table-subline">{driver.placa} · {driver.color}</small>
                  </td>
                  <td>{driver.licencia}<small className="deliveries-table-subline">Vence {driver.licenciaVence}</small></td>
                  <td>{driver.accountEmail ?? "Sin cuenta vinculada"}{driver.accountEmail === "delivery@glm.local" && <small className="deliveries-table-subline">Acceso demo al portal</small>}</td>
                  <td><span className={`deliveries-status ${driver.estado === "ACTIVO" ? "is-active" : "is-inactive"}`}>{driver.estado === "ACTIVO" ? "Activo" : "Inactivo"}</span></td>
                  {(canWrite || canDelete) && (
                    <td className="deliveries-actions">
                      {canWrite && <button type="button" aria-label={`Editar ${driver.nombre}`} title="Editar" onClick={() => openEdit(driver)}><SquarePen size={16} /></button>}
                      {canDelete && <button type="button" aria-label={`Eliminar ${driver.nombre}`} title="Eliminar" onClick={() => deleteDriver(driver)}><Trash2 size={16} /></button>}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {dialogOpen && (
        <div className="deliveries-overlay" onMouseDown={(event) => {
          if (event.target === event.currentTarget) setDialogOpen(false);
        }}>
          <section className="deliveries-dialog" role="dialog" aria-modal="true" aria-labelledby="delivery-dialog-title">
            <header>
              <div><span>ORGANIZACIÓN</span><h2 id="delivery-dialog-title">{editId ? "Editar persona" : "Agregar persona a Deliveries"}</h2></div>
              <button type="button" aria-label="Cerrar formulario" onClick={() => setDialogOpen(false)}><X size={20} /></button>
            </header>
            {error && <div className="deliveries-alert" role="alert">{error}</div>}
            <form onSubmit={submitForm}>
              <div className="deliveries-form-section">
                <h3>Datos de la persona</h3>
                <label className="deliveries-employee-toggle">
                  <input
                    type="checkbox"
                    checked={useRegisteredEmployee}
                    onChange={(event) => {
                      setUseRegisteredEmployee(event.target.checked);
                      setSelectedEmployeeId("");
                    }}
                  />
                  <span>Seleccionar desde empleados registrados</span>
                </label>
                {useRegisteredEmployee && (
                  <div className="deliveries-employee-selector">
                    <label htmlFor="delivery-employee">Empleado con cargo de mensajería</label>
                    <select
                      id="delivery-employee"
                      value={selectedEmployeeId}
                      disabled={employeesLoading || employeeOptions.length === 0}
                      onChange={(event) => handleEmployeeSelection(event.target.value)}
                    >
                      <option value="">
                        {employeesLoading
                          ? "Cargando empleados..."
                          : employeeOptions.length > 0
                            ? "Selecciona un empleado..."
                            : "No hay empleados disponibles"}
                      </option>
                      {employeeOptions.map((employee) => (
                        <option value={employee.id} key={employee.id}>
                          {employee.nombre} · {employee.cargo}
                        </option>
                      ))}
                    </select>
                    {employeeLoadMessage && (
                      <small className={employeeSource === "demo" ? "is-demo" : ""} role="status">
                        {employeeLoadMessage}
                      </small>
                    )}
                  </div>
                )}
                <div className="deliveries-form-grid">
                  <label>Nombre completo *
                    <input value={form.nombre} onChange={(event) => setForm({ ...form, nombre: event.target.value })} required maxLength={120} />
                  </label>
                  <label>Identificación *
                    <input value={form.identificacion} onChange={(event) => setForm({ ...form, identificacion: event.target.value })} required maxLength={30} />
                  </label>
                  <label>Teléfono *
                    <input type="tel" value={form.telefono} onChange={(event) => setForm({ ...form, telefono: event.target.value })} required maxLength={30} />
                  </label>
                  <label>Estado
                    <select value={form.estado} onChange={(event) => setForm({ ...form, estado: event.target.value as DeliveryStatus })}>
                      <option value="ACTIVO">Activo</option>
                      <option value="INACTIVO">Inactivo</option>
                    </select>
                  </label>
                  <label>Empresas afiliadas
                    <input value={companySlugsInput} onChange={(event) => setCompanySlugsInput(event.target.value)} placeholder="demo, demo-cafe" />
                    <small>Slugs de los sitios, separados por comas. Vacío significa repartidor externo.</small>
                  </label>
                  <div className="deliveries-photo-field">
                    <span>Foto de la persona {!form.foto && "*"}</span>
                    <div className="deliveries-photo-control">
                      {form.foto
                        ? <img src={form.foto} alt="Vista previa de la persona repartidora" />
                        : <span><ImagePlus size={20} /> Sin foto</span>}
                      <input type="file" accept="image/png,image/jpeg,image/webp" onChange={handlePhotoChange} aria-label="Subir foto de la persona repartidora" />
                    </div>
                    <small>JPG, PNG o WebP; máximo 1 MB. Se guarda localmente.</small>
                  </div>
                </div>
              </div>

              <div className="deliveries-form-section">
                <h3>Vehículo y licencia</h3>
                <div className="deliveries-form-grid">
                  <label>Tipo de vehículo *
                    <select value={form.tipoVehiculo} onChange={(event) => setForm({ ...form, tipoVehiculo: event.target.value as DeliveryVehicleType })}>
                      {vehicleTypes.map((type) => <option value={type} key={type}>{type}</option>)}
                    </select>
                  </label>
                  <label>Marca *
                    <input value={form.marca} onChange={(event) => setForm({ ...form, marca: event.target.value })} required maxLength={60} />
                  </label>
                  <label>Modelo *
                    <input value={form.modelo} onChange={(event) => setForm({ ...form, modelo: event.target.value })} required maxLength={60} />
                  </label>
                  <label>Placa *
                    <input value={form.placa} onChange={(event) => setForm({ ...form, placa: event.target.value.toLocaleUpperCase() })} required maxLength={15} />
                  </label>
                  <label>Color *
                    <input value={form.color} onChange={(event) => setForm({ ...form, color: event.target.value })} required maxLength={40} />
                  </label>
                  <label>Número de licencia *
                    <input value={form.licencia} onChange={(event) => setForm({ ...form, licencia: event.target.value })} required maxLength={40} />
                  </label>
                  <label>Vencimiento de licencia *
                    <input type="date" value={form.licenciaVence} onChange={(event) => setForm({ ...form, licenciaVence: event.target.value })} required />
                  </label>
                </div>
              </div>

              <footer>
                <button type="button" className="deliveries-secondary-button" onClick={() => setDialogOpen(false)}>Cancelar</button>
                <button type="submit" className="deliveries-primary-button">{editId ? "Guardar cambios" : "Agregar persona"}</button>
              </footer>
            </form>
          </section>
        </div>
      )}
    </div>
  );
}
