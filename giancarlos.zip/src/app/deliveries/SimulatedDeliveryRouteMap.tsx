"use client";

import { useEffect, useMemo, useState } from "react";
import type { LatLngTuple } from "leaflet";
import { CircleMarker, MapContainer, Polyline, TileLayer, Tooltip, useMap } from "react-leaflet";
import { getGuayaquilSectorCoordinates, GUAYAQUIL_HUB } from "./guayaquil-sectors";
import { createOsrmRouteUrl, parseOsrmRoute, positionAlongRoute } from "./delivery-road-route";
import { getTrackingProgress, type DeliveryTracking } from "./delivery-tracking-store";
import "./deliveries.css";

function FitRouteBounds({ coordinates }: { coordinates: LatLngTuple[] }) {
  const map = useMap();
  useEffect(() => {
    if (coordinates.length > 1) map.fitBounds(coordinates, { padding: [40, 40], maxZoom: 14 });
  }, [coordinates, map]);
  return null;
}

export default function SimulatedDeliveryRouteMap({
  tracking,
  sector,
}: {
  tracking: DeliveryTracking;
  sector?: string;
}) {
  const [now, setNow] = useState(() => Date.now());
  const [tilesUnavailable, setTilesUnavailable] = useState(false);
  const [route, setRoute] = useState<{ sector: string | undefined; coordinates: LatLngTuple[] } | null>(null);
  const [routeError, setRouteError] = useState("");
  const [attempt, setAttempt] = useState(0);
  const destination = useMemo(() => getGuayaquilSectorCoordinates(sector), [sector]);
  const origin: LatLngTuple = [GUAYAQUIL_HUB.latitude, GUAYAQUIL_HUB.longitude];
  const coordinates = route && route.sector === sector ? route.coordinates : null;
  const progress = getTrackingProgress(tracking, now);
  const position = coordinates ? positionAlongRoute(coordinates, progress) : null;

  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    const timeout = window.setTimeout(() => controller.abort(), 12000);
    setRoute(null);
    setRouteError("");
    const routeUrl = createOsrmRouteUrl(
      [GUAYAQUIL_HUB.latitude, GUAYAQUIL_HUB.longitude],
      [destination.latitude, destination.longitude],
    );

    void fetch(routeUrl, { signal: controller.signal })
      .then(async (response) => {
        if (!response.ok) throw new Error("No se pudo consultar la ruta vial.");
        const result: unknown = await response.json();
        const parsed = parseOsrmRoute(result);
        if (active) setRoute({ sector, coordinates: parsed.coordinates });
      })
      .catch(() => {
        if (active) setRouteError("No se pudo cargar la ruta por las calles. Comprueba la conexión o el certificado del servicio e intenta nuevamente.");
      })
      .finally(() => window.clearTimeout(timeout));

    return () => {
      active = false;
      window.clearTimeout(timeout);
      controller.abort();
    };
  }, [destination, sector, attempt]);

  useEffect(() => {
    setNow(Date.now());
    if (tracking.endedAt !== null) return;
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, [tracking.startedAt, tracking.endedAt]);

  return (
    <section className="delivery-route-card" aria-label="Mapa y seguimiento de ruta">
      <header className="delivery-route-map-header">
        <div>
          <strong>Ruta de {tracking.orderId}</strong>
          <p>{tracking.endedAt === null ? "Recorrido simulado en curso" : "Recorrido simulado finalizado"}</p>
        </div>
        <span className="delivery-tracking-badge is-simulated">Simulación · {Math.round(progress * 100)} %</span>
      </header>
      <div className="delivery-route-map">
        <MapContainer center={origin} zoom={12} scrollWheelZoom={false} aria-label="Mapa de la ruta simulada">
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            eventHandlers={{ tileerror: () => setTilesUnavailable(true) }}
          />
          {coordinates && <FitRouteBounds coordinates={coordinates} />}
          {coordinates && <Polyline positions={coordinates} pathOptions={{ color: "#245c4b", weight: 5, opacity: 0.8 }} />}
          <CircleMarker center={coordinates?.[0] ?? origin} radius={8} pathOptions={{ color: "#fff", weight: 3, fillColor: "#245c4b", fillOpacity: 1 }}>
            <Tooltip permanent direction="top">Empresa</Tooltip>
          </CircleMarker>
          <CircleMarker center={coordinates?.[coordinates.length - 1] ?? [destination.latitude, destination.longitude]} radius={8} pathOptions={{ color: "#fff", weight: 3, fillColor: "#d97706", fillOpacity: 1 }}>
            <Tooltip permanent direction="top">Destino aproximado</Tooltip>
          </CircleMarker>
          {position && <CircleMarker center={position} radius={7} pathOptions={{ color: "#fff", weight: 3, fillColor: "#2563eb", fillOpacity: 1 }}>
            <Tooltip permanent direction="top">Repartidor simulado</Tooltip>
          </CircleMarker>}
        </MapContainer>
      </div>
      <p className="delivery-route-privacy">
        Recorrido vial y posición simulada, no GPS real. El origen es de demostración y el destino corresponde al centro aproximado del sector.
      </p>
      {routeError ? (
        <div className="delivery-route-privacy" role="alert">
          {routeError}{" "}
          <button type="button" className="deliveries-secondary-button" onClick={() => setAttempt((value) => value + 1)}>Reintentar</button>
        </div>
      ) : !coordinates && <p className="delivery-route-privacy" role="status">Consultando la ruta por las calles...</p>}
      {tilesUnavailable && <p className="delivery-route-privacy" role="status">No se pudo cargar el mapa base.</p>}
      <span className="delivery-map-credit">Mapa © OpenStreetMap contributors · Ruta vial de OSRM</span>
    </section>
  );
}
