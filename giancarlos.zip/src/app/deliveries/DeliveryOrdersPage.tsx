"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { Check, MapPin, Pencil, RotateCw, Send, Truck, X } from "lucide-react";
import { useAccessMenu } from "@/components/access-menu-context";
import {
  readDeliveryAssignments,
  readDeliveryRequests,
  formatDeliveryPrice,
  parseDeliveryPrice,
  setDeliveryPrice,
  updateDeliveryAssignment,
  type DeliveryAssignment,
  type DeliveryRequest,
} from "./delivery-requests-store";
import { readDeliveryDrivers, type DeliveryDriver } from "./deliveries-store";
import { TRACKING_UPDATED_EVENT } from "./delivery-tracking-store";
import "./deliveries.css";

type DeliveryRequestRow = DeliveryRequest & { assignment: DeliveryAssignment };

const emptyAssignment: DeliveryAssignment = { driverId: "", confirmed: false, published: false };
const currencyFormatter = new Intl.NumberFormat("es-EC", {
  style: "currency",
  currency: "USD",
});

function formatDate(value: string): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? value
    : date.toLocaleString("es-EC", { dateStyle: "short", timeStyle: "short" });
}

function getDestination(request: DeliveryRequest): string {
  const { fulfillment } = request;
  return [
    [fulfillment.sector, fulfillment.direccion, fulfillment.ciudad].filter(Boolean).join(" · "),
    fulfillment.referencia ? `Ref: ${fulfillment.referencia}` : "",
  ].filter(Boolean).join(" · ");
}

export default function DeliveryOrdersPage() {
  const { options, globalActions, loading: accessLoading, error: accessError } = useAccessMenu();
  const actions = globalActions | (options.find((option) => option.ruta === "/deliveries/pedidos")?.actions
    ?? options.find((option) => option.ruta === "/deliveries")?.actions
    ?? options.find((option) => option.ruta === "/empresa")?.actions
    ?? 0);
  const canView = (actions & 1) === 1;
  const canAssign = (actions & 2) === 2;
  const [orders, setOrders] = useState<DeliveryRequestRow[]>([]);
  const [drivers, setDrivers] = useState<DeliveryDriver[]>([]);
  const [draftDriverIds, setDraftDriverIds] = useState<Record<string, string>>({});
  const [draftPrices, setDraftPrices] = useState<Record<string, string>>({});
  const [editingRequestKey, setEditingRequestKey] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [usingDemoOrders, setUsingDemoOrders] = useState(false);
  const [demoNotice, setDemoNotice] = useState("");
  const [successNotice, setSuccessNotice] = useState("");
  const [error, setError] = useState("");

  const refresh = useCallback(() => {
    setLoading(true);
    let requestData: ReturnType<typeof readDeliveryRequests> = { requests: [], usingDemo: false };
    let storedAssignments: Record<string, DeliveryAssignment> = {};
    let activeDrivers: DeliveryDriver[] = [];
    const warnings: string[] = [];

    try {
      requestData = readDeliveryRequests();
    } catch (loadError) {
      warnings.push(loadError instanceof Error ? loadError.message : "No se pudieron leer los pedidos locales.");
    }

    try {
      storedAssignments = readDeliveryAssignments();
    } catch (loadError) {
      warnings.push(loadError instanceof Error ? loadError.message : "No se pudieron leer las asignaciones guardadas.");
    }

    try {
      activeDrivers = readDeliveryDrivers().filter((driver) => driver.estado === "ACTIVO");
    } catch (loadError) {
      warnings.push(loadError instanceof Error ? loadError.message : "No se pudo leer la lista local de repartidores.");
    }

    const nextOrders = requestData.requests
      .map((request) => ({
        ...request,
        assignment: storedAssignments[request.requestKey] ?? { ...emptyAssignment },
      }))
      .sort((first, second) => Date.parse(second.date) - Date.parse(first.date));

    setOrders(nextOrders);
    setDrivers(activeDrivers);
    setDraftDriverIds(Object.fromEntries(nextOrders.map((order) => [
      order.requestKey,
      order.assignment.driverId,
    ])));
    setDraftPrices(Object.fromEntries(nextOrders.map((order) => [
      order.requestKey, order.assignment.priceCents === undefined ? "" : (order.assignment.priceCents / 100).toFixed(2),
    ])));
    setEditingRequestKey(null);
    setUsingDemoOrders(requestData.usingDemo);
    setDemoNotice(requestData.usingDemo
      ? "Se muestran solicitudes de demostración junto a los pedidos locales con entrega."
      : "");
    setSuccessNotice("");
    setError(warnings.join(" "));
    setLoading(false);
  }, []);

  useEffect(() => {
    if (accessLoading) return;
    if (accessError || !canView) {
      setLoading(false);
      setOrders([]);
      setDrivers([]);
      return;
    }
    refresh();
    window.addEventListener("customer-orders-updated", refresh);
    window.addEventListener("delivery-assignments-updated", refresh);
    window.addEventListener(TRACKING_UPDATED_EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener("customer-orders-updated", refresh);
      window.removeEventListener("delivery-assignments-updated", refresh);
      window.removeEventListener(TRACKING_UPDATED_EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, [accessError, accessLoading, canView, refresh]);

  const confirmedCount = useMemo(
    () => orders.filter((order) => order.assignment.confirmed).length,
    [orders],
  );
  const publishedCount = useMemo(
    () => orders.filter((order) => order.assignment.published).length,
    [orders],
  );

  async function persistAssignment(
    order: DeliveryRequestRow,
    next: DeliveryAssignment,
    successMessage: string,
  ) {
    setSavingKey(order.requestKey);
    try {
      await updateDeliveryAssignment(order.requestKey, order.assignment, next);
      setSuccessNotice(successMessage);
      setError("");
      setEditingRequestKey(null);
    } catch (saveError) {
      refresh();
      setError(saveError instanceof Error ? saveError.message : "No se pudo guardar la asignación en este navegador.");
    } finally {
      setSavingKey(null);
    }
  }

  async function confirmAssignment(order: DeliveryRequestRow) {
    const driverId = draftDriverIds[order.requestKey] ?? "";
    if (!drivers.some((driver) => driver.id === driverId)) {
      setError("Selecciona un repartidor activo antes de confirmar la asignación.");
      return;
    }
    await persistAssignment(order, { ...order.assignment, driverId, confirmed: true, published: false }, "La asignación quedó confirmada en este navegador.");
  }

  async function savePrice(order: DeliveryRequestRow) {
    setSavingKey(order.requestKey);
    try {
      await setDeliveryPrice(order.requestKey, parseDeliveryPrice(draftPrices[order.requestKey] ?? ""), "company");
      setError("");
      setSuccessNotice(`Valor de envío del pedido ${order.orderId} actualizado en este navegador.`);
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "No se pudo guardar el valor de envío.");
    } finally {
      setSavingKey(null);
    }
  }

  async function togglePublished(order: DeliveryRequestRow) {
    if (order.assignment.driverId && !order.assignment.confirmed) {
      setError("Confirma la asignación antes de publicar la ruta.");
      return;
    }
    const driver = drivers.find((candidate) => candidate.id === order.assignment.driverId);
    if (!order.assignment.published && order.assignment.driverId && !driver?.accountEmail) {
      setError("Este repartidor no tiene una cuenta vinculada al portal.");
      return;
    }
    const nextAssignment = { ...order.assignment, published: !order.assignment.published };
    await persistAssignment(
      order,
      nextAssignment,
      nextAssignment.published
        ? order.assignment.driverId ? "La ruta fue publicada para la cuenta del repartidor." : "La ruta fue publicada para que un repartidor pueda tomarla."
        : "La ruta dejó de estar publicada.",
    );
  }

  return (
    <div className="deliveries-page">
      <header className="deliveries-header">
        <div>
          <span className="deliveries-eyebrow"><Truck size={15} /> ORGANIZACIÓN</span>
          <h1>Pedidos de entrega</h1>
          <p>Publica rutas sin asignar para que un repartidor las tome, o confirma y publica una asignación directa.</p>
        </div>
        <button type="button" className="deliveries-secondary-button" onClick={refresh} disabled={loading || accessLoading || !!accessError || !canView}>
          <RotateCw size={15} /> Actualizar
        </button>
      </header>

      {accessLoading ? (
        <p className="deliveries-demo-note" role="status">Validando permisos de acceso...</p>
      ) : accessError ? (
        <div className="deliveries-alert" role="alert">{accessError}</div>
      ) : !canView ? (
        <div className="deliveries-alert" role="alert">No tienes permiso para consultar pedidos de entrega.</div>
      ) : (
        <>
          {usingDemoOrders && <p className="deliveries-demo-note" role="status">{demoNotice}</p>}
          {successNotice && <div className="deliveries-notice" role="status">{successNotice}</div>}
          {error && <div className="deliveries-alert" role="alert">{error}</div>}

          <section className="deliveries-summary deliveries-orders-summary" aria-label="Resumen de pedidos de entrega">
            <article><span>Pedidos con entrega</span><strong>{loading ? "—" : orders.length}</strong></article>
            <article><span>Asignaciones confirmadas</span><strong>{loading ? "—" : confirmedCount}</strong></article>
            <article><span>Rutas publicadas</span><strong>{loading ? "—" : publishedCount}</strong></article>
          </section>

          <section className="deliveries-card">
            <div className="deliveries-toolbar">
              <div>
                <h2>Solicitudes de entrega</h2>
                <p>{loading ? "Cargando pedidos..." : `${orders.length} pedido${orders.length === 1 ? "" : "s"}`}</p>
              </div>
            </div>
            <div className="deliveries-table-wrap">
              <table className="deliveries-table deliveries-orders-table">
                <thead>
                  <tr>
                    <th scope="col">Pedido</th>
                    <th scope="col">Empresa</th>
                    <th scope="col">Fecha</th>
                    <th scope="col">Cliente</th>
                    <th scope="col">Destino</th>
                    <th scope="col">Productos</th>
                    <th scope="col">Total</th>
                    <th scope="col">Valor de envío</th>
                    <th scope="col">Estado</th>
                    <th scope="col">Repartidor / cuenta</th>
                    <th scope="col">Asignación</th>
                    <th scope="col">Publicación</th>
                    <th scope="col">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr><td colSpan={13} className="deliveries-empty">Cargando pedidos de entrega...</td></tr>
                  ) : orders.length === 0 ? (
                    <tr><td colSpan={13} className="deliveries-empty">No hay pedidos que soliciten entrega.</td></tr>
                  ) : orders.map((order) => {
                    const isEditing = editingRequestKey === order.requestKey;
                    const selectedDriverId = isEditing || !order.assignment.confirmed
                      ? draftDriverIds[order.requestKey] ?? order.assignment.driverId
                      : order.assignment.driverId;
                    const selectedDriver = drivers.find((driver) => driver.id === selectedDriverId);
                    return (
                      <tr key={order.requestKey}>
                        <td><strong>{order.orderId}</strong>{order.isDemo && <small className="deliveries-table-subline">Demostración</small>}</td>
                        <td>{order.companyName}</td>
                        <td>{formatDate(order.date)}</td>
                        <td>{order.customer}</td>
                        <td><span className="deliveries-order-destination"><MapPin size={14} />{getDestination(order)}</span></td>
                        <td className="deliveries-order-products">
                          {order.items.map((item) => `${item.quantity} × ${item.name}`).join(", ") || "Sin detalle"}
                        </td>
                        <td>{currencyFormatter.format(order.total)}</td>
                        <td>
                          {canAssign ? (
                            <>
                              <input className="deliveries-order-driver-select" type="number" min="0" max="1000000" step="0.01"
                                aria-label={`Valor de envío del pedido ${order.orderId}`}
                                value={draftPrices[order.requestKey] ?? ""}
                                disabled={order.status === "ENTREGADO" || Boolean(order.assignment.offers?.length || order.assignment.customerAccepted) || savingKey === order.requestKey}
                                onChange={(event) => setDraftPrices((current) => ({ ...current, [order.requestKey]: event.target.value }))} />
                              <button type="button" className="deliveries-action-button" disabled={order.status === "ENTREGADO" || Boolean(order.assignment.offers?.length || order.assignment.customerAccepted) || savingKey === order.requestKey}
                                onClick={() => void savePrice(order)}>Guardar valor</button>
                            </>
                          ) : order.assignment.priceCents === undefined ? "Sin definir" : formatDeliveryPrice(order.assignment.priceCents)}
                          {order.assignment.offers?.map((offer) => <small key={offer.id} className="deliveries-table-subline">Oferta pendiente: {formatDeliveryPrice(offer.priceCents)} · {drivers.find((driver) => driver.id === offer.driverId)?.nombre ?? "Repartidor no disponible"}</small>)}
                          {order.assignment.customerAccepted && <small className="deliveries-table-subline">Oferta aceptada por el cliente</small>}
                        </td>
                        <td><span className="deliveries-order-state">{order.status}</span>
                          {order.proofPhoto && <details className="delivery-proof">
                            <summary>Ver foto de recepción</summary>
                            <Image className="delivery-proof-photo" src={order.proofPhoto} alt={`Foto de recepción del pedido ${order.orderId}`} width={300} height={220} unoptimized />
                          </details>}
                        </td>
                        <td>
                          <select
                            className="deliveries-order-driver-select"
                            value={selectedDriverId}
                            disabled={order.status === "ENTREGADO" || !canAssign || savingKey === order.requestKey || drivers.length === 0 || (order.assignment.confirmed && !isEditing)}
                            onChange={(event) => setDraftDriverIds((current) => ({
                              ...current,
                              [order.requestKey]: event.target.value,
                            }))}
                            aria-label={`Asignar repartidor al pedido ${order.orderId}`}
                          >
                            <option value="">Sin asignar</option>
                            {selectedDriverId && !drivers.some((driver) => driver.id === selectedDriverId) && (
                              <option value={selectedDriverId} disabled>Repartidor no disponible</option>
                            )}
                            {drivers.map((driver) => (
                              <option value={driver.id} key={driver.id}>{driver.nombre} · {driver.placa}{driver.companySlugs?.includes(order.slug) ? "" : " · externo"}</option>
                            ))}
                          </select>
                          {selectedDriver?.accountEmail ? (
                            <small className="deliveries-table-subline">Cuenta: {selectedDriver.accountEmail}</small>
                          ) : selectedDriver ? (
                            <small className="deliveries-table-subline is-warning">Sin cuenta vinculada al portal</small>
                          ) : drivers.length === 0 ? (
                            <small className="deliveries-table-subline">Agrega un repartidor activo primero.</small>
                          ) : null}
                        </td>
                        <td>
                          <span className={`deliveries-publication-state${order.assignment.confirmed ? " is-confirmed" : ""}`}>
                            {order.assignment.confirmed ? "Confirmada" : "Pendiente"}
                          </span>
                        </td>
                        <td>
                          <span className={`deliveries-publication-state${order.assignment.published ? " is-published" : ""}`}>
                            {order.assignment.published ? "Publicada" : "No publicada"}
                          </span>
                        </td>
                        <td>
                          {order.status === "ENTREGADO" ? <span className="deliveries-table-subline">Entrega confirmada</span> : canAssign ? (
                            <div className="deliveries-order-actions">
                              {!order.assignment.confirmed || isEditing ? (
                                <button
                                  type="button"
                                  className="deliveries-action-button is-primary"
                                  disabled={!selectedDriver || savingKey === order.requestKey}
                                  onClick={() => void confirmAssignment(order)}
                                  title={isEditing ? "Confirmar cambios de asignación" : "Confirmar asignación"}
                                >
                                  <Check size={14} /> {isEditing ? "Confirmar cambios" : "Confirmar"}
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  className="deliveries-action-button"
                                  disabled={savingKey === order.requestKey}
                                  onClick={() => {
                                    setDraftDriverIds((current) => ({
                                      ...current,
                                      [order.requestKey]: order.assignment.driverId,
                                    }));
                                    setEditingRequestKey(order.requestKey);
                                  }}
                                >
                                  <Pencil size={14} /> Editar
                                </button>
                              )}
                              {isEditing && (
                                <button
                                  type="button"
                                  className="deliveries-action-button"
                                  onClick={() => {
                                    setDraftDriverIds((current) => ({
                                      ...current,
                                      [order.requestKey]: order.assignment.driverId,
                                    }));
                                    setEditingRequestKey(null);
                                  }}
                                >
                                  <X size={14} /> Cancelar
                                </button>
                              )}
                              {!isEditing && (
                                <button
                                  type="button"
                                  className={`deliveries-action-button${order.assignment.published ? " is-published" : " is-primary"}`}
                                  disabled={savingKey === order.requestKey || (!order.assignment.published && (order.assignment.confirmed
                                    ? !drivers.find((driver) => driver.id === order.assignment.driverId)?.accountEmail
                                    : Boolean(selectedDriverId)))}
                                  onClick={() => void togglePublished(order)}
                                  title={order.assignment.published ? "Retirar la ruta del portal" : "Publicar ruta en el portal"}
                                >
                                  <Send size={14} /> {order.assignment.published ? "Retirar" : "Publicar"}
                                </button>
                              )}
                            </div>
                          ) : (
                            <span className="deliveries-table-subline">Solo lectura</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
    </div>
  );
}
