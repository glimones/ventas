export const GUAYAQUIL_HUB = { latitude: -2.1709, longitude: -79.9223 };

export const GUAYAQUIL_SECTORS = [
  { name: "Alborada", latitude: -2.143, longitude: -79.899 },
  { name: "Ceibos", latitude: -2.151, longitude: -79.928 },
  { name: "Centro", latitude: -2.194, longitude: -79.885 },
  { name: "Centenario", latitude: -2.204, longitude: -79.893 },
  { name: "Floresta", latitude: -2.234, longitude: -79.908 },
  { name: "Garzota", latitude: -2.143, longitude: -79.902 },
  { name: "Guasmo", latitude: -2.275, longitude: -79.891 },
  { name: "Guayacanes", latitude: -2.13, longitude: -79.904 },
  { name: "Kennedy", latitude: -2.169, longitude: -79.899 },
  { name: "Mucho Lote", latitude: -2.112, longitude: -79.916 },
  { name: "Puerto Santa Ana", latitude: -2.18, longitude: -79.875 },
  { name: "Samanes", latitude: -2.125, longitude: -79.915 },
  { name: "Sauces", latitude: -2.137, longitude: -79.906 },
  { name: "Urdesa", latitude: -2.17, longitude: -79.91 },
  { name: "Vía a la Costa", latitude: -2.158, longitude: -79.99 },
  { name: "Otro sector de Guayaquil", latitude: -2.194, longitude: -79.885 },
] as const;

export type GuayaquilSectorName = (typeof GUAYAQUIL_SECTORS)[number]["name"];

export function getGuayaquilSectorCoordinates(sector?: string) {
  return GUAYAQUIL_SECTORS.find((location) => location.name === sector)
    ?? GUAYAQUIL_SECTORS.find((location) => location.name === "Centro")!;
}
