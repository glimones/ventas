"use client";

import { useEffect, useMemo, useState } from "react";
import type { LatLngTuple } from "leaflet";
import {
  CircleMarker,
  MapContainer,
  Polyline,
  TileLayer,
  Tooltip,
  useMap,
} from "react-leaflet";
import { getGuayaquilSectorCoordinates, GUAYAQUIL_HUB } from "./guayaquil-sectors";
import { createOsrmRouteUrl, parseOsrmRoute } from "./delivery-road-route";
import type { DeliveryRequest } from "./delivery-requests-store";

export interface DeliveryRouteMapProps {
  request: DeliveryRequest;
}

function FitRouteBounds({ coordinates }: { coordinates: LatLngTuple[] }) {
  const map = useMap();
  useEffect(() => {
    if (coordinates.length > 1) map.fitBounds(coordinates, { padding: [40, 40], maxZoom: 14 });
  }, [coordinates, map]);
  return null;
}

export default function DeliveryRouteMap({ request }: DeliveryRouteMapProps) {
  const destination = useMemo(
    () => getGuayaquilSectorCoordinates(request.fulfillment.sector),
    [request.fulfillment.sector],
  );
  const initialRoute = useMemo<LatLngTuple[]>(() => [
    [GUAYAQUIL_HUB.latitude, GUAYAQUIL_HUB.longitude],
    [destination.latitude, destination.longitude],
  ], [destination]);
  const [routeCoordinates, setRouteCoordinates] = useState<LatLngTuple[]>(initialRoute);
  const [routeStatus, setRouteStatus] = useState("Consultando la ruta aproximada...");
  const [routeSummary, setRouteSummary] = useState("");
  const [trackingMode, setTrackingMode] = useState<"searching" | "gps" | "simulated">("searching");
  const [currentPosition, setCurrentPosition] = useState<LatLngTuple | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    setRouteCoordinates(initialRoute);
    setRouteStatus("Consultando la ruta aproximada...");
    setRouteSummary("");

    const routeUrl = createOsrmRouteUrl(
      [GUAYAQUIL_HUB.latitude, GUAYAQUIL_HUB.longitude],
      [destination.latitude, destination.longitude],
    );

    void fetch(routeUrl, { signal: controller.signal })
      .then(async (response) => {
        if (!response.ok) throw new Error("No se pudo consultar la ruta vial.");
        const result: unknown = await response.json();
        const route = parseOsrmRoute(result);
        setRouteCoordinates(route.coordinates);
        setRouteStatus("Ruta vial aproximada cargada.");
        if (typeof route.distance === "number" && typeof route.duration === "number") {
          setRouteSummary(`${(route.distance / 1000).toFixed(1)} km · ${Math.max(1, Math.round(route.duration / 60))} min estimados`);
        }
      })
      .catch((routeError: unknown) => {
        if (controller.signal.aborted) return;
        setRouteCoordinates(initialRoute);
        setRouteStatus(routeError instanceof Error
          ? "Servicio de rutas no disponible; se muestra una línea aproximada."
          : "No se pudo consultar la ruta; se muestra una línea aproximada.");
      });

    return () => controller.abort();
  }, [destination, initialRoute]);

  useEffect(() => {
    let receivedPosition = false;
    let watchId: number | null = null;
    const fallbackTimer = window.setTimeout(() => {
      if (!receivedPosition) setTrackingMode("simulated");
    }, 8000);

    if (!navigator.geolocation) {
      window.clearTimeout(fallbackTimer);
      setTrackingMode("simulated");
      return () => window.clearTimeout(fallbackTimer);
    }

    watchId = navigator.geolocation.watchPosition(
      (position) => {
        receivedPosition = true;
        window.clearTimeout(fallbackTimer);
        setCurrentPosition([position.coords.latitude, position.coords.longitude]);
        setTrackingMode("gps");
      },
      () => {
        window.clearTimeout(fallbackTimer);
        setTrackingMode("simulated");
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 },
    );

    return () => {
      window.clearTimeout(fallbackTimer);
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
    };
  }, []);

  useEffect(() => {
    if (trackingMode !== "simulated") return;
    let index = 0;
    const step = Math.max(1, Math.ceil((routeCoordinates.length - 1) / 24));
    setCurrentPosition(routeCoordinates[0]);
    const timer = window.setInterval(() => {
      index = Math.min(routeCoordinates.length - 1, index + step);
      setCurrentPosition(routeCoordinates[index]);
      if (index >= routeCoordinates.length - 1) window.clearInterval(timer);
    }, 1500);
    return () => window.clearInterval(timer);
  }, [routeCoordinates, trackingMode]);

  return (
    <section className="delivery-route-card" aria-label="Mapa y seguimiento de ruta">
      <header className="delivery-route-map-header">
        <div>
          <strong>Ruta de {request.orderId}</strong>
          <p>{routeSummary || routeStatus}</p>
        </div>
        <span className={`delivery-tracking-badge is-${trackingMode}`}>
          {trackingMode === "gps" ? "GPS activo" : trackingMode === "simulated" ? "Seguimiento simulado" : "Buscando GPS"}
        </span>
      </header>
      <div className="delivery-route-map">
        <MapContainer
          center={initialRoute[0]}
          zoom={12}
          scrollWheelZoom={false}
          aria-label="Mapa de la ruta del repartidor"
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <FitRouteBounds coordinates={routeCoordinates} />
          <Polyline positions={routeCoordinates} pathOptions={{ color: "#245c4b", weight: 5, opacity: 0.8 }} />
          <CircleMarker center={initialRoute[0]} radius={8} pathOptions={{ color: "#fff", weight: 3, fillColor: "#245c4b", fillOpacity: 1 }}>
            <Tooltip permanent direction="top">Empresa</Tooltip>
          </CircleMarker>
          <CircleMarker center={initialRoute[1]} radius={8} pathOptions={{ color: "#fff", weight: 3, fillColor: "#d97706", fillOpacity: 1 }}>
            <Tooltip permanent direction="top">Destino aproximado</Tooltip>
          </CircleMarker>
          {currentPosition && (
            <CircleMarker center={currentPosition} radius={7} pathOptions={{ color: "#fff", weight: 3, fillColor: "#2563eb", fillOpacity: 1 }}>
              <Tooltip direction="top">Repartidor</Tooltip>
            </CircleMarker>
          )}
        </MapContainer>
      </div>
      <p className="delivery-route-privacy">
        El destino se aproxima al centro del sector. La dirección exacta no se envía al servicio de rutas;
        la ubicación GPS se muestra en este navegador y no se guarda ni comparte.
      </p>
      <span className="delivery-map-credit">Mapa © OpenStreetMap contributors · Ruta vial de OSRM (servicio comunitario)</span>
      {trackingMode === "searching" && <span className="sr-only" role="status">Solicitando acceso al GPS del dispositivo.</span>}
      {trackingMode === "simulated" && <span className="sr-only" role="status">GPS no disponible; se muestra un recorrido simulado.</span>}
    </section>
  );
}
