import { NextResponse } from "next/server";
import { getDatabasePool } from "@/lib/db";
import { findCompanyBySlug } from "@/services/clientes-web.service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  context: { params: Promise<{ slug: string }> },
) {
  const { slug } = await context.params;
  const company = await findCompanyBySlug(slug);
  if (!company) return NextResponse.json({ error: "Empresa no encontrada." }, { status: 404 });

  const result = await getDatabasePool().query<{
    id: string;
    codigo: string;
    nombre: string;
    direccion: string | null;
    ciudad: string | null;
  }>(
    `SELECT id::text, codigo, nombre, direccion, ciudad
     FROM sucursales
     WHERE empresa_id = $1 AND estado = 'ACTIVA'
     ORDER BY nombre, codigo`,
    [company.id],
  );

  return NextResponse.json({
    data: result.rows.map((branch) => ({
      ...branch,
      id: Number(branch.id),
      direccion: branch.direccion ?? "",
      ciudad: branch.ciudad ?? "",
    })),
  });
}
